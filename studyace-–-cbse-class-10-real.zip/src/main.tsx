import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Suppress benign Vite HMR websocket errors that can appear as unhandled rejections
window.addEventListener('unhandledrejection', (event) => {
  if (
    event.reason?.message?.includes?.('WebSocket') || 
    event.reason?.includes?.('WebSocket') ||
    (typeof event.reason === 'string' && event.reason.includes('WebSocket'))
  ) {
    event.preventDefault();
  }
});

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
