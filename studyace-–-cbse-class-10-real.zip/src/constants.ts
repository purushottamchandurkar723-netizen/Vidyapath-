/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Subject } from './types';

export const SUBJECTS: Record<string, Subject> = {
  maths: {
    key: 'maths',
    label: 'Mathematics',
    icon: '📐',
    color: '#4F46E5',
    light: '#EEF2FF',
    chapters: [
      { name: 'Real Numbers' },
      { name: 'Polynomials' },
      { name: 'Pair of Linear Equations in Two Variables' },
      { name: 'Quadratic Equations' },
      { name: 'Arithmetic Progressions' },
      { name: 'Triangles' },
      { name: 'Coordinate Geometry' },
      { name: 'Introduction to Trigonometry' },
      { name: 'Applications of Trigonometry' },
      { name: 'Circles' },
      { name: 'Areas Related to Circles' },
      { name: 'Surface Areas and Volumes' },
      { name: 'Statistics' },
      { name: 'Probability' }
    ]
  },
  science: {
    key: 'science',
    label: 'Science',
    icon: '🔬',
    color: '#059669',
    light: '#ECFDF5',
    chapters: [
      { name: 'Chemical Reactions and Equations' },
      { name: 'Acid, Bases and Salts' },
      { name: 'Metals and Non-metals' },
      { name: 'Carbon and Its Compounds' },
      { name: 'Life Processes' },
      { name: 'Control and Coordination' },
      { name: 'How Do Organisms Reproduce?' },
      { name: 'Heredity' },
      { name: 'Light – Reflection and Refraction' },
      { name: 'The Human Eye and the Colourful World' },
      { name: 'Electricity' },
      { name: 'Magnetic Effects of Electric Current' },
      { name: 'Our Environment' }
    ]
  },
  sst: {
    key: 'sst',
    label: 'Social Studies',
    icon: '🌏',
    color: '#D97706',
    light: '#FFFBEB',
    chapters: [
      { name: 'The Rise of Nationalism in Europe' },
      { name: 'Nationalism in India' },
      { name: 'The Making of a Global World' },
      { name: 'The Age of Industrialisation' },
      { name: 'Print Culture and the Modern World' },
      { name: 'Resources and Development' },
      { name: 'Forest and Wildlife Resources' },
      { name: 'Water Resources' },
      { name: 'Agriculture' },
      { name: 'Minerals and Energy Resources' },
      { name: 'Manufacturing Industries' },
      { name: 'Lifelines of National Economy' },
      { name: 'Power Sharing' },
      { name: 'Federalism' },
      { name: 'Democracy and Diversity' },
      { name: 'Gender, Religion and Caste' },
      { name: 'Political Parties' },
      { name: 'Outcomes of Democracy' },
      { name: 'Development' },
      { name: 'Sectors of the Indian Economy' },
      { name: 'Money and Credit' },
      { name: 'Globalisation and the Indian Economy' }
    ]
  },
  english: {
    key: 'english',
    label: 'English',
    icon: '📖',
    color: '#DB2777',
    light: '#FDF2F8',
    chapters: [
      { name: 'A Letter to God' },
      { name: 'Nelson Mandela: Long Walk to Freedom' },
      { name: 'Two Stories about Flying' },
      { name: 'From the Diary of Anne Frank' },
      { name: 'Glimpses of India' },
      { name: 'Mijbil the Otter' },
      { name: 'Madam Rides the Bus' },
      { name: 'The Sermon at Benares' },
      { name: 'The Proposal' },
      { name: 'A Triumph of Surgery' },
      { name: "The Thief's Story" },
      { name: 'Grammar & Writing Skills' }
    ]
  },
  hindi: {
    key: 'hindi',
    label: 'Hindi Course A',
    icon: '✍️',
    color: '#E8500A',
    light: '#FFF8F4',
    chapters: [
      { name: 'सूरदास के पद' },
      { name: 'राम-लक्ष्मण-परशुराम संवाद' },
      { name: 'देव के सवैये और कवित्त' },
      { name: 'जयशंकर प्रसाद – आत्मकथ्य' },
      { name: 'सूर्यकांत त्रिपाठी निराला' },
      { name: 'नागार्जुन – यह दंतुरहित मुसकान' },
      { name: 'गिरिजाकुमार माथुर – छाया मत छूना' },
      { name: 'बालगोबिन भगत' },
      { name: 'लखनवी अंदाज़' },
      { name: 'एक कहानी यह भी' },
      { name: 'स्त्री शिक्षा के विरोधी' },
      { name: 'संस्कृति' },
      { name: 'माता का आँचल' },
      { name: 'व्याकरण – वाक्य, समास, छंद' }
    ]
  },
  hindi_b: {
    key: 'hindi_b',
    label: 'Hindi Course B',
    icon: '📚',
    color: '#F97316',
    light: '#FFF7ED',
    chapters: [
      { name: 'कबीर – साखी' },
      { name: 'मीरा – पद' },
      { name: 'बिहारी – दोहे' },
      { name: 'मैथिलीशरण गुप्त – मनुष्यता' },
      { name: 'सुमित्रानंदन पंत – पर्वत प्रदेश में पावस' },
      { name: 'तोप (वीरेन डंगवाल)' },
      { name: 'आत्मत्राण (रवींद्रनाथ ठाकुर)' },
      { name: 'बड़े भाई साहब (प्रेमचंद)' },
      { name: 'डायरी का एक पन्ना' },
      { name: 'तताँरा-वामीरो कथा' },
      { name: 'तीसरी कसम के शिल्पकार शैलेंद्र' },
      { name: 'अब कहाँ दूसरे के दुख से दुखी होने वाले' },
      { name: 'पतझड़ में टूटी पत्तियाँ' },
      { name: 'कारतूस (हबीब तनवीर)' },
      { name: 'हरिहर काका' },
      { name: 'सपनों के-से दिन' },
      { name: 'टोपी शुक्ला' },
      { name: 'व्याकरण – पदबंध, समास, मुहावरे' }
    ]
  },
  marathi: {
    key: 'marathi',
    label: 'Marathi (अक्षरभारती)',
    icon: '🪔',
    color: '#7C3AED',
    light: '#F5F3FF',
    chapters: [
      { name: 'तू बुद्धी दे (प्रार्थना)' },
      { name: 'संतवाणी: (अ) अंकिला मी दास तुझा, (आ) योगी सर्वकाळ सुखदाता' },
      { name: 'शाल (रा. ग. जाधव)' },
      { name: 'उपास (पु. ल. देशपांडे)' },
      { name: 'मोठ्यांचे बालपण (स्थूलवाचन)' },
      { name: 'दोन दिवस (कविता)' },
      { name: 'गवताचे पाते (वि. स. खांडेकर)' },
      { name: 'वाटणी (व्यंकटेश माडगूळकर)' },
      { name: 'आश्वासक चित्र (कविता)' },
      { name: 'रंग साहित्याचे' },
      { name: 'जंगल डायरी (अतुल धामणकर)' },
      { name: 'गोष्ट एका माणसाची (स्थूलवाचन)' },
      { name: 'आकाशी झेप घे रे (कविता)' },
      { name: 'खरा नागरिक (सुहास बारटक्के)' },
      { name: 'भरतवाक्य (कविता)' },
      { name: 'कर्ते सुधारक कर्वे' },
      { name: 'व्युत्पत्ती कोश (स्थूलवाचन)' },
      { name: 'व्याकरण व भाषिक अभ्यास (समास, वाक्प्रचार, शब्दसंपत्ती)' },
      { name: 'उपयोजित लेखन (पत्रलेखन, सारांश, बातमी, निबंध)' }
    ]
  }
};

export const ALL_CBSE_CHAPTERS = Object.values(SUBJECTS).flatMap(sub => 
  sub.chapters.map(ch => ({ subject: sub.label, chapter: ch.name }))
);
