/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { auth } from "./firebase";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function loadItem<T>(key: string, defaultValue: T): T {
  try {
    // Determine user-scoped key if logged in
    const currentUser = auth?.currentUser;
    const scopedKey = currentUser ? `${currentUser.uid}_${key}` : `guest_${key}`;
    
    let saved = localStorage.getItem(scopedKey);
    
    // Fallback logic for graceful transition
    if (saved === null) {
      // Check legacy global key (for upgrading local-only guest user logs)
      const legacySaved = localStorage.getItem(key);
      if (legacySaved !== null) {
        // If a student just signed in, migrate their guest history to their account namespace
        if (currentUser) {
          localStorage.setItem(scopedKey, legacySaved);
        }
        saved = legacySaved;
      }
    }
    
    return saved ? JSON.parse(saved) : defaultValue;
  } catch (e) {
    return defaultValue;
  }
}

export function saveItem<T>(key: string, value: T): void {
  try {
    const currentUser = auth?.currentUser;
    const scopedKey = currentUser ? `${currentUser.uid}_${key}` : `guest_${key}`;
    
    localStorage.setItem(scopedKey, JSON.stringify(value));

    // Quietly schedule background cloud synchronization if authenticated
    if (currentUser) {
      import('../services/cloudSync')
        .then(({ enqueueCloudSync }) => {
          enqueueCloudSync(currentUser.uid, key, value);
        })
        .catch(err => console.error('[CloudSync] Dynamic import failure:', err));
    }
  } catch (e) {
    console.error('localStorage write failed:', e);
  }
}

export function normalizeAnswer(val: string): string {
  return String(val || '')
    .trim()
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .replace(/[.,;:!?]$/g, '');
}

export function isAnswerCorrect(selected: string | string[], correct: string | string[]): boolean {
  const sel = Array.isArray(selected) ? selected : [selected];
  const cor = Array.isArray(correct) ? correct : [correct];
  if (sel.length !== cor.length) return false;
  const s1 = [...sel].map(normalizeAnswer).sort();
  const s2 = [...cor].map(normalizeAnswer).sort();
  return s1.every((v, i) => v === s2[i]);
}
