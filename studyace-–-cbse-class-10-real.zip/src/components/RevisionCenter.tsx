/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Trophy, Flame, Calendar, AlertTriangle, CheckCircle2, Clock, 
  ArrowLeft, BookOpen, Sparkles, Brain, ListChecks, RefreshCw, 
  Play, ArrowRight, History, HelpCircle, Check, Award, Activity, 
  ChevronRight, AlertCircle, RefreshCcw, Smile
} from 'lucide-react';
import { cn, loadItem, saveItem } from '../lib/utils';
import { SUBJECTS } from '../constants';
import { 
  calculateChapterMastery, 
  updateChapterMasteryState, 
  getChapterMasteryState 
} from '../utils/masteryHelper';
import { recordEvent } from '../services/analytics';
import { 
  fetchQuestionsFromAI, 
  fetchStudyGuideForChapter, 
  fetchFormulasForChapter 
} from '../services/geminiService';

interface RevisionCenterProps {
  navigateTo: (s: any, subKey?: string | null, chIdx?: number | null, topic?: string | null, tab?: string | null) => void;
  showToast: (msg: string) => void;
}

interface RevisionItem {
  chapterName: string;
  subjectKey: string;
  subjectLabel: string;
  subjectIcon: string;
  subjectColor: string;
  completionDay: number;
  revisionsCount: number;
  dueDay: number;
  daysRemaining: number;
  status: 'due' | 'upcoming' | 'missed' | 'auto-rescheduled';
}

export default function RevisionCenter({ navigateTo, showToast }: RevisionCenterProps) {
  // Current planner state from local storage (synced with FastTrackPlanner)
  const [currentDay, setCurrentDay] = useState<number>(() => loadItem('vidypath_ft_day_val', 1));
  const [completedChapters, setCompletedChapters] = useState<Record<string, number>>(() => 
    loadItem('vidypath_ft_completed_chapters_val', {})
  );

  // Auto-reschedule configuration toggles
  const [autoRescheduleActive, setAutoRescheduleActive] = useState<boolean>(() => 
    loadItem('vidypath_rev_auto_reschedule', true)
  );
  
  // Rescheduled tracking (keep list of items we auto-rescheduled)
  const [rescheduledItems, setRescheduledItems] = useState<Record<string, boolean>>(() =>
    loadItem('vidypath_rev_rescheduled_items', {})
  );

  // Active revision days completed (to compute continuous streak)
  const [revisedDays, setRevisedDays] = useState<number[]>(() =>
    loadItem('vidypath_rev_completed_days', [])
  );

  // Active Quick Revision Item State
  const [activeRevItem, setActiveRevItem] = useState<RevisionItem | null>(null);
  
  // Quick Revision Sub-sections: 'notes' | 'tricks' | 'mistakes' | 'quiz' | 'complete'
  const [quickRevStep, setQuickRevStep] = useState<'notes' | 'tricks' | 'mistakes' | 'quiz' | 'complete'>('notes');

  // Loading and fetched states for Quick Revision
  const [isLoading, setIsLoading] = useState(false);
  const [studyGuide, setStudyGuide] = useState<any>(null);
  const [formulas, setFormulas] = useState<any[]>([]);
  const [quizQuestions, setQuizQuestions] = useState<any[]>([]);
  const [currentQuizIndex, setCurrentQuizIndex] = useState(0);
  const [quizAnswers, setQuizAnswers] = useState<Record<number, string>>({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [quizScore, setQuizScore] = useState(0);

  // Local mistake records
  const [chapterMistakes, setChapterMistakes] = useState<any[]>([]);
  const [selectedMistakeIndex, setSelectedMistakeIndex] = useState<number>(0);
  const [showMistakesAnswer, setShowMistakesAnswer] = useState<boolean>(false);

  // Rules for Spaced Repetition (Days from completion)
  const REVISION_INTERVALS = [3, 7, 15, 30];

  // Save basic states when they alter
  useEffect(() => {
    saveItem('vidypath_rev_auto_reschedule', autoRescheduleActive);
    saveItem('vidypath_rev_rescheduled_items', rescheduledItems);
    saveItem('vidypath_rev_completed_days', revisedDays);
  }, [autoRescheduleActive, rescheduledItems, revisedDays]);

  // Compute Streak logic
  const calculateStreak = () => {
    if (revisedDays.length === 0) return 0;
    const sortedDays = [...new Set(revisedDays)].sort((a, b) => a - b);
    
    // Check if streak still alive: max completed day must be today or yesterday
    const maxDayObj = sortedDays[sortedDays.length - 1];
    if (maxDayObj < currentDay - 1) {
      return 0; // Streak broken
    }

    let streak = 0;
    let checkDay = maxDayObj;
    
    while (sortedDays.includes(checkDay)) {
      streak++;
      checkDay--;
    }
    return streak;
  };

  const currentStreak = calculateStreak();

  // Load and reconcile all revision tasks
  const getRevisionItems = (): { due: RevisionItem[]; upcoming: RevisionItem[]; missed: RevisionItem[] } => {
    const dueList: RevisionItem[] = [];
    const upcomingList: RevisionItem[] = [];
    const missedList: RevisionItem[] = [];

    // Traverse all completed chapters
    Object.entries(completedChapters).forEach(([chapterName, compDay]) => {
      // Find its subject details
      let subKey = 'maths';
      let subLabel = 'Mathematics';
      let subIcon = '📐';
      let subColor = '#4F46E5';

      Object.entries(SUBJECTS).forEach(([key, sub]) => {
        if (sub.chapters.some(c => c.name === chapterName)) {
          subKey = key;
          subLabel = sub.label;
          subIcon = sub.icon;
          subColor = sub.color || '#4F46E5';
        }
      });

      // Get current revisions completed
      const mastery = calculateChapterMastery(subKey, chapterName);
      const revsCount = mastery.state.revisions_count;

      if (revsCount < 4) {
        const interval = REVISION_INTERVALS[revsCount];
        let originalDueDay = compDay + interval;
        let dueDay = originalDueDay;
        let isAutoRescheduled = false;

        // If missed and autoReschedule is active, push the target day to currentDay
        if (dueDay < currentDay && autoRescheduleActive) {
          dueDay = currentDay;
          isAutoRescheduled = true;
        }

        const daysRemaining = dueDay - currentDay;

        let status: 'due' | 'upcoming' | 'missed' | 'auto-rescheduled' = 'upcoming';
        if (isAutoRescheduled) {
          status = 'auto-rescheduled';
        } else if (daysRemaining === 0) {
          status = 'due';
        } else if (daysRemaining < 0) {
          status = 'missed';
        }

        const item: RevisionItem = {
          chapterName,
          subjectKey: subKey,
          subjectLabel: subLabel,
          subjectIcon: subIcon,
          subjectColor: subColor,
          completionDay: compDay,
          revisionsCount: revsCount,
          dueDay,
          daysRemaining,
          status
        };

        if (status === 'due' || status === 'auto-rescheduled') {
          dueList.push(item);
        } else if (status === 'upcoming') {
          upcomingList.push(item);
        } else if (status === 'missed') {
          missedList.push(item);
        }
      }
    });

    return { due: dueList, upcoming: upcomingList, missed: missedList };
  };

  const { due: dueToday, upcoming: upcomingRevs, missed: missedRevs } = getRevisionItems();

  // Handle Manual Rescheduling of a specific missed item
  const handleManualReschedule = (item: RevisionItem) => {
    // Shifting the completion day base so that the item becomes due today!
    const interval = REVISION_INTERVALS[item.revisionsCount];
    const newCompletionDay = currentDay - interval;
    
    const updatedCompleted = { ...completedChapters, [item.chapterName]: newCompletionDay };
    setCompletedChapters(updatedCompleted);
    saveItem('vidypath_ft_completed_chapters_val', updatedCompleted);
    
    setRescheduledItems(prev => ({ ...prev, [item.chapterName]: true }));
    showToast(`🔄 Auto-rescheduled ${item.chapterName} into Today's workload!`);
  };

  // Triggering Fast Quick Revision Session
  const startQuickRevision = async (item: RevisionItem) => {
    setActiveRevItem(item);
    setQuickRevStep('notes');
    setIsLoading(true);
    setStudyGuide(null);
    setFormulas([]);
    setQuizQuestions([]);
    setCurrentQuizIndex(0);
    setQuizAnswers({});
    setQuizSubmitted(false);
    setQuizScore(0);

    // Load static mistakes logged for this specific chapter
    const rawMistakes = loadItem<any[]>('vidypath_mistakes_v1', []);
    const filteredMistakes = rawMistakes.filter(m => 
      m.chapterName?.toLowerCase() === item.chapterName?.toLowerCase()
    );
    setChapterMistakes(filteredMistakes);
    setSelectedMistakeIndex(0);
    setShowMistakesAnswer(false);

    try {
      // Parallel fetches for speed & responsiveness
      const [guideData, formulaData, quizData] = await Promise.all([
        fetchStudyGuideForChapter(item.subjectLabel, item.chapterName).catch(() => null),
        fetchFormulasForChapter(item.subjectLabel, item.chapterName).catch(() => []),
        fetchQuestionsFromAI(item.subjectLabel, item.chapterName).catch(() => [])
      ]);

      setStudyGuide(guideData);
      setFormulas(formulaData);
      
      // Adaptively format quiz questions
      if (quizData && quizData.length > 0) {
        setQuizQuestions(quizData.slice(0, 5));
      } else {
        // High-yield offline backup quizzes
        setQuizQuestions(getOfflineBackupQuiz(item.chapterName, item.subjectLabel));
      }
    } catch (err) {
      console.error("AI fetch failed, loading offline-first models:", err);
      setQuizQuestions(getOfflineBackupQuiz(item.chapterName, item.subjectLabel));
    } finally {
      setIsLoading(false);
    }
  };

  // Offline failover question definitions
  const getOfflineBackupQuiz = (chapter: string, subject: string) => {
    return [
      {
        question: `What is the core examiner-expected sign convention or main law inside "${chapter}"?`,
        options: [
          "State formulas completely, showing parameters with standard SI units.",
          "Write only the final numerical number without steps.",
          "Ignore units entirely so computations are fast.",
          "Avoid neat diagrams to save writing space."
        ],
        answer: "State formulas completely, showing parameters with standard SI units."
      },
      {
        question: `For any Class 10 Board assessment regarding "${chapter}", what is recommended to earn maximum analytical marks?`,
        options: [
          "Explain the key conceptual working, draw a clear diagram, and solve numericals step-by-step.",
          "A simple copy-paste of textbook headlines.",
          "Leave hard equations blank.",
          "Use non-standard terminology and shortcuts."
        ],
        answer: "Explain the key conceptual working, draw a clear diagram, and solve numericals step-by-step."
      },
      {
        question: `Under standard NCERT curriculum, the concepts of "${chapter}" are mainly developed to evaluate:`,
        options: [
          "Competency-based analytical scenarios and basic applications",
          "Advanced college-level experimental proofs",
          "Literal rote learning of footnotes",
          "None of the above"
        ],
        answer: "Competency-based analytical scenarios and basic applications"
      },
      {
        question: `When labeling diagrams for "${chapter}", students must always verify that:`,
        options: [
          "Pencil is sharp, borders are straight, and label arrowheads point precisely to elements.",
          "They draw complex sketches in multi-colored sketch pens.",
          "They omit labeled indicators.",
          "Labels are placed overlapping the text borders."
        ],
        answer: "Pencil is sharp, borders are straight, and label arrowheads point precisely to elements."
      },
      {
        question: `Which activity is the most efficient daily revision tactic for "${chapter}"?`,
        options: [
          "Solving previous years' papers (PYQs) and correcting mistakes.",
          "Skimming textbook titles occasionally.",
          "Leaving chapter practice entirely for the final night.",
          "Memorizing answers without understanding steps."
        ],
        answer: "Solving previous years' papers (PYQs) and correcting mistakes."
      }
    ];
  };

  // Quiz interactive elements
  const handleOptionSelect = (opt: string) => {
    if (quizSubmitted) return;
    setQuizAnswers(prev => ({ ...prev, [currentQuizIndex]: opt }));
  };

  const submitQuiz = () => {
    if (quizQuestions.length === 0) return;
    let score = 0;
    quizQuestions.forEach((q, idx) => {
      if (quizAnswers[idx] === q.answer) {
        score++;
      }
    });
    setQuizScore(score);
    setQuizSubmitted(true);
  };

  // Complete revision, increment state and track streak
  const finalizeRevision = () => {
    if (!activeRevItem) return;

    const { subjectKey, chapterName } = activeRevItem;
    const state = getChapterMasteryState(subjectKey, chapterName);
    
    const newCount = Math.min(4, (state.revisions_count || 0) + 1);
    
    // Update the ChapterMasteryState revisions_count!
    updateChapterMasteryState(subjectKey, chapterName, {
      revisions_count: newCount
    });

    // Track revision completed event
    recordEvent('revision_completed', 'Spaced Revision Center', subjectKey, chapterName);

    // Award streak points
    if (!revisedDays.includes(currentDay)) {
      setRevisedDays(prev => [...prev, currentDay]);
    }

    showToast(`🎉 Spaced Revision completed for "${chapterName}"! Streak updated!`);
    setActiveRevItem(null);
  };

  return (
    <div className="relative animate-fadeIn">
      {/* 2. HEADER CONTAINER */}
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-display font-black tracking-tight text-ink flex items-center gap-3">
            <span className="p-2.5 rounded-2xl bg-orange-lt text-orange text-lg">💡</span>
            Spaced Revision Center
          </h1>
          <p className="text-ink3 text-xs font-semibold uppercase tracking-wider mt-1.5">
            Optimized Day [3, 7, 15, 30] Schedule • Momentum Tracker
          </p>
        </div>

        {/* STREAK WIDGET */}
        <div className="flex items-center gap-4 bg-surface border border-border p-3.5 rounded-2xl shadow-3xs w-full lg:w-auto">
          <div className="w-12 h-12 bg-orange-lt rounded-xl flex items-center justify-center text-orange shrink-0">
            <Flame className="w-6 h-6 fill-orange text-orange animate-pulse" />
          </div>
          <div>
            <div className="text-xl font-display font-bold text-ink">
              {currentStreak} Days
            </div>
            <div className="text-[10px] font-bold text-ink3 uppercase tracking-wider">
              Continuous Rev. Streak
            </div>
          </div>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {!activeRevItem ? (
          <motion.div
            key="dashboard"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            className="space-y-8 text-left"
          >
            {/* 3. SETTINGS & CONTEXT CARD */}
            <div className="bg-surface border border-border p-5 rounded-2xl shadow-3xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div className="space-y-1">
                <span className="text-[10px] bg-orange-lt text-orange font-black uppercase tracking-widest px-2.5 py-1 rounded-full border border-orange-mid">
                  Active Study Day: Day {currentDay}
                </span>
                <p className="text-ink2 text-xs pt-2">
                  System monitors completed planner topics to auto-schedule spaced repetitions on <strong className="text-orange">Day 3, 7, 15, and 30</strong>.
                </p>
              </div>

              {/* AUTO-RESCHEDULE TOGGLE */}
              <div className="flex items-center gap-3 bg-bg border border-border p-2.5 rounded-xl shrink-0 w-full md:w-auto">
                <div className="flex-1 text-left">
                  <div className="text-xs font-bold text-ink">Auto-Reschedule Overdue</div>
                  <div className="text-[9px] text-ink3">Reschedule missed items to today</div>
                </div>
                <button
                  onClick={() => {
                    setAutoRescheduleActive(prev => !prev);
                    showToast(`🔄 Auto-Reschedulers ${!autoRescheduleActive ? 'enabled' : 'disabled'}`);
                  }}
                  className={cn(
                    "w-12 h-6 rounded-full p-1 transition-all",
                    autoRescheduleActive ? "bg-orange flex-row-reverse" : "bg-border"
                  )}
                >
                  <div className="w-4 h-4 bg-white rounded-full shadow-xs transition-transform" />
                </button>
              </div>
            </div>

            {/* MAIN SECTIONS GRID */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              
              {/* LEFT BLOCK: DUE TODAY & MISSED REVISIONS */}
              <div className="lg:col-span-8 space-y-8">
                {/* DUE TODAY */}
                <div className="bg-surface border border-border rounded-2xl overflow-hidden shadow-3xs p-6">
                  <div className="flex items-center justify-between border-b border-border pb-4 mb-4">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse" />
                      <h2 className="font-display font-medium text-lg text-ink">Due For Revision Today</h2>
                    </div>
                    <span className="text-xs font-black px-2.5 py-1 bg-emerald-50 text-emerald-600 rounded-full border border-emerald-100 uppercase tracking-widest">
                      {dueToday.length} Topics
                    </span>
                  </div>

                  {dueToday.length === 0 ? (
                    <div className="py-12 text-center text-ink3 space-y-3">
                      <Smile className="w-10 h-10 text-emerald-500 mx-auto" />
                      <p className="text-xs font-semibold">Fantastic work! No topics due for scheduled revision today.</p>
                      <p className="text-[10px] max-w-sm mx-auto">Keep completing active planner chapters to populate spaced intervals.</p>
                    </div>
                  ) : (
                    <div className="divide-y divide-border/60">
                      {dueToday.map((item, idx) => (
                        <div key={idx} className="py-4 first:pt-0 last:pb-0 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                          <div className="flex items-start gap-3.5">
                            <span className="text-2xl pt-0.5">{item.subjectIcon}</span>
                            <div className="text-left">
                              <h3 className="font-display font-medium text-sm text-ink">{item.chapterName}</h3>
                              <div className="flex flex-wrap items-center gap-2 mt-1">
                                <span className="text-[10px] font-bold uppercase tracking-wider text-ink3">
                                  {item.subjectLabel}
                                </span>
                                <span className="w-1.5 h-1.5 rounded-full bg-border" />
                                <span className="text-[10px] text-orange font-bold uppercase tracking-wider">
                                  Repetition {item.revisionsCount + 1}/4
                                </span>
                                {item.status === 'auto-rescheduled' && (
                                  <>
                                    <span className="w-1.5 h-1.5 rounded-full bg-border" />
                                    <span className="text-[10px] bg-amber-500-lt text-amber-600 font-bold px-1.5 py-0.5 rounded uppercase tracking-wider">
                                      Rescheduled
                                    </span>
                                  </>
                                )}
                              </div>
                            </div>
                          </div>

                          <button
                            onClick={() => startQuickRevision(item)}
                            className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-4 py-2 bg-orange hover:bg-orange/95 text-white font-black text-[10px] uppercase tracking-widest rounded-xl shadow-xs hover:shadow-sm active:scale-95 transition-all"
                          >
                            <Play className="w-3 h-3 fill-white" /> Quick Revise
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* MISSED REVISIONS */}
                <div className="bg-surface border border-border rounded-2xl overflow-hidden shadow-3xs p-6">
                  <div className="flex items-center justify-between border-b border-border pb-4 mb-4">
                    <div className="flex items-center gap-2 text-red-500">
                      <AlertTriangle className="w-5 h-5 stroke-[2.5px]" />
                      <h2 className="font-display font-medium text-lg text-ink">Missed & Overdue</h2>
                    </div>
                    <span className="text-xs font-black px-2.5 py-1 bg-red-50 text-red-500 rounded-full border border-red-100 uppercase tracking-widest">
                      {missedRevs.length} Overdue
                    </span>
                  </div>

                  {missedRevs.length === 0 ? (
                    <div className="py-8 text-center text-ink3 space-y-1.5">
                      <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto" />
                      <p className="text-xs font-semibold">Awesome rhythm! You missed 0 scheduled revisions.</p>
                    </div>
                  ) : (
                    <div className="divide-y divide-border/60">
                      {missedRevs.map((item, idx) => (
                        <div key={idx} className="py-4 first:pt-0 last:pb-0 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                          <div className="flex items-start gap-3">
                            <span className="text-2xl pt-0.5">{item.subjectIcon}</span>
                            <div className="text-left">
                              <h3 className="font-display font-medium text-sm text-ink">{item.chapterName}</h3>
                              <div className="flex flex-wrap items-center gap-2 mt-1">
                                <span className="text-[10px] font-bold text-ink3 uppercase">{item.subjectLabel}</span>
                                <span className="w-1.5 h-1.5 rounded-full bg-border" />
                                <span className="text-[10px] text-red-500 font-bold uppercase">
                                  Scheduled Day {item.dueDay} (Overdue by {Math.abs(item.daysRemaining)} Days)
                                </span>
                              </div>
                            </div>
                          </div>

                          <button
                            onClick={() => handleManualReschedule(item)}
                            className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-3 py-2 border border-orange text-orange font-black text-[10px] uppercase tracking-widest rounded-xl hover:bg-orange/5 transition-all"
                          >
                            <RefreshCcw className="w-3 h-3" /> Reschedule Today
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* RIGHT BLOCK: UPCOMING SCHEDULE */}
              <div className="lg:col-span-4">
                <div className="bg-surface border border-border rounded-2xl overflow-hidden shadow-3xs p-6 text-left">
                  <div className="flex items-center justify-between border-b border-border pb-4 mb-4">
                    <div className="flex items-center gap-2 text-ink">
                      <Calendar className="w-5 h-5 text-orange" />
                      <h2 className="font-display font-medium text-lg">Upcoming Revisions</h2>
                    </div>
                  </div>

                  {upcomingRevs.length === 0 ? (
                    <div className="py-16 text-center text-ink3 text-xs">
                      No future chapters scheduled for revision yet. Finish existing study chapters to queue them!
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {upcomingRevs.map((item, idx) => (
                        <div key={idx} className="p-3 bg-bg border border-border/80 rounded-xl relative overflow-hidden">
                          <div className="flex items-start gap-2.5">
                            <span className="text-xl">{item.subjectIcon}</span>
                            <div className="flex-1 min-w-0">
                              <h4 className="font-semibold text-xs text-ink truncate">{item.chapterName}</h4>
                              <p className="text-[9px] text-orange font-bold uppercase tracking-wide mt-0.5">
                                Repetition {item.revisionsCount + 1}/4 • Scheduled Day {item.dueDay}
                              </p>
                            </div>
                          </div>
                          
                          {/* Progress/Time Badge */}
                          <div className="absolute top-2.5 right-2.5 flex items-center gap-1 text-[9px] font-black uppercase text-ink3 bg-surface border border-border px-2 py-0.5 rounded">
                            <Clock className="w-2.5 h-2.5" /> Due in {item.daysRemaining} Days
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

            </div>
          </motion.div>
        ) : (
          <motion.div
            key="quick-revision"
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.98 }}
            className="bg-surface border border-border rounded-2xl shadow-3xs overflow-hidden max-w-4xl mx-auto"
          >
            {/* ACTIVE SESSION BAR */}
            <div className="bg-ink text-white p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => {
                    if (confirm("Are you sure you want to stop this revision session? Progress will not be saved.")) {
                      setActiveRevItem(null);
                    }
                  }}
                  className="p-1.5 rounded-lg hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors"
                >
                  <ArrowLeft className="w-4 h-4" />
                </button>
                <div className="text-left">
                  <div className="text-[10px] font-bold text-orange uppercase tracking-widest flex items-center gap-1.5">
                    <span>{activeRevItem.subjectIcon}</span>
                    <span>{activeRevItem.subjectLabel}</span>
                  </div>
                  <h2 className="font-display font-bold text-sm tracking-tight text-white">{activeRevItem.chapterName}</h2>
                </div>
              </div>

              <div className="hidden sm:flex items-center gap-1 px-3 py-1 bg-neutral-800 rounded-full border border-neutral-700 text-[9px] font-black uppercase text-emerald-400">
                <Brain className="w-3 h-3 text-emerald-400 animate-pulse" /> Spaced Session #{activeRevItem.revisionsCount + 1}
              </div>
            </div>

            {/* PROGRESS STEP BAR */}
            <div className="grid grid-cols-5 border-b border-border bg-orange-lt">
              {[
                { id: 'notes', label: '1. Quick Notes', icon: BookOpen },
                { id: 'tricks', label: '2. Tricks & Hacks', icon: Sparkles },
                { id: 'mistakes', label: '3. Mistake Review', icon: AlertCircle },
                { id: 'quiz', label: '4. Mini Quiz', icon: HelpCircle },
                { id: 'complete', label: '5. Complete', icon: Award }
              ].map((step, idx) => {
                const stepOrder = ['notes', 'tricks', 'mistakes', 'quiz', 'complete'];
                const curIdx = stepOrder.indexOf(quickRevStep);
                const stepIdx = stepOrder.indexOf(step.id);
                const isActive = quickRevStep === step.id;
                const isCompleted = stepIdx < curIdx;

                return (
                  <button
                    key={step.id}
                    disabled={step.id === 'complete' && curIdx < 4}
                    onClick={() => {
                      // Allow moving backward anytime or forward only if completed
                      if (stepIdx <= curIdx) {
                        setQuickRevStep(step.id as any);
                      }
                    }}
                    className={cn(
                      "py-3 border-r border-border last:border-0 transition-all flex flex-col items-center justify-center gap-1 text-[9px] font-black uppercase text-center outline-none",
                      isActive ? "bg-white text-orange font-black border-b-[2.5px] border-b-orange" : "text-ink3 hover:text-ink hover:bg-neutral-50"
                    )}
                  >
                    <step.icon className={cn(
                      "w-4 h-4",
                      isActive ? "text-orange" : isCompleted ? "text-emerald-500" : "text-ink3"
                    )} />
                    <span className="hidden md:inline">{step.label}</span>
                  </button>
                );
              })}
            </div>

            {/* ACTION CONTAINER */}
            <div className="p-6 md:p-8 min-h-[400px] flex flex-col justify-between">
              
              {isLoading ? (
                <div className="flex-1 flex flex-col items-center justify-center py-20 gap-4">
                  <div className="w-12 h-12 border-4 border-orange/20 border-t-orange rounded-full animate-spin" />
                  <p className="text-xs font-semibold text-ink3 uppercase tracking-widest animate-pulse">
                    Synthesizing Textbook Core Concepts via AI...
                  </p>
                </div>
              ) : (
                <div className="flex-1 text-left">
                  
                  {/* STEP 1: QUICK NOTES */}
                  {quickRevStep === 'notes' && (
                    <div className="space-y-6">
                      <div className="bg-orange-lt border border-orange-mid/30 p-4 rounded-xl flex items-start gap-3">
                        <span className="text-xl">📖</span>
                        <div className="space-y-1">
                          <h4 className="font-bold text-xs text-orange uppercase tracking-wide">NCERT Core Syllabus Focus</h4>
                          <p className="text-xs text-ink">Review high-yield summaries, formulas, and examiner priority highlights below.</p>
                        </div>
                      </div>

                      {studyGuide ? (
                        <div className="space-y-6 prose max-w-none text-xs text-ink2 leading-relaxed">
                          <div className="border border-border rounded-xl p-4 bg-bg">
                            <h3 className="font-display font-medium text-sm text-ink mb-2">Chapter Overview</h3>
                            <p>{studyGuide.overview?.replace(/\*\*+/g, "")}</p>
                          </div>

                          {studyGuide.keyConcepts && studyGuide.keyConcepts.map((concept: any, kIdx: number) => (
                            <div key={kIdx} className="border border-border/80 rounded-xl p-4 space-y-2">
                              <div className="flex justify-between items-center bg-bg/50 px-3 py-1.5 rounded-lg border-b border-border/40">
                                <span className="font-bold text-xs text-ink">{concept.conceptName}</span>
                                <span className="text-[10px] font-bold uppercase text-red-500 bg-red-50 border border-red-100 px-2 py-0.5 rounded-full">
                                  {concept.importance}
                                </span>
                              </div>
                              <p className="text-xs whitespace-pre-line p-1 pt-2">{concept.explanation?.replace(/###\s+/g, "").replace(/\*\*+/g, "")}</p>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="py-12 text-center text-ink3 text-xs bg-bg rounded-xl border border-border">
                          Unable to retrieve core guide. Please use the fallback summary or next section.
                        </div>
                      )}

                      {/* Math/Chemical Formula list if applicable */}
                      {formulas && formulas.length > 0 && (
                        <div className="border border-border rounded-xl p-4 space-y-3 text-left bg-bg mt-6">
                          <h4 className="font-bold text-xs uppercase text-orange tracking-widest border-b border-border pb-2">
                            Key Formulas / Laws Checksheet
                          </h4>
                          <div className="space-y-3">
                            {formulas.map((form: any, idx: number) => (
                              <div key={idx} className="p-2.5 bg-surface border border-border/80 rounded-lg space-y-1">
                                <span className="font-bold text-xs text-ink">{form.name}</span>
                                <code className="block bg-neutral-900 text-green-400 p-2 rounded text-[10px] my-1.5 font-mono">
                                  {form.expression}
                                </code>
                                <p className="text-ink3 text-[11px] leading-relaxed">{form.description}</p>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {/* STEP 2: TRICKS & MEMORY HACKS */}
                  {quickRevStep === 'tricks' && (
                    <div className="space-y-6">
                      <div className="bg-orange-lt border border-orange-mid/30 p-4 rounded-xl flex items-start gap-3">
                        <span className="text-xl">⚡</span>
                        <div className="space-y-1">
                          <h4 className="font-bold text-xs text-orange uppercase tracking-wide">Board Mnemonics & Exam Traps</h4>
                          <p className="text-xs text-ink">Leverage custom acronyms and scoring advice to prevent standard exam errors.</p>
                        </div>
                      </div>

                      {studyGuide?.mnemonics && studyGuide.mnemonics.length > 0 ? (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {studyGuide.mnemonics.map((mn: any, idx: number) => (
                            <div key={idx} className="border border-border rounded-xl p-4 bg-bg space-y-2">
                              <span className="font-black text-xs text-orange bg-orange-lt px-2 py-0.5 rounded">
                                Mnemonic: {mn.title}
                              </span>
                              <div className="text-sm font-black font-mono pl-1 pt-1 text-ink">{mn.phrase}</div>
                              <p className="text-xs text-ink2 whitespace-pre-line pl-1">{mn.breakdown?.replace(/\*\*+/g, "")}</p>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="p-4 bg-bg border border-border rounded-xl text-xs text-neutral-500">
                          No customized mnemonics found. Apply standard R-P-L-N sign coordinates (Right Positive, Left Negative) for mirror questions, or R-P-K (Reactive Potassium first) sequence for reactivity.
                        </div>
                      )}

                      {/* Syllabus scoring advice */}
                      {studyGuide?.syllabiTips && (
                        <div className="bg-surface border border-border rounded-xl p-4 space-y-3">
                          <div className="flex items-center gap-2 border-b border-border pb-2">
                            <span className="p-1 rounded bg-amber-500-lt text-amber-600 font-bold text-[10px]">Scoring Tip</span>
                            <span className="font-bold text-xs">Exemplar Grade Advice</span>
                          </div>
                          <ul className="list-disc pl-5 text-xs text-ink2 space-y-2">
                            {studyGuide.syllabiTips.map((tip: string, idx: number) => (
                              <li key={idx} dangerouslySetInnerHTML={{ __html: tip.replace(/\*\*+/g, "<strong>").replace(/\*\*/g, "</strong>") }} />
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  )}

                  {/* STEP 3: MISTAKE RECALL */}
                  {quickRevStep === 'mistakes' && (
                    <div className="space-y-6">
                      <div className="bg-orange-lt border border-orange-mid/30 p-4 rounded-xl flex items-start gap-3">
                        <span className="text-xl">🧙‍♂️</span>
                        <div className="space-y-1">
                          <h4 className="font-bold text-xs text-orange uppercase tracking-wide">Mistake Recall Review</h4>
                          <p className="text-xs text-ink">Resolve original errors recorded under standard board question testing.</p>
                        </div>
                      </div>

                      {chapterMistakes.length === 0 ? (
                        <div className="border border-emerald-100 bg-emerald-50 text-emerald-800 p-8 rounded-xl text-center space-y-3">
                          <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center mx-auto text-emerald-500 font-black text-xl shadow-xs">✓</div>
                          <p className="font-black text-sm uppercase tracking-wide">🎉 Clean Book Alert!</p>
                          <p className="text-xs">No active conceptual mistakes have been logged for this chapter. Great baseline accuracy!</p>
                        </div>
                      ) : (
                        <div className="border border-border rounded-xl p-5 bg-bg space-y-4">
                          <div className="flex justify-between items-center border-b border-border pb-3">
                            <span className="text-[10px] font-black uppercase text-red-500 bg-red-100 px-2 py-0.5 rounded">
                              Mistake {selectedMistakeIndex + 1} of {chapterMistakes.length}
                            </span>
                            <div className="flex gap-1">
                              <button
                                disabled={selectedMistakeIndex === 0}
                                onClick={() => {
                                  setSelectedMistakeIndex(prev => prev - 1);
                                  setShowMistakesAnswer(false);
                                }}
                                className="px-2 py-1 bg-surface border border-border text-[9px] font-bold rounded disabled:opacity-50"
                              >
                                Prev
                              </button>
                              <button
                                disabled={selectedMistakeIndex === chapterMistakes.length - 1}
                                onClick={() => {
                                  setSelectedMistakeIndex(prev => prev + 1);
                                  setShowMistakesAnswer(false);
                                }}
                                className="px-2 py-1 bg-surface border border-border text-[9px] font-bold rounded disabled:opacity-50"
                              >
                                Next
                              </button>
                            </div>
                          </div>

                          <div className="space-y-1">
                            <div className="text-[10px] font-bold text-neutral-400 uppercase">Question:</div>
                            <div className="text-xs font-semibold text-ink leading-relaxed">
                              {chapterMistakes[selectedMistakeIndex].question}
                            </div>
                          </div>

                          {showMistakesAnswer ? (
                            <div className="space-y-2 pt-3 border-t border-border animate-fadeUp text-xs">
                              <div>
                                <span className="font-bold text-emerald-600 block">✓ Correct Resolved Answer:</span>
                                <p className="text-ink text-xs mt-1 bg-surface p-2.5 rounded border border-emerald-100">
                                  {chapterMistakes[selectedMistakeIndex].correctAnswer}
                                </p>
                              </div>
                              {chapterMistakes[selectedMistakeIndex].similarQuestion && (
                                <div className="mt-4 p-3 bg-orange-lt border border-orange-mid/30 rounded-xl space-y-1">
                                  <span className="font-bold text-orange text-[10px] uppercase">Additional Retake Check:</span>
                                  <p className="font-semibold text-ink">{chapterMistakes[selectedMistakeIndex].similarQuestion}</p>
                                  <p className="text-ink3 mt-1 pl-1">Hint: {chapterMistakes[selectedMistakeIndex].similarAnswer}</p>
                                </div>
                              )}
                            </div>
                          ) : (
                            <div className="pt-4 text-center">
                              <button
                                onClick={() => setShowMistakesAnswer(true)}
                                className="px-4 py-2 bg-neutral-900 border border-neutral-800 hover:bg-neutral-850 text-white font-black text-[9px] uppercase tracking-widest rounded-lg transition-transform active:scale-95"
                              >
                                Reveal Explanation & Correct Option
                              </button>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  )}

                  {/* STEP 4: 5 QUESTION MINI QUIZ */}
                  {quickRevStep === 'quiz' && (
                    <div className="space-y-6">
                      <div className="bg-orange-lt border border-orange-mid/30 p-4 rounded-xl flex items-start gap-3">
                        <span className="text-xl">⚡</span>
                        <div className="space-y-1">
                          <h4 className="font-bold text-xs text-orange uppercase tracking-wide">Mini Board Evaluation</h4>
                          <p className="text-xs text-ink">Execute these exactly 5 MCQs to evaluate your active revision recall.</p>
                        </div>
                      </div>

                      {quizQuestions.length > 0 && (
                        <div className="space-y-6">
                          {/* PROGRESS HEADER */}
                          <div className="flex justify-between items-center bg-bg px-4 py-2.5 rounded-lg border border-border">
                            <span className="text-xs font-bold text-ink">
                              Question {currentQuizIndex + 1} of 5
                            </span>
                            <div className="flex h-2 bg-border/60 rounded-full overflow-hidden w-24">
                              <div 
                                className="bg-orange h-full transition-all"
                                style={{ width: `${((currentQuizIndex + 1) / 5) * 100}%` }}
                              />
                            </div>
                          </div>

                          {/* QUESTION BLOCK */}
                          <div className="border border-border rounded-xl p-5 bg-bg space-y-4">
                            <h3 className="font-display font-bold text-xs text-ink leading-relaxed">
                              {quizQuestions[currentQuizIndex].question}
                            </h3>

                            {/* OPTIONS LIST */}
                            <div className="space-y-2.5">
                              {quizQuestions[currentQuizIndex].options.map((option: string, idx: number) => {
                                const isSelected = quizAnswers[currentQuizIndex] === option;
                                const isCorrect = option === quizQuestions[currentQuizIndex].answer;
                                
                                return (
                                  <button
                                    key={idx}
                                    disabled={quizSubmitted}
                                    onClick={() => handleOptionSelect(option)}
                                    className={cn(
                                      "w-full p-3 rounded-xl border text-left text-xs font-semibold transition-all transition-colors flex items-center justify-between",
                                      isSelected 
                                        ? "bg-orange-lt border-orange text-orange font-bold" 
                                        : "bg-surface border-border hover:border-orange/35 text-ink2",
                                      quizSubmitted && isCorrect && "bg-green-50 border-green-500 text-green-700 font-bold",
                                      quizSubmitted && isSelected && !isCorrect && "bg-red-50 border-red-400 text-red-700"
                                    )}
                                  >
                                    <span>{option}</span>
                                    {quizSubmitted && isCorrect && <span className="text-green-600 font-black">✓ Correct</span>}
                                  </button>
                                );
                              })}
                            </div>
                          </div>

                          {/* SUBMIT BUTTON OR NAVIGATION */}
                          <div className="flex justify-between items-center mt-4">
                            <button
                              disabled={currentQuizIndex === 0}
                              onClick={() => setCurrentQuizIndex(prev => prev - 1)}
                              className="px-3 py-1.5 bg-surface border border-border text-ink3 font-bold text-[9px] uppercase tracking-widest rounded-lg disabled:opacity-40"
                            >
                              Prev
                            </button>

                            {!quizSubmitted ? (
                              currentQuizIndex === 4 ? (
                                <button
                                  disabled={Object.keys(quizAnswers).length < 5}
                                  onClick={submitQuiz}
                                  className="px-5 py-2 bg-orange hover:bg-orange/90 text-white font-black text-[9px] uppercase tracking-widest rounded-lg disabled:opacity-50 transition-all shadow-xs"
                                >
                                  Submit Assessment
                                </button>
                              ) : (
                                <button
                                  onClick={() => setCurrentQuizIndex(prev => prev + 1)}
                                  className="px-4 py-2 bg-neutral-900 hover:bg-neutral-850 text-white font-black text-[9px] uppercase tracking-widest rounded-lg"
                                >
                                  Next
                                </button>
                              )
                            ) : (
                              <div className="flex items-center gap-3">
                                <span className="text-xs font-bold text-ink">
                                  Score: {quizScore}/5 ({Math.round((quizScore / 5) * 100)}%)
                                </span>
                                <button
                                  onClick={() => setQuickRevStep('complete')}
                                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-[9px] uppercase tracking-widest rounded-lg shadow-xs"
                                >
                                  Continue to Complete <ArrowRight className="w-3 h-3 inline ml-1" />
                                </button>
                              </div>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {/* STEP 5: REVISION COMPLETE CELEBRATION */}
                  {quickRevStep === 'complete' && (
                    <div className="flex-1 flex flex-col items-center justify-center py-10 gap-5 text-center">
                      <div className="w-20 h-20 bg-green-50 border border-green-200 rounded-full flex items-center justify-center text-green-500 text-4xl shadow-md shadow-green-100 animate-bounce">
                        🎉
                      </div>
                      <div className="space-y-2">
                        <h3 className="font-display font-black text-lg text-ink">
                          Revision Interval Completed Successfully!
                        </h3>
                        <p className="text-xs text-ink3 max-w-sm mx-auto">
                          You completed the Quick Notes, mnemonics tricks, mistake review, and evaluated active recall questions for:
                        </p>
                        <p className="font-display font-black text-sm text-orange py-1">
                          {activeRevItem.chapterName}
                        </p>
                        <div className="grid grid-cols-2 gap-4 max-w-xs mx-auto pt-4 text-left">
                          <div className="p-3 bg-bg border border-border rounded-xl">
                            <div className="text-lg font-black text-emerald-500">
                              {revisedDays.includes(currentDay) ? currentStreak : currentStreak + 1} Days
                            </div>
                            <p className="text-[9px] font-black uppercase text-ink3 mt-0.5">Continuous Streak</p>
                          </div>
                          <div className="p-3 bg-bg border border-border rounded-xl">
                            <div className="text-lg font-black text-orange">
                              +{Math.min(4, activeRevItem.revisionsCount + 1)}/4
                            </div>
                            <p className="text-[9px] font-black uppercase text-ink3 mt-0.5">Spaced Revisions Finished</p>
                          </div>
                        </div>
                      </div>

                      <button
                        onClick={finalizeRevision}
                        className="mt-6 px-8 py-3 bg-emerald-600 hover:bg-emerald-500 hover:shadow-md text-white font-black text-xs uppercase tracking-widest rounded-xl transition-all"
                      >
                        Log Revision Complete
                      </button>
                    </div>
                  )}

                </div>
              )}

            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
