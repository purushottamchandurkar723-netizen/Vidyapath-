/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Screen } from '../App';
import { SUBJECTS } from '../constants';
import { motion } from 'motion/react';
import { Trophy, ArrowLeft, RefreshCw, BarChart2, CheckCircle, XCircle } from 'lucide-react';
import { cn } from '../lib/utils';
import Markdown from 'react-markdown';

interface ResultsProps {
  results: {
    subjectKey: string;
    chapterName: string;
    topic?: string;
    score: number;
    total: number;
    userAnswers: any[];
  };
  navigateTo: (s: Screen, subKey?: string | null, chIdx?: number | null, topic?: string | null) => void;
}

export default function Results({ results, navigateTo }: ResultsProps) {
  const pct = Math.round((results.score / results.total) * 100);
  
  let emoji = '🎉';
  let title = 'Great Work!';
  let subtitle = 'You are on the right track! Review the concepts you missed.';

  if (pct === 100) {
    emoji = '🏆'; title = 'Perfect Score!'; subtitle = 'Outstanding! You are board-exam ready!';
  } else if (pct >= 80) {
    emoji = '🎉'; title = 'Excellent!'; subtitle = 'Great score! Review the ones you missed.';
  } else if (pct < 50) {
    emoji = '📚'; title = 'Keep Studying'; subtitle = 'Go through the chapter again and retry.';
  }

  return (
    <div className="max-w-[660px] mx-auto px-4 py-8 pb-32">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-gradient-to-br from-orange to-[#FF9A3C] rounded-[40px] p-8 text-white text-center shadow-xl shadow-orange/35 relative overflow-hidden"
      >
        <div className="absolute top-[-30px] -right-10 w-40 h-40 bg-white/10 rounded-full blur-xl" />
        <div className="text-6xl mb-4">{emoji}</div>
        <h2 className="text-2xl font-display mb-1">{title}</h2>
        {results.topic && <div className="text-[10px] font-black uppercase tracking-[0.2em] opacity-70 mt-1 mb-2">Topic: {results.topic}</div>}
        <div className="text-7xl font-display my-4 leading-none">{results.score}<span className="text-3xl opacity-50">/{results.total}</span></div>
        <div className="text-xl font-display opacity-90 mb-2">{pct}% accuracy</div>
        <p className="text-sm opacity-80 max-w-xs mx-auto leading-relaxed">{subtitle}</p>
        
        <div className="mt-8 h-2.5 w-full bg-white/20 rounded-full overflow-hidden">
          <motion.div 
            initial={{ width: 0 }}
            animate={{ width: `${pct}%` }}
            transition={{ duration: 1, delay: 0.5, ease: "easeOut" }}
            className="h-full bg-white rounded-full"
          />
        </div>
      </motion.div>

      <div className="mt-12 space-y-6">
        <h3 className="text-lg font-display text-ink uppercase tracking-tight">Question Review</h3>
        <div className="space-y-4">
          {results.userAnswers.map((ans, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="bg-surface p-6 rounded-[28px] border border-border shadow-sm space-y-4"
            >
              <div className="flex justify-between items-start gap-4">
                <p className="text-base font-bold leading-relaxed flex-1">
                  <span className="text-ink3 mr-2">{i+1}.</span>
                  {ans.question}
                </p>
                <div className={cn(
                  "px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest",
                  ans.isCorrect ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
                )}>
                  {ans.isCorrect ? "Correct" : "Mistake"}
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center gap-2 text-xs font-semibold">
                  <div className={cn("w-1.5 h-1.5 rounded-full", ans.isCorrect ? "bg-green-500" : "bg-red-500")} />
                  <span className="text-ink2">Your answer:</span>
                  <span className={ans.isCorrect ? "text-green-700" : "text-red-700"}>{ans.selected}</span>
                </div>
                {!ans.isCorrect && (
                  <div className="flex items-center gap-2 text-xs font-semibold">
                    <div className="w-1.5 h-1.5 rounded-full bg-green-500" />
                    <span className="text-ink2">Correct answer:</span>
                    <span className="text-green-700">{ans.correct}</span>
                  </div>
                )}
              </div>

              {ans.explanation && (
                <div className="bg-blue-lt border border-blue-100 p-4 rounded-2xl space-y-2 text-left">
                  <div className="text-[10px] font-black uppercase tracking-widest text-blue-500">AI Explanation</div>
                  <div className="text-sm text-blue-900 leading-relaxed font-medium italic markdown-body font-sans">
                    <Markdown>{ans.explanation}</Markdown>
                  </div>
                </div>
              )}
            </motion.div>
          ))}
        </div>
      </div>

      <div className="fixed bottom-0 left-0 w-full p-6 bg-surface/80 backdrop-blur-md border-t border-border z-40">
        <div className="max-w-[660px] mx-auto flex flex-wrap gap-3">
          <button 
            onClick={() => navigateTo('quiz', results.subjectKey, SUBJECTS[results.subjectKey].chapters.findIndex(c => c.name === results.chapterName), results.topic)}
            className="flex-1 min-w-[140px] bg-orange text-white px-6 py-3.5 rounded-2xl font-bold text-sm shadow-md flex items-center justify-center gap-2"
          >
            <RefreshCw className="w-4 h-4" />
            Retry
          </button>
          <button 
            onClick={() => navigateTo('home')}
            className="flex-1 min-w-[140px] bg-surface border border-border text-ink px-6 py-3.5 rounded-2xl font-bold text-sm shadow-sm flex items-center justify-center gap-2 hover:bg-surface2 transition-all"
          >
            <ArrowLeft className="w-4 h-4" />
            Home
          </button>
        </div>
      </div>
    </div>
  );
}
