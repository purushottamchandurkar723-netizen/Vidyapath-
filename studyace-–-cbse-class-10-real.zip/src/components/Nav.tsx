/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Screen } from '../App';
import { Sun, Moon, BarChart2, BookOpen, PenTool, LayoutGrid, Calendar, FileText, CheckCircle2, FlaskConical, User, LogOut, LogIn, Cloud, CloudOff, ClipboardList, Trophy, Lightbulb, Award, ShieldCheck } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { cn } from '../lib/utils';

interface NavProps {
  theme: 'light' | 'dark';
  toggleTheme: () => void;
  navigateTo: (s: Screen, subKey?: string | null, chIdx?: number | null, topic?: string | null) => void;
}

export default function Nav({ theme, toggleTheme, navigateTo }: NavProps) {
  const { user, profile, setAuthModalOpen, logout } = useAuth();

  return (
    <nav className="flex items-center justify-between px-4 py-3 bg-surface/90 backdrop-blur-md border-b border-border sticky top-0 z-50 shadow-sm">
      <div className="flex items-center gap-4">
        <div 
          className="text-xl font-display text-orange tracking-tight cursor-pointer flex items-center gap-2"
          onClick={() => navigateTo('home')}
        >
          Vidy<span className="text-ink">Path</span>
        </div>
 
        {/* Desktop Navigation Links */}
        <div className="hidden lg:flex items-center gap-1 ml-4 border-l border-border pl-4">
          {[
            { id: 'ai-tools' as Screen, label: 'AI Tools', icon: FlaskConical },
            { id: 'tracker' as Screen, label: 'Progress', icon: BarChart2 },
            { id: 'mastery-dashboard' as Screen, label: 'Mastery', icon: Award },
            { id: 'leaderboard' as Screen, label: 'Leaderboard', icon: Trophy },
            { id: 'planner' as Screen, label: 'Planner', icon: Calendar },
            { id: 'revision-center' as Screen, label: 'Revision', icon: Lightbulb },
            { id: 'mistake-book' as Screen, label: 'Mistakes', icon: ClipboardList },
            ...(profile?.role === 'owner' 
              ? [{ id: 'admin-dashboard' as Screen, label: 'Admin Hub', icon: ShieldCheck }]
              : []
            ),
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => navigateTo(item.id)}
              className="flex items-center gap-2 px-3 py-1.5 text-[10px] font-black uppercase tracking-widest text-ink3 hover:text-orange hover:bg-orange-lt rounded-xl transition-all"
            >
              <item.icon className="w-3.5 h-3.5" />
              {item.label}
            </button>
          ))}
        </div>

        {user ? (
          <div className="hidden sm:flex items-center gap-1.5 px-2 py-0.5 bg-green-50 rounded-full border border-green-100 text-[8px] font-black uppercase text-green-600 tracking-tighter">
            <Cloud className="w-2.5 h-2.5" />
            Live Sync
          </div>
        ) : (
          <div className="hidden sm:flex items-center gap-1.5 px-2 py-0.5 bg-gray-50 rounded-full border border-gray-200 text-[8px] font-black uppercase text-gray-400 tracking-tighter">
            <CloudOff className="w-2.5 h-2.5" />
            Offline Mode
          </div>
        )}
      </div>

      <div className="flex items-center gap-3">
        <span className="hidden md:inline-flex items-center gap-1 px-3 py-1 text-[10px] uppercase font-bold tracking-widest bg-orange-lt text-orange border border-orange-mid rounded-full">
          CBSE Class 10
        </span>

        <button 
          onClick={toggleTheme}
          className="w-9 h-9 flex items-center justify-center rounded-xl border border-border text-ink2 hover:border-orange hover:bg-orange-lt transition-colors"
        >
          {theme === 'light' ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
        </button>

        {user ? (
          <div className="flex items-center gap-2 pl-2 border-l border-border">
            <div 
              className="cursor-pointer hover:scale-105 transition-transform"
              onClick={() => navigateTo('profile')}
            >
              {user.photoURL && user.photoURL.length > 4 ? (
                <img src={user.photoURL} alt="Profile" className="w-8 h-8 rounded-full border border-orange shadow-sm" />
              ) : (
                <div className="w-8 h-8 rounded-full bg-orange-lt flex items-center justify-center text-sm border border-orange-mid shadow-sm font-semibold">
                  {user.photoURL || <User className="w-4 h-4 text-orange" />}
                </div>
              )}
            </div>
            <button 
              onClick={() => logout()}
              className="p-2 text-ink3 hover:text-red-500 transition-colors"
              title="Logout"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <button 
            onClick={() => setAuthModalOpen(true)}
            className="flex items-center gap-1.5 px-4 py-2 text-[10px] font-black uppercase tracking-widest bg-ink text-white rounded-xl hover:bg-orange transition-all shadow-md shadow-ink/10 active:scale-95"
          >
            <LogIn className="w-3.5 h-3.5" />
            Sign In
          </button>
        )}
      </div>
    </nav>
  );
}
