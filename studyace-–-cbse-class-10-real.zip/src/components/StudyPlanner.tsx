import React from 'react';
import { Screen } from '../App';
import { ArrowLeft, Zap } from 'lucide-react';
import FastTrackPlanner from './FastTrackPlanner';

interface PlannerProps {
  navigateTo: (s: Screen, subKey?: string | null, chIdx?: number | null) => void;
  showToast: (msg: string) => void;
}

export default function StudyPlanner({ navigateTo, showToast }: PlannerProps) {
  return (
    <div className="relative animate-fadeIn">
      <div className="max-w-6xl mx-auto px-4 py-8 pb-32">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => navigateTo('home')} 
              className="inline-flex items-center gap-2 text-ink3 font-bold text-xs uppercase tracking-widest hover:text-orange transition-colors"
            >
              <ArrowLeft className="w-3.5 h-3.5" /> Home
            </button>
            <div className="flex items-center gap-1 text-[9px] font-black uppercase tracking-widest text-orange bg-orange-lt px-2 py-1 rounded-full border border-orange/10 shadow-3xs">
              <Zap className="w-2.5 h-2.5 text-orange animate-pulse" />
              Fast-Track Mode Active
            </div>
          </div>
        </div>

        <FastTrackPlanner navigateTo={navigateTo} showToast={showToast} />
      </div>
    </div>
  );
}
