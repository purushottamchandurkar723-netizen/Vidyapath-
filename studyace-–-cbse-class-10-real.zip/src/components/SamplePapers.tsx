/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Screen } from '../App';
import { ArrowLeft, FileText, Download, Play, Clock, Award } from 'lucide-react';
import { cn } from '../lib/utils';

interface SamplePapersProps {
  navigateTo: (s: Screen, subKey?: string | null, chIdx?: number | null) => void;
  showToast: (msg: string) => void;
}

const PAPERS = [
  { id: 'p1', title: 'Mathematics Standard 2024-25', status: 'official', marks: 80, time: '3h' },
  { id: 'p2', title: 'Science (Theory) Term II', status: 'mock', marks: 80, time: '3h' },
  { id: 'p3', title: 'Social Science Full Syllabus', status: 'mock', marks: 80, time: '3h' },
  { id: 'p4', title: 'English Communicative Set A', status: 'official', marks: 70, time: '3h' },
];

export default function SamplePapers({ navigateTo, showToast }: SamplePapersProps) {
  const [subject, setSubject] = useState('Mathematics');

  return (
    <div className="max-w-[780px] mx-auto px-4 py-8 pb-32">
      <button onClick={() => navigateTo('home')} className="inline-flex items-center gap-2 mb-8 text-ink3 font-bold text-xs uppercase tracking-widest hover:text-orange transition-colors">
        <ArrowLeft className="w-3.5 h-3.5" /> Home
      </button>

      <div className="space-y-2 mb-10">
        <h2 className="text-3xl font-display tracking-tight">Sample Papers</h2>
        <p className="text-sm text-ink2">Board pattern papers, previous year questions, and official CBSE sets.</p>
      </div>

      <div className="flex gap-2 mb-8 overflow-x-auto no-scrollbar">
        {['Mathematics', 'Science', 'Social Studies', 'English'].map(s => (
          <button 
            key={s} 
            onClick={() => setSubject(s)}
            className={cn(
              "px-6 py-2.5 rounded-2xl border-2 font-bold text-xs transition-all",
              subject === s ? "bg-ink border-ink text-white shadow-lg" : "bg-surface border-border text-ink2 hover:border-orange"
            )}
          >
            {s}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-4">
        {PAPERS.map(p => (
           <div key={p.id} className="bg-surface p-6 rounded-[32px] border border-border shadow-sm group hover:border-orange/20 transition-all">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-orange-lt text-orange flex items-center justify-center shadow-inner">
                      <FileText className="w-6 h-6" />
                    </div>
                    <div>
                       <span className={cn(
                        "px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-widest mb-1 inline-block",
                        p.status === 'official' ? "bg-green-100 text-green-700" : "bg-blue-50 text-blue-600"
                       )}>
                         {p.status}
                       </span>
                       <h4 className="text-base font-bold text-ink leading-tight">{p.title}</h4>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-6">
                    <div className="flex items-center gap-1.5 text-ink3">
                      <Clock className="w-3.5 h-3.5" />
                      <span className="text-[10px] font-black uppercase">{p.time}</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-ink3">
                      <Award className="w-3.5 h-3.5" />
                      <span className="text-[10px] font-black uppercase">{p.marks} Marks</span>
                    </div>
                  </div>
                </div>

                <div className="flex flex-col gap-2">
                   <button 
                    onClick={() => showToast('Starting paper simulation...')}
                    className="p-3 rounded-2xl bg-orange text-white shadow-lg shadow-orange/20 hover:scale-110 active:scale-95 transition-all"
                   >
                     <Play className="w-4 h-4 fill-current" />
                   </button>
                   <button 
                    onClick={() => showToast('Downloading PDF...')}
                    className="p-3 rounded-2xl bg-surface2 border border-border text-ink3 hover:text-ink hover:border-orange transition-all"
                   >
                     <Download className="w-4 h-4" />
                   </button>
                </div>
              </div>
           </div>
        ))}
      </div>

      <div className="mt-12 bg-blue-lt border border-blue-100 p-8 rounded-[40px] shadow-sm flex flex-col sm:flex-row items-center gap-8 text-center sm:text-left">
          <div className="w-24 h-24 bg-white rounded-3xl p-5 shadow-inner flex items-center justify-center relative">
            <span className="text-4xl">🏛️</span>
            <div className="absolute -top-2 -right-2 w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-[10px] font-black shadow-lg">OFF</div>
          </div>
          <div className="space-y-4 flex-1">
            <h3 className="text-xl font-display text-blue-900 leading-tight">Official CBSE Resources</h3>
            <p className="text-xs font-medium text-blue-700 max-w-sm leading-relaxed">Direct links to official sample question papers and latest marking schemes from cbseacademic.nic.in.</p>
            <div className="flex flex-wrap gap-2 justify-center sm:justify-start">
               <a href="https://cbseacademic.nic.in/SQP_CLASSX_2024-25.html" target="_blank" className="px-5 py-2 bg-blue-600 text-white rounded-xl text-[10px] font-black uppercase shadow-lg shadow-blue-200">Visit Portal</a>
            </div>
          </div>
      </div>
    </div>
  );
}
