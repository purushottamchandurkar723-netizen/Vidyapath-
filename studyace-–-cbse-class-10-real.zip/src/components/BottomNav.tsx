/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Screen } from '../App';
import { Home, FlaskConical, BarChart2, Calendar, ClipboardList, User } from 'lucide-react';
import { cn } from '../lib/utils';

interface BottomNavProps {
  currentScreen: Screen;
  navigateTo: (s: Screen) => void;
}

export default function BottomNav({ currentScreen, navigateTo }: BottomNavProps) {
  const tabs = [
    { id: 'home' as Screen, label: 'Home', icon: Home },
    { id: 'ai-tools' as Screen, label: 'AI', icon: FlaskConical },
    { id: 'tracker' as Screen, label: 'Progress', icon: BarChart2 },
    { id: 'planner' as Screen, label: 'Plan', icon: Calendar },
    { id: 'mistake-book' as Screen, label: 'Mistakes', icon: ClipboardList },
    { id: 'profile' as Screen, label: 'Profile', icon: User },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-surface/80 backdrop-blur-2xl border-t border-border px-2 pt-3 pb-8 flex justify-between items-center z-50 sm:hidden">
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = currentScreen === tab.id;
        return (
          <button
            key={tab.id}
            onClick={() => navigateTo(tab.id)}
            className={cn(
              "flex flex-col items-center gap-1.5 transition-all outline-none relative",
              isActive ? "text-orange" : "text-ink3"
            )}
          >
            <div className={cn(
              "w-11 h-11 rounded-2xl flex items-center justify-center transition-all duration-300",
              isActive ? "bg-orange shadow-lg shadow-orange/20 text-white translate-y-[-14px]" : "bg-transparent"
            )}>
              <Icon className={cn("w-5 h-5", isActive ? "stroke-[2.5px]" : "stroke-[2px]")} />
            </div>
            <span className={cn(
              "text-[9px] font-bold uppercase tracking-wide transition-all duration-300",
              isActive ? "opacity-100 translate-y-[-10px]" : "opacity-60"
            )}>
              {tab.label}
            </span>
            {isActive && <div className="absolute bottom-[-4px] w-1 h-1 bg-orange rounded-full" />}
          </button>
        );
      })}
    </div>
  );
}
