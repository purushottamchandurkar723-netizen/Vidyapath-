/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { Screen } from '../App';
import { useAuth } from '../context/AuthContext';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { 
  collection, 
  doc, 
  setDoc, 
  getDocs, 
  query, 
  orderBy, 
  limit, 
  serverTimestamp, 
  onSnapshot 
} from 'firebase/firestore';
import { loadItem, saveItem, cn } from '../lib/utils';
import { ProgressRecord } from '../types';
import { 
  Trophy, 
  Flame, 
  Target, 
  Award, 
  Crown, 
  Check, 
  Sparkles, 
  RefreshCw, 
  Zap, 
  Lock, 
  UserPlus, 
  TrendingUp, 
  BookOpen, 
  ChevronRight, 
  Info,
  Medal
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface LeaderboardProps {
  navigateTo: (s: Screen) => void;
  showToast: (msg: string) => void;
}

export interface LeaderboardEntry {
  userId: string;
  displayName: string;
  photoURL: string;
  streakCount: number;
  quizzesPassed: number;
  avgScore: number;
  totalPoints: number;
  updatedAt?: any;
  isSimulated?: boolean;
}

// Simulated Topper Peers for friendly benchmarking & offline states
const AI_PEER_STUDENTS: LeaderboardEntry[] = [
  {
    userId: 'peer_1',
    displayName: 'Ananya Iyer (Delhi Topper Prep)',
    photoURL: '',
    streakCount: 22,
    quizzesPassed: 18,
    avgScore: 96,
    totalPoints: 1800 + 22 * 25 + Math.round(96 * 2), // 1800 + 550 + 192 = 2542
    isSimulated: true
  },
  {
    userId: 'peer_2',
    displayName: 'Kabir Deshmukh (Maharashtra Board)',
    photoURL: '',
    streakCount: 15,
    quizzesPassed: 14,
    avgScore: 92,
    totalPoints: 1400 + 15 * 25 + Math.round(92 * 2), // 1400 + 375 + 184 = 1959
    isSimulated: true
  },
  {
    userId: 'peer_3',
    displayName: 'Ishita Paul (Kolkata Kendriya V.)',
    photoURL: '',
    streakCount: 12,
    quizzesPassed: 11,
    avgScore: 89,
    totalPoints: 1100 + 12 * 25 + Math.round(89 * 2), // 1100 + 300 + 178 = 1578
    isSimulated: true
  },
  {
    userId: 'peer_4',
    displayName: 'Rohan Jha (Bihar Scholar)',
    photoURL: '',
    streakCount: 8,
    quizzesPassed: 9,
    avgScore: 85,
    totalPoints: 900 + 8 * 25 + Math.round(85 * 2), // 900 + 200 + 170 = 1270
    isSimulated: true
  },
  {
    userId: 'peer_5',
    displayName: 'Meera Kutty (Chennai Academic Hub)',
    photoURL: '',
    streakCount: 5,
    quizzesPassed: 6,
    avgScore: 88,
    totalPoints: 600 + 5 * 25 + Math.round(88 * 2), // 600 + 125 + 176 = 901
    isSimulated: true
  }
];

// Hall Of Toppers with previous year final scores & top secret strategies
const PREVIOUS_YEAR_TOPPERS = [
  {
    name: "Sanjna Roy",
    year: "CBSE Class 10 Topper (2025)",
    score: "499/500 (99.8%)",
    subjectFocus: "Social Science & Sanskrit",
    tip: "Do not read multiple guidebooks. Master the NCERT line-by-line first. Make sure your Board answers are strictly composed of bulleted points with neat margins.",
    color: "from-amber-500 to-yellow-600"
  },
  {
    name: "Pratham Rastogi",
    year: "CBSE Class 10 Rank 2 (2024)",
    score: "498/500 (99.6%)",
    subjectFocus: "Mathematics & Science",
    tip: "Keep a separate small formula diary for trigonometry and carbonic chemicals. Practice previous year questions strictly within a 3-hour timer every Saturday.",
    color: "from-blue-500 to-indigo-600"
  },
  {
    name: "Gauri Deshpande",
    year: "National Merit Scholar (2025)",
    score: "497/500 (99.4%)",
    subjectFocus: "English Literature & Computer App",
    tip: "Most spelling marks are lost in English sections during literature quotes. Underline key lines from standard poems and reference character names correctly.",
    color: "from-purple-500 to-pink-600"
  }
];

export default function Leaderboard({ navigateTo, showToast }: LeaderboardProps) {
  const { user, setAuthModalOpen } = useAuth();
  const [activeTab, setActiveTab] = useState<'live' | 'hall'>('live');
  const [dbLeaderboard, setDbLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [syncedLeaderboard, setSyncedLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [loading, setLoading] = useState(false);
  const [syncingStats, setSyncingStats] = useState(false);

  // Local user computed values
  const [userStats, setUserStats] = useState<{
    streakCount: number;
    quizzesPassed: number;
    avgScore: number;
    totalPoints: number;
  }>({
    streakCount: 0,
    quizzesPassed: 0,
    avgScore: 0,
    totalPoints: 0
  });

  // Calculate local user stats derived from current storage
  useEffect(() => {
    const savedStreak = loadItem<any>('vidypath_streak_v1', null);
    const streakCount = savedStreak?.count || 0;
    
    const allProg = loadItem<Record<string, ProgressRecord>>('vidypath_progress_v4', {});
    const records = Object.values(allProg);
    const quizzesPassed = records.length;
    
    let avgScore = 0;
    if (quizzesPassed > 0) {
      avgScore = Math.round(
        records.reduce((sum, r) => sum + (r.bestScore / r.totalOut) * 100, 0) / quizzesPassed
      );
    }
    
    // Total Points formula: quizzesPassed * 100 + streakCount * 25 + Math.round(avgScore * 2);
    const totalPoints = quizzesPassed * 100 + streakCount * 25 + Math.round(avgScore * 2);
    
    setUserStats({
      streakCount,
      quizzesPassed,
      avgScore,
      totalPoints
    });
  }, []);

  // Sync / write local user stats to Firestore Leaderboard
  const syncLocalToGlobalLeaderboard = async () => {
    if (!user || userStats.quizzesPassed === 0) return;
    setSyncingStats(true);
    try {
      const dataPayload = {
        userId: user.uid,
        displayName: user.displayName || 'Board Aspirant',
        photoURL: user.photoURL || '',
        streakCount: userStats.streakCount,
        quizzesPassed: userStats.quizzesPassed,
        avgScore: userStats.avgScore,
        totalPoints: userStats.totalPoints,
        updatedAt: serverTimestamp()
      };
      
      await setDoc(doc(db, 'leaderboard', user.uid), dataPayload);
      console.log('Leaderboard record synchronized successfully.');
    } catch (err) {
      console.error('Error synchronizing global leaderboard:', err);
    } finally {
      setSyncingStats(false);
    }
  };

  // Trigger sync on user change or status calculation
  useEffect(() => {
    if (user && userStats.quizzesPassed > 0) {
      syncLocalToGlobalLeaderboard();
    }
  }, [user, userStats]);

  // Read Leaderboard from Firestore (Live onSnapshot)
  useEffect(() => {
    if (!user) return;
    setLoading(true);
    
    const dbQuery = query(collection(db, 'leaderboard'), orderBy('totalPoints', 'desc'), limit(40));
    
    const unsubscribe = onSnapshot(dbQuery, (snapshot) => {
      const entries: LeaderboardEntry[] = [];
      snapshot.forEach((docSnap) => {
        entries.push(docSnap.data() as LeaderboardEntry);
      });
      setDbLeaderboard(entries);
      setLoading(false);
    }, (error) => {
      console.error('Leaderboard fetch rejected: ', error);
      setLoading(false);
    });

    return unsubscribe;
  }, [user]);

  // Mix user local/firestore values and AI peers so the board is gorgeous and dynamic
  useEffect(() => {
    let mixedBoard: LeaderboardEntry[] = [];
    
    if (user && dbLeaderboard.length > 0) {
      // Filter out simulated peers that conflict with any real records,
      // and sort everything neatly together.
      const realUserIds = new Set(dbLeaderboard.map(e => e.userId));
      const filteredPeers = AI_PEER_STUDENTS.filter(peer => !realUserIds.has(peer.userId));
      
      mixedBoard = [...dbLeaderboard, ...filteredPeers];
    } else {
      // If offline/logged out, we mix the user's computed stats with simulated peers so they can see where they rank!
      const localUserEntry: LeaderboardEntry = {
        userId: 'local_current_user',
        displayName: user?.displayName || 'You (Aspirant)',
        photoURL: user?.photoURL || '',
        streakCount: userStats.streakCount,
        quizzesPassed: userStats.quizzesPassed,
        avgScore: userStats.avgScore,
        totalPoints: userStats.totalPoints
      };
      
      // Inject yourself if has active stats
      if (userStats.quizzesPassed > 0 || userStats.streakCount > 0) {
        mixedBoard = [localUserEntry, ...AI_PEER_STUDENTS];
      } else {
        mixedBoard = [...AI_PEER_STUDENTS];
      }
    }

    // Sort by points desc
    mixedBoard.sort((a, b) => b.totalPoints - a.totalPoints);
    setSyncedLeaderboard(mixedBoard);
  }, [dbLeaderboard, user, userStats]);

  // User's own position in combined board
  const myRank = syncedLeaderboard.findIndex(
    item => item.userId === (user ? user.uid : 'local_current_user')
  ) + 1;

  const triggerToastNotice = () => {
    showToast("🔥 Push your streak to conquer the Class 10 leader boards!");
  };

  return (
    <div className="max-w-[800px] mx-auto px-4 py-6 pb-28 space-y-6" id="leaderboard_primary_container">
      
      {/* Visual Hub Header */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 bg-surface p-7 rounded-[40px] border border-border/80 shadow-3xs relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-orange opacity-10 blur-[80px] -mr-16 -mt-16" />
        <div className="space-y-1 text-left relative z-10">
          <span className="text-[10px] font-black text-orange uppercase tracking-[0.2em] flex items-center gap-1.5 leading-none">
            <Trophy className="w-3.5 h-3.5 animate-bounce text-orange" />
            CBSE class 10 rankings
          </span>
          <h2 className="text-2xl font-display text-ink leading-tight">Board Prep Leaderboard</h2>
          <p className="text-xs text-ink3 font-medium leading-relaxed max-w-sm">
            Friendly competitive arena matching syllabus momentum, quiz masteries, and daily revision streaks.
          </p>
        </div>

        {/* Sync Indicator */}
        <div className="relative z-10 shrink-0">
          {user ? (
            <div className="flex flex-col items-end text-right gap-1">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-green-50 rounded-full border border-green-155 text-[9px] font-black uppercase text-green-700 tracking-wider">
                <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-ping" />
                Live Sync Enabled
              </span>
              {myRank > 0 && (
                <span className="text-[10px] text-ink3 font-bold mt-1">Your Rank: #{myRank} global</span>
              )}
            </div>
          ) : (
            <div className="p-3 bg-slate-50 dark:bg-slate-900 border border-border rounded-2xl flex items-center gap-3">
              <div className="text-left">
                <p className="text-[9px] font-black text-ink3 uppercase tracking-wide">Sync Offline Stats</p>
                <p className="text-[10px] font-bold text-ink mt-0.5">Sign in to claim Rank</p>
              </div>
              <button 
                type="button"
                onClick={() => setAuthModalOpen(true)}
                className="px-2.5 py-1.5 bg-blue-600 font-bold hover:bg-blue-700 text-white rounded-xl text-[9px] uppercase tracking-wider transition-all cursor-pointer"
              >
                Join Board
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Tabs Control Row */}
      <div className="flex bg-surface p-1.5 rounded-2xl border border-border" id="leaderboard_switch_tabs">
        <button
          type="button"
          onClick={() => setActiveTab('live')}
          className={cn(
            "flex-1 py-3 text-[10px] font-black uppercase tracking-wider rounded-xl transition-all flex items-center justify-center gap-2",
            activeTab === 'live' 
              ? "bg-ink text-white shadow-sm" 
              : "text-ink3 hover:text-ink hover:bg-gray-50/20"
          )}
        >
          <Zap className="w-3.5 h-3.5" />
          Active CBSE Toppers (2027)
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('hall')}
          className={cn(
            "flex-1 py-3 text-[10px] font-black uppercase tracking-wider rounded-xl transition-all flex items-center justify-center gap-2",
            activeTab === 'hall' 
              ? "bg-ink text-white shadow-sm" 
              : "text-ink3 hover:text-ink hover:bg-gray-50/20"
          )}
        >
          <Crown className="w-3.5 h-3.5" />
          Topper Hall of Fame (Previous Years)
        </button>
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'live' ? (
          <motion.div
            key="live-tab"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            className="space-y-4"
            id="toppers_2027_active_panel"
          >
            {/* Quick point rules helper banner */}
            <div className="p-4 bg-orange-lt/40 border border-orange-mid/40 rounded-3xl flex items-start gap-3.5 text-left">
              <Sparkles className="w-4 h-4 text-orange shrink-0 mt-0.5 animate-pulse" />
              <div>
                <p className="text-[10px] font-black text-orange uppercase tracking-wider">Formula for Board Prep Score</p>
                <p className="text-[11px] font-bold text-ink2 mt-1 leading-relaxed">
                  Earn <span className="text-orange">100 Points</span> for each Quiz completed, <span className="text-orange">25 Points</span> per continuous Active Day Streak, plus accuracy boosts from high scores. Retake quizzes to perfect your placement!
                </p>
              </div>
            </div>

            {/* Combined Leaderboard Feed */}
            <div className="bg-surface rounded-[32px] border border-border p-3 space-y-2.5">
              {loading && syncedLeaderboard.length === 0 ? (
                <div className="py-20 flex flex-col items-center justify-center gap-3 text-ink3">
                  <RefreshCw className="w-6 h-6 animate-spin text-blue-600" />
                  <span className="text-[10px] font-black uppercase tracking-widest">Querying database...</span>
                </div>
              ) : (
                <div className="space-y-2">
                  {syncedLeaderboard.map((entry, idx) => {
                    const rank = idx + 1;
                    const isCurrentUser = entry.userId === (user ? user.uid : 'local_current_user');
                    
                    // Medals style
                    let rankVisual = (
                      <span className="text-xs font-black text-ink3 w-5 text-center">{rank}</span>
                    );
                    if (rank === 1) {
                      rankVisual = <div className="w-6 h-6 bg-gradient-to-br from-yellow-300 to-amber-500 rounded-full flex items-center justify-center text-[10px] text-white shadow-xs font-black shrink-0">🥇</div>;
                    } else if (rank === 2) {
                      rankVisual = <div className="w-6 h-6 bg-gradient-to-br from-slate-200 to-slate-400 rounded-full flex items-center justify-center text-[10px] text-white shadow-xs font-black shrink-0">🥈</div>;
                    } else if (rank === 3) {
                      rankVisual = <div className="w-6 h-6 bg-gradient-to-br from-amber-500 to-orange rounded-full flex items-center justify-center text-[10px] text-white shadow-xs font-black shrink-0">🥉</div>;
                    }

                    return (
                      <div
                        key={`rank-${entry.userId}`}
                        className={cn(
                          "flex items-center justify-between p-3.5 rounded-2xl transition-all border",
                          isCurrentUser 
                            ? "bg-blue-50/50 dark:bg-blue-950/20 border-blue-300 shadow-sm" 
                            : "bg-surface border-border/40 hover:border-border"
                        )}
                      >
                        {/* Rank & Profile Name */}
                        <div className="flex items-center gap-3 min-w-0">
                          <div className="shrink-0 w-8 flex items-center justify-center">
                            {rankVisual}
                          </div>
                          
                          {/* Profile Circle */}
                          <div className="shrink-0 relative">
                            {entry.photoURL ? (
                              <img src={entry.photoURL} alt={entry.displayName} className="w-8 h-8 rounded-xl object-cover border border-border" />
                            ) : (
                              <div className={cn(
                                "w-8 h-8 rounded-xl flex items-center justify-center font-bold text-xs shadow-3xs",
                                entry.isSimulated 
                                  ? "bg-teal-50 text-teal-600 border border-teal-100" 
                                  : "bg-blue-50 text-blue-600 border border-blue-105"
                              )}>
                                {entry.displayName.charAt(0)}
                              </div>
                            )}

                            {isCurrentUser && (
                              <div className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-blue-500 text-white border-2 border-surface rounded-full flex items-center justify-center text-[6px] font-black">
                                YOU
                              </div>
                            )}
                          </div>

                          {/* Profile Text fields */}
                          <div className="min-w-0 text-left">
                            <p className={cn(
                              "text-xs font-bold truncate flex items-center gap-1.5",
                              isCurrentUser ? "text-blue-900 dark:text-blue-200" : "text-ink"
                            )}>
                              {entry.displayName}
                              {entry.isSimulated && (
                                <span className="px-1.5 py-0.5 bg-slate-100 text-[7px] font-black text-ink3 rounded uppercase tracking-wider shrink-0">PEER</span>
                              )}
                            </p>
                            
                            {/* Visual mini-status */}
                            <div className="flex items-center gap-2.5 mt-0.5 text-slate-500 text-[10px]">
                              <span className="flex items-center gap-1 shrink-0">
                                <Flame className="w-3.5 h-3.5 text-orange" />
                                <span className="font-bold">{entry.streakCount}d streak</span>
                              </span>
                              <span className="shrink-0 font-medium">·</span>
                              <span className="flex items-center gap-1 shrink-0">
                                <Target className="w-3.5 h-3.5 text-blue-500" />
                                <span className="font-bold">{entry.quizzesPassed} quizzes</span>
                              </span>
                              <span className="shrink-0 font-medium">·</span>
                              <span className="shrink-0 font-black text-green-600 dark:text-green-400">{entry.avgScore}% avg</span>
                            </div>
                          </div>
                        </div>

                        {/* Points Score badge */}
                        <div className="text-right shrink-0">
                          <span className="font-display text-sm font-black text-ink block">{entry.totalPoints}</span>
                          <span className="text-[8px] font-black text-ink3 uppercase tracking-wider block">PREP POINTS</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="hall-tab"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            className="space-y-4"
            id="hall_of_toppers_panel"
          >
            {/* Description Banner */}
            <div className="p-4 bg-purple-lt/40 border border-purple-mid/40 rounded-3xl flex items-start gap-3.5 text-left">
              <Award className="w-4 h-4 text-purple-600 shrink-0 mt-0.5" />
              <div>
                <p className="text-[10px] font-black text-purple-600 uppercase tracking-wider">Meet previous National board rankers</p>
                <p className="text-[11px] font-bold text-ink2 mt-1 leading-relaxed">
                  Proven approaches and active habit tricks shared by elite stars who conquered CBSE Class 10 with ultimate high scores. Use these tips during daily self-discipline routines.
                </p>
              </div>
            </div>

            {/* Topper Cards Grid */}
            <div className="grid grid-cols-1 gap-4 text-left">
              {PREVIOUS_YEAR_TOPPERS.map((topper, index) => (
                <div 
                  key={`topper-${index}`} 
                  className="bg-surface rounded-3xl border border-border p-6 shadow-3xs space-y-4 hover:border-purple-300 transition-all group"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${topper.color} text-white flex items-center justify-center font-display text-lg font-black`}>
                        {topper.name.charAt(0)}
                      </div>
                      <div>
                        <h4 className="font-display font-bold text-ink text-md group-hover:text-purple-600 transition-colors">{topper.name}</h4>
                        <p className="text-[10px] font-bold text-ink3 uppercase tracking-wider">{topper.year}</p>
                      </div>
                    </div>
                    
                    <div className="px-3 py-1 bg-amber-50 text-amber-700 font-display font-bold text-xs rounded-full border border-amber-200/50">
                      {topper.score}
                    </div>
                  </div>

                  <div className="bg-surface2 p-3.5 rounded-2xl border border-border/60 text-slate-700 text-xs font-semibold leading-relaxed">
                    <strong>Subject focus:</strong> {topper.subjectFocus}
                  </div>

                  <div className="space-y-2">
                    <div className="text-[9px] font-black uppercase text-purple-600 tracking-wider flex items-center gap-1.5">
                      <Check className="w-3.5 h-3.5" />
                      GOLDEN ACTION TIP
                    </div>
                    <p className="text-xs text-ink2 leading-relaxed font-medium">
                      "{topper.tip}"
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Encouraging motivational card or action call */}
      <div className="bg-gradient-to-br from-indigo-900 to-slate-950 p-7 rounded-[40px] text-white flex flex-col md:flex-row items-center justify-between gap-6 relative overflow-hidden text-left shadow-xl shadow-slate-300">
        <div className="absolute top-0 right-0 w-48 h-48 bg-blue-500 opacity-25 blur-[100px] -mr-16 -mt-16" />
        <div className="space-y-1 relative z-10">
          <p className="text-[9px] font-black text-blue-300 uppercase tracking-[0.2em]">Unlock Your Full Academic Potential</p>
          <h4 className="text-xl font-display text-white">Daily Consistency Outperforms Cramming</h4>
          <p className="text-xs text-white/60 leading-relaxed max-w-sm font-medium">
            Accumulate continuous daily study sessions, update your record, and scale high up the leaderboard peer group in real-time.
          </p>
        </div>
        
        <button
          type="button"
          onClick={() => navigateTo('home')}
          className="w-full md:w-auto px-7 py-3.5 bg-orange hover:bg-orange-dark text-white text-[10px] uppercase tracking-widest font-black rounded-2xl relative z-10 shadow-lg active:scale-95 transition-all text-center"
        >
          Practice a Chapter Now
        </button>
      </div>

    </div>
  );
}
