/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { Screen } from '../App';
import { SUBJECTS } from '../constants';
import { 
  calculateChapterMastery, 
  getChapterMasteryState 
} from '../utils/masteryHelper';
import { 
  Award, 
  BookOpen, 
  CheckCircle, 
  ChevronRight, 
  HelpCircle, 
  Sparkles, 
  Search, 
  ArrowLeft, 
  Flame, 
  Info, 
  BookOpenCheck,
  TrendingUp,
  Sliders,
  AlertCircle,
  PlayCircle
} from 'lucide-react';
import { cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';

interface MasteryDashboardProps {
  navigateTo: (s: Screen, subKey?: string | null, chIdx?: number | null, topic?: string | null, tab?: string | null) => void;
  showToast: (msg: string) => void;
}

export default function MasteryDashboard({ navigateTo, showToast }: MasteryDashboardProps) {
  // Filters: Selected Subject
  const [selectedSubjectKey, setSelectedSubjectKey] = useState<string>('all');
  
  // Search state
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  // Status Filter: 'all' | 'mastered' | 'learning' | 'attention'
  const [activeStatusTab, setActiveStatusTab] = useState<'all' | 'mastered' | 'learning' | 'attention'>('all');

  // Info Modal / Breakdown helper toggle
  const [showFormulaModal, setShowFormulaModal] = useState<boolean>(false);

  // Selected chapter for detailed formula view
  const [expandedChapterKey, setExpandedChapterKey] = useState<string | null>(null);

  // Re-calculate mastery states for all subjects & chapters
  const masteryData = useMemo(() => {
    let totalChaptersCount = 0;
    let sumMasteryScore = 0;
    
    const subjectScores: Record<string, { sum: number; count: number; mastered: number; learning: number; attention: number }> = {};
    const chaptersList: Array<{
      subjectKey: string;
      subjectLabel: string;
      subjectColor: string;
      subjectIcon: string;
      chapterName: string;
      chapterIndex: number;
      masteryScore: number;
      status: 'Needs Attention' | 'Learning' | 'Practicing' | 'Mastered';
      breakdown: {
        lecture: number;
        qbank: number;
        quiz: number;
        mistakes: number;
        revision: number;
        tricks: number;
      };
      remainingTasks: string[];
    }> = [];

    Object.entries(SUBJECTS).forEach(([subKey, sub]) => {
      subjectScores[subKey] = { sum: 0, count: 0, mastered: 0, learning: 0, attention: 0 };

      sub.chapters.forEach((ch, chIdx) => {
        totalChaptersCount++;
        const m = calculateChapterMastery(subKey, ch.name);
        
        // Calculate exact point contributions for debugging / detailed view
        const state = getChapterMasteryState(subKey, ch.name);
        const progressLogs = JSON.parse(localStorage.getItem('vidypath_progress_v4') || '{}');
        const quizRecord = progressLogs[`${subKey}__${ch.name}`];
        const quiz_accuracy = quizRecord && quizRecord.totalOut > 0 
          ? Math.round((quizRecord.bestScore / quizRecord.totalOut) * 100) 
          : 0;

        const mistakes = JSON.parse(localStorage.getItem('vidypath_mistakes_v1') || '[]');
        const chapterMistakes = mistakes.filter((mist: any) => 
          mist.chapterName?.toLowerCase() === ch.name?.toLowerCase() &&
          (mist.subject?.toLowerCase() === sub.label?.toLowerCase() || mist.subject?.toLowerCase() === subKey?.toLowerCase())
        );
        const totalMistakes = chapterMistakes.length;
        const fixedMistakes = chapterMistakes.filter((mist: any) => mist.originalSolved && mist.similarSolved).length;
        const recovery_pct = totalMistakes === 0 ? 100 : Math.round((fixedMistakes / totalMistakes) * 100);

        const breakdown = {
          lecture: state.lecture_completed ? 20 : 0,
          qbank: Math.round(state.qbank_accuracy * 0.25),
          quiz: Math.round(quiz_accuracy * 0.25),
          mistakes: Math.round(recovery_pct * 0.15),
          revision: Math.min(state.revisions_count, 4) * 2.5,
          tricks: state.tricks_completed ? 5 : 0
        };

        const totalCalculated = breakdown.lecture + breakdown.qbank + breakdown.quiz + breakdown.mistakes + breakdown.revision + breakdown.tricks;
        const score = Math.min(100, Math.max(0, totalCalculated));

        sumMasteryScore += score;
        subjectScores[subKey].sum += score;
        subjectScores[subKey].count += 1;

        if (m.status === 'Mastered') {
          subjectScores[subKey].mastered += 1;
        } else if (m.status === 'Learning' || m.status === 'Practicing') {
          subjectScores[subKey].learning += 1;
        } else {
          subjectScores[subKey].attention += 1;
        }

        chaptersList.push({
          subjectKey: subKey,
          subjectLabel: sub.label,
          subjectColor: sub.color || '#4F46E5',
          subjectIcon: sub.icon,
          chapterName: ch.name,
          chapterIndex: chIdx,
          masteryScore: score,
          status: m.status,
          breakdown,
          remainingTasks: m.remainingTasks
        });
      });
    });

    const overallMastery = totalChaptersCount > 0 ? Math.round(sumMasteryScore / totalChaptersCount) : 0;

    const subjectsSummary = Object.entries(SUBJECTS).map(([key, sub]) => {
      const stats = subjectScores[key];
      const avgScore = stats.count > 0 ? Math.round(stats.sum / stats.count) : 0;
      return {
        key,
        label: sub.label,
        icon: sub.icon,
        color: sub.color || '#4F46E5',
        light: sub.light || '#EEF2FF',
        averageMastery: avgScore,
        totalChapters: stats.count,
        masteredCount: stats.mastered,
        learningCount: stats.learning,
        attentionCount: stats.attention
      };
    });

    return {
      overallMastery,
      chaptersList,
      subjectsSummary
    };
  }, []);

  // Filter Chapters List dynamic computation
  const filteredChapters = useMemo(() => {
    return masteryData.chaptersList.filter(ch => {
      // 1. Subject filter
      if (selectedSubjectKey !== 'all' && ch.subjectKey !== selectedSubjectKey) return false;

      // 2. Search query filter
      if (searchQuery.trim() !== '') {
        const query = searchQuery.toLowerCase();
        const matchesName = ch.chapterName.toLowerCase().includes(query);
        const matchesSubject = ch.subjectLabel.toLowerCase().includes(query);
        if (!matchesName && !matchesSubject) return false;
      }

      // 3. Status filter
      // status matches: Needs Attention (0-49), Learning (50-69), Practicing (70-84), Mastered (85-100)
      if (activeStatusTab === 'mastered' && ch.status !== 'Mastered') return false;
      if (activeStatusTab === 'learning' && ch.status !== 'Learning' && ch.status !== 'Practicing') return false;
      if (activeStatusTab === 'attention' && ch.status !== 'Needs Attention') return false;

      return true;
    });
  }, [masteryData, selectedSubjectKey, searchQuery, activeStatusTab]);

  // Aggregate stats across filtered scope
  const listStats = useMemo(() => {
    const list = selectedSubjectKey === 'all' 
      ? masteryData.chaptersList 
      : masteryData.chaptersList.filter(c => c.subjectKey === selectedSubjectKey);

    const mastered = list.filter(c => c.status === 'Mastered').length;
    const learning = list.filter(c => c.status === 'Learning' || c.status === 'Practicing').length;
    const attention = list.filter(c => c.status === 'Needs Attention').length;

    return {
      total: list.length,
      mastered,
      learning,
      attention
    };
  }, [masteryData, selectedSubjectKey]);

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 pb-32 text-left animate-fadeIn">
      
      {/* 1. HEADER SECTION */}
      <header className="mb-8 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <button 
            onClick={() => navigateTo('home')}
            className="inline-flex items-center gap-1.5 text-ink3 font-bold text-xs uppercase tracking-widest hover:text-orange transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            Back to Home
          </button>
          <div className="flex items-center gap-2.5 pt-1">
            <h1 className="text-3xl font-display font-black tracking-tight text-ink">
              Mastery Dashboard
            </h1>
            <span className="bg-orange-lt text-orange font-black text-[10px] uppercase tracking-widest px-2.5 py-1 rounded-full border border-orange-mid/30">
              Board Engine Active
            </span>
          </div>
          <p className="text-ink3 text-xs">
            Comprehensive curriculum weights analyzer & priority practice routing.
          </p>
        </div>

        <button
          onClick={() => setShowFormulaModal(true)}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-ink3 hover:text-orange hover:bg-orange-lt border border-border/80 rounded-xl transition-all"
        >
          <Info className="w-4 h-4 text-orange" />
          How Mastery Is Calculated
        </button>
      </header>

      {/* 2. OVERALL AGGREGATE SUMMARY BANNER */}
      <section className="grid grid-cols-1 md:grid-cols-12 gap-6 mb-8">
        
        {/* OVERALL RADIAL/LINEAR GAUGE CARD */}
        <div className="md:col-span-4 bg-surface border border-border/80 rounded-3xl p-6 shadow-3xs flex flex-col items-center justify-center text-center relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-24 h-24 bg-orange/5 rounded-full blur-2xl -translate-y-6 translate-x-6" />
          
          <span className="text-[10px] font-black uppercase tracking-widest text-[#9CA3AF] mb-3 block">
            Overall Curriculum Mastery
          </span>
          
          <div className="relative w-36 h-36 flex items-center justify-center mb-4">
            {/* SVG Ring Gauge */}
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
              <circle
                cx="50"
                cy="50"
                r="42"
                className="stroke-neutral-100 dark:stroke-neutral-800"
                strokeWidth="8"
                fill="none"
              />
              <circle
                cx="50"
                cy="50"
                r="42"
                className="stroke-orange transition-all duration-1000 ease-out"
                strokeWidth="8.5"
                strokeDasharray={`${2 * Math.PI * 42}`}
                strokeDashoffset={`${2 * Math.PI * 42 * (1 - masteryData.overallMastery / 100)}`}
                strokeLinecap="round"
                fill="none"
              />
            </svg>
            <div className="absolute flex flex-col items-center justify-center">
              <span className="text-4xl font-display font-black text-ink">
                {masteryData.overallMastery}%
              </span>
              <span className="text-[9px] font-black text-emerald-500 bg-emerald-50 border border-emerald-100/50 px-2 py-0.5 rounded-full uppercase mt-1">
                {masteryData.overallMastery >= 85 ? 'Mastered' : masteryData.overallMastery >= 70 ? 'Practicing' : masteryData.overallMastery >= 50 ? 'Learning' : 'Needs Work'}
              </span>
            </div>
          </div>

          <p className="text-[10px] text-ink3 max-w-xs leading-relaxed">
            Your aggregate mastery score across all subjects based on the custom 6-stage metric weights.
          </p>
        </div>

        {/* STATUS TILES GRID */}
        <div className="md:col-span-8 grid grid-cols-1 sm:grid-cols-3 gap-4 h-full">
          
          {/* MASTERED STATUS TILE */}
          <div className="bg-surface border border-emerald-200/50 rounded-3xl p-6 flex flex-col justify-between shadow-3xs relative overflow-hidden">
            <div className="absolute top-4 right-4 w-10 h-10 bg-emerald-50 rounded-2xl flex items-center justify-center text-emerald-500 border border-emerald-100">
              <Award className="w-5.5 h-5.5" />
            </div>
            <div>
              <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest block mb-1">
                Mastered
              </span>
              <h3 className="text-3xl font-display font-black text-ink">
                {masteryData.chaptersList.filter(c => c.status === 'Mastered').length}
              </h3>
              <p className="text-ink3 text-[10px] font-bold uppercase mt-1">
                Chapters (85-100)
              </p>
            </div>
            <div className="pt-4 border-t border-border/40 mt-4 flex items-center justify-between">
              <span className="text-[10px] text-emerald-600 font-bold">Goal: 100% Mastered</span>
              <span className="text-[10px] text-ink3 font-bold">
                {Math.round((masteryData.chaptersList.filter(c => c.status === 'Mastered').length / (masteryData.chaptersList.length || 1)) * 100)}% of Total
              </span>
            </div>
          </div>

          {/* LEARNING / PRACTICING STATUS TILE */}
          <div className="bg-surface border border-blue-200/50 rounded-3xl p-6 flex flex-col justify-between shadow-3xs relative overflow-hidden">
            <div className="absolute top-4 right-4 w-10 h-10 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-500 border border-blue-100">
              <TrendingUp className="w-5.5 h-5.5" />
            </div>
            <div>
              <span className="text-[10px] font-black text-blue-600 uppercase tracking-widest block mb-1">
                Active Learning
              </span>
              <h3 className="text-3xl font-display font-black text-ink">
                {masteryData.chaptersList.filter(c => c.status === 'Learning' || c.status === 'Practicing').length}
              </h3>
              <p className="text-ink3 text-[10px] font-bold uppercase mt-1">
                Chapters (50-84)
              </p>
            </div>
            <div className="pt-4 border-t border-border/40 mt-4 flex items-center justify-between">
              <span className="text-[10px] text-blue-600 font-bold">In Active Focus</span>
              <span className="text-[10px] text-ink3 font-bold">
                {Math.round((masteryData.chaptersList.filter(c => c.status === 'Learning' || c.status === 'Practicing').length / (masteryData.chaptersList.length || 1)) * 100)}% of Total
              </span>
            </div>
          </div>

          {/* NEEDS ATTENTION STATUS TILE */}
          <div className="bg-surface border border-red-200/50 rounded-3xl p-6 flex flex-col justify-between shadow-3xs relative overflow-hidden">
            <div className="absolute top-4 right-4 w-10 h-10 bg-red-50 rounded-2xl flex items-center justify-center text-red-500 border border-red-100">
              <AlertCircle className="w-5.5 h-5.5" />
            </div>
            <div>
              <span className="text-[10px] font-black text-red-500 uppercase tracking-widest block mb-1">
                Needs Attention
              </span>
              <h3 className="text-3xl font-display font-black text-ink">
                {masteryData.chaptersList.filter(c => c.status === 'Needs Attention').length}
              </h3>
              <p className="text-ink3 text-[10px] font-bold uppercase mt-1">
                Chapters (0-49)
              </p>
            </div>
            <div className="pt-4 border-t border-border/40 mt-4 flex items-center justify-between">
              <span className="text-[10px] text-red-500 font-bold">Critical Priority</span>
              <span className="text-[10px] text-ink3 font-bold">
                {Math.round((masteryData.chaptersList.filter(c => c.status === 'Needs Attention').length / (masteryData.chaptersList.length || 1)) * 100)}% of Total
              </span>
            </div>
          </div>

        </div>

      </section>

      {/* 3. SUBJECT MASTERY GRID */}
      <section className="mb-10">
        <div className="flex items-center gap-2 mb-4">
          <BookOpenCheck className="w-5 h-5 text-orange" />
          <h2 className="text-lg font-display font-bold text-ink">Subject Mastery Ratings</h2>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
          {/* "All" Select Card */}
          <button
            onClick={() => setSelectedSubjectKey('all')}
            className={cn(
              "p-4 rounded-2xl border text-center transition-all duration-300 relative overflow-hidden flex flex-col items-center justify-between min-h-[110px]",
              selectedSubjectKey === 'all'
                ? "bg-orange text-white border-orange shadow-md shadow-orange/15"
                : "bg-surface border-border hover:border-orange/40 text-ink2"
            )}
          >
            <div className="w-10 h-10 rounded-full flex items-center justify-center text-lg bg-white/20 mb-2">
              🪐
            </div>
            <div className="space-y-0.5">
              <div className="text-[10px] font-black uppercase tracking-wider">All Subjects</div>
              <div className="text-lg font-black font-display">
                {masteryData.overallMastery}%
              </div>
            </div>
            <span className="text-[8px] font-black uppercase opacity-60">
              {masteryData.chaptersList.length} Chapters
            </span>
          </button>

          {/* Subjects List Mapping */}
          {masteryData.subjectsSummary.map((sub) => {
            const isSelected = selectedSubjectKey === sub.key;
            return (
              <button
                key={sub.key}
                onClick={() => setSelectedSubjectKey(sub.key)}
                className={cn(
                  "p-4 rounded-2xl border text-center transition-all duration-300 relative overflow-hidden flex flex-col items-center justify-between min-h-[110px]",
                  isSelected
                    ? "text-white shadow-lg shadow-orange/10 border-orange"
                    : "bg-surface border-border hover:border-orange/20 text-ink2"
                )}
                style={{
                  backgroundColor: isSelected ? sub.color : undefined,
                  borderColor: isSelected ? sub.color : undefined
                }}
              >
                <div 
                  className="w-10 h-10 rounded-xl flex items-center justify-center text-lg mb-2"
                  style={{ backgroundColor: isSelected ? 'rgba(255, 255, 255, 0.25)' : sub.light }}
                >
                  {sub.icon}
                </div>
                <div className="space-y-0.5">
                  <div className="text-[9px] font-black uppercase tracking-normal w-full truncate max-w-[100px] leading-tight">
                    {sub.label.split(' ')[0]} {/* Grab first word */}
                  </div>
                  <div className="text-lg font-black font-display">
                    {sub.averageMastery}%
                  </div>
                </div>
                <span className="text-[8px] font-black uppercase opacity-60">
                  {sub.totalChapters} Chapters
                </span>
              </button>
            );
          })}
        </div>
      </section>

      {/* 4. MAIN INTERACTIVE CHAPTER FILTER & DETAILS SECTION */}
      <section className="bg-surface border border-border/80 rounded-3xl p-6 shadow-3xs text-left">
        
        {/* FILTERS HEADER */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-border/60 pb-5 mb-6">
          
          {/* SEARCH BOX */}
          <div className="relative flex-1 max-w-sm">
            <Search className="w-4 h-4 text-ink3 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search chapters by name..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-bg border border-border focus:border-orange pl-10 pr-4 py-2 rounded-xl text-xs font-semibold text-ink outline-none transition-colors shadow-3xs"
            />
          </div>

          {/* STATUS CATEGORIES TAB CONTROL */}
          <div className="flex items-center gap-1.5 bg-bg border border-border p-1 rounded-xl scrollbar-none overflow-x-auto shrink-0 self-start md:self-auto">
            {[
              { id: 'all', label: 'All', count: listStats.total, color: 'text-ink' },
              { id: 'mastered', label: 'Mastered', count: listStats.mastered, color: 'text-emerald-500 bg-emerald-50 border-emerald-100' },
              { id: 'learning', label: 'Learning (50-84)', count: listStats.learning, color: 'text-blue-500 bg-blue-50 border-blue-100' },
              { id: 'attention', label: 'Needs Attention', count: listStats.attention, color: 'text-red-500 bg-red-50 border-red-100' }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveStatusTab(tab.id as any)}
                className={cn(
                  "px-3 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-wide transition-all outline-none flex items-center gap-1.5 whitespace-nowrap",
                  activeStatusTab === tab.id
                    ? "bg-white text-orange shadow-3xs shadow-black/5"
                    : "text-ink3 hover:text-ink hover:bg-neutral-50/50"
                )}
              >
                <span>{tab.label}</span>
                <span className="px-1.5 py-0.5 rounded-md bg-neutral-100 font-bold text-ink3">
                  {tab.count}
                </span>
              </button>
            ))}
          </div>

        </div>

        {/* RESULTS FEED */}
        <div className="space-y-4">
          {filteredChapters.length === 0 ? (
            <div className="py-20 text-center text-ink3 space-y-3">
              <span className="text-4xl">🔍</span>
              <p className="text-xs font-semibold">No chapters found matching standard parameters.</p>
              <p className="text-[10px] max-w-sm mx-auto">Try clearing search phrases or choosing a different subject key.</p>
            </div>
          ) : (
            <div className="space-y-3.5">
              {filteredChapters.map((ch, idx) => {
                const uniqueKey = `${ch.subjectKey}__${ch.chapterName}`;
                const isExpanded = expandedChapterKey === uniqueKey;
                
                // Color mapping for status metrics
                let statusBadgeColor = "bg-red-50 text-red-500 border border-red-100";
                let fillBarColor = "bg-red-500";
                
                if (ch.status === 'Mastered') {
                  statusBadgeColor = "bg-emerald-50 text-emerald-600 border border-emerald-100";
                  fillBarColor = "bg-emerald-500";
                } else if (ch.status === 'Practicing') {
                  statusBadgeColor = "bg-indigo-50 text-indigo-500 border border-indigo-100";
                  fillBarColor = "bg-indigo-500";
                } else if (ch.status === 'Learning') {
                  statusBadgeColor = "bg-amber-50 text-amber-600 border border-amber-100";
                  fillBarColor = "bg-amber-500";
                }

                return (
                  <div 
                    key={idx}
                    className={cn(
                      "border border-border/85 rounded-2xl bg-bg/40 hover:bg-bg transition-colors overflow-hidden",
                      isExpanded && "bg-bg/90 border-orange/40 ring-1 ring-orange/5"
                    )}
                  >
                    {/* ACCORDION COLLAPSIBLE TRIGGER BAR */}
                    <div 
                      onClick={() => setExpandedChapterKey(isExpanded ? null : uniqueKey)}
                      className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 cursor-pointer select-none"
                    >
                      {/* Left: Chapter Details */}
                      <div className="flex items-start gap-3.5 max-w-md">
                        <span className="text-2xl pt-0.5">{ch.subjectIcon}</span>
                        <div>
                          <h4 className="font-display font-medium text-sm text-ink leading-tight">
                            {ch.chapterName}
                          </h4>
                          <span className="text-[9px] font-black uppercase text-ink3 tracking-wide mt-1 block">
                            {ch.subjectLabel}
                          </span>
                        </div>
                      </div>

                      {/* Right: Progress Meter & Stats */}
                      <div className="flex items-center gap-6 justify-between sm:justify-start">
                        {/* Progress slider bar */}
                        <div className="space-y-1 block sm:text-right">
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-ink">{ch.masteryScore}% Mastery</span>
                            <span className={cn("text-[9px] font-black uppercase px-2 py-0.5 rounded-full shrink-0", statusBadgeColor)}>
                              {ch.status === 'Needs Attention' ? 'Attention' : ch.status}
                            </span>
                          </div>
                          
                          {/* Beautiful line scale */}
                          <div className="w-40 bg-neutral-100 dark:bg-neutral-800 h-2 rounded-full overflow-hidden">
                            <div 
                              className={cn("h-full rounded-full transition-all duration-300", fillBarColor)}
                              style={{ width: `${ch.masteryScore}%` }}
                            />
                          </div>
                        </div>

                        {/* Expand Chevron icon */}
                        <div className={cn(
                          "w-8 h-8 rounded-full border border-border/70 flex items-center justify-center hover:bg-orange-lt hover:text-orange transition-all",
                          isExpanded && "transform rotate-90 text-orange border-orange-mid/30"
                        )}>
                          <ChevronRight className="w-4 h-4" />
                        </div>
                      </div>

                    </div>

                    {/* EXPANDED BREAKDOWN DRAWER */}
                    <AnimatePresence initial={false}>
                      {isExpanded && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.2 }}
                          className="border-t border-border/50 bg-surface text-xs overflow-hidden"
                        >
                          <div className="p-5 space-y-6">
                            
                            {/* 1. COMPREHENSIVE CRITERIA MATRIX WEIGHTS */}
                            <div>
                              <h5 className="font-bold text-[10px] uppercase tracking-wider text-[#9CA3AF] mb-3">
                                Chapter Metric Contribution Breakdown (Goal: 100pts)
                              </h5>

                              <div className="grid grid-cols-2 md:grid-cols-6 gap-3.5">
                                {/* Lecture weight tile */}
                                <div className="p-3 bg-bg border border-border/80 rounded-xl space-y-1">
                                  <div className="flex items-center justify-between text-[10px] font-bold text-ink3">
                                    <span>Lecture (20%)</span>
                                    <span className={ch.breakdown.lecture > 0 ? "text-emerald-500 font-extrabold" : "text-neutral-400"}>
                                      {ch.breakdown.lecture}/20
                                    </span>
                                  </div>
                                  <div className="h-1.5 bg-neutral-100 dark:bg-neutral-800 rounded-full overflow-hidden">
                                    <div className="bg-emerald-500 h-full" style={{ width: `${(ch.breakdown.lecture / 20) * 100}%` }} />
                                  </div>
                                  <span className="text-[9px] text-[#9CA3AF] font-medium uppercase tracking-tighter">
                                    {ch.breakdown.lecture > 0 ? '✓ Completed' : '✕ Pending'}
                                  </span>
                                </div>

                                {/* Question Bank Weight */}
                                <div className="p-3 bg-bg border border-border/80 rounded-xl space-y-1">
                                  <div className="flex items-center justify-between text-[10px] font-bold text-ink3">
                                    <span>QBank (25%)</span>
                                    <span className={ch.breakdown.qbank >= 20 ? "text-emerald-500 font-extrabold" : "text-orange"}>
                                      {ch.breakdown.qbank}/25
                                    </span>
                                  </div>
                                  <div className="h-1.5 bg-neutral-100 dark:bg-neutral-800 rounded-full overflow-hidden">
                                    <div className="bg-orange h-full" style={{ width: `${(ch.breakdown.qbank / 25) * 100}%` }} />
                                  </div>
                                  <span className="text-[9px] text-[#9CA3AF] font-medium uppercase tracking-tighter">
                                    Acc: {Math.round(ch.breakdown.qbank / 0.25)}%
                                  </span>
                                </div>

                                {/* Quiz weight Tile */}
                                <div className="p-3 bg-bg border border-border/80 rounded-xl space-y-1">
                                  <div className="flex items-center justify-between text-[10px] font-bold text-ink3">
                                    <span>Mini Quiz (25%)</span>
                                    <span className={ch.breakdown.quiz >= 20 ? "text-emerald-500 font-extrabold" : "text-indigo-500"}>
                                      {ch.breakdown.quiz}/25
                                    </span>
                                  </div>
                                  <div className="h-1.5 bg-neutral-100 dark:bg-neutral-800 rounded-full overflow-hidden">
                                    <div className="bg-indigo-500 h-full" style={{ width: `${(ch.breakdown.quiz / 25) * 100}%` }} />
                                  </div>
                                  <span className="text-[9px] text-[#9CA3AF] font-medium uppercase tracking-tighter">
                                    Acc: {Math.round(ch.breakdown.quiz / 0.25)}%
                                  </span>
                                </div>

                                {/* Mistake Recovery Tile */}
                                <div className="p-3 bg-bg border border-border/80 rounded-xl space-y-1">
                                  <div className="flex items-center justify-between text-[10px] font-bold text-ink3">
                                    <span>Mistakes (15%)</span>
                                    <span className={ch.breakdown.mistakes >= 15 ? "text-emerald-500 font-extrabold" : "text-amber-500"}>
                                      {ch.breakdown.mistakes}/15
                                    </span>
                                  </div>
                                  <div className="h-1.5 bg-neutral-100 dark:bg-neutral-800 rounded-full overflow-hidden">
                                    <div className="bg-amber-500 h-full" style={{ width: `${(ch.breakdown.mistakes / 15) * 100}%` }} />
                                  </div>
                                  <span className="text-[9px] text-[#9CA3AF] font-medium uppercase tracking-tighter">
                                    Resolved: {Math.round(ch.breakdown.mistakes / 0.15)}%
                                  </span>
                                </div>

                                {/* Spaced Revision Tile */}
                                <div className="p-3 bg-bg border border-border/80 rounded-xl space-y-1">
                                  <div className="flex items-center justify-between text-[10px] font-bold text-ink3">
                                    <span>Revision (10%)</span>
                                    <span className={ch.breakdown.revision >= 10 ? "text-emerald-500 font-extrabold" : "text-pink-500"}>
                                      {ch.breakdown.revision}/10
                                    </span>
                                  </div>
                                  <div className="h-1.5 bg-neutral-100 dark:bg-neutral-800 rounded-full overflow-hidden">
                                    <div className="bg-pink-500 h-full" style={{ width: `${(ch.breakdown.revision / 10) * 100}%` }} />
                                  </div>
                                  <span className="text-[9px] text-[#9CA3AF] font-medium uppercase tracking-tighter">
                                    Revs: {ch.breakdown.revision / 2.5}/4
                                  </span>
                                </div>

                                {/* Tricks & Hacks Title */}
                                <div className="p-3 bg-bg border border-border/80 rounded-xl space-y-1">
                                  <div className="flex items-center justify-between text-[10px] font-bold text-ink3">
                                    <span>Tricks (5%)</span>
                                    <span className={ch.breakdown.tricks > 0 ? "text-emerald-500 font-extrabold" : "text-neutral-400"}>
                                      {ch.breakdown.tricks}/5
                                    </span>
                                  </div>
                                  <div className="h-1.5 bg-neutral-100 dark:bg-neutral-800 rounded-full overflow-hidden">
                                    <div className="bg-yellow-500 h-full" style={{ width: `${(ch.breakdown.tricks / 5) * 100}%` }} />
                                  </div>
                                  <span className="text-[9px] text-[#9CA3AF] font-medium uppercase tracking-tighter">
                                    {ch.breakdown.tricks > 0 ? '✓ Mastered' : '✕ Pending'}
                                  </span>
                                </div>

                              </div>
                            </div>

                            {/* 2. REMAINING STRATEGIC ACTIONS OR RECOMMENDATIONS */}
                            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-bg border border-border p-4 rounded-2xl">
                              
                              <div className="space-y-1 text-left">
                                <span className="text-[10px] uppercase font-black text-ink3 tracking-wider flex items-center gap-1">
                                  <Info className="w-3.5 h-3.5 text-orange" /> Suggestions to Maximize Chapter Mastery
                                </span>
                                {ch.remainingTasks.length === 0 ? (
                                  <p className="text-[11px] text-emerald-600 font-semibold pl-4.5">
                                    🎉 Champion pacing! This chapter has hit 100% full parameters!
                                  </p>
                                ) : (
                                  <ul className="list-disc pl-5 text-[11px] text-ink2 space-y-1.5 pt-1">
                                    {ch.remainingTasks.map((task, tIdx) => (
                                      <li key={tIdx} className="hover:text-ink">{task}</li>
                                    ))}
                                  </ul>
                                )}
                              </div>

                              <button
                                onClick={() => navigateTo('chapter-hub', ch.subjectKey, ch.chapterIndex, null, 'exam')}
                                className="w-full md:w-auto inline-flex items-center justify-center gap-1.5 px-4.5 py-2.5 bg-neutral-900 border border-neutral-800 hover:bg-neutral-850 hover:shadow-xs active:scale-95 text-white font-black text-[10px] uppercase tracking-widest rounded-xl transition-all shadow-3xs"
                              >
                                <PlayCircle className="w-4 h-4 text-emerald-400" /> Go To Practice Hub
                              </button>

                            </div>

                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                );
              })}
            </div>
          )}
        </div>

      </section>

      {/* 5. HOW IT WORKS MODAL */}
      <AnimatePresence>
        {showFormulaModal && (
          <div className="fixed inset-0 bg-ink/75 z-[999] backdrop-blur-sm flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-surface max-w-lg w-full rounded-[32px] border border-border shadow-2xl p-6 relative overflow-hidden"
            >
              <div className="space-y-4">
                <div className="flex justify-between items-center border-b border-border pb-3.5">
                  <div className="flex items-center gap-2">
                    <Sliders className="w-5.5 h-5.5 text-orange" />
                    <h3 className="font-display font-black text-md text-ink">Mastery Formula Weights</h3>
                  </div>
                  <button 
                    onClick={() => setShowFormulaModal(false)}
                    className="p-1.5 hover:bg-orange-lt rounded-xl text-ink3 hover:text-orange text-xs font-black uppercase transition-all"
                  >
                    Close
                  </button>
                </div>

                <div className="text-xs text-ink2 space-y-3 pt-2">
                  <p>
                    Every chapter's overall mastery score is dynamically parsed utilizing official educational weight benchmarks. Below are the coefficients for each milestone:
                  </p>

                  <div className="space-y-2 pt-2">
                    {[
                      { component: '📺 Video Lecture', weight: '20%', desc: 'Full study of conceptual lecture explanation' },
                      { component: '📖 Question Bank Practice', weight: '25%', desc: 'Accuracy rate achieved across structured exam questions' },
                      { component: '📝 Mini Board Quiz Assessment', weight: '25%', desc: 'Best score achieved in chapter evaluations' },
                      { component: '🎯 Mistake Recovery Review', weight: '15%', desc: 'Rate of fixing logged analytical mistakes in your Mistake Book' },
                      { component: '🔄 Spaced Revision schedule', weight: '10%', desc: 'Spaced repetition checks completed on Day 3, 7, 15, and 30' },
                      { component: '⚡ Memory Tricks & Mnemonics', weight: '5%', desc: 'Familiarity assessment of exam mnemonics and traps' }
                    ].map((item, idx) => (
                      <div key={idx} className="flex justify-between items-start p-2.5 bg-bg/50 border border-border/60 rounded-xl gap-2">
                        <div className="text-left">
                          <div className="font-bold text-[11px] text-ink">{item.component}</div>
                          <div className="text-[10px] text-ink3 leading-snug">{item.desc}</div>
                        </div>
                        <span className="px-2.5 py-0.5 rounded-lg bg-orange-lt text-orange font-black text-[10px] shrink-0 border border-orange-mid/30">
                          {item.weight}
                        </span>
                      </div>
                    ))}
                  </div>

                  <div className="p-3.5 bg-neutral-900 border border-neutral-800 text-white rounded-2xl flex items-start gap-2.5 mt-4">
                    <span className="text-lg">🏆</span>
                    <div>
                      <div className="font-black font-display text-[11px] text-white uppercase tracking-wider">Status Grading Brackets</div>
                      <div className="grid grid-cols-2 gap-x-4 gap-y-1 mt-1 text-[10px] font-semibold text-neutral-300">
                        <div>• 85 to 100 : <strong className="text-emerald-400">Mastered</strong></div>
                        <div>• 70 to 84 : <strong className="text-indigo-400">Practicing</strong></div>
                        <div>• 50 to 69 : <strong className="text-amber-400">Learning</strong></div>
                        <div>• 0 to 49 : <strong className="text-red-400">Needs Attention</strong></div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t border-border/40 text-center">
                  <button
                    onClick={() => setShowFormulaModal(false)}
                    className="w-full py-2.5 bg-orange text-white font-black text-[10px] uppercase tracking-widest rounded-xl hover:bg-orange/90 transition-all active:scale-95 shadow-xs"
                  >
                    Got It, Let's Master Chapters!
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
