/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { Screen } from '../App';
import { getAIResponse, fetchFlashcardsFromAI } from '../services/geminiService';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowLeft, MessageSquare, CheckCircle, Trophy, RefreshCw, Sparkles, Image as ImageIcon, Search, Settings, ShieldCheck, AlertCircle, Layers, ChevronLeft, ChevronRight, Save, BookOpen } from 'lucide-react';
import { cn, loadItem, saveItem } from '../lib/utils';
import { TestHistoryItem } from '../types';
import { SUBJECTS } from '../constants';
import { db, auth } from '../lib/firebase';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';

interface AIToolsProps {
  navigateTo: (s: Screen, subKey?: string | null, chIdx?: number | null) => void;
  showToast: (msg: string) => void;
}

type AITab = 'doubt' | 'notebook' | 'answer' | 'rank' | 'flashcards' | 'settings';

import DoubtSolverChat from './DoubtSolverChat';
import NotebookBuddy from './NotebookBuddy';

export default function AITools({ navigateTo, showToast }: AIToolsProps) {
  const [activeTab, setActiveTab] = useState<AITab>('doubt');
  
  // Answer Checker State
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [acResult, setAcResult] = useState<any>(null);
  const [acLoading, setAcLoading] = useState(false);

  // Rank Predictor State
  const [scores, setScores] = useState(['', '', '', '', '']);
  const [rpResult, setRpResult] = useState<any>(null);

  // Flashcards State
  const [selectedSub, setSelectedSub] = useState('maths');
  const [selectedCh, setSelectedCh] = useState(SUBJECTS['maths'].chapters[0].name);
  const [flashcards, setFlashcards] = useState<any[]>([]);
  const [isGeneratingFl, setIsGeneratingFl] = useState(false);
  const [isSavingFl, setIsSavingFl] = useState(false);
  const [currentFlIdx, setCurrentFlIdx] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [flMode, setFlMode] = useState<'ai' | 'manual'>('ai');
  const [srSettings] = useState({
    startingEase: 2.5,
    initialInterval: 1,
    hardMultiplier: 1.2,
    easyMultiplier: 1.5
  });
  const [manualCard, setManualCard] = useState({ front: '', back: '' });

  const updateCardContent = (idx: number, side: 'front' | 'back', val: string) => {
    const newCards = [...flashcards];
    if (newCards[idx]) {
      newCards[idx][side] = val;
      setFlashcards(newCards);
    }
  };

  const handleManualAdd = () => {
    if (!manualCard.front || !manualCard.back) {
      showToast('Please fill both sides.');
      return;
    }
    setFlashcards([...flashcards, { ...manualCard }]);
    setManualCard({ front: '', back: '' });
    showToast('Card added to list!');
  };

  // Settings State
  const [testResults, setTestResults] = useState<any>(null);
  const [testing, setTesting] = useState(false);

  const testConnection = async () => {
    setTesting(true);
    try {
      const res = await fetch('/api/test-keys');
      const data = await res.json();
      setTestResults(data);
      showToast('Connection test completed.');
    } catch (e) {
      showToast('Failed to test connection.');
    } finally {
      setTesting(false);
    }
  };

  const checkAns = async () => {
    if (!question || answer.length < 20) {
      showToast('Please enter both question and a detailed answer.');
      return;
    }
    setAcLoading(true);
    setAcResult(null);
    try {
      const prompt = `You are a CBSE Class 10 examiner. Evaluate the student's answer.
Question: ${question}
Student's answer: ${answer}

Evaluate strictly:
1. Score out of 10
2. Feedback (2-3 lines)
3. One improvement tip

Return ONLY JSON: {"score":7,"feedback":"...","suggestion":"..."}`;
      const raw = await getAIResponse(prompt);
      const jt = raw.replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/\s*```\s*$/i, '').trim();
      const res = JSON.parse(jt);
      setAcResult(res);
    } catch (e) {
      showToast('Evaluation failed. Try typing a longer answer.');
    } finally {
      setAcLoading(false);
    }
  };

  const predictRank = () => {
    const validScores = scores.map(s => parseFloat(s)).filter(s => !isNaN(s));
    if (validScores.length < 2) {
      showToast('Enter at least 2 test scores.');
      return;
    }
    const avg = validScores.reduce((a,b)=>a+b,0) / validScores.length;
    const predicted = Math.round(avg + (avg > 50 ? 5 : -5));
    const range = `${Math.max(0, predicted - 4)}–${Math.min(100, predicted + 4)}%`;
    setRpResult({ range, avg });
  };

  const generateFlashcards = async () => {
    setIsGeneratingFl(true);
    setFlashcards([]);
    setCurrentFlIdx(0);
    setIsFlipped(false);
    try {
      const cards = await fetchFlashcardsFromAI(SUBJECTS[selectedSub].label, selectedCh);
      setFlashcards(cards);
      showToast(`Generated ${cards.length} flashcards!`);
    } catch (e) {
      showToast('Flashcard generation failed.');
    } finally {
      setIsGeneratingFl(false);
    }
  };

  const saveToDeck = async () => {
    if (!auth.currentUser || flashcards.length === 0) {
      showToast(auth.currentUser ? 'No cards to save.' : 'Login to save cards.');
      return;
    }
    setIsSavingFl(true);
    try {
      const batchPromises = flashcards.map(card => 
        addDoc(collection(db, 'users', auth.currentUser!.uid, 'flashcards'), {
          ...card,
          subject: SUBJECTS[selectedSub].label,
          chapter: selectedCh,
          createdAt: serverTimestamp(),
          nextReview: serverTimestamp(),
          interval: srSettings.initialInterval,
          ease: srSettings.startingEase
        })
      );
      await Promise.all(batchPromises);
      showToast(`Successfully saved ${flashcards.length} cards to your deck!`);
      setFlashcards([]);
    } catch (e) {
      showToast('Failed to save flashcards.');
    } finally {
      setIsSavingFl(false);
    }
  };

  return (
    <div className="max-w-[780px] mx-auto px-4 py-8 pb-32">
      <button 
        onClick={() => navigateTo('home')}
        className="inline-flex items-center gap-2 mb-8 text-ink3 font-bold text-xs uppercase tracking-widest hover:text-orange transition-colors"
      >
        <ArrowLeft className="w-3.5 h-3.5" />
        Home
      </button>

      <div className="space-y-2 mb-8">
        <h2 className="text-3xl font-display tracking-tight">AI Study Tools</h2>
        <p className="text-sm text-ink2">Advanced tools to solve doubts, check answers & predict board scores.</p>
      </div>

      <div className="flex gap-2 p-1.5 bg-surface2 border border-border rounded-[24px] mb-8 overflow-x-auto no-scrollbar shadow-inner">
        {[
          { id: 'doubt', label: 'Doubt Solver', icon: MessageSquare },
          { id: 'notebook', label: 'Study Notebook', icon: BookOpen },
          { id: 'answer', label: 'Answer Checker', icon: CheckCircle },
          { id: 'flashcards', label: 'Flashcards', icon: Layers },
          { id: 'rank', label: 'Rank Predictor', icon: Trophy },
          { id: 'settings', label: 'Security', icon: ShieldCheck },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as AITab)}
            className={cn(
              "flex-1 flex items-center justify-center gap-2 px-5 py-3 text-[11px] font-black uppercase tracking-tight rounded-[18px] whitespace-nowrap transition-all duration-300",
              activeTab === tab.id 
                ? "bg-orange text-white shadow-lg shadow-orange/25 scale-[1.02]" 
                : "text-ink3 hover:text-ink hover:bg-surface"
            )}
          >
            <tab.icon className={cn("w-4 h-4", activeTab === tab.id ? "stroke-[2.5px]" : "stroke-[2px]")} />
            {tab.label}
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.15 }}
        >
          {activeTab === 'doubt' && (
            <DoubtSolverChat showToast={showToast} />
          )}

          {activeTab === 'notebook' && (
            <NotebookBuddy showToast={showToast} />
          )}

          {activeTab === 'answer' && (
            <div className="space-y-6">
              <div className="bg-surface p-6 rounded-3xl border border-border shadow-sm space-y-6">
                <div>
                  <label className="text-[10px] font-black uppercase tracking-widest text-ink3 mb-2 block">📝 What was the question?</label>
                  <input 
                    value={question}
                    onChange={(e) => setQuestion(e.target.value)}
                    placeholder="e.g. Define Ohm's Law and its mathematical expression."
                    className="w-full p-3 bg-surface2 border-1.5 border-border rounded-xl text-sm outline-none focus:border-orange transition-all font-semibold"
                  />
                </div>
                
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-[10px] font-black uppercase tracking-widest text-ink3">✏️ Type your answer</label>
                    <span className="text-[10px] font-bold text-ink3">{answer.length} characters</span>
                  </div>
                  <textarea 
                    value={answer}
                    onChange={(e) => setAnswer(e.target.value)}
                    rows={6}
                    placeholder="Write your answer as you would in a board exam..."
                    className="w-full p-4 bg-surface2 border-1.5 border-border rounded-2xl text-sm outline-none focus:border-orange transition-all font-medium resize-none"
                  />
                </div>

                <div className="p-4 border-2 border-dashed border-border rounded-2xl text-center space-y-1 group cursor-pointer hover:bg-orange-lt hover:border-orange/30 transition-all">
                  <ImageIcon className="w-6 h-6 mx-auto text-ink3 group-hover:text-orange" />
                  <div className="text-xs font-bold">Upload Handwritten Answer</div>
                  <p className="text-[10px] text-ink3">Coming soon: AI OCR support</p>
                </div>

                <button 
                  onClick={checkAns}
                  disabled={acLoading}
                  className="w-full bg-blue-600 text-white p-4 rounded-2xl font-bold text-sm shadow-xl shadow-blue-200 flex items-center justify-center gap-2 hover:-translate-y-1 transition-all active:scale-[0.98]"
                >
                  {acLoading ? <RefreshCw className="w-5 h-5 animate-spin" /> : <Search className="w-5 h-5" />}
                  Check My Answer
                </button>
              </div>

              {acResult && (
                <motion.div initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }} className="bg-surface rounded-3xl border border-border shadow-lg p-6 space-y-6">
                   <div className="flex items-center gap-6 border-b border-border pb-6">
                    <div className={cn(
                      "w-20 h-20 rounded-full border-4 flex flex-col items-center justify-center shadow-inner",
                      acResult.score >= 7 ? "border-green-100 text-green-600" : "border-orange-100 text-orange-600"
                    )}>
                      <div className="text-3xl font-display leading-none">{acResult.score}</div>
                      <div className="text-[10px] font-black uppercase opacity-60">/ 10</div>
                    </div>
                    <div>
                      <div className="text-lg font-bold">Evaluation Result</div>
                      <p className="text-xs text-ink3 font-medium">CBSE Examiner AI Report</p>
                    </div>
                   </div>

                   <div className="space-y-4">
                    <div className="space-y-2">
                       <label className="text-[10px] font-black uppercase tracking-widest text-ink3">AI Feedback</label>
                       <p className="text-sm font-medium text-ink leading-relaxed bg-surface2 p-4 rounded-2xl">{acResult.feedback}</p>
                    </div>
                    <div className="bg-orange-lt border border-orange-200 p-4 rounded-2xl space-y-1">
                      <div className="flex items-center gap-2 text-orange-700 font-bold text-[10px] uppercase">
                        <Sparkles className="w-3.5 h-3.5" />
                        Examiner Tip
                      </div>
                      <p className="text-xs text-orange-950 font-medium leading-relaxed">{acResult.suggestion}</p>
                    </div>
                   </div>
                </motion.div>
              )}
            </div>
          )}

          {activeTab === 'rank' && (
            <div className="space-y-6">
              <div className="bg-surface p-6 rounded-3xl border border-border shadow-sm space-y-6">
                <div className="grid grid-cols-5 gap-2">
                   {scores.map((s, i) => (
                    <div key={i} className="space-y-2">
                      <label className="text-[8px] font-bold uppercase text-ink3 text-center block">Test {i+1}</label>
                      <input 
                        type="number" 
                        value={s}
                        onChange={(e) => { const ns = [...scores]; ns[i] = e.target.value; setScores(ns); }}
                        placeholder="—"
                        className="w-full text-center p-2.5 bg-surface2 border border-border rounded-xl text-sm font-black focus:border-orange outline-none"
                      />
                    </div>
                   ))}
                </div>
                
                <button 
                  onClick={predictRank}
                  className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 text-white p-4 rounded-2xl font-bold text-sm shadow-xl shadow-purple-100 hover:-translate-y-1 transition-all active:scale-[0.98]"
                >
                  🔮 Predict Board Score
                </button>
              </div>

              {rpResult && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-gradient-to-br from-purple-600 to-purple-800 text-white p-8 rounded-[40px] text-center shadow-xl shadow-purple-200 relative overflow-hidden">
                  <div className="absolute top-[-40px] -right-10 w-40 h-40 bg-white/10 rounded-full blur-2xl" />
                  <div className="text-[11px] font-bold uppercase tracking-[0.2em] opacity-70 mb-2">Predicted Board Percentage</div>
                  <div className="text-6xl font-display mb-1">{rpResult.range}</div>
                  <p className="text-xs opacity-80 mt-4 leading-relaxed max-w-[240px] mx-auto">Based on your recent tests and a 5.2% average board-difficulty adjustment factor.</p>
                </motion.div>
              )}
            </div>
          )}

          {activeTab === 'flashcards' && (
            <div className="space-y-6">
              {/* Mode Toggle & Settings */}
              <div className="flex items-center justify-between gap-4">
                <div className="bg-surface2 p-1 rounded-xl border border-border inline-flex shadow-inner">
                  <button 
                    onClick={() => setFlMode('ai')}
                    className={cn(
                      "px-4 py-1.5 rounded-lg text-xs font-bold transition-all",
                      flMode === 'ai' ? "bg-white text-orange shadow-sm" : "text-ink3 hover:text-ink"
                    )}
                  >
                    AI Mode
                  </button>
                  <button 
                    onClick={() => setFlMode('manual')}
                    className={cn(
                      "px-4 py-1.5 rounded-lg text-xs font-bold transition-all",
                      flMode === 'manual' ? "bg-white text-orange shadow-sm" : "text-ink3 hover:text-ink"
                    )}
                  >
                    Manual
                  </button>
                </div>
                
                <div className="flex gap-2">
                  <button className="p-2 bg-surface2 rounded-xl border border-border text-ink3 hover:text-orange transition-colors">
                    <Settings className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {flMode === 'ai' ? (
                <div className="bg-surface p-6 rounded-3xl border border-border shadow-sm space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-ink3 block">Subject</label>
                      <select 
                        value={selectedSub}
                        onChange={(e) => {
                          setSelectedSub(e.target.value);
                          setSelectedCh(SUBJECTS[e.target.value].chapters[0].name);
                        }}
                        className="w-full p-3 bg-surface2 border-1.5 border-border rounded-xl text-sm outline-none focus:border-orange transition-all font-semibold appearance-none"
                      >
                        {Object.values(SUBJECTS).map(s => (
                          <option key={s.key} value={s.key}>{s.label}</option>
                        ))}
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-ink3 block">Chapter</label>
                      <select 
                        value={selectedCh}
                        onChange={(e) => setSelectedCh(e.target.value)}
                        className="w-full p-3 bg-surface2 border-1.5 border-border rounded-xl text-sm outline-none focus:border-orange transition-all font-semibold appearance-none"
                      >
                        {SUBJECTS[selectedSub].chapters.map(ch => (
                          <option key={ch.name} value={ch.name}>{ch.name}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <button 
                    onClick={generateFlashcards}
                    disabled={isGeneratingFl}
                    className="w-full bg-orange text-white p-4 rounded-2xl font-bold text-sm shadow-xl shadow-orange/20 flex items-center justify-center gap-2 hover:-translate-y-1 transition-all active:scale-[0.98]"
                  >
                    {isGeneratingFl ? <RefreshCw className="w-5 h-5 animate-spin" /> : <Sparkles className="w-5 h-5 fill-current" />}
                    Generate AI Flashcards
                  </button>
                </div>
              ) : (
                <div className="bg-surface p-6 rounded-3xl border border-border shadow-sm space-y-4">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-widest text-ink3 block">Front Side</label>
                    <textarea 
                      value={manualCard.front}
                      onChange={(e) => setManualCard({...manualCard, front: e.target.value})}
                      placeholder="Enter question or term..."
                      className="w-full p-4 bg-surface2 border-1.5 border-border rounded-2xl text-sm outline-none focus:border-orange transition-all h-24 resize-none"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-widest text-ink3 block">Back Side</label>
                    <textarea 
                      value={manualCard.back}
                      onChange={(e) => setManualCard({...manualCard, back: e.target.value})}
                      placeholder="Enter explanation or answer..."
                      className="w-full p-4 bg-surface2 border-1.5 border-border rounded-2xl text-sm outline-none focus:border-orange transition-all h-24 resize-none"
                    />
                  </div>
                  <button 
                    onClick={handleManualAdd}
                    className="w-full py-3 bg-ink text-white rounded-xl font-bold text-sm hover:opacity-90 transition-opacity"
                  >
                    Add to Session
                  </button>
                </div>
              )}

              {flashcards.length > 0 && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between px-2">
                    <div className="text-sm font-bold text-ink">
                      Card {currentFlIdx + 1} of {flashcards.length}
                    </div>
                    <div className="flex gap-3">
                      <button 
                        onClick={() => setFlashcards(prev => prev.filter((_, i) => i !== currentFlIdx))}
                        className="text-xs font-bold text-ink3 hover:text-red-500"
                      >
                        Discard
                      </button>
                      <button 
                        onClick={saveToDeck}
                        disabled={isSavingFl}
                        className="flex items-center gap-2 text-xs font-bold text-orange hover:bg-orange-lt px-3 py-1.5 rounded-lg transition-colors border border-orange/20"
                      >
                        {isSavingFl ? <RefreshCw className="w-3 h-3 animate-spin" /> : <Save className="w-3 h-3" />}
                        Save All ({flashcards.length})
                      </button>
                    </div>
                  </div>

                  {/* Editable Card */}
                  <div className="relative h-72 w-full perspective-1000">
                    <motion.div
                      animate={{ rotateY: isFlipped ? 180 : 0 }}
                      transition={{ duration: 0.6, type: "spring", stiffness: 260, damping: 20 }}
                      className="w-full h-full preserve-3d relative"
                    >
                      {/* Front */}
                      <div className="absolute inset-0 backface-hidden bg-surface border-2 border-orange/20 rounded-[32px] p-6 flex flex-col shadow-xl overflow-hidden">
                        <div className="absolute top-0 left-0 right-0 h-1 bg-orange/10" />
                        <div className="flex justify-between items-center mb-6">
                          <div className="flex flex-col">
                            <span className="text-[10px] font-black uppercase text-orange tracking-[0.2em]">Front</span>
                            <span className="text-[8px] font-bold text-ink3 uppercase truncate max-w-[150px]">
                              {SUBJECTS[selectedSub]?.label} • {selectedCh}
                            </span>
                          </div>
                          <Sparkles className="w-5 h-5 text-orange/30 p-1 bg-orange-lt rounded-lg" />
                        </div>
                        <div className="flex-1 flex flex-col items-center justify-center">
                          <textarea 
                            value={flashcards[currentFlIdx].front}
                            onChange={(e) => updateCardContent(currentFlIdx, 'front', e.target.value)}
                            className="w-full bg-transparent text-xl font-bold text-ink resize-none outline-none text-center leading-tight placeholder:text-ink3 placeholder:font-normal"
                            placeholder="Front side content..."
                          />
                        </div>
                        <button 
                          onClick={() => setIsFlipped(true)}
                          className="mt-6 py-2 px-4 rounded-xl bg-surface2 text-[10px] font-bold text-ink3 uppercase tracking-widest hover:text-orange hover:bg-orange-lt transition-all border border-border/50"
                        >
                          Click to Flip
                        </button>
                      </div>

                      {/* Back */}
                      <div 
                        className="absolute inset-0 backface-hidden bg-white border-2 border-orange/40 rounded-[32px] p-6 flex flex-col shadow-xl overflow-hidden"
                        style={{ transform: 'rotateY(180deg)', transformStyle: 'preserve-3d' }}
                      >
                        <div className="absolute top-0 left-0 right-0 h-1 bg-orange" />
                        <div className="flex justify-between items-center mb-6">
                          <div className="flex flex-col">
                            <span className="text-[10px] font-black uppercase text-orange tracking-[0.2em]">Back</span>
                            <span className="text-[8px] font-bold text-ink3 uppercase">Answer / Explanation</span>
                          </div>
                          <CheckCircle className="w-5 h-5 text-orange p-1 bg-orange-lt rounded-lg" />
                        </div>
                        <div className="flex-1 flex flex-col items-center justify-center">
                          <textarea 
                            value={flashcards[currentFlIdx].back}
                            onChange={(e) => updateCardContent(currentFlIdx, 'back', e.target.value)}
                            className="w-full bg-transparent text-lg font-medium leading-relaxed text-ink resize-none outline-none text-center placeholder:text-ink3"
                            placeholder="Back side content..."
                          />
                        </div>
                        <button 
                          onClick={() => setIsFlipped(false)}
                          className="mt-6 py-2 px-4 rounded-xl bg-orange text-[10px] font-bold text-white uppercase tracking-widest hover:bg-orange-dark transition-all shadow-md shadow-orange/20"
                        >
                          Go Back
                        </button>
                      </div>
                    </motion.div>
                  </div>

                  <div className="flex items-center justify-center gap-4">
                    <button 
                      onClick={() => {
                        setCurrentFlIdx(prev => Math.max(0, prev - 1));
                        setIsFlipped(false);
                      }}
                      disabled={currentFlIdx === 0}
                      className="w-12 h-12 rounded-full bg-surface border border-border flex items-center justify-center disabled:opacity-30 hover:shadow-md transition-all active:scale-95"
                    >
                      <ChevronLeft className="w-6 h-6" />
                    </button>
                    <button 
                      onClick={() => {
                        setCurrentFlIdx(prev => Math.min(flashcards.length - 1, prev + 1));
                        setIsFlipped(false);
                      }}
                      disabled={currentFlIdx === flashcards.length - 1}
                      className="w-12 h-12 rounded-full bg-surface border border-border flex items-center justify-center disabled:opacity-30 hover:shadow-md transition-all active:scale-95"
                    >
                      <ChevronRight className="w-6 h-6" />
                    </button>
                  </div>

                  {/* SR Preview Info */}
                  <div className="bg-orange-lt border border-orange/10 p-4 rounded-2xl flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-orange flex items-center justify-center text-white">
                      <RefreshCw className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-ink">Spaced Repetition Logic</div>
                      <p className="text-[10px] text-ink2 leading-tight">These cards will be saved with a starting ease of {srSettings.startingEase} to optimize your board preparation.</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {activeTab === 'settings' && (
            <div className="space-y-6">
              <div className="bg-surface p-6 rounded-3xl border border-border shadow-sm space-y-6">
                <div className="space-y-2">
                  <h3 className="text-sm font-bold flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-green-600" />
                    AI Provider Security
                  </h3>
                  <p className="text-xs text-ink3">All third-party API keys are strictly handled on our secure server. Your connection to AI providers is encrypted and safe.</p>
                </div>

                <div className="space-y-4 pt-4 border-t border-border/50">
                  <button 
                    onClick={testConnection}
                    disabled={testing}
                    className="w-full bg-surface2 border border-border p-3 rounded-xl text-xs font-bold hover:bg-surface3 transition-all flex items-center justify-center gap-2 group"
                  >
                    {testing ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <RefreshCw className="w-3.5 h-3.5 group-hover:rotate-180 transition-transform duration-500" />}
                    Test API Connections
                  </button>

                  {testResults && (
                    <div className="space-y-3">
                      {Object.entries(testResults).map(([key, info]: [string, any]) => (
                        <div key={key} className="flex items-center justify-between p-3 bg-surface2 rounded-xl border border-border">
                          <div className="capitalize text-xs font-bold">{key}</div>
                          <div className="flex items-center gap-2">
                            {info.status === 'ok' ? (
                              <span className="flex items-center gap-1 text-[10px] font-black text-green-600 uppercase">
                                <CheckCircle className="w-3 h-3" /> Ready
                              </span>
                            ) : info.status === 'configured' ? (
                                <span className="flex items-center gap-1 text-[10px] font-black text-blue-600 uppercase">
                                <CheckCircle className="w-3 h-3" /> Confirmed
                              </span>
                            ) : info.status === 'missing' ? (
                              <span className="flex items-center gap-1 text-[10px] font-black text-ink3 uppercase">
                                <AlertCircle className="w-3 h-3" /> Not Configured
                              </span>
                            ) : (
                              <span className="flex items-center gap-1 text-[10px] font-black text-red-600 uppercase">
                                <AlertCircle className="w-3 h-3" /> Error
                              </span>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="bg-blue-lt p-4 rounded-2xl border border-blue-100">
                  <p className="text-[10px] leading-relaxed text-blue-800 font-medium">
                    <b>Note:</b> If status is "Not Configured", please add your keys (GEMINI_API_KEY, GROQ_API_KEY, or OPENROUTER_API_KEY) in the App Settings.
                  </p>
                </div>
              </div>
            </div>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
