/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Screen } from '../App';
import { fetchBoardQuestions } from '../services/geminiService';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowLeft, Clock, PenTool, ClipboardCheck, ChevronRight, AlertCircle } from 'lucide-react';
import { cn, loadItem, saveItem } from '../lib/utils';
import { BoardQuestion, TestHistoryItem } from '../types';

interface BoardTestProps {
  navigateTo: (s: Screen, subKey?: string | null, chIdx?: number | null) => void;
  showToast: (msg: string) => void;
}

const TEST_TYPES = {
  daily: { id: 'daily', label: 'Daily Practice', mins: 15, qCount: 10, sections: [{ id: 'A', name: 'MCQ', type: 'mcq', count: 5, marks: 1 }, { id: 'B', name: 'Short', type: 'short', count: 5, marks: 2 }] },
  weekly: { id: 'weekly', label: 'Weekly Mock', mins: 30, qCount: 15, sections: [{ id: 'A', name: 'MCQ', type: 'mcq', count: 8, marks: 1 }, { id: 'B', name: 'Short', type: 'short', count: 5, marks: 3 }, { id: 'C', name: 'Case', type: 'case', count: 2, marks: 4 }] },
  monthly: { id: 'monthly', label: 'Board Level', mins: 90, qCount: 30, sections: [{ id: 'A', name: 'Objective', type: 'mcq', count: 12, marks: 1 }, { id: 'B', name: 'Short I', type: 'short', count: 8, marks: 2 }, { id: 'C', name: 'Short II', type: 'short', count: 5, marks: 3 }, { id: 'D', name: 'Long', type: 'long', count: 3, marks: 5 }, { id: 'E', name: 'Case', type: 'case', count: 2, marks: 4 }] }
};

export default function BoardTest({ navigateTo, showToast }: BoardTestProps) {
  const [phase, setPhase] = useState<'select' | 'active' | 'review'>('select');
  const [selectedType, setSelectedType] = useState('daily');
  const [subject, setSubject] = useState('Science');
  const [questions, setQuestions] = useState<BoardQuestion[]>([]);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const [timeLeft, setTimeLeft] = useState(0);

  useEffect(() => {
    let timer: any;
    if (phase === 'active' && timeLeft > 0) {
      timer = setInterval(() => setTimeLeft(prev => prev - 1), 1000);
    } else if (timeLeft === 0 && phase === 'active') {
      submitTest();
    }
    return () => clearInterval(timer);
  }, [phase, timeLeft]);

  const startTest = async () => {
    setLoading(true);
    const type = (TEST_TYPES as any)[selectedType];
    setTimeLeft(type.mins * 60);

    try {
      const allQs: BoardQuestion[] = [];
      let totalNum = 0;

      // Parallelize sections for speed
      const sectionPromises = type.sections.map((section: any) => 
        fetchBoardQuestions(section.type, subject, [], section.count, section.marks)
          .then(data => ({ section, data }))
      );

      const results = await Promise.all(sectionPromises);

      results.forEach(({ section, data }) => {
        data.forEach((q: any, i: number) => {
          allQs.push({
            id: `${section.id}_${i}`,
            sectionId: section.id,
            sectionName: section.name,
            type: section.type,
            marks: section.marks,
            num: ++totalNum,
            isWeak: false,
            q: q.q,
            opts: q.opts,
            ans: q.ans,
            ans_hint: q.ans_hint,
            passage: q.passage
          });
        });
      });

      setQuestions(allQs);
      setAnswers({});
      setPhase('active');
    } catch (e: any) {
      showToast('Error building test. Check connection.');
    } finally {
      setLoading(false);
    }
  };

  const submitTest = () => {
    setPhase('review');
    // Save to history
    const scored = questions.reduce((s, q) => {
      const ans = answers[q.id] || '';
      if (q.type === 'mcq') return s + (ans === q.ans ? q.marks : 0);
      return s + (ans.length > 20 ? q.marks : 0); // basic auto-score for subjective
    }, 0);
    const total = questions.reduce((s, q) => s + q.marks, 0);
    
    const item: TestHistoryItem = {
      id: Date.now(),
      type: selectedType,
      subject,
      scored,
      total,
      pct: Math.round((scored/total) * 100),
      mcqCorrect: 0,
      mcqTotal: 0,
      date: new Date().toLocaleDateString('en-IN')
    };
    
    const history = loadItem<TestHistoryItem[]>('vidypath_test_history_v1', []);
    saveItem('vidypath_test_history_v1', [item, ...history].slice(0, 50));
  };

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  if (loading) return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] text-center p-6 space-y-4">
      <div className="w-12 h-12 border-4 border-border border-t-orange rounded-full animate-spin" />
      <h3 className="font-bold text-lg">Building your Board Test...</h3>
      <p className="text-xs text-ink3">Preparing section-wise paper for {subject}</p>
    </div>
  );

  return (
    <div className="max-w-[760px] mx-auto px-4 py-8 pb-32">
      {phase === 'select' && (
        <div className="space-y-10 animate-fadeUp">
          <header className="space-y-4">
            <button onClick={() => navigateTo('home')} className="flex items-center gap-2 text-ink3 font-bold text-xs uppercase tracking-widest hover:text-orange transition-colors">
              <ArrowLeft className="w-3.5 h-3.5" /> Home
            </button>
            <div className="space-y-1">
              <h2 className="text-3xl font-display tracking-tight text-ink">Board Simulation</h2>
              <p className="text-sm text-ink2">Section-wise tests with real board patterns and time constraints.</p>
            </div>
          </header>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {Object.values(TEST_TYPES).map(t => (
              <button
                key={t.id}
                onClick={() => setSelectedType(t.id)}
                className={cn(
                  "p-6 rounded-3xl border-2 text-left space-y-4 transition-all group",
                  selectedType === t.id ? "bg-orange-lt border-orange shadow-lg shadow-orange/10" : "bg-surface border-border hover:border-orange/30 shadow-sm"
                )}
              >
                <div className={cn(
                  "w-10 h-10 rounded-2xl flex items-center justify-center text-lg",
                  selectedType === t.id ? "bg-orange text-white" : "bg-surface2 text-ink3 group-hover:text-orange transition-colors"
                )}>
                  {t.id === 'daily' ? '⚡' : t.id === 'weekly' ? '📅' : '🏆'}
                </div>
                <div>
                  <h4 className="font-bold text-base leading-tight mb-1">{t.label}</h4>
                  <p className="text-[10px] uppercase font-black tracking-wider opacity-60">{t.qCount} Questions · {t.mins} Mins</p>
                </div>
              </button>
            ))}
          </div>

          <div className="space-y-4">
             <label className="text-[10px] font-black uppercase tracking-widest text-ink3 block">Choose Subject</label>
             <div className="flex flex-wrap gap-2">
                {['Mathematics', 'Science', 'Social Studies', 'English', 'Hindi Course A', 'Hindi Course B', 'Marathi']
                  .filter(s => {
                    const activeLang = loadItem<string>('vidypath_active_language', 'hindi');
                    const sLower = s.toLowerCase();
                    if (sLower === 'mathematics' || sLower === 'science' || sLower === 'social studies' || sLower === 'english') return true;
                    if (activeLang === 'hindi' && s === 'Hindi Course A') return true;
                    if (activeLang === 'hindi_b' && s === 'Hindi Course B') return true;
                    if (activeLang === 'marathi' && s === 'Marathi') return true;
                    return false;
                  })
                  .map(s => (
                  <button 
                    key={s} 
                    onClick={() => setSubject(s)}
                    className={cn(
                      "px-5 py-2 text-xs font-bold rounded-xl border transition-all",
                      subject === s ? "bg-ink border-ink text-white" : "bg-surface border-border text-ink2 hover:border-orange"
                    )}
                  >
                    {s}
                  </button>
                ))}
             </div>
          </div>

          <button 
            onClick={startTest}
            className="w-full bg-orange text-white p-5 rounded-2xl font-bold tracking-tight shadow-xl shadow-orange/30 hover:-translate-y-1 transition-all active:scale-[0.98]"
          >
            Start Mock Test →
          </button>
        </div>
      )}

      {phase === 'active' && (
        <div className="space-y-8 animate-fadeUp">
          <div className="sticky top-20 z-50 bg-surface/90 backdrop-blur-md border border-border p-4 rounded-2xl shadow-md flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className={cn("px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest", selectedType === 'daily' ? 'bg-orange-lt text-orange' : 'bg-blue-50 text-blue-600')}>
                {selectedType}
              </div>
              <div className="text-sm font-bold text-ink2">{subject}</div>
            </div>
            <div className={cn("text-xl font-display flex items-center gap-2", timeLeft < 120 ? 'text-red-500 animate-pulse' : 'text-ink')}>
              <Clock className="w-5 h-5" />
              {formatTime(timeLeft)}
            </div>
            <button onClick={() => { if(confirm('Submit assessment?')) submitTest(); }} className="bg-green-600 text-white px-5 py-2 rounded-xl text-xs font-black uppercase tracking-widest shadow-md active:scale-95 transition-all">Submit</button>
          </div>

          <div className="space-y-12 pb-24">
            {Object.entries(questions.reduce((acc, q) => {
              if(!acc[q.sectionId]) acc[q.sectionId] = { name: q.sectionName, marks: q.marks, qs: [] };
              acc[q.sectionId].qs.push(q);
              return acc;
            }, {} as any)).map(([sid, sec]: any) => (
              <div key={`section-${sid}`} className="space-y-6">
                <div className="bg-ink text-white p-4 rounded-2xl flex items-center justify-between shadow-lg">
                   <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center font-display font-black text-sm">§{sid}</div>
                    <div className="text-sm font-bold tracking-tight">{sec.name}</div>
                   </div>
                   <div className="text-[10px] font-black uppercase opacity-60">{sec.marks} Mark{sec.marks > 1 ? 's' : ''} each</div>
                </div>

                <div className="space-y-4">
                  {sec.qs.map((q: BoardQuestion) => (
                    <div key={q.id} className="bg-surface p-6 rounded-[32px] border border-border shadow-sm space-y-6">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-black uppercase tracking-[0.2em] text-orange">Question {q.num}</span>
                        <div className="w-2 h-2 rounded-full bg-border" />
                      </div>
                      
                      {q.passage && (
                        <div className="bg-blue-lt border border-blue-100 p-5 rounded-2xl text-sm leading-relaxed text-blue-900 border-l-4 border-l-blue-400 italic">
                           <div className="text-[10px] font-black uppercase text-blue-500 not-italic mb-2 flex items-center gap-1">
                            <ClipboardCheck className="w-3.5 h-3.5" /> Case-based Passage
                           </div>
                           {q.passage}
                        </div>
                      )}

                      <h4 className="text-base font-bold leading-relaxed text-ink">{q.q}</h4>

                      {q.type === 'mcq' && q.opts ? (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {q.opts.map((opt, i) => (
                            <button
                              key={`opt-${q.id}-${i}`}
                              onClick={() => setAnswers(prev => ({ ...prev, [q.id]: opt }))}
                              className={cn(
                                "p-4 text-left rounded-2xl border-2 transition-all text-xs font-semibold flex gap-3 items-center",
                                answers[q.id] === opt ? "bg-blue-50 border-blue-500 text-blue-900 shadow-inner" : "bg-surface2 border-border/50 text-ink2 hover:border-orange/30"
                              )}
                            >
                              <div className={cn("w-6 h-6 rounded-lg flex items-center justify-center font-bold text-[10px]", answers[q.id] === opt ? "bg-blue-500 text-white" : "bg-border text-ink3")}>
                                {['A','B','C','D'][i]}
                              </div>
                              {opt}
                            </button>
                          ))}
                        </div>
                      ) : (
                        <textarea 
                          className="w-full bg-surface2 border-2 border-border/50 rounded-2xl p-5 text-sm font-medium outline-none focus:border-orange transition-all placeholder:text-ink3/40"
                          rows={sid === 'D' ? 8 : 4}
                          placeholder="Type your structured answer here..."
                          value={answers[q.id] || ''}
                          onChange={(e) => setAnswers(prev => ({ ...prev, [q.id]: e.target.value }))}
                        />
                      )}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {phase === 'review' && (
        <div className="space-y-8 animate-fadeUp">
          <header className="space-y-4">
             <button onClick={() => navigateTo('home')} className="flex items-center gap-2 text-ink3 font-bold text-xs uppercase tracking-widest hover:text-orange transition-colors">
              <ArrowLeft className="w-3.5 h-3.5" /> Back to Home
            </button>
            <h2 className="text-3xl font-display tracking-tight text-ink">Test Report</h2>
          </header>
          
          <div className="bg-gradient-to-br from-orange to-[#FF9A3C] p-10 rounded-[40px] text-white text-center shadow-xl space-y-6">
            <div className="text-[11px] font-black uppercase tracking-[0.3em] opacity-80">Assessment Results</div>
            <div className="text-8xl font-display leading-none">
               {Math.round((questions.reduce((s,q) => s + (q.type === 'mcq' ? (answers[q.id] === q.ans ? q.marks : 0) : 0), 0) / questions.reduce((s,q) => s+q.marks, 0)) * 100)}%
            </div>
            <div className="space-y-1">
              <p className="text-lg font-bold">Excellent attempt in {subject}!</p>
              <p className="text-xs opacity-70">Review the subjective answer hints below to self-evaluate.</p>
            </div>
          </div>

          <div className="space-y-4">
             {questions.map(q => {
               const isCorrect = q.type === 'mcq' ? (answers[q.id] === q.ans) : (answers[q.id]?.length > 20);
               return (
                <div key={q.id} className="bg-surface p-6 rounded-[32px] border border-border shadow-sm space-y-4">
                   <div className="flex items-center gap-3">
                    <div className={cn("px-2.5 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest", isCorrect ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700')}>
                      {isCorrect ? 'Matched' : 'Check Hint'}
                    </div>
                    <span className="text-[10px] font-bold text-ink3">Q{q.num} · {q.sectionName}</span>
                   </div>
                   <p className="text-sm font-bold leading-relaxed">{q.q}</p>
                   {q.type === 'mcq' ? (
                     <div className="text-xs font-semibold py-1">
                      <div className="text-ink2 mb-1">Your answer: <span className={isCorrect ? 'text-green-600' : 'text-red-600'}>{answers[q.id] || 'Skipped'}</span></div>
                      {!isCorrect && <div className="text-green-600">Correct: {q.ans}</div>}
                     </div>
                   ) : (
                     <div className="space-y-4 pt-2">
                       <div className="text-xs font-medium text-ink2 leading-relaxed italic bg-surface2 p-4 rounded-xl">Your answer: {answers[q.id] || '(No response typed)'}</div>
                       <div className="bg-blue-lt border border-blue-100 p-4 rounded-xl text-xs font-bold text-blue-900 leading-relaxed">
                        <div className="flex items-center gap-1.5 text-blue-600 text-[10px] uppercase mb-1">
                          <AlertCircle className="w-3 h-3" /> Model Hint
                        </div>
                        {q.ans_hint}
                       </div>
                     </div>
                   )}
                </div>
               );
             })}
          </div>
          
          <button onClick={() => setPhase('select')} className="w-full bg-surface border border-border p-5 rounded-2xl font-bold text-ink transition-all active:scale-[0.98]">
            Take Another Test
          </button>
        </div>
      )}
    </div>
  );
}
