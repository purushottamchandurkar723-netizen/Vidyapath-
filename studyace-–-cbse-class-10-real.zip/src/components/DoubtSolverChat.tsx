/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { getAIResponse } from '../services/geminiService';
import { motion } from 'motion/react';
import { MessageSquare, Send, RefreshCw, Trash2 } from 'lucide-react';
import { cn, loadItem, saveItem } from '../lib/utils';
import { ChatMessage } from '../types';
import { db, auth } from '../lib/firebase';
import { collection, addDoc, serverTimestamp, query, orderBy, limit, onSnapshot, getDocs, writeBatch } from 'firebase/firestore';

interface DoubtSolverChatProps {
  showToast: (msg: string) => void;
  height?: string;
  className?: string;
}

function parseTutorMarkdown(text: string) {
  if (!text) return null;
  // Splits by double linebreaks to find paragraphs or block elements
  const blocks = text.split('\n\n');
  return blocks.map((block, bIdx) => {
    const trimmed = block.trim();
    if (!trimmed) return null;

    // Check if it is a heading/topic starting with # or **
    const isHeading = trimmed.startsWith('#') || (trimmed.startsWith('**') && trimmed.endsWith('**') && !trimmed.includes('\n'));
    if (isHeading) {
      const cleanHeading = trimmed.replace(/[\#\*]/g, '').trim();
      return <h5 key={bIdx} className="font-bold text-sm mt-3 mb-1 text-orange uppercase tracking-wider">{cleanHeading}</h5>;
    }

    // Check if it's a list (bullet points starting with '-' or '*')
    const lines = trimmed.split('\n');
    const isList = lines.every(line => /^\s*[\-\*\u2022]\s|^\s*\d+[\.\)]\s/.test(line));
    if (isList && lines.length > 0) {
      return (
        <ul key={bIdx} className="list-disc pl-5 my-2 space-y-1 text-xs">
          {lines.map((l, lIdx) => {
            const cleanLine = l.replace(/^\s*[\-\*\u2022]\s|^\s*\d+[\.\)]\s/, '').trim();
            return <li key={lIdx} className="leading-relaxed">{parseInlineMarkdown(cleanLine)}</li>;
          })}
        </ul>
      );
    }

    // Normal paragraph with inline styles (bold words)
    return (
      <p key={bIdx} className="text-xs mb-2 leading-relaxed last:mb-0">
        {parseInlineMarkdown(trimmed)}
      </p>
    );
  });
}

function parseInlineMarkdown(text: string) {
  const parts = text.split(/(\*\*[^*]+\*\*)/g);
  return parts.map((part, i) => {
    if (part.startsWith('**') && part.endsWith('**')) {
      return <strong key={i} className="font-extrabold text-orange">{part.slice(2, -2)}</strong>;
    }
    return part;
  });
}

export default function DoubtSolverChat({ showToast, height = "520px", className }: DoubtSolverChatProps) {
  const [chat, setChat] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [loadingChat, setLoadingChat] = useState(false);
  const [showChips, setShowChips] = useState(true);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const quickChips = ["Explain standard deviation", "What is photosynthesis?", "Pythagorean theorem formula", "Important dates in History"];

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chat, isTyping]);

  useEffect(() => {
    let unsubscribe: undefined | (() => void);

    if (auth.currentUser) {
      setLoadingChat(true);
      const q = query(
        collection(db, 'users', auth.currentUser.uid, 'chatMessages'),
        orderBy('timestamp', 'asc'),
        limit(50)
      );

      unsubscribe = onSnapshot(q, (snapshot) => {
        const msgs = snapshot.docs.map(doc => {
          const data = doc.data();
          return {
            role: data.role,
            content: data.content
          } as ChatMessage;
        });
        setChat(msgs);
        setLoadingChat(false);
      }, (error) => {
        console.error("Chat sync error:", error);
        setLoadingChat(false);
      });
    } else {
      setChat(loadItem('vidypath_chat_v1', []));
    }

    return () => unsubscribe?.();
  }, [auth.currentUser]);

  useEffect(() => {
    if (!auth.currentUser) {
      saveItem('vidypath_chat_v1', chat);
    }
  }, [chat]);

  const sendMsg = async () => {
    if (!input.trim() || isTyping) return;
    const userMsg: ChatMessage = { role: 'user', content: input };
    
    if (auth.currentUser) {
      try {
        await addDoc(collection(db, 'users', auth.currentUser.uid, 'chatMessages'), {
          ...userMsg,
          timestamp: serverTimestamp()
        });
      } catch (e) {
        showToast('Failed to save message.');
        return;
      }
    } else {
      setChat(prev => [...prev, userMsg]);
    }

    const currentInput = input;
    setInput('');
    setIsTyping(true);

    try {
      const prompt = `You are a friendly, expert CBSE Class 10 tutor. Give clear, concise explanations at Class 10 level. Use simple language, examples, and NCERT-aligned content. Keep replies under 200 words.\n\nStudent: ${currentInput}`;
      const reply = await getAIResponse(prompt);
      const aiMsg: ChatMessage = { role: 'assistant', content: reply };

      if (auth.currentUser) {
        await addDoc(collection(db, 'users', auth.currentUser.uid, 'chatMessages'), {
          ...aiMsg,
          timestamp: serverTimestamp()
        });
      } else {
        setChat(prev => [...prev, aiMsg]);
      }
    } catch (e) {
      const errMsg: ChatMessage = { role: 'assistant', content: "⚠️ Sorry, I'm having trouble connecting to my brain. Please try again." };
      if (!auth.currentUser) {
        setChat(prev => [...prev, errMsg]);
      }
      showToast('AI response failed.');
    } finally {
      setIsTyping(false);
    }
  };

  const clearChat = async () => {
    if (!confirm('Are you sure you want to clear the entire chat history?')) return;

    if (auth.currentUser) {
      try {
        const q = query(collection(db, 'users', auth.currentUser.uid, 'chatMessages'));
        const snapshot = await getDocs(q);
        const batch = writeBatch(db);
        snapshot.docs.forEach(d => batch.delete(d.ref));
        await batch.commit();
        showToast('Cloud chat history cleared.');
      } catch (e) {
        showToast('Failed to clear cloud history.');
      }
    } else {
      setChat([]);
      saveItem('vidypath_chat_v1', []);
      showToast('Local chat history cleared.');
    }
  };

  return (
    <div className={cn("bg-surface rounded-3xl border border-border shadow-md overflow-hidden flex flex-col", className)} style={{ height }}>
      <div className="flex items-center justify-between p-4 bg-gradient-to-r from-orange to-[#FF9A3C] text-white">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-white/20 rounded-full flex items-center justify-center text-xl">🤖</div>
          <div>
            <div className="text-sm font-bold leading-none">AI Tutor</div>
            <div className="text-[10px] opacity-70 mt-1 uppercase font-bold tracking-widest">Always active</div>
          </div>
        </div>
        {chat.length > 0 && (
          <button 
            onClick={clearChat}
            className="p-2 hover:bg-white/10 rounded-lg transition-colors group"
            title="Clear Chat"
          >
            <Trash2 className="w-4 h-4 text-white/80 group-hover:text-white" />
          </button>
        )}
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
        {loadingChat && (
          <div className="h-full flex items-center justify-center opacity-40">
            <RefreshCw className="w-8 h-8 animate-spin text-orange" />
          </div>
        )}
        {!loadingChat && chat.length === 0 && (
          <div className="h-full flex flex-col items-center justify-center text-center p-8 space-y-4">
            <div className="grayscale opacity-40 flex flex-col items-center gap-4">
              <MessageSquare className="w-12 h-12" />
              <p className="text-sm font-semibold max-w-[200px]">Ask any doubt — concepts, equations, or NCERT problems.</p>
            </div>
            {showChips && (
              <div className="flex flex-wrap justify-center gap-2 pt-4">
                {quickChips.map((chip, idx) => (
                  <button
                    key={idx}
                    onClick={() => { setInput(chip); setShowChips(false); }}
                    className="px-3 py-1.5 bg-surface2 border border-border rounded-full text-[10px] font-bold text-ink2 hover:bg-orange-lt hover:text-orange hover:border-orange-mid transition-all"
                  >
                    + {chip}
                  </button>
                ))}
              </div>
            )}
          </div>
        )}
        {!loadingChat && chat.map((m, i) => (
          <div key={i} className={cn("flex gap-3 max-w-[85%]", m.role === 'user' ? "ml-auto flex-row-reverse" : "")}>
            <div className={cn(
              "w-7 h-7 rounded-full flex items-center justify-center text-xs flex-shrink-0 mt-1 shadow-sm",
              m.role === 'user' ? "bg-orange text-white" : "bg-blue-50 text-blue-600 border border-blue-100"
            )}>
              {m.role === 'user' ? '👤' : '🤖'}
            </div>
            <div className={cn(
              "px-4 py-3 rounded-2xl text-sm leading-relaxed",
              m.role === 'user' ? "bg-orange text-white rounded-tr-none shadow-sm" : "bg-surface2 border border-border rounded-tl-none text-ink"
            )}>
              {m.role === 'user' ? (
                <p className="text-xs">{m.content}</p>
              ) : (
                <div className="space-y-1.5">{parseTutorMarkdown(m.content)}</div>
              )}
            </div>
          </div>
        ))}
        {isTyping && (
          <div className="flex gap-3 max-w-[85%]">
            <div className="w-7 h-7 bg-blue-50 border border-blue-100 rounded-full flex items-center justify-center text-xs flex-shrink-0 mt-1 shadow-sm text-blue-600">🤖</div>
            <div className="bg-surface2 border border-border px-4 py-3 rounded-2xl rounded-tl-none flex gap-1 items-center">
              <span className="w-1.5 h-1.5 bg-ink3 rounded-full animate-bounce" />
              <span className="w-1.5 h-1.5 bg-ink3 rounded-full animate-bounce [animation-delay:0.2s]" />
              <span className="w-1.5 h-1.5 bg-ink3 rounded-full animate-bounce [animation-delay:0.4s]" />
            </div>
          </div>
        )}
        <div ref={chatEndRef} />
      </div>

      <div className="p-4 bg-surface border-t border-border flex gap-2">
        <input 
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && sendMsg()}
          placeholder="Type your doubt here..."
          className="flex-1 bg-surface2 border-1.5 border-border rounded-2xl px-4 py-2.5 text-sm outline-none focus:border-orange focus:ring-4 focus:ring-orange/10 transition-all font-medium"
        />
        <button 
          onClick={sendMsg}
          disabled={!input.trim() || isTyping}
          className="w-10 h-10 bg-orange text-white rounded-xl shadow-lg shadow-orange/20 flex items-center justify-center disabled:opacity-50 transition-all active:scale-95"
        >
          <Send className="w-4 h-4 fill-current" />
        </button>
      </div>
    </div>
  );
}
