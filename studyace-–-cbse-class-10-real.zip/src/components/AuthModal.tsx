import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { X, LogIn, Mail, Lock, User, BookOpen, GraduationCap, Sparkles } from 'lucide-react';
import { cn } from '../lib/utils';

const AVATARS = [
  { id: 'fox', emoji: '🦊', label: 'Clever Fox', bg: 'bg-amber-100 border-amber-200 text-amber-700' },
  { id: 'owl', emoji: '🦉', label: 'Wise Owl', bg: 'bg-green-100 border-green-200 text-green-700' },
  { id: 'rocket', emoji: '🚀', label: 'Star Scholar', bg: 'bg-orange-100 border-orange-200 text-orange-700' },
  { id: 'bulb', emoji: '💡', label: 'Tech Brain', bg: 'bg-yellow-100 border-yellow-200 text-yellow-700' },
  { id: 'lion', emoji: '🦁', label: 'Bold Topper', bg: 'bg-red-100 border-red-200 text-red-700' },
  { id: 'grad', emoji: '🎓', label: 'CBSE Champ', bg: 'bg-blue-100 border-blue-200 text-blue-700' },
];

interface AuthModalProps {
  onClose: () => void;
}

export default function AuthModal({ onClose }: AuthModalProps) {
  const { signIn, signInWithEmail, signUpWithEmail } = useAuth();
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [classVal, setClassVal] = useState('CBSE Class 10');
  const [schoolVal, setSchoolVal] = useState('');
  const [selectedAvatar, setSelectedAvatar] = useState('fox');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const getAvatarEmoji = (id: string) => {
    return AVATARS.find(a => a.id === id)?.emoji || '🦊';
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      if (isSignUp) {
        if (!name.trim()) throw new Error('Please enter your full name');
        if (!email.trim()) throw new Error('Please enter your email address');
        if (password.length < 6) throw new Error('Password must be at least 6 characters');

        const avatarEmoji = getAvatarEmoji(selectedAvatar);
        await signUpWithEmail(
          email.trim(),
          password,
          name.trim(),
          classVal,
          schoolVal.trim() || undefined,
          avatarEmoji
        );
      } else {
        if (!email.trim()) throw new Error('Please enter your email address');
        if (!password) throw new Error('Please enter your password');

        await signInWithEmail(email.trim(), password);
      }
      onClose();
    } catch (err: any) {
      console.error(err);
      let errMsg = err.message || 'An authentication error occurred';
      if (err.code === 'auth/user-not-found' || err.code === 'auth/wrong-password' || err.code === 'auth/invalid-credential') {
        errMsg = 'Invalid email or password. Please try again.';
      } else if (err.code === 'auth/email-already-in-use') {
        errMsg = 'This email address is already in use by another student.';
      } else if (err.code === 'auth/invalid-email') {
        errMsg = 'Please enter a valid email address.';
      } else if (err.code === 'auth/weak-password') {
        errMsg = 'Password is too weak. Please use at least 6 characters.';
      }
      setError(errMsg);
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setError(null);
    setLoading(true);
    try {
      await signIn();
      onClose();
    } catch (err: any) {
      console.error(err);
      if (err.code !== 'auth/popup-closed-by-user') {
        setError(err.message || 'Google Sign-In failed');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-100 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
      <div className="bg-surface max-w-[480px] w-full rounded-[36px] border border-border p-6 shadow-2xl relative overflow-y-auto max-h-[90vh] text-center space-y-6 animate-scaleIn">
        
        {/* Close Button */}
        <button 
          onClick={onClose}
          type="button"
          className="absolute top-4 right-4 p-2 bg-surface2 hover:bg-surface3 border border-border text-ink3 hover:text-ink rounded-full transition-all"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Branding header */}
        <div className="flex flex-col items-center pt-2 gap-2 text-center">
          <img 
            src="/src/assets/images/vidypath_app_icon_1781441846760.jpg" 
            alt="VidyPath Logo" 
            className="w-14 h-14 rounded-2xl shadow-xl border-2 border-surface shrink-0"
            referrerPolicy="no-referrer"
          />
          <div>
            <h3 className="text-xl font-display tracking-tight text-ink">
              {isSignUp ? 'Create Student Account' : 'VidyPath'}
            </h3>
            <p className="text-[10px] text-ink2 uppercase font-black tracking-widest mt-0.5">
              {isSignUp ? 'Learn • Practice • Master' : 'Learn • Practice • Master'}
            </p>
          </div>
        </div>

        {/* Error pill */}
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 p-3.5 rounded-2xl text-xs font-semibold text-left flex gap-2 animate-shake">
            <span className="shrink-0 text-base">⚠️</span>
            <span>{error}</span>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4 text-left">
          {isSignUp && (
            <>
              {/* Name */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-black uppercase tracking-wider text-ink3 ml-2">Full Name</label>
                <div className="relative">
                  <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-ink3" />
                  <input
                    type="text"
                    required
                    placeholder="Enter your full name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 bg-surface2 border border-border rounded-2xl text-sm focus:border-orange focus:outline-none transition-colors"
                  />
                </div>
              </div>

              {/* Class & School Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black uppercase tracking-wider text-ink3 ml-2">Class / Syllabus</label>
                  <div className="relative">
                    <BookOpen className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-ink3" />
                    <select
                      value={classVal}
                      onChange={(e) => setClassVal(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 bg-surface2 border border-border rounded-2xl text-sm focus:border-orange focus:outline-none transition-colors appearance-none"
                    >
                      <option value="CBSE Class 10">CBSE Class 10</option>
                      <option value="CBSE Class 9">CBSE Class 9</option>
                      <option value="CBSE Class 8">CBSE Class 8</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-black uppercase tracking-wider text-ink3 ml-2">School <span className="opacity-55">(Optional)</span></label>
                  <div className="relative">
                    <GraduationCap className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-ink3" />
                    <input
                      type="text"
                      placeholder="e.g. KV School"
                      value={schoolVal}
                      onChange={(e) => setSchoolVal(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 bg-surface2 border border-border rounded-2xl text-sm focus:border-orange focus:outline-none transition-colors"
                    />
                  </div>
                </div>
              </div>

              {/* Scholar Avatar Selection */}
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-wider text-ink3 ml-2 flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                  Choose Student Avatar
                </label>
                <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                  {AVATARS.map((avatar) => (
                    <button
                      type="button"
                      key={avatar.id}
                      onClick={() => setSelectedAvatar(avatar.id)}
                      className={cn(
                        "p-2.5 rounded-2xl border flex flex-col items-center justify-center transition-all bg-surface hover:scale-105 active:scale-95 cursor-pointer",
                        selectedAvatar === avatar.id 
                          ? "border-orange ring-2 ring-orange/10 scale-105 shadow-sm" 
                          : "border-border/60 hover:border-slate-300"
                      )}
                    >
                      <span className="text-2xl">{avatar.emoji}</span>
                      <span className="text-[8px] font-black uppercase tracking-tighter mt-1 text-ink2 line-clamp-1">{avatar.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            </>
          )}

          {/* Email */}
          <div className="space-y-1.5">
            <label className="text-[10px] font-black uppercase tracking-wider text-ink3 ml-2">Email Address</label>
            <div className="relative">
              <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-ink3" />
              <input
                type="email"
                required
                placeholder="you@school.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-surface2 border border-border rounded-2xl text-sm focus:border-orange focus:outline-none transition-colors"
              />
            </div>
          </div>

          {/* Password */}
          <div className="space-y-1.5">
            <label className="text-[10px] font-black uppercase tracking-wider text-ink3 ml-2 flex justify-between">
              <span>Password</span>
            </label>
            <div className="relative">
              <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-ink3" />
              <input
                type="password"
                required
                placeholder="At least 6 characters"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-surface2 border border-border rounded-2xl text-sm focus:border-orange focus:outline-none transition-colors"
              />
            </div>
          </div>

          {/* Submit button */}
          <button
            type="submit"
            disabled={loading}
            className="w-full py-3.5 mt-2 bg-orange hover:bg-orange/95 text-white text-xs font-black uppercase tracking-widest rounded-2xl transition-all shadow-lg hover:shadow-orange/15 shadow-orange/10 flex items-center justify-center gap-2 disabled:opacity-50 active:scale-95 cursor-pointer"
          >
            <LogIn className="w-4 h-4" />
            {loading ? 'Processing...' : isSignUp ? 'Register & Enter Classroom' : 'Sign In'}
          </button>
        </form>

        {/* Separator */}
        <div className="relative flex py-1 items-center">
          <div className="flex-grow border-t border-border"></div>
          <span className="flex-shrink mx-4 text-[9px] font-black text-ink3 uppercase tracking-widest">OR</span>
          <div className="flex-grow border-t border-border"></div>
        </div>

        {/* Google sign-in */}
        <button
          onClick={handleGoogleSignIn}
          disabled={loading}
          type="button"
          className="w-full py-3 bg-surface hover:bg-surface2 border border-border text-ink hover:text-ink font-bold text-xs rounded-2xl transition-all flex items-center justify-center gap-3 active:scale-95 cursor-pointer"
        >
          {/* Flat Google logo svg */}
          <svg className="w-4 h-4" viewBox="0 0 24 24">
            <path
              fill="#EA4335"
              d="M12.24 10.285V14.4h6.887c-.648 2.41-2.519 4.114-5.136 4.114A5.88 5.88 0 0 1 8 12.63a5.88 5.88 0 0 1 5.99-5.885c1.554 0 2.943.593 3.99 1.554l3.15-3.15C19.141 3.257 16.326 2 12.991 2 7.03 2 2.2 6.83 2.2 12.79c0 5.96 4.83 10.79 10.791 10.79 5.82 0 10.93-4.114 10.93-10.79 0-.671-.05-1.343-.16-1.99H12.24Z"
            />
          </svg>
          Continue with Google
        </button>

        {/* Footer toggling */}
        <div className="text-center pt-2">
          <p className="text-xs text-ink3 font-medium">
            {isSignUp ? 'Already registered?' : "First time using VidyPath?"}{' '}
            <button
              onClick={() => {
                setError(null);
                setIsSignUp(!isSignUp);
              }}
              type="button"
              className="text-orange hover:underline font-black outline-none bg-none border-none p-0"
            >
              {isSignUp ? 'Sign In' : 'Create Student Account'}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}
