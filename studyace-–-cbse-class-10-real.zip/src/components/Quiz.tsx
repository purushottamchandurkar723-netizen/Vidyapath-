/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Screen } from '../App';
import { SUBJECTS } from '../constants';
import { fetchQuestionsFromAI, getAIResponse } from '../services/geminiService';
import { ArrowLeft, RefreshCw, Brain, CheckCircle2, XCircle, ChevronRight, Lightbulb } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn, isAnswerCorrect, loadItem, saveItem } from '../lib/utils';
import { Question } from '../types';
import { useAuth } from '../context/AuthContext';
import { db, OperationType, handleFirestoreError } from '../lib/firebase';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';
import Markdown from 'react-markdown';
import { getBadgeStatuses } from '../utils/badgeHelper';
import { recordEvent } from '../services/analytics';

interface QuizProps {
  subjectKey: string;
  chapterIndex: number;
  topic?: string;
  navigateTo: (s: Screen, subKey?: string | null, chIdx?: number | null, topic?: string | null) => void;
  setResults: (data: any) => void;
  showToast: (msg: string) => void;
}

export default function Quiz({ subjectKey, chapterIndex, topic, navigateTo, setResults, showToast }: QuizProps) {
  const { user } = useAuth();
  const sub = SUBJECTS[subjectKey];
  const chapter = sub.chapters[chapterIndex];

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState<any[]>([]);
  const [score, setScore] = useState(0);
  const [answered, setAnswered] = useState(false);
  const [explanation, setExplanation] = useState<string | null>(null);
  const [expLoading, setExpLoading] = useState(false);
  const [hint, setHint] = useState<string | null>(null);
  const [hintLoading, setHintLoading] = useState(false);

  useEffect(() => {
    setCurrentIndex(0);
    setUserAnswers([]);
    setScore(0);
    setAnswered(false);
    setExplanation(null);
    setHint(null);
    loadQuestions();
  }, [chapterIndex, subjectKey, topic]);

  const loadQuestions = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchQuestionsFromAI(sub.label, chapter.name, topic);
      setQuestions(data);
    } catch (err: any) {
      setError(err.message || 'Failed to load questions');
    } finally {
      setLoading(false);
    }
  };

  const handleSelect = async (option: string) => {
    if (answered) return;

    const q = questions[currentIndex];
    const isCorrect = isAnswerCorrect(option, q.answer);
    
    if (isCorrect) setScore(prev => prev + 1);
    
    const currentResult = {
      question: q.question,
      selected: option,
      correct: q.answer,
      isCorrect,
      explanation: ''
    };

    setUserAnswers(prev => [...prev, currentResult]);
    setAnswered(true);
    setExpLoading(true);

    // Fetch explanation
    try {
      const langInstr = sub.label.toLowerCase().includes('hindi') 
        ? "\nIMPORTANT: Explain strictly in HINDI language (Devanagari script)." 
        : sub.label.toLowerCase().includes('marathi') 
        ? "\nIMPORTANT: Explain strictly in MARATHI language (Devanagari script)." 
        : "";

      const prompt = `You are a CBSE Class 10 teacher. 
Subject: ${sub.label}, Chapter: ${chapter.name}
Question: ${q.question}
Correct Answer: ${q.answer}
${langInstr}

Explain in 3 simple sentences why this is correct. Don't start with "The correct answer is".`;
      const text = await getAIResponse(prompt);
      setExplanation(text);
      
      // Update result with explanation
      setUserAnswers(prev => {
        const next = [...prev];
        if (next[currentIndex]) {
          next[currentIndex].explanation = text;
        }
        return next;
      });
    } catch (e) {
      setExplanation("Could not load explanation.");
    } finally {
      setExpLoading(false);
    }
  };

  const handleSkip = async () => {
    if (answered) return;
    
    const q = questions[currentIndex];
    
    const currentResult = {
      question: q.question,
      selected: "(Skipped)",
      correct: q.answer,
      isCorrect: false,
      explanation: ''
    };

    setUserAnswers(prev => [...prev, currentResult]);
    setAnswered(true);
    setExpLoading(true);

    try {
      const langInstr = sub.label.toLowerCase().includes('hindi') 
        ? "\nIMPORTANT: Explain strictly in HINDI language (Devanagari script)." 
        : sub.label.toLowerCase().includes('marathi') 
        ? "\nIMPORTANT: Explain strictly in MARATHI language (Devanagari script)." 
        : "";

      const prompt = `You are a CBSE Class 10 teacher. 
Subject: ${sub.label}, Chapter: ${chapter.name}
Question: ${q.question}
Correct Answer: ${q.answer}
${langInstr}

Explain in 3 simple sentences why this is correct. Don't start with "The correct answer is".`;
      const text = await getAIResponse(prompt);
      setExplanation(text);
      
      setUserAnswers(prev => {
        const next = [...prev];
        if (next[currentIndex]) {
          next[currentIndex].explanation = text;
        }
        return next;
      });
    } catch (e) {
      setExplanation("Could not load explanation.");
    } finally {
      setExpLoading(false);
    }
  };

  const getHint = async () => {
    if (answered || hintLoading) return;
    setHintLoading(true);
    try {
      const q = questions[currentIndex];
      const langInstr = sub.label.toLowerCase().includes('hindi') 
        ? "\nIMPORTANT: Provide the hint strictly in HINDI." 
        : sub.label.toLowerCase().includes('marathi') 
        ? "\nIMPORTANT: Provide the hint strictly in MARATHI." 
        : "";

      const prompt = `A CBSE Class 10 student is solving this MCQ: "${q.question}". 
Give ONE short, helpful hint (1-2 sentences) that guides their thinking WITHOUT revealing the answer. No spoilers.
${langInstr}`;
      const text = await getAIResponse(prompt);
      setHint(text);
    } catch (e) {
      setHint("Focus on the core concept mentioned in the question.");
    } finally {
      setHintLoading(false);
    }
  };

  const nextQuestion = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setAnswered(false);
      setExplanation(null);
      setHint(null);
    } else {
      finishQuiz();
    }
  };

  const finishQuiz = () => {
    const finalResults = {
      subjectKey,
      chapterName: chapter.name,
      topic,
      score,
      total: questions.length,
      userAnswers
    };
    setResults(finalResults);
    saveProgress(finalResults);
    navigateTo('results');
  };

  const saveProgress = (res: any) => {
    // 1. Check badge status before updates
    const savedStreak = loadItem<any>('vidypath_streak_v1', null);
    const streakCount = savedStreak?.count || 0;
    const recordsBefore = Object.values(loadItem<Record<string, any>>('vidypath_progress_v4', {}));
    const badgesBefore = getBadgeStatuses(streakCount, recordsBefore as any);

    const all = loadItem<any>('vidypath_progress_v4', {});
    const k = `${subjectKey}__${chapter.name}`;
    const today = new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
    
    if (all[k]) {
      all[k].lastScore = res.score;
      all[k].attempts += 1;
      all[k].lastDate = today;
      if (res.score > all[k].bestScore) all[k].bestScore = res.score;
    } else {
      all[k] = { 
        subjectKey, 
        chapterName: chapter.name, 
        bestScore: res.score, 
        lastScore: res.score, 
        totalOut: res.total, 
        attempts: 1, 
        lastDate: today 
      };
    }
    saveItem('vidypath_progress_v4', all);

    // Track quiz attempt events
    recordEvent('quiz_attempt', 'Chapter Quiz', subjectKey, chapter.name, { score: res.score, total: res.total });

    // 2. Check badge status after updates to trigger congratulations
    const recordsAfter = Object.values(all);
    const badgesAfter = getBadgeStatuses(streakCount, recordsAfter as any);

    badgesAfter.forEach(afterStatus => {
      const beforeStatus = badgesBefore.find(b => b.badge.id === afterStatus.badge.id);
      if (afterStatus.unlocked && (!beforeStatus || !beforeStatus.unlocked)) {
        setTimeout(() => {
          showToast(`🏆 ACHIEVEMENT UNLOCKED: "${afterStatus.badge.title}" Badge! Inspect this reward on your Profile page.`);
        }, 1200);
      }
    });

    const progressData = all[k];

    // Cloud Sync
    if (user) {
      // Sync Progress
      setDoc(doc(db, 'users', user.uid, 'progress', k), {
        ...progressData,
        updatedAt: serverTimestamp()
      }).catch(err => handleFirestoreError(err, OperationType.WRITE, `users/${user.uid}/progress/${k}`));

      // Sync Mistakes
      res.userAnswers.forEach((ans: any) => {
        if (!ans.isCorrect) {
          const mistakeId = Date.now().toString() + Math.random().toString(36).substring(2);
          setDoc(doc(db, 'users', user.uid, 'mistakes', mistakeId), {
            question: ans.question,
            correctAnswer: ans.correct,
            subject: sub.label,
            chapterName: chapter.name,
            practiced: false,
            date: today,
            createdAt: serverTimestamp()
          }).catch(err => console.error('Cloud mistake sync failed:', err));
        }
      });
    }

    // Save mistakes locally
    const mistakes = loadItem<any[]>('vidypath_mistakes_v1', []);
    res.userAnswers.forEach((ans: any) => {
      if (!ans.isCorrect) {
        if (!mistakes.some(m => m.question === ans.question)) {
          mistakes.unshift({
            id: Date.now() + Math.random(),
            question: ans.question,
            correctAnswer: ans.correct,
            subject: sub.label,
            chapterName: chapter.name,
            practiced: false,
            date: today
          });
        }
      }
    });
    saveItem('vidypath_mistakes_v1', mistakes.slice(0, 200));
  };

  if (loading) return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] text-center p-6 space-y-4">
      <div className="w-12 h-12 border-4 border-border border-t-orange rounded-full animate-spin" />
      <div className="space-y-1">
        <h3 className="font-bold text-lg">Generating Test...</h3>
        <p className="text-xs text-ink3">AI is writing board-level questions for {chapter.name}</p>
      </div>
    </div>
  );

  if (error) return (
    <div className="max-w-md mx-auto mt-20 p-8 bg-red-50 border border-red-100 rounded-3xl text-center space-y-4">
      <div className="text-red-500 text-4xl">⚠️</div>
      <h3 className="font-bold text-red-900">Couldn't load questions</h3>
      <p className="text-sm text-red-700">{error}</p>
      <button onClick={loadQuestions} className="bg-red-500 text-white px-6 py-2 rounded-xl font-bold text-sm">Retry</button>
    </div>
  );

  const q = questions[currentIndex];
  const progress = ((currentIndex) / questions.length) * 100;

  return (
    <div className="max-w-[660px] mx-auto px-4 py-8 pb-32">
      <div className="mb-6 flex items-center justify-between">
        <button 
          onClick={() => {
            if (answered || currentIndex > 0) {
              if (confirm('Are you sure you want to quit the quiz? Your current progress will not be saved.')) {
                navigateTo('home');
              }
            } else {
              navigateTo('home');
            }
          }}
          className="inline-flex items-center gap-2 text-ink3 font-bold text-xs uppercase tracking-widest hover:text-orange transition-colors"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          Quit Quiz
        </button>
        <div className="text-[10px] font-bold text-ink3 uppercase tracking-widest">
          {chapter.name}
        </div>
      </div>

      <header className="bg-surface p-4 rounded-2xl border border-border shadow-sm mb-6 space-y-3 sticky top-20 z-40">
        <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-widest text-ink3">
          <span className="bg-orange-lt text-orange px-2 py-0.5 rounded">Q{currentIndex + 1} of {questions.length}</span>
          <span className="bg-green-100 text-green-700 px-2 py-0.5 rounded">Score: {score}</span>
        </div>
        <div className="h-1.5 w-full bg-border rounded-full overflow-hidden">
          <motion.div 
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            className="h-full bg-gradient-to-r from-orange to-[#FF9A3C]"
          />
        </div>
      </header>

      <div className="space-y-6">
        <motion.div 
          key={currentIndex}
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-surface p-6 sm:p-8 rounded-[32px] border border-border shadow-sm space-y-4"
        >
          <div className="text-[10px] font-bold text-orange uppercase tracking-widest">
            <div className="w-1 h-3 bg-orange rounded-full" />
            {topic ? `Topic: ${topic}` : `Question ${currentIndex + 1}`}
          </div>
          <h3 className="text-lg sm:text-xl font-bold leading-relaxed text-ink">{q.question}</h3>
        </motion.div>

        <div className="grid grid-cols-1 gap-2.5">
          {q.options.map((opt, i) => {
            const letters = ['A','B','C','D'];
            const isCorrect = opt === q.answer;
            const currentAns = userAnswers[userAnswers.length - 1];
            const isSelected = answered && currentAns && currentAns.selected === opt;
            
            let btnClass = "bg-surface border-border hover:border-orange hover:bg-orange-lt active:scale-[0.98]";
            let letterClass = "bg-surface2 text-ink2";

            if (answered) {
              if (isCorrect) {
                btnClass = "bg-green-50 border-green-500 text-green-900";
                letterClass = "bg-green-500 text-white";
              } else if (isSelected) {
                btnClass = "bg-red-50 border-red-500 text-red-900";
                letterClass = "bg-red-500 text-white";
              } else {
                btnClass = "bg-surface border-border opacity-50";
                letterClass = "bg-surface2 text-ink2";
              }
            }

            return (
              <button
                key={`opt-${currentIndex}-${i}`}
                disabled={answered}
                onClick={() => handleSelect(opt)}
                className={cn(
                  "group flex items-start text-left gap-4 p-4 border-2 rounded-2xl transition-all duration-200",
                  btnClass
                )}
              >
                <div className={cn(
                  "w-7 h-7 flex-shrink-0 flex items-center justify-center rounded-lg text-xs font-bold transition-colors",
                  letterClass
                )}>
                  {letters[i]}
                </div>
                <span className="text-sm font-semibold leading-tight pt-1">{opt}</span>
              </button>
            );
          })}
        </div>

        <AnimatePresence>
          {!answered && (
            <motion.div 
              key="quiz-controls"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex justify-center items-center gap-4 py-2"
            >
              {!hint && (
                <button 
                  onClick={getHint}
                  disabled={hintLoading}
                  className="px-4 py-2.5 bg-surface border border-border rounded-xl text-[10px] font-black text-ink3 uppercase tracking-widest hover:text-orange hover:bg-orange-lt hover:border-orange/20 flex items-center gap-1.5 transition-all shadow-sm"
                >
                  {hintLoading ? <RefreshCw className="w-3 h-3 animate-spin" /> : <Lightbulb className="w-3.5 h-3.5" />}
                  Get a Hint
                </button>
              )}

              <button 
                onClick={handleSkip}
                className="px-4 py-2.5 bg-surface border border-border rounded-xl text-[10px] font-black text-ink3 uppercase tracking-widest hover:text-orange hover:bg-orange-lt hover:border-orange/20 flex items-center gap-1.5 transition-all shadow-sm"
              >
                <span>Skip Question</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </motion.div>
          )}

          {hint && (
            <motion.div
              key="quiz-hint"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-orange-lt border border-orange-200 p-4 rounded-2xl text-xs text-orange-950 font-medium leading-relaxed"
            >
              <div className="font-bold flex items-center gap-1.5 mb-1 text-[10px] uppercase">
                <Lightbulb className="w-3 h-3" />
                Hint
              </div>
              {hint}
            </motion.div>
          )}

          {answered && (
            <motion.div
              key="quiz-answered-review"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-4"
            >
              <div className={cn(
                "p-4 rounded-2xl border text-sm font-bold flex items-center gap-2",
                userAnswers[userAnswers.length - 1]?.isCorrect 
                  ? "bg-green-50 border-green-200 text-green-700" 
                  : "bg-red-50 border-red-200 text-red-700"
              )}>
                {userAnswers[userAnswers.length - 1]?.isCorrect ? <CheckCircle2 className="w-5 h-5" /> : <XCircle className="w-5 h-5" />}
                {userAnswers[userAnswers.length - 1]?.isCorrect ? "Correct! Well done." : `Incorrect or Skipped. Answer is: ${q.answer}`}
              </div>

              <div className="bg-blue-lt border border-blue-200 p-5 rounded-2xl shadow-sm space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-blue-600 font-bold text-[10px] uppercase tracking-widest">
                    <Brain className="w-3.5 h-3.5 text-blue-500" />
                    AI Explanation
                  </div>
                  {expLoading && <div className="w-3 h-3 border-2 border-blue-200 border-t-blue-500 rounded-full animate-spin" />}
                </div>
                <div className="text-sm text-blue-900 leading-relaxed font-semibold text-left markdown-body font-sans">
                  {explanation ? (
                    <Markdown>{explanation}</Markdown>
                  ) : (
                    expLoading ? "Thinking..." : ""
                  )}
                </div>
              </div>

              {/* Inline Next button right where the question comes */}
              <div className="pt-2">
                <button
                  onClick={nextQuestion}
                  className="w-full bg-gradient-to-r from-orange to-[#FF9A3C] text-white py-4 px-6 rounded-2xl font-black uppercase tracking-[0.2em] text-[10px] shadow-lg shadow-orange/20 transition-all hover:brightness-105 active:scale-[0.99] flex items-center justify-center gap-1.5 border border-transparent"
                >
                  {currentIndex === questions.length - 1 ? "See Results & Finish" : "Next Question"}
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="fixed bottom-0 left-0 w-full p-4 bg-surface/80 backdrop-blur-md border-t border-border z-40">
        <div className="max-w-[660px] mx-auto flex justify-end">
          <AnimatePresence>
            {answered && (
              <motion.button
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                onClick={nextQuestion}
                className="bg-gradient-to-r from-orange to-[#FF9A3C] text-white px-8 py-3.5 rounded-2xl font-bold text-xs shadow-lg shadow-orange/30 flex items-center gap-1.5"
              >
                {currentIndex === questions.length - 1 ? "See Results" : "Next Question"}
                <ChevronRight className="w-4 h-4" />
              </motion.button>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
