/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Screen } from '../App';
import { loadItem, saveItem } from '../lib/utils';
import { 
  ArrowLeft, Trash2, BookOpen, Skull, CheckCircle2, RotateCw, Cloud, 
  Sparkles, Check, ChevronDown, ChevronUp, Clock, HelpCircle, Brain, RefreshCw 
} from 'lucide-react';
import { cn } from '../lib/utils';
import { Mistake } from '../types';
import { useAuth } from '../context/AuthContext';
import { db, OperationType, handleFirestoreError } from '../lib/firebase';
import { collection, query, getDocs, doc, setDoc, deleteDoc, writeBatch, serverTimestamp } from 'firebase/firestore';
import { fetchQBankSimilarQuestion } from '../services/geminiService';
import { updateChapterMasteryState } from '../utils/masteryHelper';
import { recordEvent } from '../services/analytics';

interface MistakeBookProps {
  navigateTo: (s: Screen, subKey?: string | null, chIdx?: number | null) => void;
  showToast: (msg: string) => void;
}

export default function MistakeBook({ navigateTo, showToast }: MistakeBookProps) {
  const { user } = useAuth();
  const [mistakes, setMistakes] = useState<Mistake[]>(() => {
    const local = loadItem<Mistake[]>('vidypath_mistakes_v1', []);
    // Map missing status properties gracefully on boot
    return local.map(m => ({
      ...m,
      originalSolved: m.originalSolved || false,
      similarSolved: m.similarSolved || false,
      similarQuestion: m.similarQuestion || '',
      similarAnswer: m.similarAnswer || '',
      fixed: m.originalSolved && m.similarSolved ? true : false,
      questionType: m.questionType || 'mcq'
    }));
  });

  const [filter, setFilter] = useState('all');
  const [syncing, setSyncing] = useState(false);
  
  // Workspace States for active reviews
  const [activeReviewId, setActiveReviewId] = useState<string | number | null>(null);
  const [checkingOriginal, setCheckingOriginal] = useState<Record<string | number, boolean>>({});
  const [userOriginalDraft, setUserOriginalDraft] = useState<string>('');
  
  const [generatingSimilar, setGeneratingSimilar] = useState(false);
  const [checkingSimilar, setCheckingSimilar] = useState<Record<string | number, boolean>>({});
  const [userSimilarDraft, setUserSimilarDraft] = useState<string>('');

  // Sync from Firestore
  useEffect(() => {
    if (!user) return;

    const fetchMistakes = async () => {
      setSyncing(true);
      try {
        const q = query(collection(db, 'users', user.uid, 'mistakes'));
        const querySnapshot = await getDocs(q);
        const cloudMistakes: Mistake[] = [];
        querySnapshot.forEach((doc) => {
          const docId = doc.id;
          const parsedId = isNaN(Number(docId)) ? docId : Number(docId);
          const data = doc.data();
          cloudMistakes.push({
            ...data,
            id: parsedId,
            originalSolved: data.originalSolved || false,
            similarSolved: data.similarSolved || false,
            similarQuestion: data.similarQuestion || '',
            similarAnswer: data.similarAnswer || '',
            fixed: (data.originalSolved && data.similarSolved) ? true : false,
            questionType: data.questionType || 'mcq'
          } as Mistake);
        });
        if (cloudMistakes.length > 0) {
          setMistakes(cloudMistakes);
        }
      } catch (err) {
        console.error('Failed to fetch mistakes from cloud:', err);
      } finally {
        setSyncing(false);
      }
    };

    fetchMistakes();
  }, [user]);

  // Sync to LocalStorage
  useEffect(() => {
    saveItem('vidypath_mistakes_v1', mistakes);
  }, [mistakes]);

  const removeMistake = async (id: string | number) => {
    if (!confirm('Are you sure you want to delete this mistake reference?')) return;
    setMistakes(prev => prev.filter(m => m.id !== id));
    if (user) {
      try {
        await deleteDoc(doc(db, 'users', user.uid, 'mistakes', id.toString()));
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, `users/${user.uid}/mistakes/${id}`);
      }
    }
    showToast('Mistake removed from your book.');
    if (activeReviewId === id) setActiveReviewId(null);
  };

  const syncMistakeToCloud = async (m: Mistake) => {
    if (!user) return;
    try {
      await setDoc(doc(db, 'users', user.uid, 'mistakes', m.id.toString()), {
        ...m,
        updatedAt: serverTimestamp()
      });
    } catch (err) {
      console.error('Failed to sync mistake status to cloud:', err);
    }
  };

  const handleToggleOriginalSolved = async (m: Mistake) => {
    const isNow = !m.originalSolved;
    const isFixed = isNow && m.similarSolved;
    
    const updated = mistakes.map(item => item.id === m.id ? { 
      ...item, 
      originalSolved: isNow,
      fixed: isFixed
    } : item);
    
    setMistakes(updated);
    const affected = updated.find(item => item.id === m.id)!;
    await syncMistakeToCloud(affected);
    
    if (isFixed) {
      showToast('🎉 Excellent! Both original and similar questions solved. Mistake recovered!');
      triggerMasteryUpdate(m);
    } else {
      showToast(isNow ? 'Original question marked as solved!' : 'Original unmarked.');
    }
  };

  const handleToggleSimilarSolved = async (m: Mistake) => {
    const isNow = !m.similarSolved;
    const isFixed = m.originalSolved && isNow;
    
    const updated = mistakes.map(item => item.id === m.id ? { 
      ...item, 
      similarSolved: isNow,
      fixed: isFixed
    } : item);
    
    setMistakes(updated);
    const affected = updated.find(item => item.id === m.id)!;
    await syncMistakeToCloud(affected);

    if (isFixed) {
      showToast('🎉 Excellent! Both original and similar questions solved. Mistake recovered!');
      triggerMasteryUpdate(m);
    } else {
      showToast(isNow ? 'Similar practice question marked as solved!' : 'Similar unmarked.');
    }
  };

  // Helper to push updates to the mastery state for a given subject and chapter
  const triggerMasteryUpdate = (m: Mistake) => {
    // Map subject string back to subject key if needed
    let sKey = m.subject?.toLowerCase() || '';
    if (sKey === 'mathematics') sKey = 'maths';
    if (sKey === 'science') sKey = 'science';
    if (sKey === 'social science' || sKey === 'sst') sKey = 'sst';
    if (sKey === 'english') sKey = 'english';
    
    updateChapterMasteryState(sKey, m.chapterName, {}); // Trigger an state saving write
    recordEvent('mistake_recovered', 'Smart Mistake Book', sKey, m.chapterName);
  };

  const handleGenerateSimilarQuestion = async (m: Mistake) => {
    if (m.similarQuestion) {
      showToast('Similar question already generated.');
      return;
    }
    setGeneratingSimilar(true);
    try {
      showToast('🧠 AI is drafting an identical skill evaluation...');
      const res = await fetchQBankSimilarQuestion(m.subject, m.chapterName, m.questionType || 'mcq', m.question);
      
      let parsedQuestion = '';
      let parsedAnswer = '';

      if (res) {
        if (res.question) {
          parsedQuestion = res.question;
          if (res.options) {
            parsedQuestion += '\n\nOptions:\n' + res.options.map((o: string, i: number) => `${['A','B','C','D'][i]}. ${o}`).join('\n');
          }
        } else if (res.assertion) {
          parsedQuestion = `Assertion (A): ${res.assertion}\nReason (R): ${res.reason}`;
        } else if (res.pairs) {
          parsedQuestion = 'Match the following pairs:\n' + res.pairs.map((p: any) => `- Left: ${p.left}  |  Right: ${p.right}`).join('\n');
        } else {
          parsedQuestion = JSON.stringify(res);
        }

        parsedAnswer = res.answer || JSON.stringify(res);
      } else {
        throw new Error('No response');
      }

      const updated = mistakes.map(item => item.id === m.id ? {
        ...item,
        similarQuestion: parsedQuestion,
        similarAnswer: parsedAnswer
      } : item);
      setMistakes(updated);
      await syncMistakeToCloud(updated.find(item => item.id === m.id)!);
      showToast('⚡ Similar practice question retrieved successfully!');
    } catch (e) {
      console.error(e);
      // Fallback
      const val = `Fallback Mock Question: How is this skill applied in secondary CBSE standard modules? Explain with a matching example for ${m.chapterName}.`;
      const ans = "Apply standard textbook definition & formula to solve.";
      const updated = mistakes.map(item => item.id === m.id ? {
        ...item,
        similarQuestion: val,
        similarAnswer: ans
      } : item);
      setMistakes(updated);
      showToast('⚠️ Local backup practice generated.');
    } finally {
      setGeneratingSimilar(false);
    }
  };

  const clearAll = async () => {
    if (!confirm('Clear all mistakes? This is irreversible.')) return;
    
    setMistakes([]);
    if (user) {
      try {
        const batch = writeBatch(db);
        const q = query(collection(db, 'users', user.uid, 'mistakes'));
        const querySnapshot = await getDocs(q);
        querySnapshot.forEach((doc) => {
          batch.delete(doc.ref);
        });
        await batch.commit();
      } catch (err) {
        console.error('Failed to clear mistakes in cloud:', err);
      }
    }
  };

  // Stats Calculations
  const totalMistakes = mistakes.length;
  const fixedMistakes = mistakes.filter(m => m.originalSolved && m.similarSolved).length;
  const recoveryPct = totalMistakes === 0 ? 100 : Math.round((fixedMistakes / totalMistakes) * 100);

  const subjects = Array.from(new Set(mistakes.map(m => m.subject).filter(Boolean)));
  const filteredMistakes = filter === 'all' ? mistakes : mistakes.filter(m => m.subject === filter);

  return (
    <div className="max-w-[840px] mx-auto px-4 py-8 pb-32">
      {/* Top Banner and Navigation */}
      <div className="flex items-center justify-between mb-8">
        <button 
          onClick={() => navigateTo('home')}
          className="inline-flex items-center gap-2 text-ink3 font-black text-xs uppercase tracking-widest hover:text-orange transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Home
        </button>
        {user && (
          <div className="flex items-center gap-1.5 text-[10px] font-black uppercase tracking-widest text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-100 shadow-3xs">
            <Cloud className={cn("w-3 h-3Color", syncing && "animate-spin text-emerald-600")} />
            {syncing ? 'Cloud Syncing...' : 'Connected Profile'}
          </div>
        )}
      </div>

      <div className="space-y-2 mb-8 text-left">
        <div className="inline-flex items-center gap-1.5 text-[10px] font-black uppercase text-red-600 tracking-wider bg-red-100/50 px-2.5 py-0.5 rounded">
          <Skull className="w-3 h-3 animate-pulse" /> CBSE Mistake Recovery Core
        </div>
        <h2 className="text-4xl font-display font-medium tracking-tight">Mistake Book</h2>
        <p className="text-sm text-ink2 max-w-xl">
          Review your quiz mistakes, generate similar high-yield questions on the spot to self-test, and check both off to fully recover your mastery index.
        </p>
      </div>

      {/* Interactive Mistake Statistics Dashboard Card */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <div className="bg-surface p-5 rounded-[28px] border border-border shadow-3xs flex items-center gap-4 text-left">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/10 flex items-center justify-center text-amber-600">
            <HelpCircle className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[10px] font-black uppercase text-ink3 tracking-wide">Total Mistakes</span>
            <h3 className="text-2xl font-black text-ink leading-tight">{totalMistakes}</h3>
          </div>
        </div>

        <div className="bg-surface p-5 rounded-[28px] border border-border shadow-3xs flex items-center gap-4 text-left">
          <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 flex items-center justify-center text-emerald-600">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[10px] font-black uppercase text-ink3 tracking-wide">Fixed Mistakes</span>
            <h3 className="text-2xl font-black text-ink leading-tight">{fixedMistakes}</h3>
          </div>
        </div>

        <div className="bg-surface p-5 rounded-[28px] border border-border shadow-3xs flex items-center gap-4 text-left">
          <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 flex items-center justify-center text-indigo-600">
            <Brain className="w-6 h-6" />
          </div>
          <div className="flex-1">
            <span className="text-[10px] font-black uppercase text-ink3 tracking-wide">Recovery Index</span>
            <div className="flex items-center gap-3">
              <h3 className="text-2xl font-black text-ink leading-tight">{recoveryPct}%</h3>
              <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden mt-0.5 max-w-[80px]">
                <div 
                  className={cn("h-full transition-all", recoveryPct >= 80 ? "bg-emerald-500" : recoveryPct >= 50 ? "bg-amber-500" : "bg-red-500")}
                  style={{ width: `${recoveryPct}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Subject Filter Tabs */}
      <div className="flex gap-2 overflow-x-auto no-scrollbar pb-4 block">
        <button 
          onClick={() => setFilter('all')}
          className={cn(
            "px-5 py-2 text-xs font-bold rounded-full border transition-all whitespace-nowrap cursor-pointer",
            filter === 'all' ? "bg-ink border-ink text-white shadow-3xs" : "bg-surface border-border text-ink2 hover:border-slate-350"
          )}
        >
          All Subjects ({mistakes.length})
        </button>
        {subjects.map((s, idx) => (
          <button 
            key={`${s || 'subj'}-${idx}`}
            onClick={() => setFilter(s)}
            className={cn(
              "px-5 py-2 text-xs font-bold rounded-full border transition-all whitespace-nowrap cursor-pointer",
              filter === s ? "bg-ink border-ink text-white shadow-3xs" : "bg-surface border-border text-ink2 hover:border-slate-350"
            )}
          >
            {s} ({mistakes.filter(mi => mi.subject === s).length})
          </button>
        ))}
      </div>

      {/* Mistakes List */}
      {filteredMistakes.length === 0 ? (
        <div className="py-20 text-center space-y-4 bg-surface rounded-[40px] border border-border border-dashed p-6">
          <div className="w-20 h-20 bg-surface2 border-2 border-dashed border-border rounded-full flex items-center justify-center mx-auto text-3xl">
            <CheckCircle2 className="w-10 h-10 text-emerald-500 animate-bounce" />
          </div>
          <p className="max-w-[280px] mx-auto text-sm font-bold text-ink2">
            No active mistakes found in this category! Keep up the brilliant quiz accuracy.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredMistakes.map((m) => {
            const isReviewOpen = activeReviewId === m.id;
            const originalChecking = checkingOriginal[m.id] || false;
            const similarChecking = checkingSimilar[m.id] || false;

            return (
              <div 
                key={m.id} 
                className={cn(
                  "bg-surface rounded-[32px] border transition-all shadow-3xs overflow-hidden text-left",
                  m.fixed ? "border-emerald-500/40 bg-emerald-50/5 dark:bg-emerald-950/2" : "border-border hover:border-slate-300"
                )}
              >
                {/* Collapsible Card Header Info */}
                <div 
                  onClick={() => setActiveReviewId(isReviewOpen ? null : m.id)}
                  className="p-6 cursor-pointer flex items-start justify-between gap-4 select-none"
                >
                  <div className="space-y-2 flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="px-2 py-0.5 bg-red-100 text-red-700 rounded text-[9px] font-black uppercase tracking-widest">{m.subject}</span>
                      <span className="text-[10px] font-extrabold text-ink3 truncate max-w-[180px]">{m.chapterName}</span>
                      <span className="text-[9px] bg-slate-100 px-2 py-0.5 rounded text-slate-600 font-mono">{m.date}</span>
                    </div>
                    
                    <h4 className="text-base font-bold leading-relaxed text-ink line-clamp-2">
                      {m.question}
                    </h4>

                    {/* Progress Pills */}
                    <div className="flex items-center gap-2 pt-1">
                      <span className={cn(
                        "text-[9px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1",
                        m.originalSolved ? "bg-emerald-50 text-emerald-600 border border-emerald-200" : "bg-red-50 text-red-600 border border-red-200"
                      )}>
                        Original Question: {m.originalSolved ? 'Solved ✓' : 'Pending'}
                      </span>
                      <span className={cn(
                        "text-[9px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1",
                        m.similarSolved ? "bg-emerald-50 text-emerald-600 border border-emerald-200" : "bg-red-50 text-red-600 border border-red-200"
                      )}>
                        Similar Question: {m.similarSolved ? 'Solved ✓' : 'Pending'}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 shrink-0">
                    {m.fixed ? (
                      <span className="bg-emerald-500 text-white p-1 rounded-full flex items-center justify-center">
                        <Check className="w-4 h-4 stroke-[3px]" />
                      </span>
                    ) : (
                      <span className="text-xs bg-amber-500/10 text-amber-700 font-extrabold px-3 py-1 rounded-xl">
                        Review Needed
                      </span>
                    )}
                    <button className="text-ink3 hover:text-ink transition-colors">
                      {isReviewOpen ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                    </button>
                  </div>
                </div>

                {/* Collapsible Practice Workspace Area */}
                {isReviewOpen && (
                  <div className="border-t border-border bg-surface2/60 p-6 space-y-6 animate-fadeIn">
                    
                    {/* Part 1: Original Question Workspace */}
                    <div className="bg-surface p-5 rounded-[24px] border border-border shadow-3xs space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-black uppercase text-red-600 tracking-wider bg-red-50 px-2 py-0.5 rounded">
                          📌 Part 1: Solve Original Question
                        </span>
                        <button
                          onClick={() => handleToggleOriginalSolved(m)}
                          className={cn(
                            "px-3 py-1 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer",
                            m.originalSolved 
                              ? "bg-emerald-500 text-white" 
                              : "bg-surface2 hover:bg-slate-100 text-ink border border-border"
                          )}
                        >
                          {m.originalSolved ? '✓ Solved' : 'Mark as Solved'}
                        </button>
                      </div>

                      <div className="p-4 bg-surface2 rounded-xl text-sm font-semibold border border-border leading-relaxed">
                        {m.question}
                      </div>

                      <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase text-ink3 ml-1">Draft Your Solution / Scratchpad</label>
                        <textarea
                          value={userOriginalDraft}
                          onChange={(e) => setUserOriginalDraft(e.target.value)}
                          placeholder="Work out equations, definitions, or steps here..."
                          rows={2}
                          className="w-full p-3 bg-surface2 border border-border rounded-xl text-xs font-semibold placeholder:text-ink3 text-ink outline-none focus:bg-white resize-none"
                        />
                      </div>

                      <div className="flex flex-wrap items-center justify-between gap-4">
                        <button
                          onClick={() => {
                            setCheckingOriginal(prev => ({ ...prev, [m.id]: !originalChecking }));
                          }}
                          className="px-4 py-2 bg-ink hover:bg-slate-800 text-white rounded-xl text-[10px] font-black uppercase tracking-widest cursor-pointer shadow-3xs"
                        >
                          {originalChecking ? 'Hide Answer Model' : 'Verify Correct Answer'}
                        </button>
                        <button
                          onClick={() => removeMistake(m.id)}
                          className="text-[9px] font-black text-red-600 hover:text-red-700 uppercase tracking-wider"
                        >
                          🗑 Delete Mistake Log entry
                        </button>
                      </div>

                      {originalChecking && (
                        <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-xs space-y-1.5 text-left animate-fadeUp">
                          <span className="text-[9px] font-black uppercase tracking-widest text-emerald-600 block">Board Model Answer Solution:</span>
                          <p className="font-bold text-slate-800 dark:text-slate-100 leading-relaxed font-mono">{m.correctAnswer}</p>
                        </div>
                      )}
                    </div>

                    {/* Part 2: Similar Practice Question Generator */}
                    <div className="bg-surface p-5 rounded-[24px] border border-border shadow-3xs space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-black uppercase text-purple-600 tracking-wider bg-purple-100/50 px-2 py-0.5 rounded">
                          🦄 Part 2: Solved Identical Board Skill
                        </span>
                        {m.similarQuestion && (
                          <button
                            onClick={() => handleToggleSimilarSolved(m)}
                            className={cn(
                              "px-3 py-1 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer",
                              m.similarSolved 
                                ? "bg-emerald-500 text-white" 
                                : "bg-surface2 hover:bg-slate-100 text-ink border border-border"
                            )}
                          >
                            {m.similarSolved ? '✓ Solved' : 'Mark as Solved'}
                          </button>
                        )}
                      </div>

                      {!m.similarQuestion ? (
                        <div className="py-6 text-center space-y-3">
                          <p className="text-xs text-ink3">
                            Prove you've fully recovered this mistake! AI will customize an identical problem with modified coordinates or concepts.
                          </p>
                          <button
                            onClick={() => handleGenerateSimilarQuestion(m)}
                            disabled={generatingSimilar}
                            className="inline-flex items-center gap-2 px-5 py-3 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-black uppercase tracking-widest cursor-pointer shadow-md disabled:bg-purple-400"
                          >
                            {generatingSimilar ? (
                              <>
                                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                                Analyzing Syllabus...
                              </>
                            ) : (
                              <>
                                <Sparkles className="w-4 h-4 animate-pulse" />
                                Generate Similar Question
                              </>
                            )}
                          </button>
                        </div>
                      ) : (
                        <div className="space-y-4 animate-fadeIn">
                          <div className="p-4 bg-purple-100/5 dark:bg-purple-950/2 border border-purple-200/50 rounded-xl text-xs font-bold leading-relaxed whitespace-pre-wrap">
                            {m.similarQuestion}
                          </div>

                          <div className="space-y-2">
                            <label className="text-[10px] font-black uppercase text-ink3 ml-1">Draft Your Answer</label>
                            <textarea
                              value={userSimilarDraft}
                              onChange={(e) => setUserSimilarDraft(e.target.value)}
                              placeholder="Type your steps, formulas, options or calculations..."
                              rows={2}
                              className="w-full p-3 bg-surface2 border border-border rounded-xl text-xs font-semibold placeholder:text-ink3 text-ink outline-none focus:bg-white resize-none"
                            />
                          </div>

                          <button
                            onClick={() => {
                              setCheckingSimilar(prev => ({ ...prev, [m.id]: !similarChecking }));
                            }}
                            className="px-4 py-2 bg-purple-650 hover:bg-purple-700 text-white rounded-xl text-[10px] font-black uppercase tracking-widest cursor-pointer shadow-3xs"
                          >
                            {similarChecking ? 'Hide Answer Model' : 'Verify Correct Answer'}
                          </button>

                          {similarChecking && (
                            <div className="p-4 bg-green-500/10 border border-green-500/20 rounded-xl text-xs space-y-1.5 text-left animate-fadeUp">
                              <span className="text-[9px] font-black uppercase tracking-widest text-green-600 block">Board Model Answer:</span>
                              <p className="font-bold text-slate-800 dark:text-slate-150 leading-relaxed font-mono">{m.similarAnswer}</p>
                            </div>
                          )}
                        </div>
                      )}
                    </div>

                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {mistakes.length > 0 && (
        <div className="mt-16 text-center border-t border-border pt-8">
          <button 
            onClick={clearAll}
            className="text-[10px] font-black uppercase tracking-widest text-ink3 hover:text-red-500 transition-colors cursor-pointer"
          >
            🗑 Clear All Mistakes
          </button>
        </div>
      )}
    </div>
  );
}
