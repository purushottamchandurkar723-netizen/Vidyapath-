/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Screen } from '../App';
import { SUBJECTS } from '../constants';
import { loadItem, saveItem } from '../lib/utils';
import { ArrowLeft, Save, Calendar, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { cn } from '../lib/utils';

interface DateSheetProps {
  navigateTo: (s: Screen, subKey?: string | null, chIdx?: number | null) => void;
  showToast: (msg: string) => void;
}

export default function DateSheet({ navigateTo, showToast }: DateSheetProps) {
  const [dates, setDates] = useState<Record<string, string>>(() => loadItem('vidypath_datesheet_v1', {}));
  const [isSaved, setIsSaved] = useState(false);

  const handleSave = () => {
    saveItem('vidypath_datesheet_v1', dates);
    setIsSaved(true);
    showToast('Date sheet saved successfully!');
    setTimeout(() => setIsSaved(false), 3000);
  };

  const getDaysLeft = (dateStr: string) => {
    if (!dateStr) return null;
    const today = new Date();
    today.setHours(0,0,0,0);
    const exam = new Date(dateStr);
    exam.setHours(0,0,0,0);
    const diff = Math.ceil((exam.getTime() - today.getTime()) / (1000 * 3600 * 24));
    return diff;
  };

  const sortedSubjects = Object.entries(SUBJECTS)
    .map(([key, sub]) => ({ key, ...sub, date: dates[key] || '' }))
    .sort((a,b) => {
        if(!a.date) return 1;
        if(!b.date) return -1;
        return new Date(a.date).getTime() - new Date(b.date).getTime();
    });

  return (
    <div className="max-w-[780px] mx-auto px-4 py-8 pb-32">
      <button onClick={() => navigateTo('home')} className="inline-flex items-center gap-2 mb-8 text-ink3 font-bold text-xs uppercase tracking-widest hover:text-orange transition-colors">
        <ArrowLeft className="w-3.5 h-3.5" /> Home
      </button>

      <div className="space-y-2 mb-10">
        <h2 className="text-3xl font-display tracking-tight">Exam Date Sheet</h2>
        <p className="text-sm text-ink2">Track your board exam schedule. The study planner will auto-adjust based on these dates.</p>
      </div>

      <div className="space-y-4">
        {sortedSubjects.map((sub) => {
          const daysLeft = getDaysLeft(sub.date);
          const isUrgent = daysLeft !== null && daysLeft <= 7;
          const isUpcoming = daysLeft !== null && daysLeft > 0;

          return (
            <div key={sub.key} className={cn(
                "bg-surface p-5 rounded-[28px] border border-border flex flex-col sm:flex-row sm:items-center gap-4 transition-all shadow-sm",
                isUrgent ? "border-red-200 bg-red-50/20" : ""
            )}>
              <div className="flex items-center gap-4 flex-1">
                 <div className="w-12 h-12 rounded-2xl bg-surface2 border border-border flex items-center justify-center text-xl shadow-inner">
                   {sub.icon}
                 </div>
                 <div className="flex-1 min-w-0">
                    <h4 className="font-bold text-sm text-ink truncate">{sub.label}</h4>
                    <div className="text-[10px] font-black uppercase text-ink3 tracking-widest flex items-center gap-1.5 mt-0.5">
                        {daysLeft === null ? (
                            <span className="text-ink3/50 italic font-medium">Date not set</span>
                        ) : daysLeft === 0 ? (
                            <span className="text-orange animate-pulse flex items-center gap-1">
                                <AlertTriangle className="w-3 h-3" /> EXAM TODAY
                            </span>
                        ) : daysLeft < 0 ? (
                            <span className="text-green-600">COMPLETED ✓</span>
                        ) : (
                            <span className={cn(isUrgent ? "text-red-500 font-black" : "text-blue-500")}>
                                {daysLeft} Days to go
                            </span>
                        )}
                    </div>
                 </div>
              </div>

              <input 
                type="date"
                value={sub.date}
                onChange={(e) => setDates(prev => ({ ...prev, [sub.key]: e.target.value }))}
                className="p-3 bg-surface2 border-1.5 border-border rounded-xl text-xs font-bold text-ink outline-none focus:border-orange transition-all h-11"
              />
            </div>
          );
        })}
      </div>

      <div className="fixed bottom-6 left-0 w-full px-4 z-[60]">
         <div className="max-w-[780px] mx-auto">
            <button 
                onClick={handleSave}
                disabled={isSaved}
                className={cn(
                    "w-full p-4 rounded-2xl font-bold text-sm shadow-xl flex items-center justify-center gap-2 transition-all",
                    isSaved ? "bg-green-500 text-white" : "bg-orange text-white shadow-orange/30 hover:-translate-y-1 active:scale-95"
                )}
            >
                {isSaved ? (
                    <>
                        <CheckCircle2 className="w-5 h-5" />
                        Saved to roadmap
                    </>
                ) : (
                    <>
                        <Save className="w-5 h-5" />
                        Update Study Plan
                    </>
                )}
            </button>
         </div>
      </div>
    </div>
  );
}
