/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { Screen } from '../App';
import { 
  User, 
  LogOut, 
  Settings, 
  Trash2, 
  Award, 
  BookOpen, 
  Target, 
  ChevronRight, 
  ShieldCheck, 
  Bell, 
  Globe,
  Share2,
  HelpCircle,
  Mail,
  Flame,
  Trophy,
  Crown,
  Star,
  Gem,
  Compass,
  Sparkles,
  Lock,
  Unlock,
  Check,
  X,
  Info,
  FileText,
  LifeBuoy,
  Send
} from 'lucide-react';
import { cn } from '../lib/utils';
import { loadItem, saveItem } from '../lib/utils';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { getBadgeStatuses, BadgeStatus } from '../utils/badgeHelper';

const ICON_MAP: Record<string, React.ComponentType<any>> = {
  Award: Award,
  Flame: Flame,
  Trophy: Trophy,
  Target: Target,
  Crown: Crown,
  Star: Star,
  Gem: Gem,
  BookOpen: BookOpen,
  Compass: Compass,
  Sparkles: Sparkles
};

const AVATARS = [
  { id: 'fox', emoji: '🦊', label: 'Clever Fox' },
  { id: 'owl', emoji: '🦉', label: 'Wise Owl' },
  { id: 'rocket', emoji: '🚀', label: 'Star Scholar' },
  { id: 'bulb', emoji: '💡', label: 'Tech Brain' },
  { id: 'lion', emoji: '🦁', label: 'Bold Topper' },
  { id: 'grad', emoji: '🎓', label: 'CBSE Champ' },
];

interface ProfileProps {
  navigateTo: (s: Screen) => void;
  showToast: (msg: string) => void;
}

export default function Profile({ navigateTo, showToast }: ProfileProps) {
  const { user, profile, updateProfileCustom, logout, setAuthModalOpen } = useAuth();
  const [progStats, setProgStats] = useState({ avgPct: 0, count: 0 });
  const [syncing, setSyncing] = useState(false);
  const [activeLanguage, setActiveLanguage] = useState<string>(() => loadItem('vidypath_active_language', 'hindi'));
  const [badges, setBadges] = useState<BadgeStatus[]>([]);
  const [selectedBadge, setSelectedBadge] = useState<BadgeStatus | null>(null);

  // Profile Edit fields
  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState('');
  const [editClass, setEditClass] = useState('CBSE Class 10');
  const [editSchool, setEditSchool] = useState('');
  const [editAvatar, setEditAvatar] = useState('fox');

  // Feedback Hub states
  const [activeFeedbackCategory, setActiveFeedbackCategory] = useState<'feedback' | 'bug' | 'feature' | null>(null);
  const [feedbackMessage, setFeedbackMessage] = useState('');
  const [screenshot, setScreenshot] = useState<string | null>(null);
  const [submittingFeedback, setSubmittingFeedback] = useState(false);

  // Legal & Support states
  const [activeLegalModal, setActiveLegalModal] = useState<'about' | 'privacy' | 'terms' | 'support' | null>(null);
  const [supportSubject, setSupportSubject] = useState('');
  const [supportCategory, setSupportCategory] = useState('AI Tool Issues');
  const [supportMessage, setSupportMessage] = useState('');
  const [supportEmail, setSupportEmail] = useState('');
  const [supportSubmitting, setSupportSubmitting] = useState(false);

  useEffect(() => {
    if (user?.email && !supportEmail) {
      setSupportEmail(user.email);
    }
  }, [user]);

  const compressImage = (base64Str: string, maxWidth = 800, maxHeight = 800): Promise<string> => {
    return new Promise((resolve) => {
      const img = new Image();
      img.src = base64Str;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > maxWidth) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          }
        } else {
          if (height > maxHeight) {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          resolve(canvas.toDataURL('image/jpeg', 0.6));
        } else {
          resolve(base64Str);
        }
      };
      img.onerror = () => resolve(base64Str);
    });
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      showToast("Selected file is too large! Please choose an image smaller than 5MB.");
      return;
    }

    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64Str = reader.result as string;
      const compressed = await compressImage(base64Str);
      setScreenshot(compressed);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmitFeedback = async () => {
    if (!feedbackMessage.trim()) {
      showToast('Please enter a description!');
      return;
    }

    setSubmittingFeedback(true);
    try {
      const feedbackId = `fb_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      const feedbackData = {
        userId: user!.uid,
        userEmail: user!.email || 'anonymous',
        category: activeFeedbackCategory,
        message: feedbackMessage.trim(),
        appVersion: 'v2.4.1',
        timestamp: serverTimestamp(),
        ...(screenshot ? { screenshot } : {})
      };

      await setDoc(doc(db, 'feedbacks', feedbackId), feedbackData);

      showToast('🎉 Thank you! Your feedback has been sent to our desk.');
      // Reset form fields
      setFeedbackMessage('');
      setScreenshot(null);
      setActiveFeedbackCategory(null);
    } catch (err: any) {
      handleFirestoreError(err, OperationType.WRITE, `feedbacks`);
      showToast('Failed to submit feedback: ' + err.message);
    } finally {
      setSubmittingFeedback(false);
    }
  };

  const handleSubmitSupport = async () => {
    if (!supportMessage.trim() || !supportSubject.trim()) {
      showToast('Please enter both subject and details!');
      return;
    }

    setSupportSubmitting(true);
    try {
      const ticketId = `support_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      const supportData = {
        userId: user!.uid,
        userEmail: supportEmail || user!.email || 'anonymous',
        category: 'support',
        message: `[SUPPORT TICKET - ${supportCategory}]\nSubject: ${supportSubject}\n\nDescription: ${supportMessage}`,
        appVersion: 'v2.5.0-RC1',
        timestamp: serverTimestamp()
      };

      await setDoc(doc(db, 'feedbacks', ticketId), supportData);

      showToast('🎉 Support ticket created! Our helpdesk will respond shortly.');
      // Reset form fields
      setSupportSubject('');
      setSupportMessage('');
      setActiveLegalModal(null);
    } catch (err: any) {
      handleFirestoreError(err, OperationType.WRITE, `feedbacks`);
      showToast('Failed to create support ticket: ' + err.message);
    } finally {
      setSupportSubmitting(false);
    }
  };

  useEffect(() => {
    if (profile) {
      setEditName(profile.name || user?.displayName || '');
      setEditClass(profile.class || 'CBSE Class 10');
      setEditSchool(profile.school || '');
      const matchedAvatar = AVATARS.find(a => a.emoji === profile.photoURL)?.id || 'fox';
      setEditAvatar(matchedAvatar);
    } else if (user) {
      setEditName(user.displayName || '');
      setEditClass('CBSE Class 10');
      setEditSchool('');
      setEditAvatar('fox');
    }
  }, [profile, user]);

  const handleSaveProfile = async () => {
    try {
      if (!editName.trim()) {
        showToast("Name cannot be empty!");
        return;
      }
      const matchedEmoji = AVATARS.find(a => a.id === editAvatar)?.emoji || '🦊';
      await updateProfileCustom({
        name: editName.trim(),
        class: editClass,
        school: editSchool.trim(),
        photoURL: matchedEmoji
      });
      setIsEditing(false);
      showToast("Student profile saved successfully!");
    } catch (err: any) {
      showToast("Failed to save profile: " + err.message);
    }
  };

  const updateLanguage = async (lang: string) => {
    setActiveLanguage(lang);
    saveItem('vidypath_active_language', lang);
    if (user) {
      try {
        await setDoc(doc(db, 'users', user.uid), {
          secondLanguage: lang,
          updatedAt: serverTimestamp()
        }, { merge: true });
        showToast(`Language updated to ${lang.replace('_', ' ').toUpperCase()}`);
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, `users/${user.uid}`);
      }
    } else {
      showToast('Preference saved locally.');
    }
  };

  useEffect(() => {
    const records = Object.values(loadItem<Record<string, any>>('vidypath_progress_v4', {}));
    if (records.length > 0) {
      const avg = records.reduce((sum, r) => sum + (r.bestScore / r.totalOut) * 100, 0) / records.length;
      setProgStats({
        avgPct: Math.round(avg),
        count: records.length
      });
    }

    const savedStreak = loadItem<any>('vidypath_streak_v1', null);
    const streakCount = savedStreak?.count || 0;
    const computedBadges = getBadgeStatuses(streakCount, records as any);
    setBadges(computedBadges);
  }, []);

  const manualSync = () => {
    setSyncing(true);
    setTimeout(() => {
      setSyncing(false);
      showToast('Cloud data re-verified and synced successfully!');
    }, 1500);
  };

  const [showSignOutConfirm, setShowSignOutConfirm] = useState(false);

  if (!user) {
    return (
      <div className="max-w-[780px] mx-auto px-4 py-16 flex flex-col items-center justify-center text-center space-y-6">
        <div className="w-20 h-20 bg-orange-lt rounded-[32px] flex items-center justify-center text-orange shadow-xl shadow-orange/10 border-2 border-orange-mid/20">
          <User className="w-10 h-10" />
        </div>
        <div className="space-y-2">
          <h2 className="text-2xl font-display">Student Profile</h2>
          <p className="text-sm text-ink3 max-w-xs mx-auto">Sign in to sync your progress, save study plans, and unlock personalized AI insights.</p>
        </div>
        <button 
          onClick={() => setAuthModalOpen(true)}
          className="px-8 py-4 bg-orange text-white rounded-2xl font-black uppercase tracking-widest text-xs shadow-xl shadow-orange/20 hover:scale-105 transition-all active:scale-95 cursor-pointer animate-pulse"
        >
          Sign In / Register Account
        </button>
      </div>
    );
  }

  const userPhoto = profile?.photoURL || user.photoURL;

  return (
    <div className="max-w-[780px] mx-auto px-4 py-8 pb-32 space-y-8 animate-fadeUp">
      {/* Header Profile Info */}
      <div className="flex flex-col items-center text-center space-y-4">
        <div className="relative group">
          {userPhoto && userPhoto.length > 4 ? (
            <img 
              src={userPhoto} 
              alt="Profile" 
              className="w-24 h-24 rounded-[36px] border-4 border-orange shadow-2xl group-hover:rotate-3 transition-transform duration-500 object-cover" 
            />
          ) : (
            <div className="w-24 h-24 rounded-[36px] bg-orange-lt flex items-center justify-center text-4xl border-4 border-orange shadow-2xl group-hover:rotate-3 transition-transform duration-500 font-bold select-none text-orange">
              {userPhoto || <User className="w-12 h-12" />}
            </div>
          )}
          <div className="absolute -bottom-2 -right-2 bg-green-500 text-white p-1.5 rounded-xl border-4 border-bg shadow-lg">
            <ShieldCheck className="w-4 h-4" />
          </div>
        </div>
        
        <div className="space-y-1">
          <h2 className="text-3xl font-display tracking-tight text-ink">{profile?.name || user.displayName || 'Bright Scholar'}</h2>
          <p className="text-sm text-ink3 font-medium">{user.email}</p>
        </div>

        <div className="flex flex-col items-center gap-2">
          <div className="flex flex-wrap gap-2 justify-center">
            <span className="px-3 py-1 bg-blue-lt text-blue-500 border border-blue-mid rounded-full text-[10px] font-black uppercase tracking-widest">{profile?.class || 'CBSE Class 10'}</span>
            <span className="px-3 py-1 bg-orange-lt text-orange border border-orange-mid rounded-full text-[10px] font-black uppercase tracking-widest">Session 2026-27</span>
            {profile?.school && (
              <span className="px-3 py-1 bg-purple-50 text-purple-600 border border-purple-200 rounded-full text-[10px] font-black uppercase tracking-widest">🏫 {profile.school}</span>
            )}
          </div>
          
          <button 
            type="button"
            onClick={() => setIsEditing(!isEditing)}
            className="mt-2 px-4 py-2 bg-surface text-ink hover:text-orange text-[10px] uppercase tracking-widest font-black border border-border hover:border-orange rounded-xl transition-all shadow-2xs active:scale-95 cursor-pointer flex items-center gap-1.5"
          >
            <User className="w-3.5 h-3.5" />
            {isEditing ? 'Cancel Editing' : 'Edit Profile Details'}
          </button>
        </div>
      </div>

      {/* Editing section */}
      {isEditing && (
        <div className="bg-surface p-6 rounded-[32px] border border-border shadow-xl space-y-4 text-left animate-fadeIn">
          <h3 className="text-xs font-black uppercase tracking-widest text-ink flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-orange" />
            Update Student Profile
          </h3>
          
          <div className="space-y-4">
            {/* Name */}
            <div className="space-y-1">
              <label className="text-[9px] font-black uppercase tracking-widest text-ink3 ml-1">Full Name</label>
              <input 
                type="text"
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                className="w-full px-4 py-3 bg-surface2 border border-border rounded-xl text-sm text-ink focus:outline-none focus:border-orange"
                placeholder="Student Name"
              />
            </div>

            {/* Class & School */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-[9px] font-black uppercase tracking-widest text-ink3 ml-1">Class / Syllabus</label>
                <select
                  value={editClass}
                  onChange={(e) => setEditClass(e.target.value)}
                  className="w-full px-4 py-3 bg-surface2 border border-border rounded-xl text-sm text-ink focus:outline-none focus:border-orange appearance-none"
                >
                  <option value="CBSE Class 10">CBSE Class 10</option>
                  <option value="CBSE Class 9">CBSE Class 9</option>
                  <option value="CBSE Class 8">CBSE Class 8</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[9px] font-black uppercase tracking-widest text-ink3 ml-1">School Name</label>
                <input 
                  type="text"
                  value={editSchool}
                  onChange={(e) => setEditSchool(e.target.value)}
                  className="w-full px-4 py-3 bg-surface2 border border-border rounded-xl text-sm text-ink focus:outline-none focus:border-orange"
                  placeholder="e.g. Kendriya Vidyalaya"
                />
              </div>
            </div>

            {/* Avatar picker */}
            <div className="space-y-2">
              <label className="text-[9px] font-black uppercase tracking-widest text-ink3 ml-1">Select Student Avatar</label>
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                {AVATARS.map((avatar) => (
                  <button
                    type="button"
                    key={avatar.id}
                    onClick={() => setEditAvatar(avatar.id)}
                    className={cn(
                      "p-2.5 rounded-xl border flex flex-col items-center justify-center transition-all bg-surface hover:scale-105 active:scale-95 cursor-pointer",
                      editAvatar === avatar.id 
                        ? "border-orange ring-2 ring-orange/10 scale-105 shadow-sm" 
                        : "border-border/60 hover:border-slate-300"
                    )}
                  >
                    <span className="text-xl">{avatar.emoji}</span>
                    <span className="text-[8px] font-black uppercase tracking-tighter text-ink2 mt-1 shrink-0">{avatar.label.split(' ')[1]}</span>
                  </button>
                ))}
              </div>
            </div>

            <button
              type="button"
              onClick={handleSaveProfile}
              className="w-full py-3 bg-orange text-white text-[10px] uppercase tracking-widest font-black rounded-xl transition-all shadow-md hover:shadow-orange/15 shadow-orange/10 hover:bg-orange/95 cursor-pointer"
            >
              Save Student Profile
            </button>
          </div>
        </div>
      )}

      {/* Cloud Sync Status */}
      <div className="bg-gradient-to-br from-green-50 to-emerald-50 border border-green-100 p-6 rounded-[32px] space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
             <div className="w-10 h-10 bg-white rounded-2xl flex items-center justify-center text-green-600 shadow-sm border border-green-100">
                <ShieldCheck className={cn("w-5 h-5", syncing && "animate-bounce")} />
             </div>
             <div>
                <h4 className="text-[10px] font-black uppercase tracking-widest text-green-700">Storage Protection</h4>
                <div className="text-sm font-bold text-green-900">Cloud Data Integrity Active</div>
             </div>
          </div>
          <button 
            onClick={manualSync}
            disabled={syncing}
            className="p-2.5 bg-white border border-green-200 rounded-xl text-green-600 hover:bg-green-600 hover:text-white transition-all shadow-sm disabled:opacity-50"
          >
            <Globe className={cn("w-4 h-4", syncing && "animate-spin")} />
          </button>
        </div>
        <p className="text-[10px] text-green-800/70 font-medium leading-relaxed">
          Your progress, study plans, and mistake history are automatically synced to our secure cloud. No data will be lost during updates or app maintenance.
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-surface p-5 rounded-[32px] border border-border shadow-sm flex flex-col items-center justify-center text-center space-y-2">
          <div className="w-10 h-10 bg-orange-lt text-orange rounded-2xl flex items-center justify-center">
            <Award className="w-5 h-5" />
          </div>
          <div>
            <div className="text-2xl font-black text-ink">{progStats.avgPct}%</div>
            <div className="text-[10px] font-black uppercase tracking-widest text-ink3">Avg Score</div>
          </div>
        </div>
        <div className="bg-surface p-5 rounded-[32px] border border-border shadow-sm flex flex-col items-center justify-center text-center space-y-2">
          <div className="w-10 h-10 bg-blue-lt text-blue-500 rounded-2xl flex items-center justify-center">
            <Target className="w-5 h-5" />
          </div>
          <div>
            <div className="text-2xl font-black text-ink">{progStats.count}</div>
            <div className="text-[10px] font-black uppercase tracking-widest text-ink3">Quizzes Done</div>
          </div>
        </div>
      </div>

      {/* Badges & Achievements System */}
      <div className="space-y-4">
        <div className="flex items-center justify-between px-2">
          <div className="text-left">
            <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-ink3">Badges & Achievements</h3>
            <p className="text-xs text-ink font-black mt-0.5">Syllabus Gamification & Rewards</p>
          </div>
          <div className="px-3 py-1 bg-amber-50 dark:bg-amber-950/20 border border-amber-200/50 rounded-full text-[10px] font-extrabold text-amber-700 uppercase tracking-wider flex items-center gap-1 shrink-0">
            <Trophy className="w-3 h-3 text-amber-500 animate-pulse" />
            {badges.filter(b => b.unlocked).length} / {badges.length} Unlocked
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3">
          {badges.map((bStatus) => {
            const { badge, unlocked, progressStr, current, target } = bStatus;
            const IconComponent = ICON_MAP[badge.iconName] || Award;
            const ratio = Math.min(100, Math.round((current / (target || 1)) * 100));

            return (
              <button
                type="button"
                key={badge.id}
                onClick={() => setSelectedBadge(bStatus)}
                className={cn(
                  "p-4 rounded-[28px] border bg-surface flex flex-col items-center justify-between text-center transition-all shadow-3xs group relative overflow-hidden select-none active:scale-95 duration-205 min-h-[140px]",
                  unlocked 
                    ? "border-amber-200/60 dark:border-amber-950 hover:border-amber-400 hover:shadow-xs cursor-pointer" 
                    : "border-border/60 opacity-70 hover:opacity-100 hover:border-slate-300 cursor-pointer"
                )}
              >
                {/* Visual Emblem Circle */}
                <div className="relative mb-3">
                  <div className={cn(
                    "w-11 h-11 rounded-[18px] flex items-center justify-center transition-transform duration-300 group-hover:scale-110",
                    unlocked 
                      ? `bg-gradient-to-br ${badge.bgClass} text-white shadow-sm` 
                      : "bg-surface3 border border-dashed border-border text-ink3"
                  )}>
                    <IconComponent className="w-4 h-4" />
                  </div>
                  
                  {/* Small Lock/Unlock Signet */}
                  <div className={cn(
                    "absolute -bottom-1 -right-1 w-4 h-4 rounded-lg flex items-center justify-center border border-bg shadow-2xs text-[8px]",
                    unlocked 
                      ? "bg-green-500 text-white" 
                      : "bg-surface3 text-ink3 border-border"
                  )}>
                    {unlocked ? <Check className="w-2.5 h-2.5 font-black" /> : <Lock className="w-2.5 h-2.5" />}
                  </div>
                </div>

                {/* Badge title & mini stats */}
                <div className="space-y-1 w-full">
                  <p className="text-[10px] font-black tracking-tight text-ink line-clamp-1 leading-tight">
                    {badge.title}
                  </p>
                  
                  {/* Small custom bar tracker inside standard layout */}
                  <div className="w-full bg-surface3 rounded-full h-1 mt-1.5 overflow-hidden border border-border/10">
                    <div 
                      className={cn(
                        "h-full rounded-full transition-all duration-500", 
                        unlocked ? "bg-amber-400" : "bg-blue-500"
                      )} 
                      style={{ width: `${ratio}%` }}
                    />
                  </div>
                  <span className="text-[8px] font-bold text-ink3 uppercase block tracking-wider mt-0.5">
                    {progressStr}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Badge Achievement Details Modal Overlay */}
      {selectedBadge && (() => {
        const { badge, unlocked, progressStr, current, target } = selectedBadge;
        const IconComponent = ICON_MAP[badge.iconName] || Award;
        const ratio = Math.min(100, Math.round((current / (target || 1)) * 100));

        return (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs anim-fadeIn">
            <div className="bg-surface max-w-sm w-full rounded-[36px] border border-border p-6 shadow-2xl relative overflow-hidden text-center space-y-6 animate-scaleIn">
              
              {/* Top dismissal corner */}
              <button 
                type="button"
                onClick={() => setSelectedBadge(null)}
                className="absolute top-4 right-4 p-1.5 bg-surface2 hover:bg-surface3 border border-border text-ink3 hover:text-ink rounded-full transition-all"
              >
                <X className="w-3.5 h-3.5" />
              </button>

              {/* Central badge large design */}
              <div className="flex flex-col items-center pt-2">
                <div className={cn(
                  "w-16 h-16 rounded-[22px] flex items-center justify-center relative shadow-md transform rotate-3 hover:rotate-0 transition-transform duration-300",
                  unlocked 
                    ? `bg-gradient-to-br ${badge.bgClass} text-white` 
                    : "bg-surface3 border-2 border-dashed border-border text-ink3"
                )}>
                  <IconComponent className="w-7 h-7" />
                </div>
                
                {/* Status Pillow tag */}
                <span className={cn(
                  "mt-4 px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest border shadow-3xs",
                  unlocked 
                    ? "bg-green-100 text-green-700 border-green-200" 
                    : "bg-surface2 text-ink3 border-border"
                )}>
                  {unlocked ? "Unlocked Badge ✓" : "In Progress / Locked"}
                </span>
              </div>

              {/* Header Titles */}
              <div className="space-y-1.5">
                <h4 className="text-lg font-display text-ink leading-tight">{badge.title}</h4>
                <p className="text-xs text-ink3 font-medium leading-relaxed max-w-xs mx-auto">
                  {badge.description}
                </p>
              </div>

              {/* Progress visual section */}
              <div className="bg-surface2 p-4 rounded-3xl border border-border text-left space-y-2">
                <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-wider text-ink2">
                  <span>Syllabus Target Progress</span>
                  <span className="text-right text-blue-600">{progressStr}</span>
                </div>
                <div className="w-full bg-surface3 rounded-full h-2 overflow-hidden border border-border/20">
                  <div 
                    className={cn(
                      "h-full rounded-full transition-all duration-500", 
                      unlocked ? "bg-amber-400" : "bg-blue-500"
                    )} 
                    style={{ width: `${ratio}%` }}
                  />
                </div>
              </div>

              {/* CBSE Board topper academic tip */}
              <div className="bg-gradient-to-br from-amber-50 to-orange-50 dark:from-neutral-900 border border-amber-100/60 p-4 rounded-3xl text-left space-y-1.5 shadow-3xs">
                <span className="text-[9px] font-black text-amber-700 uppercase tracking-widest flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-500 animate-pulse shrink-0" />
                  CBSE Topper Prep Guide
                </span>
                <p className="text-[11px] font-bold text-amber-950 dark:text-neutral-250 leading-relaxed">
                  "{badge.cbseTip}"
                </p>
              </div>

              {/* Under-action button */}
              <button
                type="button"
                onClick={() => setSelectedBadge(null)}
                className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white text-[10px] font-black uppercase tracking-widest rounded-2xl transition-all shadow-md shadow-blue-200"
              >
                Close & Continue Prep
              </button>
            </div>
          </div>
        );
      })()}

      {/* Settings Sections */}
      <div className="space-y-3">
        <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-ink3 ml-4">Academic Settings</h3>
        <div className="bg-surface rounded-[40px] border border-border shadow-xl overflow-hidden">
          <button 
            onClick={() => navigateTo('tracker')}
            className="w-full p-6 flex items-center gap-4 hover:bg-surface2 transition-colors border-b border-border group"
          >
            <div className="w-12 h-12 bg-white rounded-2xl border border-border flex items-center justify-center text-orange shadow-sm group-hover:scale-110 transition-transform">
              <BookOpen className="w-5 h-5" />
            </div>
            <div className="flex-1 text-left">
              <div className="text-sm font-bold">Progress History</div>
              <p className="text-[10px] text-ink3">Review your detailed performance metrics</p>
            </div>
            <ChevronRight className="w-5 h-5 text-ink3 group-hover:translate-x-1 transition-transform" />
          </button>

          <button 
             onClick={() => navigateTo('mistake-book')}
             className="w-full p-6 flex items-center gap-4 hover:bg-surface2 transition-colors border-b border-border group"
          >
            <div className="w-12 h-12 bg-white rounded-2xl border border-border flex items-center justify-center text-red-500 shadow-sm group-hover:scale-110 transition-transform">
              <Trash2 className="w-5 h-5" />
            </div>
            <div className="flex-1 text-left">
              <div className="text-sm font-bold">Mistake Book</div>
              <p className="text-[10px] text-ink3">Manage and review your collection of errors</p>
            </div>
            <ChevronRight className="w-5 h-5 text-ink3 group-hover:translate-x-1 transition-transform" />
          </button>

          <button 
             onClick={() => navigateTo('planner')}
             className="w-full p-6 flex items-center gap-4 hover:bg-surface2 transition-colors group"
          >
            <div className="w-12 h-12 bg-white rounded-2xl border border-border flex items-center justify-center text-blue-500 shadow-sm group-hover:scale-110 transition-transform">
              <Target className="w-5 h-5" />
            </div>
            <div className="flex-1 text-left">
              <div className="text-sm font-bold">Planner Config</div>
              <p className="text-[10px] text-ink3">Modify your proficiency and daily study time</p>
            </div>
            <ChevronRight className="w-5 h-5 text-ink3 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </div>

      <div className="space-y-3">
        <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-ink3 ml-4">Preferences</h3>
        <div className="bg-surface rounded-[40px] border border-border shadow-xl overflow-hidden p-6 space-y-6">
          <div className="flex items-center gap-4 group cursor-default">
            <div className="w-12 h-12 bg-white rounded-2xl border border-border flex items-center justify-center text-ink shadow-sm">
              <Globe className="w-5 h-5" />
            </div>
            <div className="flex-1 text-left">
              <div className="text-sm font-bold">Subject Selection</div>
              <p className="text-[10px] text-ink3">Choose your optional second language</p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-2 bg-surface2 p-1.5 rounded-2xl border border-border">
            {[
              { id: 'hindi', label: 'Hindi A' },
              { id: 'hindi_b', label: 'Hindi B' },
              { id: 'marathi', label: 'Marathi' }
            ].map((lang) => (
              <button
                key={lang.id}
                onClick={() => updateLanguage(lang.id)}
                className={cn(
                  "flex-1 px-4 py-3 text-[10px] font-black uppercase tracking-widest rounded-xl transition-all flex items-center justify-center gap-2",
                  activeLanguage === lang.id 
                    ? "bg-orange text-white shadow-lg shadow-orange/20" 
                    : "bg-white text-ink3 border border-border/50 hover:border-orange/30 hover:text-ink"
                )}
              >
                {activeLanguage === lang.id && <Globe className="w-3.5 h-3.5 animate-pulse" />}
                {lang.label}
              </button>
            ))}
          </div>
        </div>

        <div className="bg-surface rounded-[40px] border border-border shadow-xl overflow-hidden">
          <div className="p-6 flex items-center gap-4 border-b border-border group cursor-default">
            <div className="w-12 h-12 bg-white rounded-2xl border border-border flex items-center justify-center text-ink shadow-sm">
              <Bell className="w-5 h-5" />
            </div>
            <div className="flex-1 text-left">
              <div className="text-sm font-bold">Notifications</div>
              <p className="text-[10px] text-ink3">Daily study goals & CBSE alerts</p>
            </div>
            <div className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" defaultChecked />
              <div className="w-11 h-6 bg-surface2 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-orange border border-border" />
            </div>
          </div>
          
          <button 
             onClick={async () => {
               const shareUrl = window.location.origin;
               if (navigator.share) {
                 try {
                   await navigator.share({
                     title: 'VidyPath - Class 10 CBSE Companion',
                     text: 'Check out this amazing AI study companion for Class 10 board exams!',
                     url: shareUrl
                   });
                 } catch (err: any) {
                   // Handle cancellation (AbortError) silently or fall back if other error (e.g. Iframe restrictions)
                   if (err.name !== 'AbortError') {
                     try {
                       await navigator.clipboard.writeText(shareUrl);
                       showToast('Link copied to clipboard!');
                     } catch (clipErr) {
                       // Silently ignore if both share and clipboard fail due to sandboxed iframe context
                     }
                   }
                 }
               } else {
                 try {
                   await navigator.clipboard.writeText(shareUrl);
                   showToast('Sharing link copied to clipboard!');
                 } catch (clipErr) {
                   showToast('Share link: ' + shareUrl);
                 }
               }
             }}
             className="w-full p-6 flex items-center gap-4 hover:bg-surface2 transition-colors group"
          >
            <div className="w-12 h-12 bg-white rounded-2xl border border-border flex items-center justify-center text-pink-500 shadow-sm group-hover:scale-110 transition-transform">
              <Share2 className="w-5 h-5" />
            </div>
            <div className="flex-1 text-left">
              <div className="text-sm font-bold">Invite Friends</div>
              <p className="text-[10px] text-ink3">Study better with classmates</p>
            </div>
            <ChevronRight className="w-5 h-5 text-ink3 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </div>

      <div className="space-y-3">
        <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-ink3 ml-4">VidyPath Legal & Release Hub</h3>
        <div className="bg-surface rounded-[40px] border border-border shadow-xl overflow-hidden p-3 divide-y divide-border/40">
          
          {/* About Page Trigger */}
          <button 
            type="button"
            onClick={() => setActiveLegalModal('about')}
            className="w-full p-4 flex items-center gap-4 hover:bg-surface2 transition-all rounded-[24px] text-left cursor-pointer group"
          >
            <div className="w-11 h-11 bg-orange/15 text-orange rounded-2xl flex items-center justify-center shadow-3xs group-hover:scale-105 transition-transform shrink-0">
              <Info className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <div className="text-xs font-bold text-ink">About VidyPath</div>
              <p className="text-[9px] text-ink3 leading-snug">Platform vision, Class 10th features & release track</p>
            </div>
            <ChevronRight className="w-4 h-4 text-ink3 group-hover:translate-x-1 transition-transform shrink-0" />
          </button>

          {/* Privacy Policy Trigger */}
          <button 
            type="button"
            onClick={() => setActiveLegalModal('privacy')}
            className="w-full p-4 flex items-center gap-4 hover:bg-surface2 transition-all rounded-[24px] text-left cursor-pointer group"
          >
            <div className="w-11 h-11 bg-emerald-100/40 dark:bg-emerald-950/20 text-emerald-600 rounded-2xl flex items-center justify-center shadow-3xs group-hover:scale-105 transition-transform shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <div className="text-xs font-bold text-ink">Privacy Policy</div>
              <p className="text-[9px] text-ink3 leading-snug">Student data safe-harbor and CBSE privacy standard guidelines</p>
            </div>
            <ChevronRight className="w-4 h-4 text-ink3 group-hover:translate-x-1 transition-transform shrink-0" />
          </button>

          {/* Terms of Use Trigger */}
          <button 
            type="button"
            onClick={() => setActiveLegalModal('terms')}
            className="w-full p-4 flex items-center gap-4 hover:bg-surface2 transition-all rounded-[24px] text-left cursor-pointer group"
          >
            <div className="w-11 h-11 bg-purple-100/40 dark:bg-purple-950/20 text-purple-600 rounded-2xl flex items-center justify-center shadow-3xs group-hover:scale-105 transition-transform shrink-0">
              <FileText className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <div className="text-xs font-bold text-ink">Terms of Use</div>
              <p className="text-[9px] text-ink3 leading-snug">Academic fair-play, content usage, and system-wide guidelines</p>
            </div>
            <ChevronRight className="w-4 h-4 text-ink3 group-hover:translate-x-1 transition-transform shrink-0" />
          </button>

          {/* Contact Support Trigger */}
          <button 
            type="button"
            onClick={() => setActiveLegalModal('support')}
            className="w-full p-4 flex items-center gap-4 hover:bg-surface2 transition-all rounded-[24px] text-left cursor-pointer group"
          >
            <div className="w-11 h-11 bg-indigo-100/40 dark:bg-indigo-950/20 text-indigo-600 rounded-2xl flex items-center justify-center shadow-3xs group-hover:scale-105 transition-transform shrink-0">
              <LifeBuoy className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <div className="text-xs font-bold text-ink">Contact Helpdesk Support</div>
              <p className="text-[9px] text-ink3 leading-snug">Open a direct support ticket to state-side engineering desks</p>
            </div>
            <ChevronRight className="w-4 h-4 text-ink3 group-hover:translate-x-1 transition-transform shrink-0" />
          </button>

        </div>
      </div>

      <div className="space-y-3">
        <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-ink3 ml-4">Support & Feedback Hub</h3>
        <div className="bg-surface rounded-[40px] border border-border shadow-xl overflow-hidden p-6 space-y-5">
          <div className="flex items-center gap-4 border-b border-border pb-4">
            <div className="w-12 h-12 bg-white rounded-2xl border border-border flex items-center justify-center text-blue-400 shadow-sm">
              <HelpCircle className="w-5 h-5" />
            </div>
            <div className="flex-1 text-left">
              <div className="text-sm font-bold">Help Center</div>
              <p className="text-[10px] text-ink3">FAQs and guidance on using CBSE AI tools</p>
            </div>
          </div>

          <div className="space-y-3">
            <p className="text-[10px] text-ink3 font-bold uppercase tracking-wider">Submit a direct report:</p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {/* General Feedback Button */}
              <button 
                type="button"
                onClick={() => setActiveFeedbackCategory('feedback')}
                className="p-4 bg-indigo-50 hover:bg-indigo-100/60 dark:bg-indigo-950/20 border border-indigo-100 dark:border-indigo-900/40 rounded-2xl flex flex-col items-center justify-center text-center transition-all group active:scale-95 cursor-pointer"
              >
                <div className="w-8 h-8 bg-white rounded-xl flex items-center justify-center text-indigo-600 shadow-3xs group-hover:scale-110 transition-transform">
                  <Mail className="w-4 h-4" />
                </div>
                <span className="text-[10px] font-black uppercase tracking-wider text-indigo-700 dark:text-indigo-300 mt-2.5">Feedback</span>
                <span className="text-[8px] text-indigo-800/60 dark:text-indigo-400/60 font-semibold mt-0.5">Share thoughts</span>
              </button>

              {/* Report Bug Button */}
              <button 
                type="button"
                onClick={() => setActiveFeedbackCategory('bug')}
                className="p-4 bg-pink-50 hover:bg-pink-100/60 dark:bg-pink-950/20 border border-pink-100 dark:border-pink-900/40 rounded-2xl flex flex-col items-center justify-center text-center transition-all group active:scale-95 cursor-pointer"
              >
                <div className="w-8 h-8 bg-white rounded-xl flex items-center justify-center text-pink-600 shadow-3xs group-hover:scale-110 transition-transform">
                  <Info className="w-4 h-4" />
                </div>
                <span className="text-[10px] font-black uppercase tracking-wider text-pink-700 dark:text-pink-300 mt-2.5">Report Bug</span>
                <span className="text-[8px] text-pink-800/60 dark:text-pink-400/60 font-semibold mt-0.5">Flag app issues</span>
              </button>

              {/* Feature Request Button */}
              <button 
                type="button"
                onClick={() => setActiveFeedbackCategory('feature')}
                className="p-4 bg-purple-50 hover:bg-purple-100/60 dark:bg-purple-950/20 border border-purple-100 dark:border-purple-900/40 rounded-2xl flex flex-col items-center justify-center text-center transition-all group active:scale-95 cursor-pointer"
              >
                <div className="w-8 h-8 bg-white rounded-xl flex items-center justify-center text-purple-600 shadow-3xs group-hover:scale-110 transition-transform">
                  <Sparkles className="w-4 h-4" />
                </div>
                <span className="text-[10px] font-black uppercase tracking-wider text-purple-700 dark:text-purple-300 mt-2.5">Request</span>
                <span className="text-[8px] text-purple-800/60 dark:text-purple-400/60 font-semibold mt-0.5">Suggest features</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Interactive Floating modal for Feedback submissions */}
      {activeFeedbackCategory && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
          <div className="bg-surface max-w-md w-full rounded-[36px] border border-border p-6 shadow-2xl relative space-y-5 text-left animate-scaleIn">
            
            {/* Modal header details */}
            <div className="flex items-center justify-between border-b border-border pb-3">
              <div className="flex items-center gap-2">
                <span className="text-xl">
                  {activeFeedbackCategory === 'feedback' ? '💬' : activeFeedbackCategory === 'bug' ? '🐛' : '💡'}
                </span>
                <div>
                  <h4 className="text-sm font-black uppercase tracking-wider text-ink leading-none">
                    {activeFeedbackCategory === 'feedback' ? 'General Feedback' : activeFeedbackCategory === 'bug' ? 'Report a Bug' : 'Feature Request'}
                  </h4>
                  <p className="text-[9px] font-black tracking-widest text-ink3 uppercase mt-1">VidyPath Desk Pipeline</p>
                </div>
              </div>
              <button 
                type="button"
                onClick={() => {
                  setActiveFeedbackCategory(null);
                  setFeedbackMessage('');
                  setScreenshot(null);
                }}
                className="p-1.5 bg-surface2 hover:bg-surface3 border border-border text-ink3 hover:text-ink rounded-full transition-all"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Content Message form */}
            <div className="space-y-4">
              <div className="space-y-1">
                <label className="text-[9px] font-black uppercase tracking-widest text-ink3 ml-1">
                  {activeFeedbackCategory === 'feedback' ? 'Your feedback or suggestion' : activeFeedbackCategory === 'bug' ? 'Describe the bug / issue encountered' : 'Describe the feature you would love to see'}
                </label>
                <textarea 
                  value={feedbackMessage}
                  onChange={(e) => setFeedbackMessage(e.target.value)}
                  className="w-full h-28 px-4 py-3 bg-surface2 border border-border rounded-2xl text-xs text-ink focus:outline-none focus:border-orange placeholder:text-ink3/60 leading-relaxed resize-none"
                  placeholder={
                    activeFeedbackCategory === 'feedback' ? "e.g. The app is incredibly useful! I want to suggest..." :
                    activeFeedbackCategory === 'bug' ? "e.g. When taking Science Chapter 2 quiz, the options on Question #5 are overlapping..." :
                    "e.g. It would be amazing to have a digital whiteboard inside the Math chapter dashboard..."
                  }
                />
              </div>

              {/* Advanced file uploading attachments */}
              <div className="space-y-2">
                <label className="text-[9px] font-black uppercase tracking-widest text-ink3 ml-1 block">
                  Screenshot Attachment (Optional)
                </label>
                
                {screenshot ? (
                  <div className="relative w-40 h-28 border border-border rounded-2xl overflow-hidden group shadow-sm bg-surface2 animate-fadeIn">
                    <img 
                      src={screenshot} 
                      alt="Attachment preview" 
                      className="w-full h-full object-cover" 
                      referrerPolicy="no-referrer"
                    />
                    <button
                      type="button"
                      onClick={() => setScreenshot(null)}
                      className="absolute top-2 right-2 p-1 bg-red-600 hover:bg-red-700 text-white rounded-lg shadow-md transition-colors"
                      title="Remove attachment"
                    >
                      <X className="w-3 h-3" />
                    </button>
                    <div className="absolute bottom-0 inset-x-0 bg-black/60 py-1 text-center text-[7px] text-white/90 font-black uppercase tracking-wider">
                      JPEG Auto-Compressed
                    </div>
                  </div>
                ) : (
                  <label className="flex items-center justify-center w-full h-16 border-2 border-dashed border-border/80 hover:border-orange/60 rounded-2xl bg-surface2/40 hover:bg-surface2/75 transition-all cursor-pointer group text-center px-4">
                    <input 
                      type="file" 
                      accept="image/*" 
                      onChange={handleFileChange}
                      className="hidden" 
                    />
                    <div className="flex items-center gap-2 text-ink3 group-hover:text-ink transition-colors">
                      <Mail className="w-4 h-4 text-orange" />
                      <span className="text-[10px] font-bold uppercase tracking-wider">Select or drop screenshot image</span>
                    </div>
                  </label>
                )}
              </div>
            </div>

            {/* Submission triggers */}
            <div className="flex gap-3 pt-2">
              <button
                type="button"
                onClick={() => {
                  setActiveFeedbackCategory(null);
                  setFeedbackMessage('');
                  setScreenshot(null);
                }}
                className="flex-1 py-3 border border-border bg-surface hover:bg-surface2 text-xs font-black uppercase tracking-wider text-ink rounded-2xl transition-all active:scale-95 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSubmitFeedback}
                disabled={submittingFeedback || !feedbackMessage.trim()}
                className="flex-1 py-3 bg-orange hover:bg-orange/95 text-white text-xs font-black uppercase tracking-wider rounded-2xl transition-all shadow-md shadow-orange/20 active:scale-95 disabled:opacity-50 cursor-pointer flex items-center justify-center gap-1.5"
              >
                {submittingFeedback ? (
                  <>
                    <Globe className="w-3.5 h-3.5 animate-spin" />
                    Sending...
                  </>
                ) : (
                  'Submit Report'
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Dynamic Modal overlays for Corporate/Support Policies */}
      {activeLegalModal && (
        <div className="fixed inset-0 z-55 flex items-center justify-center p-4 bg-black/65 backdrop-blur-xs animate-fadeIn">
          <div className="bg-surface max-w-lg w-full rounded-[38px] border border-border p-6 shadow-2xl relative flex flex-col max-h-[85vh] animate-scaleIn text-left">
            
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-border pb-4 mb-4 shrink-0">
              <div className="flex items-center gap-2.5">
                <span className="text-2xl p-1.5 bg-surface2 border border-border rounded-xl">
                  {activeLegalModal === 'about' && '🚀'}
                  {activeLegalModal === 'privacy' && '🛡️'}
                  {activeLegalModal === 'terms' && '📜'}
                  {activeLegalModal === 'support' && '🤝'}
                </span>
                <div>
                  <h4 className="text-sm font-black uppercase tracking-wider text-ink leading-tight">
                    {activeLegalModal === 'about' && 'About VidyPath'}
                    {activeLegalModal === 'privacy' && 'Privacy Policy'}
                    {activeLegalModal === 'terms' && 'Terms of Use'}
                    {activeLegalModal === 'support' && 'Contact Support Helpdesk'}
                  </h4>
                  <p className="text-[8px] font-black tracking-widest text-orange uppercase mt-0.5">
                    {activeLegalModal === 'about' && 'CBSE Grade 10 Companion'}
                    {activeLegalModal === 'privacy' && 'Data Safety Protocol'}
                    {activeLegalModal === 'terms' && 'Academic Integrity'}
                    {activeLegalModal === 'support' && 'Direct Engineering Support'}
                  </p>
                </div>
              </div>
              <button 
                type="button"
                onClick={() => {
                  setActiveLegalModal(null);
                  setSupportSubject('');
                  setSupportMessage('');
                }}
                className="p-1.5 bg-surface2 hover:bg-surface3 border border-border text-ink3 hover:text-ink rounded-full transition-all cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Scrollable Modal Content */}
            <div className="flex-1 overflow-y-auto pr-1 text-xs space-y-4 text-ink2 leading-relaxed">
              {activeLegalModal === 'about' && (
                <div className="space-y-4 animate-fadeIn">
                  <img 
                    src="/src/assets/images/vidypath_welcome_banner_1781441861585.jpg" 
                    alt="VidyPath Academic Journey" 
                    className="w-full aspect-[16/9] object-cover rounded-3xl shadow-lg border border-border"
                    referrerPolicy="no-referrer"
                  />
                  <div className="p-4 bg-orange/5 border border-orange/15 rounded-2xl flex items-start gap-3">
                    <span className="text-xl">🎓</span>
                    <div>
                      <p className="font-bold text-xs text-ink">Welcome to VidyPath</p>
                      <p className="text-[10px] text-ink3 mt-0.5 leading-relaxed">
                        VidyPath is an AI-powered learning platform for CBSE students. It helps students learn, practice, revise and master every chapter through videos, notes, question banks, quizzes, revision systems, mastery tracking and smart planning.
                      </p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <p className="font-bold text-ink text-xs underline decoration-orange/40">Our High-Performance Modules:</p>
                    <ul className="space-y-2 text-[10px] list-disc pl-4">
                      <li>
                        <strong className="text-ink">AI Doubt Solver:</strong> Zero-latency academic mentoring powered by Gemini server-side models. Instantly clear subject bottlenecks.
                      </li>
                      <li>
                        <strong className="text-ink">Board Test Simulation:</strong> Strict practice runs built to mirror direct CBSE standards, grading rubrics, and time constraints.
                      </li>
                      <li>
                        <strong className="text-ink">Active Retrieval Hub:</strong> Multi-topic interactive chapters quizzes and revision flashcard systems using micro-interleaved techniques.
                      </li>
                      <li>
                        <strong className="text-ink">Dynamic Study Planner:</strong> Auto-generated calendars that balance language, science, and math with smart feedback loops.
                      </li>
                    </ul>
                  </div>

                  <div className="border-t border-border pt-3.5 space-y-1.5 font-mono text-[9px] text-ink3">
                    <div className="flex justify-between">
                      <span>App Release Version:</span>
                      <span className="font-black text-ink">v2.5.0-RC1 (Stable)</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Telemetry Layer:</span>
                      <span className="font-black text-ink">Active State Syncing</span>
                    </div>
                    <div className="flex justify-between">
                      <span>CBSE Syllabus Code:</span>
                      <span className="font-black text-ink">2026 Curriculum Standard</span>
                    </div>
                  </div>
                </div>
              )}

              {activeLegalModal === 'privacy' && (
                <div className="space-y-3.5 animate-fadeIn">
                  <p className="text-[10px] font-semibold">
                    Effective Date: June 13, 2026. At VidyPath, user privacy is our highest technical mandate. This Privacy Policy details how student data is safeguarded in accordance with CBSE-standard guidelines.
                  </p>

                  <div className="space-y-1 text-left">
                    <h5 className="font-bold text-ink text-xs">1. Ledger of Collected Data</h5>
                    <p className="text-[10px]">
                      We collect basic Google-auth credentials (email, name, photo url) to verify students, as well as quiz performance indices, streak trackers, planner routines, and error logs. Base64 screenshots uploaded for feedback are encrypted and stored in administrative pipelines.
                    </p>
                  </div>

                  <div className="space-y-1 text-left">
                    <h5 className="font-bold text-ink text-xs">2. Use of Information</h5>
                    <p className="text-[10px]">
                      Information is exclusively utilized to auto-generate personalized curriculum calendars, deliver immediate mentoring through server-side AI, and populate the public leaderboard to foster constructive academic engagement.
                    </p>
                  </div>

                  <div className="space-y-1 text-left">
                    <h5 className="font-bold text-ink text-xs">3. Zero-Sharing Mandate</h5>
                    <p className="text-[10px]">
                      VidyPath does not sell, lease, or exchange student records or analytics with external third-party advertisers. All data is protected server-side behind certified enterprise Firestore security rules.
                    </p>
                  </div>

                  <div className="space-y-1 text-left">
                    <h5 className="font-bold text-ink text-xs">4. Account Rights & Deletion</h5>
                    <p className="text-[10px]">
                      Students reserve full rights to erase performance records, flush mistake logs, reset active calendars, or contact our engineering helpdesk to completely dissolve registration databases.
                    </p>
                  </div>
                </div>
              )}

              {activeLegalModal === 'terms' && (
                <div className="space-y-3.5 animate-fadeIn">
                  <p className="text-[10px]">
                    Effective Date: June 13, 2026. By registering an account with VidyPath, you agree to conform strictly to these user terms.
                  </p>

                  <div className="space-y-1 text-left">
                    <h5 className="font-bold text-ink text-xs">1. Academic Integrity</h5>
                    <p className="text-[10px]">
                      VidyPath is designed for active revision, retrieval practice, and syllabus diagnostics. Users are strictly expected to maintain honor codes during mock test simulations and diagnostic practices.
                    </p>
                  </div>

                  <div className="space-y-1 text-left">
                    <h5 className="font-bold text-ink text-xs">2. Safe & Fair Usage of AI Mentors</h5>
                    <p className="text-[10px]">
                      We integrate state-of-the-art server-side Gemini endpoints for Class 10 mentoring. Flood attacks, automated scripting, query spam, or reverse-engineering efforts are severe violations and will result in permanent UID suspension.
                    </p>
                  </div>

                  <div className="space-y-1 text-left">
                    <h5 className="font-bold text-ink text-xs">3. Proprietary Intellectual Property</h5>
                    <p className="text-[10px]">
                      All simulated question files, mark schemes, and flashcard formats are proprietary assets of VidyPath. Personal distribution or commercial resale of the CBSE simulation corpus is prohibited.
                    </p>
                  </div>

                  <div className="space-y-1 text-left">
                    <h5 className="font-bold text-ink text-xs">4. Liability Boundary</h5>
                    <p className="text-[10px]">
                      Simulations and AI predictions represent learning practice models. They are highly efficient mock tools but do not construct or alter final, official CBSE grade-cards.
                    </p>
                  </div>
                </div>
              )}

              {activeLegalModal === 'support' && (
                <div className="space-y-4 animate-fadeIn">
                  <p className="text-[10px]">
                    Encountered a curriculum bug or having trouble sync-saving? Direct-line your queries to VidyPath developers instantly.
                  </p>

                  {/* Form fields */}
                  <div className="space-y-3">
                    <div className="space-y-1">
                      <label className="text-[8px] font-black uppercase tracking-wider text-ink3 ml-0.5">Ticket Category</label>
                      <select 
                        value={supportCategory}
                        onChange={(e) => setSupportCategory(e.target.value)}
                        className="w-full px-3 py-2 bg-surface2 border border-border rounded-xl text-xs text-ink focus:outline-none focus:border-orange font-medium"
                      >
                        <option>AI Tool Issues</option>
                        <option>Syllabus Help</option>
                        <option>Progress Sync Error</option>
                        <option>Board Test Grading</option>
                        <option>General Feedback</option>
                      </select>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[8px] font-black uppercase tracking-wider text-ink3 ml-0.5">Subject Heading</label>
                      <input 
                        type="text"
                        value={supportSubject}
                        onChange={(e) => setSupportSubject(e.target.value)}
                        className="w-full px-3 py-2 bg-surface2 border border-border rounded-xl text-xs text-ink focus:outline-none focus:border-orange placeholder:text-ink3/45 font-medium"
                        placeholder="e.g. Science Chapter 4 Quiz results not sync-saving"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[8px] font-black uppercase tracking-wider text-ink3 ml-0.5">Inquiry Details</label>
                      <textarea
                        value={supportMessage}
                        onChange={(e) => setSupportMessage(e.target.value)}
                        rows={3.5}
                        className="w-full px-3 py-2.5 bg-surface2 border border-border rounded-xl text-xs text-ink focus:outline-none focus:border-orange placeholder:text-ink3/45 leading-relaxed resize-none"
                        placeholder="Please describe what you encountered, and include any error messages you saw..."
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Modal Actions */}
            <div className="border-t border-border pt-4 mt-4 flex gap-3 shrink-0">
              <button
                type="button"
                onClick={() => {
                  setActiveLegalModal(null);
                  setSupportSubject('');
                  setSupportMessage('');
                }}
                className="flex-1 py-3 border border-border bg-surface hover:bg-surface2 text-xs font-black uppercase tracking-wider text-ink rounded-2xl transition-all cursor-pointer text-center font-bold"
              >
                Close
              </button>
              {activeLegalModal === 'support' && (
                <button
                  type="button"
                  onClick={handleSubmitSupport}
                  disabled={supportSubmitting || !supportMessage.trim() || !supportSubject.trim()}
                  className="flex-1 py-3 bg-orange hover:bg-orange/95 text-white text-xs font-black uppercase tracking-wider rounded-2xl transition-all shadow-md shadow-orange/20 active:scale-95 disabled:opacity-50 cursor-pointer flex items-center justify-center gap-1.5 text-center font-bold"
                >
                  {supportSubmitting ? (
                    'Sending...'
                  ) : (
                    <>
                      <span>Send Ticket</span>
                      <Send className="w-3 h-3" />
                    </>
                  )}
                </button>
              )}
            </div>

          </div>
        </div>
      )}

      <div className="pt-4 px-4 space-y-4">
        {showSignOutConfirm ? (
          <div className="bg-red-50 border border-red-100 p-6 rounded-[32px] space-y-4 animate-fadeUp">
            <div className="text-center space-y-1">
              <h4 className="text-sm font-bold text-red-900">Are you sure?</h4>
              <p className="text-[10px] text-red-700/70 font-medium">You'll need to sign in again to sync your study data.</p>
            </div>
            <div className="flex gap-3">
              <button 
                onClick={() => setShowSignOutConfirm(false)}
                className="flex-1 py-3 bg-white border border-red-100 rounded-2xl text-[10px] font-black uppercase tracking-widest text-red-600 hover:bg-red-50 transition-all"
              >
                Cancel
              </button>
              <button 
                onClick={() => logout()}
                className="flex-1 py-3 bg-red-600 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-red-200 transition-all active:scale-95"
              >
                Sign Out
              </button>
            </div>
          </div>
        ) : (
          <button 
            onClick={() => setShowSignOutConfirm(true)}
            className="w-full py-5 bg-surface border border-border rounded-[32px] flex items-center justify-center gap-3 text-ink2 hover:text-red-500 hover:border-red-500 transition-all font-bold group shadow-sm active:scale-95"
          >
            <LogOut className="w-5 h-5 transition-transform group-hover:-translate-x-1" />
            Sign Out of VidyPath
          </button>
        )}
        
        <div className="text-center space-y-1">
          <p className="text-[9px] font-black uppercase tracking-[0.3em] text-ink3">VidyPath Stable Core v2.5.0-RC1</p>
          <p className="text-[9px] font-bold text-ink3 opacity-40">Built with precision for CBSE Standards</p>
        </div>
      </div>
    </div>
  );
}
