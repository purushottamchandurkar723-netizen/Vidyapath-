/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useMemo } from 'react';
import { Screen } from '../App';
import { SUBJECTS } from '../constants';
import { calculateChapterMastery } from '../utils/masteryHelper';
import { loadItem } from '../lib/utils';
import { 
  ArrowLeft, 
  Award, 
  BookOpen, 
  CheckCircle, 
  Clock, 
  ClipboardList, 
  TrendingUp, 
  Target, 
  BookOpenCheck,
  Zap,
  Activity,
  AlertCircle,
  HelpCircle,
  PlayCircle,
  BookMarked,
  ShieldCheck,
  Sparkles
} from 'lucide-react';
import { cn } from '../lib/utils';
import { motion } from 'motion/react';

interface ExamReadinessDashboardProps {
  navigateTo: (s: Screen, subKey?: string | null, chIdx?: number | null, topic?: string | null, tab?: string | null) => void;
  showToast: (msg: string) => void;
}

export default function ExamReadinessDashboard({ navigateTo, showToast }: ExamReadinessDashboardProps) {

  // Multi-dimensional metrics calculation
  const stats = useMemo(() => {
    let totalChaptersCount = 0;
    let completedChaptersCount = 0;
    let overallProgressSum = 0;
    let overallMasterySum = 0;
    let pendingRevisionsCount = 0;
    
    // Group analysis inside key records
    const subjectScores: Record<string, { sum: number; count: number; name: string; icon: string; color: string; light: string }> = {};

    Object.entries(SUBJECTS).forEach(([subKey, sub]) => {
      subjectScores[subKey] = { 
        sum: 0, 
        count: 0, 
        name: sub.label, 
        icon: sub.icon,
        color: sub.color || '#4F46E5',
        light: sub.light || '#EEF2FF'
      };

      sub.chapters.forEach(ch => {
        totalChaptersCount++;
        const mastery = calculateChapterMastery(subKey, ch.name);
        
        overallProgressSum += mastery.progressPct;
        overallMasterySum += mastery.masteryScore;
        
        subjectScores[subKey].sum += mastery.masteryScore;
        subjectScores[subKey].count += 1;

        if (mastery.isCompleted) {
          completedChaptersCount++;
        }
        
        // Count as pending revision if syllabus core is studied but current revision steps are 0
        if (mastery.state.lecture_completed && mastery.state.revisions_count === 0) {
          pendingRevisionsCount++;
        }
      });
    });

    // Syllabus Completion % (representing breadth of progress)
    const syllabusCompletion = totalChaptersCount > 0 ? Math.round(overallProgressSum / totalChaptersCount) : 0;
    
    // Mastery % (representing depth of scores based on official 6-stage metric)
    const overallMastery = totalChaptersCount > 0 ? Math.round(overallMasterySum / totalChaptersCount) : 0;

    // Board Readiness % (our compound readiness score combining coverage and depth)
    const boardReadiness = Math.min(100, Math.round((syllabusCompletion * 0.4) + (overallMastery * 0.6)));

    // Load actual unresolved errors from local mistake book
    const mistakes = loadItem<any[]>('vidypath_mistakes_v1', []);
    const pendingMistakesCount = mistakes.filter(m => !m.fixed && !m.practiced).length;

    // Compile strong/weak subjects
    const subjectsAnalysis = Object.entries(subjectScores).map(([key, item]) => {
      const avg = item.count > 0 ? Math.round(item.sum / item.count) : 0;
      return {
        key,
        name: item.name,
        icon: item.icon,
        avgMastery: avg,
        color: item.color,
        light: item.light
      };
    });

    // Sort subjects by average mastery
    const sortedSubjects = [...subjectsAnalysis].sort((a, b) => b.avgMastery - a.avgMastery);
    
    const strongSubjects = sortedSubjects.filter(s => s.avgMastery >= 70);
    const weakSubjects = sortedSubjects.filter(s => s.avgMastery < 70);

    // Default fallbacks in case no student metrics are recorded yet
    if (strongSubjects.length === 0 && sortedSubjects.length > 0) {
      strongSubjects.push(sortedSubjects[0]);
    }
    const filteredWeakSubjects = weakSubjects.filter(w => !strongSubjects.includes(w));

    return {
      syllabusCompletion,
      overallMastery,
      boardReadiness,
      completedChaptersCount,
      totalChaptersCount,
      pendingRevisionsCount,
      pendingMistakesCount,
      strongSubjects,
      weakSubjects: filteredWeakSubjects,
      allSubjects: sortedSubjects
    };
  }, []);

  // Board Status level feedback definition
  const readinessFeedback = useMemo(() => {
    const val = stats.boardReadiness;
    if (val >= 85) {
      return {
        label: 'Board-Topper Pacing',
        color: 'text-emerald-500 bg-emerald-50 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-900/40',
        barColor: 'bg-emerald-500',
        advice: '🏆 Exceptional preparation! You have established a strong baseline of mastery and completion. Refresh scheduled revisions to secure 100/100.',
        motivation: 'Ready to Ace!'
      };
    } else if (val >= 70) {
      return {
        label: 'Excellence On Track',
        color: 'text-indigo-500 bg-indigo-50 dark:bg-indigo-950/20 border-indigo-200 dark:border-indigo-900/40',
        barColor: 'bg-indigo-550',
        advice: '⭐ Great job! Your preparation is solid but has minor pockets for growth. Focus on improving Question Bank precision to step into the 90%+ bracket.',
        motivation: 'Practicing & Polishing'
      };
    } else if (val >= 50) {
      return {
        label: 'Actively Progressing',
        color: 'text-amber-600 bg-amber-50 dark:bg-amber-955/15 border-amber-200 dark:border-amber-900/30',
        barColor: 'bg-amber-500',
        advice: '⚡ Dynamic learning is happening. Re-watch weak lectures, read conceptual maps, and clear outstanding mistakes to build double-digit scores.',
        motivation: 'Learning & Building'
      };
    } else {
      return {
        label: 'Action Required',
        color: 'text-red-500 bg-red-50 dark:bg-red-955/10 border-red-200 dark:border-red-900/20',
        barColor: 'bg-red-500',
        advice: '⚠️ Early stage priority! Let’s lock in consistency. Complete baseline lectures for active subjects and begin practicing initial Question Bank sets.',
        motivation: 'Needs Focus'
      };
    }
  }, [stats.boardReadiness]);

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 pb-32 text-left animate-fadeIn">
      
      {/* HEADER BAR */}
      <header className="mb-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <button 
            onClick={() => navigateTo('home')}
            className="inline-flex items-center gap-1.5 text-ink3 font-bold text-xs uppercase tracking-widest hover:text-orange transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            Back to Home
          </button>
          <div className="flex items-center gap-2.5 pt-1">
            <h1 className="text-3xl font-display font-black tracking-tight text-ink">
              Exam Readiness
            </h1>
            <span className="bg-orange-lt text-orange font-black text-[9px] uppercase tracking-widest px-2.5 py-1 rounded-full border border-orange-mid/20">
              Board Engine Model v10
            </span>
          </div>
          <p className="text-ink3 text-xs">
            Instant blueprint rating of study progress, retention levels, and subject priority areas.
          </p>
        </div>
      </header>

      {/* Hero Section: Board Readiness Meter Card */}
      <section className="mb-8">
        <div className="bg-surface border border-border/80 rounded-3xl p-6 sm:p-8 shadow-3xs relative overflow-hidden flex flex-col md:flex-row items-center gap-8">
          
          {/* Decorative backdrop elements */}
          <div className="absolute top-0 right-0 w-48 h-48 bg-orange/5 rounded-full blur-3xl -translate-y-10 translate-x-10 pointer-events-none" />
          
          {/* Radial Board Readiness Meter */}
          <div className="relative w-44 h-44 flex items-center justify-center shrink-0">
            {/* SVG Ring Gauge */}
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
              <circle
                cx="50"
                cy="50"
                r="42"
                className="stroke-neutral-100 dark:stroke-neutral-800"
                strokeWidth="8"
                fill="none"
              />
              <circle
                cx="50"
                cy="50"
                r="42"
                className={cn("stroke-orange transition-all duration-1000 ease-out", readinessFeedback.barColor)}
                strokeWidth="8.5"
                strokeDasharray={`${2 * Math.PI * 42}`}
                strokeDashoffset={`${2 * Math.PI * 42 * (1 - stats.boardReadiness / 100)}`}
                strokeLinecap="round"
                fill="none"
              />
            </svg>
            <div className="absolute flex flex-col items-center justify-center text-center">
              <span className="text-4xl font-display font-black text-ink">
                {stats.boardReadiness}%
              </span>
              <span className="text-[9px] font-black uppercase text-ink3 tracking-widest mt-0.5">
                Ready
              </span>
            </div>
          </div>

          {/* Feedback & General Preparation Guidance Description */}
          <div className="flex-1 space-y-4 text-center md:text-left">
            <div className="space-y-1">
              <span className={cn("inline-block text-[10px] font-black uppercase tracking-wider px-3 py-1 rounded-full border", readinessFeedback.color)}>
                {readinessFeedback.label}
              </span>
              <h2 className="text-xl font-display font-bold text-ink">
                Your Board Exam Readiness is <span className="text-orange">{readinessFeedback.motivation}</span>
              </h2>
            </div>
            
            <p className="text-xs text-ink3 leading-relaxed max-w-xl">
              {readinessFeedback.advice}
            </p>

            <div className="pt-2 flex flex-wrap items-center justify-center md:justify-start gap-4 text-xs text-ink3 font-bold uppercase tracking-wide">
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-4.5 h-4.5 text-emerald-500" />
                <span>CBSE Verified</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Sparkles className="w-4.5 h-4.5 text-amber-500" />
                <span>No Technical Math</span>
              </div>
            </div>
          </div>

        </div>
      </section>

      {/* CORE READINESS PERCENT TILES */}
      <h3 className="text-xs font-black uppercase tracking-[0.2em] text-[#9CA3AF] mb-4">Core Readiness Indices</h3>
      <section className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
        
        {/* Core Index Card 1: Syllabus Completion % */}
        <div className="bg-surface border border-border/80 rounded-2xl p-6 shadow-3xs flex flex-col justify-between">
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <span className="text-[10px] font-black uppercase tracking-widest text-ink3">Coverage Metric</span>
              <h4 className="text-lg font-bold text-ink hover:text-orange transition-colors">Syllabus Completion</h4>
            </div>
            <div className="w-10 h-10 bg-amber-50 rounded-xl flex items-center justify-center text-amber-500 border border-amber-100">
              <BookOpenCheck className="w-5 h-5" />
            </div>
          </div>

          <div className="py-4 flex items-baseline gap-2">
            <span className="text-4xl font-display font-black text-ink">{stats.syllabusCompletion}%</span>
            <span className="text-xs text-ink3">overall progress completed</span>
          </div>

          <div className="space-y-2">
            <div className="h-2 w-full bg-surface2 rounded-full overflow-hidden border border-border/70">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${stats.syllabusCompletion}%` }}
                className="h-full bg-amber-500 rounded-full"
              />
            </div>
            <p className="text-[10px] text-ink3 font-semibold leading-relaxed">
              Curriculum progression calculated dynamic across all studied CBSE science, maths, and social syllabus sections.
            </p>
          </div>
        </div>

        {/* Core Index Card 2: Mastery % */}
        <div className="bg-surface border border-border/80 rounded-2xl p-6 shadow-3xs flex flex-col justify-between">
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <span className="text-[10px] font-black uppercase tracking-widest text-ink3">Depth Metric</span>
              <h4 className="text-lg font-bold text-ink hover:text-orange transition-colors">Overall Mastery</h4>
            </div>
            <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center text-blue-500 border border-blue-100">
              <Award className="w-5 h-5" />
            </div>
          </div>

          <div className="py-4 flex items-baseline gap-2">
            <span className="text-4xl font-display font-black text-ink">{stats.overallMastery}%</span>
            <span className="text-xs text-ink3">average concept retention</span>
          </div>

          <div className="space-y-2">
            <div className="h-2 w-full bg-surface2 rounded-full overflow-hidden border border-border/70">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${stats.overallMastery}%` }}
                className="h-full bg-blue-500 rounded-full"
              />
            </div>
            <p className="text-[10px] text-ink3 font-semibold leading-relaxed">
              Based on the standard 6-stage weight parameters: lectures, question banks, quizzes, mistake books, revisions, and shortcuts.
            </p>
          </div>
        </div>

      </section>

      {/* QUICK STATUS TICKETS GRID (DISPLAY AS CARDS) */}
      <h3 className="text-xs font-black uppercase tracking-[0.2em] text-[#9CA3AF] mb-4 font-display">Completed & Pending Targets</h3>
      <section className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
        
        {/* Completed Chapters Ticket Card */}
        <div className="bg-surface border border-border hover:border-emerald-250 transition-colors rounded-2xl p-5 shadow-3xs flex flex-col justify-between relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-20 h-20 bg-emerald-500/5 rounded-full blur-xl translate-x-5 -translate-y-5" />
          <div className="flex justify-between items-center mb-3">
            <span className="text-[10px] font-black text-[#9CA3AF] uppercase tracking-wider">Course Coverage</span>
            <CheckCircle className="w-4.5 h-4.5 text-emerald-500 group-hover:scale-110 transition-transform" />
          </div>
          <div className="space-y-1 text-left">
            <h4 className="text-3xl font-display font-black text-ink">
              {stats.completedChaptersCount} <span className="text-xs font-bold text-ink3 font-sans">/ {stats.totalChaptersCount} chapters</span>
            </h4>
            <div className="text-[11px] font-bold text-ink">Completed Chapters</div>
            <p className="text-[10px] text-ink3 mt-1 leading-snug">
              Chapters with zero pending actions across your board checklist.
            </p>
          </div>
          <div className="pt-4 border-t border-border/40 mt-4">
            <button 
              onClick={() => navigateTo('home')}
              className="text-[10px] font-black text-emerald-600 hover:text-emerald-700 uppercase tracking-widest flex items-center gap-1 leading-none"
            >
              Start New Chapter <PlayCircle className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Pending Revisions Ticket Card */}
        <div className="bg-surface border border-border hover:border-orange/20 transition-colors rounded-2xl p-5 shadow-3xs flex flex-col justify-between relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-20 h-20 bg-orange/5 rounded-full blur-xl translate-x-5 -translate-y-5" />
          <div className="flex justify-between items-center mb-3">
            <span className="text-[10px] font-black text-[#9CA3AF] uppercase tracking-wider">Performance Retention</span>
            <Clock className="w-4.5 h-4.5 text-orange group-hover:scale-110 transition-transform" />
          </div>
          <div className="space-y-1 text-left">
            <h4 className="text-3xl font-display font-black text-ink">
              {stats.pendingRevisionsCount} <span className="text-xs font-bold text-ink3 font-sans">due now</span>
            </h4>
            <div className="text-[11px] font-bold text-ink">Pending Revisions</div>
            <p className="text-[10px] text-ink3 mt-1 leading-snug">
              Active chapters waiting for structured spaced review check-ins.
            </p>
          </div>
          <div className="pt-4 border-t border-border/40 mt-4">
            <button 
              onClick={() => navigateTo('revision-center')}
              className="text-[10px] font-black text-orange hover:text-orange-dark uppercase tracking-widest flex items-center gap-1 leading-none"
            >
              Secure Memory Now <Zap className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Pending Mistakes Ticket Card */}
        <div className="bg-surface border border-border hover:border-red-200/50 transition-colors rounded-2xl p-5 shadow-3xs flex flex-col justify-between relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-20 h-20 bg-red-500/5 rounded-full blur-xl translate-x-5 -translate-y-5" />
          <div className="flex justify-between items-center mb-3">
            <span className="text-[10px] font-black text-[#9CA3AF] uppercase tracking-wider">Concept Security</span>
            <ClipboardList className="w-4.5 h-4.5 text-red-500 group-hover:scale-110 transition-transform" />
          </div>
          <div className="space-y-1 text-left">
            <h4 className="text-3xl font-display font-black text-ink">
              {stats.pendingMistakesCount} <span className="text-xs font-bold text-ink3 font-sans">questions</span>
            </h4>
            <div className="text-[11px] font-bold text-ink">Pending Mistakes</div>
            <p className="text-[10px] text-ink3 mt-1 leading-snug">
              Incorrectly solved queries remaining in your Mistake Book.
            </p>
          </div>
          <div className="pt-4 border-t border-border/40 mt-4">
            <button 
              onClick={() => navigateTo('mistake-book')}
              className="text-[10px] font-black text-red-500 hover:text-red-600 uppercase tracking-widest flex items-center gap-1 leading-none"
            >
              Solve Errors <AlertCircle className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

      </section>

      {/* STRONG AND WEAK SUBJECTS CARD GRID */}
      <h3 className="text-xs font-black uppercase tracking-[0.2em] text-[#9CA3AF] mb-4">Subject Assessment</h3>
      <section className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
        
        {/* Strong Subjects Card */}
        <div className="bg-surface border border-emerald-250/50 rounded-2xl p-6 shadow-3xs text-left relative overflow-hidden">
          <div className="absolute top-0 right-0 w-16 h-16 bg-emerald-50 rounded-full blur-xl translate-x-4 -translate-y-4" />
          <div className="flex items-center gap-2 mb-4">
            <div className="w-8 h-8 rounded-full bg-emerald-50 flex items-center justify-center text-emerald-500 border border-emerald-100">
              <Zap className="w-4.5 h-4.5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-ink">Strongest Areas</h4>
              <p className="text-[10px] text-emerald-600 font-bold uppercase tracking-wider">Excellence Established</p>
            </div>
          </div>

          {stats.strongSubjects.length === 0 ? (
            <p className="text-xs text-ink3 italic py-4">No subjects have reached the green mastery benchmark yet. Keep practicing!</p>
          ) : (
            <div className="space-y-3.5">
              {stats.strongSubjects.map((sub, idx) => (
                <div key={idx} className="flex items-center justify-between p-3 bg-bg/50 border border-border/60 rounded-xl">
                  <div className="flex items-center gap-2.5">
                    <span className="text-xl">{sub.icon}</span>
                    <div>
                      <span className="font-bold text-xs text-ink block">{sub.name}</span>
                      <span className="text-[10px] text-emerald-600 font-semibold uppercase tracking-wider">Concept Strength Retention</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-md font-display font-black text-ink">{sub.avgMastery}%</span>
                    <span className="text-[9px] block text-ink3 font-bold">mastery rating</span>
                  </div>
                </div>
              ))}
              <p className="text-[10px] text-[#9CA3AF] leading-relaxed pt-1 font-semibold">
                🎉 Wonderful retainer scores! Keep refreshing mini board tests to defend these subject scores before finals.
              </p>
            </div>
          )}
        </div>

        {/* Weak Subjects Card */}
        <div className="bg-surface border border-amber-250/50 rounded-2xl p-6 shadow-3xs text-left relative overflow-hidden">
          <div className="absolute top-0 right-0 w-16 h-16 bg-amber-50 rounded-full blur-xl translate-x-4 -translate-y-4" />
          <div className="flex items-center gap-2 mb-4">
            <div className="w-8 h-8 rounded-full bg-amber-50 flex items-center justify-center text-amber-500 border border-amber-100">
              <AlertCircle className="w-4.5 h-4.5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-ink">Focus Areas</h4>
              <p className="text-[10px] text-amber-600 font-bold uppercase tracking-wider">Attention Recommended</p>
            </div>
          </div>

          {stats.weakSubjects.length === 0 ? (
            <div className="py-6 text-center">
              <p className="text-xs text-emerald-600 font-black uppercase">🌟 Incredible Balance!</p>
              <p className="text-[10px] text-ink3 leading-relaxed mt-1">
                Every single subject on your list has achieved a magnificent 70%+ baseline. No weak areas detected!
              </p>
            </div>
          ) : (
            <div className="space-y-3.5">
              {stats.weakSubjects.map((sub, idx) => (
                <div key={idx} className="flex items-center justify-between p-3 bg-bg/50 border border-border/60 rounded-xl">
                  <div className="flex items-center gap-2.5">
                    <span className="text-xl">{sub.icon}</span>
                    <div>
                      <span className="font-bold text-xs text-ink block">{sub.name}</span>
                      <span className="text-[10px] text-amber-600 font-extrabold uppercase tracking-widest text-[#D97706]">Needs revision boosts</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-md font-display font-black text-ink">{sub.avgMastery}%</span>
                    <span className="text-[9px] block text-ink3 font-bold">mastery rating</span>
                  </div>
                </div>
              ))}
              <p className="text-[10px] text-[#9CA3AF] leading-relaxed pt-1 font-semibold">
                💡 Targeted help: Focus on completing mock assessments, clearing log files, and doing flash quizzes in these subjects to raise ratings quickly.
              </p>
            </div>
          )}
        </div>

      </section>

      {/* ALL SUBJECT STATUS LIST VIEW */}
      <section className="bg-surface border border-border/80 rounded-3xl p-6 shadow-3xs">
        <h4 className="font-display font-medium text-sm text-ink mb-2">Subject Performance Summary</h4>
        <p className="text-[11px] text-ink3 mb-4">General performance rankings for CBSE Class 10 assessment standards.</p>
        
        <div className="space-y-3">
          {stats.allSubjects.map((sub, idx) => (
            <div 
              key={idx}
              className="p-4 bg-bg rounded-2xl border border-border/60 flex items-center justify-between gap-4"
            >
              <div className="flex items-center gap-3">
                <span className="text-2xl">{sub.icon}</span>
                <div>
                  <h5 className="font-bold text-xs text-ink">{sub.name}</h5>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className={cn(
                      "text-[9px] font-black uppercase px-2 py-0.5 rounded-md",
                      sub.avgMastery >= 85 
                        ? "bg-emerald-50 text-emerald-600 dark:bg-emerald-950/20" 
                        : sub.avgMastery >= 70 
                        ? "bg-indigo-50 text-indigo-500 dark:bg-indigo-950/20" 
                        : sub.avgMastery >= 50 
                        ? "bg-amber-50 text-amber-600" 
                        : "bg-red-50 text-red-500"
                    )}>
                      {sub.avgMastery >= 85 ? 'Mastered' : sub.avgMastery >= 70 ? 'Practicing' : sub.avgMastery >= 50 ? 'Learning' : 'Needs Work'}
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="w-24 sm:w-32 bg-neutral-150 dark:bg-neutral-800 h-2 rounded-full overflow-hidden shrink-0">
                  <div 
                    className={cn(
                      "h-full rounded-full transition-all duration-300",
                      sub.avgMastery >= 85 
                        ? "bg-emerald-500" 
                        : sub.avgMastery >= 70 
                        ? "bg-indigo-500" 
                        : sub.avgMastery >= 50 
                        ? "bg-amber-500" 
                        : "bg-red-500"
                    )}
                    style={{ width: `${sub.avgMastery}%` }}
                  />
                </div>
                <span className="text-xs font-black text-ink tracking-tight shrink-0">{sub.avgMastery}%</span>
              </div>
            </div>
          ))}
        </div>
      </section>

    </div>
  );
}
