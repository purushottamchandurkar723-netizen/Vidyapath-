/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Zap, ArrowLeft, Calendar, Clock, CheckCircle2, ChevronRight, 
  Target, RefreshCw, Timer, BookOpen, Brain, ListChecks, 
  ArrowUpRight, AlertCircle, Plus, Trash2, Check, Settings, 
  Flame, Award, Activity, HelpCircle, CheckSquare, Square, Star,
  Sliders, ArrowUp, ChevronDown, ChevronUp, AlertTriangle, Eye
} from 'lucide-react';
import { cn, loadItem, saveItem } from '../lib/utils';
import { SUBJECTS } from '../constants';
import { useAuth } from '../context/AuthContext';
import { getYouTubeRecommendation, getPreferredTeacher, setPreferredTeacher, POPULAR_TEACHERS } from '../lib/videoUtils';
import { 
  getChapterMasteryState, 
  updateChapterMasteryState, 
  calculateChapterMastery, 
  getSyllabusAggregateStats,
  ChapterMasteryState
} from '../utils/masteryHelper';

interface FastTrackPlannerProps {
  navigateTo: (s: any, subKey?: string | null, chIdx?: number | null, topic?: string | null, tab?: string | null) => void;
  showToast: (msg: string) => void;
}

interface PlannerTask {
  id: string;
  subject: string;
  subjectKey: string;
  chapter: string;
  topic: string;
  type: 'revision' | 'mistake' | 'progress' | 'future';
  durationMins: number;
  priorityLabel: 'Urgent (Overdue)' | 'High' | 'Normal' | 'Secondary';
  actionLabel: string;
}

export default function FastTrackPlanner({ navigateTo, showToast }: FastTrackPlannerProps) {
  // Preferred Teachers State
  const [preferredTeachers, setPreferredTeachersState] = useState<Record<string, string>>(() => ({
    maths: getPreferredTeacher('maths'),
    science: getPreferredTeacher('science'),
    sst: getPreferredTeacher('sst'),
    english: getPreferredTeacher('english')
  }));

  const handleTeacherChange = (subjKey: string, newValue: string) => {
    setPreferredTeacher(subjKey, newValue);
    setPreferredTeachersState(prev => ({ ...prev, [subjKey]: newValue }));
    showToast(`🎯 Educator for ${subjKey.toUpperCase()} updated to ${newValue}`);
  };

  // State variables for Time and Current Study Day
  const [time, setTime] = useState<number>(() => loadItem('vidypath_ft_time_val', 60));
  const [currentDay, setCurrentDay] = useState<number>(() => loadItem('vidypath_ft_day_val', 1));
  const [showConfig, setShowConfig] = useState(false);
  const [activeSubjectTab, setActiveSubjectTab] = useState<string>('maths');
  
  // Track Active School Chapters (Max 2 per subject)
  const [activeChapters, setActiveChapters] = useState<Record<string, string[]>>(() => loadItem('vidypath_ft_active_chapters_val', {
    maths: ["Polynomials"],
    science: ["Chemical Reactions and Equations"],
    sst: ["Power Sharing"],
    english: ["A Letter to God"]
  }));

  // Track completed chapters day references
  const [completedChapters, setCompletedChapters] = useState<Record<string, number>>(() => loadItem('vidypath_ft_completed_chapters_val', {}));

  // Local copy of mastery states for force re-rendering trigger
  const [renderCount, setRenderCount] = useState(0);

  // Sync basic configurations to local storage
  useEffect(() => {
    saveItem('vidypath_ft_time_val', time);
    saveItem('vidypath_ft_day_val', currentDay);
    saveItem('vidypath_ft_active_chapters_val', activeChapters);
    saveItem('vidypath_ft_completed_chapters_val', completedChapters);
  }, [time, currentDay, activeChapters, completedChapters]);

  // Subject translation standard filter
  const activeLang = loadItem<string>('vidypath_active_language', 'hindi');
  const subjectsToUse = Object.entries(SUBJECTS).filter(([key]) => {
    const standard = ['maths', 'science', 'sst', 'english'];
    return standard.includes(key) || key === activeLang;
  });

  const triggerStateReload = () => {
    setRenderCount(prev => prev + 1);
  };

  // Add chapter to active list
  const handleAddActiveChapter = (subjectKey: string, chapterName: string) => {
    const current = activeChapters[subjectKey] || [];
    if (current.includes(chapterName)) return;

    if (current.length >= 2) {
      showToast("⚠️ Rule Lock: Maximum 2 active chapters per subject to manage workload.");
      return;
    }

    setActiveChapters(prev => ({
      ...prev,
      [subjectKey]: [...current, chapterName]
    }));
    showToast(`Added "${chapterName}" to active school chapters.`);
  };

  // Remove chapter from active list
  const handleRemoveActiveChapter = (subjectKey: string, chapterName: string) => {
    const current = activeChapters[subjectKey] || [];
    setActiveChapters(prev => ({
      ...prev,
      [subjectKey]: current.filter(c => c !== chapterName)
    }));
  };

  // Skip / Complete current day
  const handleCompleteDay = () => {
    setCurrentDay(prev => prev + 1);
    showToast(`🌄 Day ${currentDay} complete. Welcome to Day ${currentDay + 1}!`);
  };

  // Reset progress
  const handleReset = () => {
    if (confirm("Are you sure you want to reset Fast-Track Planner progress? This will reset all mastery ratings, day counts, and completions.")) {
      setTime(60);
      setCurrentDay(1);
      setActiveChapters({
        maths: ["Polynomials"],
        science: ["Chemical Reactions and Equations"],
        sst: ["Power Sharing"],
        english: ["A Letter to God"]
      });
      setCompletedChapters({});
      
      // Clear Mastery keys inside local storage
      const allKeys = Object.keys(localStorage);
      allKeys.forEach(k => {
        if (k.startsWith('vidypath_chapter_mast') || k.startsWith('vidypath_ft')) {
          localStorage.removeItem(k);
        }
      });

      showToast("Planner and Mastery ratings reset successfully!");
      triggerStateReload();
    }
  };

  const handleUpdateNotesOptional = (subjectKey: string, chapterName: string, notesChecked: boolean) => {
    const k = `${subjectKey}__${chapterName}`;
    const all = loadItem<Record<string, any>>('vidypath_chapter_mast_notes', {});
    all[k] = !notesChecked;
    saveItem('vidypath_chapter_mast_notes', all);
    triggerStateReload();
    showToast(`Notes updated (Notes are optional and never block chapter completion)!`);
  };

  const isNotesChecked = (subjectKey: string, chapterName: string) => {
    const k = `${subjectKey}__${chapterName}`;
    const all = loadItem<Record<string, boolean>>('vidypath_chapter_mast_notes', {});
    return all[k] || false;
  };

  // 1. GENERATE DAILY PLANNER TASKS & BUDGET PACKING
  const getTodaysScheduleWithBudget = (): { active: PlannerTask[]; packedMins: number; standby: PlannerTask[] } => {
    const queue: PlannerTask[] = [];

    // --- PRIORITY 1: DUE SPACED REVISIONS ---
    Object.entries(completedChapters).forEach(([chapterName, completionDay]) => {
      // Find subject key
      let subKey = 'maths';
      let subLabel = 'Mathematics';
      subjectsToUse.forEach(([k, s]) => {
        if (s.chapters.some(c => c.name === chapterName)) {
          subKey = k;
          subLabel = s.label;
        }
      });

      const entry = calculateChapterMastery(subKey, chapterName);
      const revsCompleted = entry.state.revisions_count;

      if (revsCompleted < 4) {
        const rules = [3, 7, 15, 30];
        const nextDueInDays = rules[revsCompleted];
        const targetDay = completionDay + nextDueInDays;

        if (currentDay >= targetDay) {
          const isOverdue = currentDay > targetDay;
          queue.push({
            id: `rev-${subKey}-${chapterName}`,
            subject: subLabel,
            subjectKey: subKey,
            chapter: chapterName,
            topic: `Spaced Revision ${revsCompleted + 1} (Day ${targetDay} schedule)`,
            type: 'revision',
            durationMins: 15,
            priorityLabel: isOverdue ? 'Urgent (Overdue)' : 'High',
            actionLabel: `Perform Revision ${revsCompleted + 1}`
          });
        }
      }
    });

    // --- PRIORITY 2: PENDING MISTAKE REVIEWS ---
    const rawMistakes = loadItem<any[]>('vidypath_mistakes_v1', []);
    const pendingMistakes = rawMistakes.filter(m => !m.fixed && !m.practiced);

    pendingMistakes.forEach(m => {
      let subjectK = 'maths';
      let subjectL = 'Mathematics';
      subjectsToUse.forEach(([k, s]) => {
        if (s.label?.toLowerCase() === m.subject?.toLowerCase() || k?.toLowerCase() === m.subject?.toLowerCase()) {
          subjectK = k;
          subjectL = s.label;
        }
      });

      queue.push({
        id: `mistake-${m.id}`,
        subject: subjectL,
        subjectKey: subjectK,
        chapter: m.chapterName,
        topic: `Resolve logged error: "${m.question.substring(0, 40)}..."`,
        type: 'mistake',
        durationMins: 10,
        priorityLabel: 'High',
        actionLabel: 'Solve original & similar questions in Mistake Book'
      });
    });

    // --- PRIORITY 3: CURRENT CHAPTER PROGRESS ---
    subjectsToUse.forEach(([subKey, sub]) => {
      const activeList = activeChapters[subKey] || [];
      activeList.forEach(chName => {
        const isFinished = completedChapters[chName];
        if (!isFinished) {
          const mastery = calculateChapterMastery(subKey, chName);
          
          if (!mastery.state.lecture_completed) {
            queue.push({
              id: `lecture-${subKey}-${chName}`,
              subject: sub.label,
              subjectKey: subKey,
              chapter: chName,
              topic: 'Watch topic-wise interactive lecture videos',
              type: 'progress',
              durationMins: 20,
              priorityLabel: 'Normal',
              actionLabel: 'Complete video lecture'
            });
          }

          if (mastery.state.qbank_accuracy < 80) {
            queue.push({
              id: `qbank-${subKey}-${chName}`,
              subject: sub.label,
              subjectKey: subKey,
              chapter: chName,
              topic: `Practice CBSE Subject Questions (Current Accuracy: ${mastery.state.qbank_accuracy}%)`,
              type: 'progress',
              durationMins: 15,
              priorityLabel: 'Normal',
              actionLabel: 'Achieve >= 80% Question Bank precision'
            });
          }

          if (!mastery.state.tricks_completed) {
            queue.push({
              id: `tricks-${subKey}-${chName}`,
              subject: sub.label,
              subjectKey: subKey,
              chapter: chName,
              topic: 'Review formula mind maps and keywords',
              type: 'progress',
              durationMins: 10,
              priorityLabel: 'Secondary',
              actionLabel: 'Complete study of tricks and memory hacks'
            });
          }

          if (mastery.quiz_accuracy < 80) {
            queue.push({
              id: `quiz-${subKey}-${chName}`,
              subject: sub.label,
              subjectKey: subKey,
              chapter: chName,
              topic: `Take board assessment mockup (Highest: ${mastery.quiz_accuracy}%)`,
              type: 'progress',
              durationMins: 15,
              priorityLabel: 'Normal',
              actionLabel: 'Achieve >= 80% Quiz Accuracy'
            });
          }
        }
      });
    });

    // --- PRIORITY 4: FUTURE NEW INDEX ---
    subjectsToUse.forEach(([subKey, sub]) => {
      const activeList = activeChapters[subKey] || [];
      const nextFuture = sub.chapters.find(c => !activeList.includes(c.name) && !completedChapters[c.name]);
      if (nextFuture) {
        queue.push({
          id: `future-${subKey}-${nextFuture.name}`,
          subject: sub.label,
          subjectKey: subKey,
          chapter: nextFuture.name,
          topic: 'Get a head start on foundational textbook reading',
          type: 'future',
          durationMins: 20,
          priorityLabel: 'Secondary',
          actionLabel: 'Assign and start chapter'
        });
      }
    });

    // PACKING ALGORITHM BINDING STUDY TIME
    const activePack: PlannerTask[] = [];
    const standbyQueue: PlannerTask[] = [];
    let allocated = 0;

    queue.forEach(item => {
      if (allocated + item.durationMins <= time) {
        activePack.push(item);
        allocated += item.durationMins;
      } else {
        standbyQueue.push(item);
      }
    });

    return {
      active: activePack,
      packedMins: allocated,
      standby: standbyQueue
    };
  };

  const { active: todaysTasks, packedMins: timeUsed, standby: standbyList } = getTodaysScheduleWithBudget();

  const handleTaskRedirect = (t: PlannerTask) => {
    let chapterIndex: number | null = null;
    const sub = SUBJECTS[t.subjectKey];
    if (sub && t.chapter) {
      chapterIndex = sub.chapters.findIndex(c => c.name === t.chapter);
      if (chapterIndex === -1) chapterIndex = null;
    }

    const lowercaseTopic = (t.topic || '').toLowerCase();
    const lowercaseAction = (t.actionLabel || '').toLowerCase();
    const idValue = (t.id || '').toLowerCase();

    if (t.type === 'mistake' || idValue.includes('mistake')) {
      navigateTo('mistake-book');
      showToast(`🧙‍♂️ Redirected you to Mistake Book to resolve errors!`);
      return;
    }

    if (idValue.startsWith('quiz-')) {
      if (t.subjectKey && chapterIndex !== null) {
        navigateTo('quiz', t.subjectKey, chapterIndex);
        showToast(`🧩 Directly opening assessment mock test for ${t.chapter}!`);
      } else {
        navigateTo('quiz');
      }
      return;
    }

    let targetTab: string = 'ainotes';
    let explanation = 'Revision Notes';

    if (idValue.startsWith('lecture-') || lowercaseTopic.includes('lecture') || lowercaseAction.includes('lecture') || lowercaseAction.includes('video')) {
      targetTab = 'video';
      explanation = 'Video Lectures & tutorials';
    } else if (idValue.startsWith('qbank-') || lowercaseTopic.includes('question bank') || lowercaseTopic.includes('solve') || lowercaseTopic.includes('practice')) {
      targetTab = 'questions';
      explanation = 'Interactive Question Bank';
    } else if (idValue.startsWith('tricks-') || lowercaseTopic.includes('tricks') || lowercaseTopic.includes('shortcut') || lowercaseTopic.includes('mnemonic') || lowercaseTopic.includes('memory hack')) {
      targetTab = 'tricks';
      explanation = 'Memory Hacks & Tricks';
    } else if (lowercaseTopic.includes('formulas') || lowercaseTopic.includes('equations')) {
      targetTab = 'formulas';
      explanation = 'Formulas & Equations';
    } else if (lowercaseTopic.includes('revision') || t.type === 'revision' || idValue.startsWith('rev-')) {
      targetTab = 'ainotes';
      explanation = 'Smart Revision Sheet';
    }

    if (t.subjectKey && chapterIndex !== null) {
      navigateTo('chapter-hub', t.subjectKey, chapterIndex, null, targetTab);
      showToast(`🎯 Auto-directing to ${explanation} for ${t.chapter}!`);
    } else {
      navigateTo('chapter-hub', t.subjectKey || 'maths');
    }
  };

  // Completion criteria checklists logic
  const handleToggleCheckState = (subjectKey: string, chapterName: string, criterion: 'lecture_completed' | 'notes_completed' | 'tricks_completed') => {
    const currentState = getChapterMasteryState(subjectKey, chapterName);
    const newValue = !currentState[criterion];
    
    updateChapterMasteryState(subjectKey, chapterName, { [criterion]: newValue });
    showToast(`Checkpoint updated!`);
    triggerStateReload();

    // Check if chapter was just completed
    verifyAndCompleteChapter(subjectKey, chapterName);
  };

  const handleUpdateAccuracy = (subjectKey: string, chapterName: string, score: number) => {
    updateChapterMasteryState(subjectKey, chapterName, { qbank_accuracy: score });
    showToast(`Question Bank Practice accuracy set to ${score}%!`);
    triggerStateReload();

    verifyAndCompleteChapter(subjectKey, chapterName);
  };

  const handleFulfillRevisionInline = (subjectKey: string, chapterName: string, currentVal: number) => {
    const nextVal = Math.min(4, currentVal + 1);
    updateChapterMasteryState(subjectKey, chapterName, { revisions_count: nextVal });
    showToast(`🎉 Spaced Repetition Revision ${nextVal} checked off!`);
    triggerStateReload();
  };

  // Autolog completed status
  const verifyAndCompleteChapter = (subjectKey: string, chapterName: string) => {
    const masteryObj = calculateChapterMastery(subjectKey, chapterName);
    if (masteryObj.isCompleted && !completedChapters[chapterName]) {
      setCompletedChapters(prev => ({
        ...prev,
        [chapterName]: currentDay
      }));
      showToast(`🏆 Chapter "${chapterName}" completed on Day ${currentDay}! Spaced Revision schedule is now live.`);
    } else if (!masteryObj.isCompleted && completedChapters[chapterName]) {
      const copy = { ...completedChapters };
      delete copy[chapterName];
      setCompletedChapters(copy);
    }
  };

  const handleRestartToMistake = (subjectKey: string, chapterName: string) => {
    // 1. Update Chapter Mastery state
    updateChapterMasteryState(subjectKey, chapterName, {
      revisions_count: 0,
      lecture_completed: true,
      notes_completed: true,
      tricks_completed: true,
      qbank_accuracy: Math.max(getChapterMasteryState(subjectKey, chapterName).qbank_accuracy, 80)
    });

    // 2. Ensure quiz_accuracy is >= 80 in progress logs
    const progressLogs = loadItem<Record<string, any>>('vidypath_progress_v4', {});
    const k = `${subjectKey}__${chapterName}`;
    if (!progressLogs[k] || progressLogs[k].bestScore < progressLogs[k].totalOut * 0.8) {
      progressLogs[k] = {
        totalOut: 10,
        bestScore: 8, // 80%
        history: [{ score: 8, total: 10, ts: Date.now() }]
      };
      saveItem('vidypath_progress_v4', progressLogs);
    }

    // 3. Reset existing mistakes to unresolved or insert a new review mistake
    const mistakes = loadItem<any[]>('vidypath_mistakes_v1', []);
    const sub = SUBJECTS[subjectKey];
    const subjectLabel = sub ? sub.label : '';
    
    // Find mistakes for this chapter
    const chapterMistakes = mistakes.filter(m => 
      m.chapterName?.toLowerCase() === chapterName?.toLowerCase() &&
      (m.subject?.toLowerCase() === subjectLabel?.toLowerCase() || m.subject?.toLowerCase() === subjectKey?.toLowerCase())
    );

    if (chapterMistakes.length > 0) {
      // Reset all status to unsolved so they must be reviewed
      mistakes.forEach(m => {
        if (m.chapterName?.toLowerCase() === chapterName?.toLowerCase() &&
            (m.subject?.toLowerCase() === subjectLabel?.toLowerCase() || m.subject?.toLowerCase() === subjectKey?.toLowerCase())) {
          m.originalSolved = false;
          m.similarSolved = false;
          m.practiced = false;
          m.fixed = false;
        }
      });
    } else {
      // Add a fresh, highly comprehensive conceptual check question as a mistake to solve!
      const todayString = new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
      mistakes.unshift({
        id: 'review-pitfall-' + Date.now(),
        question: `Solve & analyze critical pitfalls, key formulas, and common exam errors in: "${chapterName}"`,
        correctAnswer: "Review complete syllabus, avoid conceptual traps, and score 100%.",
        subject: subjectLabel,
        chapterName: chapterName,
        practiced: false,
        originalSolved: false,
        similarSolved: false,
        fixed: false,
        date: todayString
      });
    }

    saveItem('vidypath_mistakes_v1', mistakes);

    // 4. Since we restarted the flow, let's remove this chapter from completed list so it is actively scheduled in Fast Track!
    const copyCompleted = { ...completedChapters };
    if (copyCompleted[chapterName]) {
      delete copyCompleted[chapterName];
      setCompletedChapters(copyCompleted);
      saveItem('vidypath_ft_completed_chapters_val', copyCompleted);
    }

    // 5. Move the chapter back to activeChapters so it lists in the active workspace automatically!
    const copyActive = { ...activeChapters };
    if (!copyActive[subjectKey]) {
      copyActive[subjectKey] = [];
    }
    if (!copyActive[subjectKey].includes(chapterName)) {
      copyActive[subjectKey] = [chapterName, ...copyActive[subjectKey]].slice(0, 2); // limit to 2 per subject
      setActiveChapters(copyActive);
      saveItem('vidypath_ft_active_chapters_val', copyActive);
    }

    showToast(`🔄 Study Cycle Restarted! You are redirected to Step 6: Mistake Book review.`);
    triggerStateReload();
  };

  // Compile active chapters list and expected timeline
  const activeTimelineList: Array<{ subKey: string; subLabel: string; chapter: string; timeline: string }> = [];
  subjectsToUse.forEach(([key, sub]) => {
    const list = activeChapters[key] || [];
    list.forEach((ch, index) => {
      const sDay = currentDay + index * 3;
      const eDay = currentDay + 6 + index * 3;
      activeTimelineList.push({
        subKey: key,
        subLabel: sub.label,
        chapter: ch,
        timeline: `Day ${sDay}-${eDay}`
      });
    });
  });

  const aggregate = getSyllabusAggregateStats();

  return (
    <div className="space-y-8 animate-fadeUp text-left">
      {/* Premium Dashboard Header & Metrics */}
      <div className="bg-surface border border-border p-6 sm:p-8 rounded-3xl shadow-3xs relative overflow-hidden transition-all hover:shadow-2xs">
        {/* Subtle Ambient Lighting Core Accent */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-orange/5 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20" />
        
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-3">
            <div className="inline-flex items-center gap-1.5 text-[9px] font-black uppercase tracking-[0.15em] bg-orange-lt text-orange border border-orange/10 px-2.5 py-1 rounded-full shadow-3xs">
              <Flame className="w-3 h-3 text-orange animate-pulse" /> Fast-Track Mode Active
            </div>
            <div className="space-y-1.5">
              <h2 className="text-2xl sm:text-3xl font-display font-bold tracking-tight text-ink">Chapter Mastery Planner</h2>
              <p className="text-xs text-ink2 max-w-xl leading-relaxed">
                Empowering class 10 preparation through precision study cycles (70% active modules, 30% advance future topics). Keep pace with daily criteria to secure high-performance Mastery.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <button
              onClick={handleCompleteDay}
              className="px-5 py-3 bg-orange text-white hover:bg-orange-dark font-black rounded-xl text-[10px] uppercase tracking-widest shadow-md hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center gap-2 cursor-pointer"
            >
              🌅 Complete Day & Advance
            </button>
            <button
              onClick={() => setShowConfig(!showConfig)}
              className={cn(
                "px-5 py-3 font-black rounded-xl text-[10px] uppercase tracking-widest transition-all flex items-center gap-2 border cursor-pointer",
                showConfig 
                  ? "bg-ink text-surface border-ink" 
                  : "bg-surface hover:bg-bg border-border text-ink"
              )}
            >
              <Sliders className="w-3.5 h-3.5" /> {showConfig ? "Hide Chapters Manager" : "Manage Syllabus Chapters"}
            </button>
          </div>
        </div>

        {/* Dynamic Metrics Section */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-8 border-t border-border/85 pt-6">
          <div className="bg-bg/45 border border-border/70 p-4 rounded-xl flex items-center gap-3.5 hover:bg-bg/70 transition-colors">
            <div className="w-10 h-10 rounded-lg bg-orange-lt border border-orange/15 flex items-center justify-center text-orange shrink-0">
              <Calendar className="w-4.5 h-4.5" />
            </div>
            <div>
              <div className="text-[9px] font-mono font-bold uppercase text-ink3 tracking-wider">Current Study Day</div>
              <div className="text-lg font-bold text-ink">Day {currentDay}</div>
            </div>
          </div>

          <div className="bg-bg/45 border border-border/70 p-4 rounded-xl flex items-center gap-3.5 hover:bg-bg/70 transition-colors">
            <div className="w-10 h-10 rounded-lg bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600 shrink-0">
              <Target className="w-4.5 h-4.5" />
            </div>
            <div>
              <div className="text-[9px] font-mono font-bold uppercase text-ink3 tracking-wider">Syllabus Mastered</div>
              <div className="text-lg font-bold text-ink">{aggregate.overallCompletionPct}%</div>
            </div>
          </div>

          <div className="bg-bg/45 border border-border/70 p-4 rounded-xl flex items-center gap-3.5 hover:bg-bg/70 transition-colors">
            <div className="w-10 h-10 rounded-lg bg-emerald-50 border border-emerald-100 flex items-center justify-center text-emerald-600 shrink-0">
              <BookOpen className="w-4.5 h-4.5" />
            </div>
            <div>
              <div className="text-[9px] font-mono font-bold uppercase text-ink3 tracking-wider">Chapters Completed</div>
              <div className="text-lg font-bold text-ink">{aggregate.completedChapters} <span className="text-xs text-ink3 font-medium">/ {aggregate.totalChapters}</span></div>
            </div>
          </div>

          <div className="bg-bg/45 border border-border/70 p-4 rounded-xl flex items-center gap-3.5 hover:bg-bg/70 transition-colors">
            <div className="w-10 h-10 rounded-lg bg-amber-50 border border-amber-150 flex items-center justify-center text-amber-650 shrink-0">
              <Award className="w-4.5 h-4.5" />
            </div>
            <div>
              <div className="text-[9px] font-mono font-bold uppercase text-ink3 tracking-wider">Avg Syllabus Mastery</div>
              <div className="text-lg font-bold text-ink">{aggregate.averageMasteryScore}%</div>
            </div>
          </div>
        </div>
      </div>

      {/* Config Drawer for assigning Active Chapters and Adjusting Available Hours */}
      <AnimatePresence>
        {showConfig && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <div className="bg-surface border border-border p-6 rounded-3xl shadow-3xs space-y-6">
              <div className="flex items-center justify-between border-b border-border pb-3">
                <div>
                  <h3 className="font-bold text-base flex items-center gap-2 text-ink">
                    <Settings className="w-4.5 h-4.5 text-orange animate-spin-slow" /> Chapter Syllabus Controls
                  </h3>
                  <p className="text-[9px] text-ink3 uppercase font-bold tracking-wider">Manage Active chapters and Daily learning capacity</p>
                </div>
                <button 
                  onClick={() => setShowConfig(false)}
                  className="text-xs font-bold text-orange hover:text-orange-dark transition-colors cursor-pointer"
                >
                  Minimize ✕
                </button>
              </div>

              {/* Time selector budget */}
              <div className="space-y-3">
                <label className="text-[10px] font-bold uppercase tracking-widest text-ink2 flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-orange" /> Today's Learning Time Budget
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[30, 60, 90, 120].map(t => (
                    <button
                      key={t}
                      onClick={() => setTime(t)}
                      className={cn(
                        "py-2 px-3 rounded-xl border text-xs transition-all cursor-pointer font-bold",
                        time === t 
                          ? "bg-orange border-orange text-white shadow-3xs hover:bg-orange-dark" 
                          : "bg-surface2 border-border text-ink2 hover:bg-bg"
                      )}
                    >
                      {t} Mins <span className="opacity-75 font-normal text-[10px]">
                        {t === 30 && '(Short)'} {t === 60 && '(Balanced)'} {t === 90 && '(Intense)'} {t === 120 && '(Super)'}
                      </span>
                    </button>
                  ))}
                </div>
                <p className="text-[10px] text-ink3 leading-relaxed">
                  Workload is automatically adjusted to protect you from burnout. Extra tasks spill gracefully into Tomorrow's standby queue if your budget is too low!
                </p>
              </div>

              {/* Active chapters selection */}
              <div className="space-y-4 pt-1 border-t border-border pt-4">
                <label className="text-[10px] font-bold uppercase tracking-widest text-ink2 block">
                  Assign School-Aligned Active Chapters (Max 2 Active Chapters at once)
                </label>

                {/* Filter Subjects Tabs */}
                <div className="flex gap-1 overflow-x-auto pb-1 border-b border-border/70 scrollbar-none">
                  {subjectsToUse.map(([key, sub]) => (
                    <button
                      key={key}
                      onClick={() => setActiveSubjectTab(key)}
                      className={cn(
                        "px-3.5 py-1.5 text-[10px] font-black uppercase tracking-wider rounded-t-xl border-x border-t transition-all whitespace-nowrap cursor-pointer",
                        activeSubjectTab === key 
                          ? "text-orange border-border bg-bg font-extrabold" 
                          : "text-ink3 border-transparent hover:text-ink2 hover:bg-slate-50/50"
                      )}
                    >
                      {sub.icon} <span className="ml-1">{sub.label}</span> <span className="ml-1 text-[8px] bg-bg border border-border inline-block px-1 rounded-sm text-ink2">{activeChapters[key]?.length || 0}</span>
                    </button>
                  ))}
                </div>

                {/* Chapter List inside active tab */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 max-h-[190px] overflow-y-auto pr-1">
                  {SUBJECTS[activeSubjectTab]?.chapters.map((ch, idx) => {
                    const isActive = activeChapters[activeSubjectTab]?.includes(ch.name);
                    const isCompleted = completedChapters[ch.name];
                    const entry = calculateChapterMastery(activeSubjectTab, ch.name);

                    return (
                      <div 
                        key={idx} 
                        className="flex items-center justify-between bg-bg/40 p-2.5 rounded-xl border border-border/80 text-xs transition-colors hover:bg-bg/80"
                      >
                        <div className="flex items-center gap-2">
                          {isCompleted ? (
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                          ) : (
                            <div className="w-3.5 h-3.5 rounded-full border border-ink3/40 flex-shrink-0" />
                          )}
                          <span className={cn("font-semibold text-ink truncate max-w-[170px]", isCompleted && "opacity-50 line-through")}>
                            {ch.name}
                          </span>
                          <span className="text-[8px] text-ink3 bg-surface border px-1 rounded font-mono font-bold">
                            {entry.masteryScore}% M.
                          </span>
                        </div>

                        {!isCompleted && (
                          isActive ? (
                            <button
                              onClick={() => handleRemoveActiveChapter(activeSubjectTab, ch.name)}
                              className="px-2 py-0.5 bg-red-50 hover:bg-red-100 border border-red-100 rounded text-[8px] font-black uppercase tracking-wider text-red-500 transition-colors cursor-pointer"
                            >
                              Remove
                            </button>
                          ) : (
                            <button
                              onClick={() => handleAddActiveChapter(activeSubjectTab, ch.name)}
                              className="px-2 py-0.5 bg-orange hover:bg-orange-dark text-white rounded text-[8px] font-black uppercase tracking-wider transition-colors cursor-pointer"
                            >
                              Add Active
                            </button>
                          )
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 text-left items-start">
        {/* Left column: Daily planner task outputs */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Active Agenda List based on available hour budget */}
          <div className="bg-surface border border-border rounded-2xl p-6 shadow-3xs space-y-5">
            <div className="flex items-center justify-between border-b border-border pb-3.5">
              <div className="space-y-0.5">
                <span className="text-[9px] font-mono font-bold uppercase tracking-widest text-orange">⏰ FOCUS TIMEFRAMES</span>
                <h4 className="font-bold text-base leading-tight text-ink">Active Plan ({timeUsed} / {time} Mins)</h4>
              </div>
              <span className="text-[9px] font-black text-orange bg-orange-lt px-2 py-0.5 rounded border border-orange/10">
                Priority Balanced
              </span>
            </div>

            <div className="space-y-3">
              {todaysTasks.map((t) => {
                const isOverdue = t.priorityLabel === 'Urgent (Overdue)';

                return (
                  <div 
                    key={t.id} 
                    onDoubleClick={() => handleTaskRedirect(t)}
                    title="Double click card to directly open inside specific Desk Tab!"
                    className={cn(
                      "p-4 rounded-xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4 select-none cursor-pointer",
                      isOverdue 
                        ? "bg-rose-50/10 border-rose-200 hover:border-rose-400 border-l-[4px]" 
                        : t.type === 'revision' 
                          ? "bg-orange-lt/10 border-orange/20 hover:border-orange/40 border-l-[4px]" 
                          : t.type === 'mistake'
                            ? "bg-red-50/10 border-red-200 hover:border-red-300 border-l-[4px]"
                            : "bg-surface border-border hover:border-slate-300 border-l-[4px] border-l-slate-400"
                    )}
                  >
                    <div className="flex items-start gap-3.5">
                      <div className={cn(
                        "w-8.5 h-8.5 rounded-lg flex items-center justify-center text-xs shrink-0 border shadow-3xs font-mono",
                        isOverdue 
                          ? "bg-rose-100 border-rose-200 text-rose-600 animate-pulse" 
                          : t.type === 'revision' 
                            ? "bg-orange-lt border-orange/10 text-orange" 
                            : t.type === 'mistake' 
                              ? "bg-red-50 border-red-250 text-red-650"
                              : "bg-indigo-50 border-indigo-100 text-indigo-600"
                      )}>
                        {t.type === 'revision' ? "⏰" : t.type === 'mistake' ? "🧯" : t.type === 'future' ? "🚀" : "🏫"}
                      </div>
                      <div className="space-y-1">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="text-[8.5px] font-mono font-bold uppercase text-ink3">{t.subject}</span>
                          <span className={cn(
                            "text-[8px] px-1.5 py-0.2 rounded-sm font-black uppercase tracking-wider",
                            isOverdue
                              ? "bg-red-500 text-white"
                              : t.type === 'revision'
                                ? "bg-orange text-white"
                                : "bg-slate-100 text-slate-700"
                          )}>
                            {t.priorityLabel}
                          </span>
                        </div>
                        <h5 className="font-bold text-xs text-ink leading-tight">{t.chapter}</h5>
                        <p className="text-[11px] text-ink2 leading-relaxed font-medium">{t.topic}</p>
                        
                        {/* Interactive Lecture Quick Entry Link */}
                        {t.type === 'progress' && t.actionLabel.toLowerCase().includes('video') && (
                          <div className="pt-2">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleTaskRedirect(t);
                              }}
                              className="inline-flex items-center gap-1 text-[9px] font-bold text-red-655 bg-red-50 p-1.5 px-2 rounded-lg border border-red-100 hover:bg-red-100 transition-colors"
                            >
                              <Eye className="w-3 h-3 text-red-600" /> Watch Video Lesson in Study Desk
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
 
                    <div className="flex sm:flex-col items-end justify-between sm:justify-center gap-2 shrink-0 border-t sm:border-t-0 border-border/50 pt-2 sm:pt-0">
                      <div className="text-left sm:text-right">
                        <span className="text-[10px] font-mono font-bold text-ink2">{t.durationMins} Mins</span>
                        <span className="text-[8px] opacity-60 font-semibold uppercase tracking-wider block">Double-click 👉</span>
                      </div>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          if (t.type === 'revision') {
                            const mastery = getChapterMasteryState(t.subjectKey, t.chapter);
                            handleFulfillRevisionInline(t.subjectKey, t.chapter, mastery.revisions_count);
                          } else {
                            handleTaskRedirect(t);
                          }
                        }}
                        className={cn(
                          "px-3 py-1 rounded-lg text-[9px] font-black uppercase tracking-wider shadow-3xs hover:scale-105 active:scale-95 transition-all cursor-pointer",
                          t.type === 'revision' ? "bg-orange text-white" : "bg-slate-800 text-white hover:bg-slate-700"
                        )}
                      >
                        {t.type === 'revision' ? 'Check off Rev' : 'Launch Task'}
                      </button>
                    </div>
                  </div>
                );
              })}

              {todaysTasks.length === 0 && (
                <div className="text-center py-10 rounded-xl border border-dashed border-border flex flex-col items-center justify-center space-y-2">
                  <Check className="w-5 h-5 text-emerald-500 bg-emerald-50 p-1 rounded-full border border-emerald-100" />
                  <div>
                    <h5 className="font-bold text-xs text-slate-800">Clear Agenda</h5>
                    <p className="text-[10px] text-ink3">Add active school chapters in "Manage Syllabus Chapters" configs to fill your work plan!</p>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* STANDBY / SPILL QUEUE */}
          {standbyList.length > 0 && (
            <div className="bg-bg/40 border border-border border-dashed rounded-2xl p-6 space-y-3.5">
              <div className="flex items-center justify-between border-b border-border pb-2.5">
                <div className="space-y-0.5">
                  <span className="text-[9px] font-mono font-bold uppercase tracking-wider text-ink3">🛡️ Burnout Buffer</span>
                  <h4 className="font-bold text-xs text-ink">Standby Tasks (Spillover List)</h4>
                </div>
                <AlertCircle className="w-4 h-4 text-ink3" />
              </div>

              <div className="space-y-2">
                {standbyList.slice(0, 3).map((item, index) => (
                  <div key={index} className="flex justify-between items-center text-[11px] p-2 bg-surface border border-border rounded-xl">
                    <div className="flex items-center gap-2">
                      <span className="text-xs">💤</span>
                      <div>
                        <span className="text-[8px] font-black text-ink3 uppercase block">{item.subject}</span>
                        <span className="font-semibold text-ink truncate max-w-[200px] inline-block">{item.chapter}</span>
                        <p className="text-[9.5px] text-ink3 leading-tight truncate max-w-[250px]">{item.topic}</p>
                      </div>
                    </div>
                    <span className="text-[9px] font-mono text-ink3 shrink-0">+{item.durationMins}m scheduled</span>
                  </div>
                ))}
                {standbyList.length > 3 && (
                  <p className="text-[10px] font-bold text-ink3 text-center">+ {standbyList.length - 3} more standby topics scheduled next</p>
                )}
              </div>
            </div>
          )}

        </div>

        {/* Right column: Expected completed range timeline and Spaced repetition overview */}
        <div className="space-y-6">
          
          {/* Active Ranges Timeline */}
          <div className="bg-surface border border-border rounded-2xl p-5 shadow-3xs space-y-4">
            <h4 className="font-bold text-xs text-ink flex items-center gap-1.5 border-b border-border pb-2.5">
              <Calendar className="w-4 h-4 text-orange" /> Predicted Timeline
            </h4>
            <div className="space-y-2.5">
              {activeTimelineList.map((item, index) => {
                const mastery = calculateChapterMastery(item.subKey, item.chapter);
                return (
                  <div key={index} className="flex justify-between items-center text-xs border-b border-border/40 pb-2.5 last:border-b-0 last:pb-0">
                    <div>
                      <span className="text-[8.5px] text-ink3 uppercase font-black">{item.subLabel}</span>
                      <h5 className="font-bold text-xs leading-snug text-ink truncate max-w-[130px]">{item.chapter}</h5>
                      <span className="text-[9px] text-orange font-bold uppercase">{mastery.status}</span>
                    </div>
                    <div className="text-right shrink-0">
                      <span className="font-bold text-ink hover:text-orange">{item.timeline}</span>
                      <div className="text-[9px] font-mono font-bold text-indigo-600 mt-0.5">M. rating: {mastery.masteryScore}%</div>
                    </div>
                  </div>
                );
              })}

              {activeTimelineList.length === 0 && (
                <div className="text-center py-4 text-xs text-ink3 italic">
                  No active school chapters assigned. Timeline is empty.
                </div>
              )}
            </div>
          </div>

          {/* SPACED REPETITION INDEX */}
          <div className="bg-surface border border-border rounded-2xl p-5 shadow-3xs space-y-4">
            <h4 className="font-bold text-xs text-ink flex items-center gap-1.5 border-b border-border pb-2.5">
              <Brain className="w-4 h-4 text-indigo-600" /> Space Repetition pipeline
            </h4>
            <p className="text-[10px] text-ink2 leading-relaxed">
              Completions trigger automated micro-revisions on **Day 3**, **Day 7**, **Day 15**, and **Day 30** to secure memory retention.
            </p>
            
            <div className="space-y-3 pt-1">
              {Object.entries(completedChapters).map(([chapterName, completionDay]) => {
                let sKey = 'maths';
                subjectsToUse.forEach(([k, s]) => {
                  if (s.chapters.some(c => c.name === chapterName)) sKey = k;
                });
                const masteryObj = calculateChapterMastery(sKey, chapterName);
                const count = masteryObj.state.revisions_count;

                return (
                  <div key={chapterName} className="p-3 bg-bg/40 border border-border/80 rounded-xl space-y-2">
                    <div className="flex justify-between items-start text-xs">
                      <div>
                        <h6 className="font-bold text-xs text-ink leading-tight">{chapterName}</h6>
                        <span className="text-[9px] text-indigo-600 font-bold block mt-0.5">Revisions: {count}/4 done</span>
                      </div>
                      <span className="text-[9px] font-semibold text-ink3 font-mono">D.{completionDay}</span>
                    </div>
                    
                    {/* Visual 4-dot Pipeline */}
                    <div className="grid grid-cols-4 gap-1">
                      {[3, 7, 15, 30].map((rule, idx) => {
                        const target = completionDay + rule;
                        const isDone = count > idx;
                        const isOverdue = currentDay >= target && !isDone;

                        return (
                          <div 
                            key={idx} 
                            className={cn(
                              "py-1 rounded text-center text-[8px] font-black font-mono border transition-all",
                              isDone 
                                ? "bg-emerald-500 border-emerald-500 text-white shadow-3xs" 
                                : isOverdue 
                                  ? "bg-rose-100 border-rose-300 text-rose-600 animate-pulse" 
                                  : "bg-surface border-border text-ink3"
                            )}
                            title={isDone ? 'Reviewed' : `Scheduled Day ${target}`}
                          >
                            D+{rule}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })}

              {Object.keys(completedChapters).length === 0 && (
                <div className="text-center py-4 text-xs text-ink3 italic">
                  Completions will trigger revision calendars here.
                </div>
              )}
            </div>
          </div>

        </div>
      </div>

      {/* TRACK CHAPTER MASTERY & PROGRESS CHECKLIST WORKSPACE */}
      <div className="bg-surface border border-border rounded-2xl p-6 sm:p-8 shadow-3xs space-y-6">
        <div className="border-b border-border pb-4">
          <h4 className="text-lg font-bold flex items-center gap-2 text-ink">
            <ListChecks className="w-5 h-5 text-orange" /> Chapter Completion Checkpoints
          </h4>
          <p className="text-xs text-ink2 mt-1 leading-relaxed">
            Verify mastery checkpoints in real-time. Notes and tricks are optional, while scores and checklists optimize your board exam competency index.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {activeTimelineList.map((item, index) => {
            const mastery = calculateChapterMastery(item.subKey, item.chapter);
            const notesDone = isNotesChecked(item.subKey, item.chapter);

            return (
              <div key={index} className="bg-bg/20 border border-border p-5 rounded-2xl space-y-4 flex flex-col justify-between hover:border-slate-300 transition-colors">
                <div className="space-y-4">
                  <div className="flex justify-between items-start gap-4">
                    <div>
                      <span className="text-[8.5px] font-mono font-bold text-ink3 uppercase">{item.subLabel}</span>
                      <h4 className="font-extrabold text-sm leading-tight text-ink mt-0.5">{item.chapter}</h4>
                      <div className="inline-flex items-center gap-1.5 mt-1.5">
                        <span className={cn(
                          "text-[8px] font-black uppercase px-2 py-0.5 rounded",
                          mastery.status === 'Mastered' ? "bg-emerald-500 text-white" : mastery.status === 'Practicing' ? "bg-indigo-600 text-white" : "bg-amber-500 text-white"
                        )}>{mastery.status}</span>
                        <span className="text-[10px] font-bold text-ink2">({mastery.metCount}/7 met)</span>
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <div className="text-xl font-black text-orange leading-none">{mastery.masteryScore}%</div>
                      <span className="text-[8px] text-ink3 font-bold uppercase tracking-wider block mt-1">Weighted score</span>
                    </div>
                  </div>

                  <div className="space-y-1.5 pt-1">
                    <div className="flex items-center justify-between text-[10px] font-bold text-ink3">
                      <span>Requirement Checklist</span>
                      <span>Progress: {mastery.progressPct}%</span>
                    </div>
                    <div className="h-1.5 w-full bg-surface border border-border/80 rounded-full overflow-hidden">
                      <div className="h-full bg-orange transition-all duration-300" style={{ width: `${mastery.progressPct}%` }} />
                    </div>
                  </div>

                  <div className="space-y-1.5 text-xs pt-1.5">
                    
                    {/* Item 1: Lecture completed */}
                    <button
                      onClick={() => handleToggleCheckState(item.subKey, item.chapter, 'lecture_completed')}
                      className="w-full text-left font-bold flex items-center gap-2 p-2 hover:bg-surface rounded-xl transition-all border border-transparent hover:border-border cursor-pointer"
                    >
                      {mastery.state.lecture_completed ? (
                        <CheckSquare className="w-4.5 h-4.5 text-orange shrink-0" />
                      ) : (
                        <Square className="w-4.5 h-4.5 text-ink3 shrink-0" />
                      )}
                      <span className={cn(mastery.state.lecture_completed && "line-through text-ink3 font-medium")}>
                        Step 1: Board Lecture Video watched
                      </span>
                    </button>

                    {/* Item 2: Chapter Notes studied */}
                    <button
                      onClick={() => handleToggleCheckState(item.subKey, item.chapter, 'notes_completed')}
                      className="w-full text-left font-bold flex items-center gap-2 p-2 hover:bg-surface rounded-xl transition-all border border-transparent hover:border-border cursor-pointer"
                    >
                      {(mastery.state.notes_completed ?? false) ? (
                        <CheckSquare className="w-4.5 h-4.5 text-orange shrink-0" />
                      ) : (
                        <Square className="w-4.5 h-4.5 text-ink3 shrink-0" />
                      )}
                      <span className={cn((mastery.state.notes_completed ?? false) && "line-through text-ink3 font-medium")}>
                        Step 2: Chapter Smart Study notes read
                      </span>
                    </button>

                    {/* Item 3: Tricks memorized */}
                    <button
                      onClick={() => handleToggleCheckState(item.subKey, item.chapter, 'tricks_completed')}
                      className="w-full text-left font-bold flex items-center gap-2 p-2 hover:bg-surface rounded-xl transition-all border border-transparent hover:border-border cursor-pointer"
                    >
                      {mastery.state.tricks_completed ? (
                        <CheckSquare className="w-4.5 h-4.5 text-orange shrink-0" />
                      ) : (
                        <Square className="w-4.5 h-4.5 text-ink3 shrink-0" />
                      )}
                      <span className={cn(mastery.state.tricks_completed && "line-through text-ink3 font-medium")}>
                        Step 3: Revision map formulas & tricks memorized
                      </span>
                    </button>

                    {/* Item 4: Question Bank accuracy >= 80% */}
                    <div className="p-2 bg-surface/50 rounded-xl border border-border/60 transition-all space-y-2.5">
                      <div className="flex items-center justify-between font-bold">
                        <div className="flex items-center gap-2">
                          {mastery.state.qbank_accuracy >= 80 ? (
                            <CheckSquare className="w-4.5 h-4.5 text-orange shrink-0" />
                          ) : (
                            <Square className="w-4.5 h-4.5 text-ink3 shrink-0" />
                          )}
                          <span className={cn(mastery.state.qbank_accuracy >= 80 && "line-through text-ink3 font-medium")}>
                            Step 4: Q-Bank Accuracy: {mastery.state.qbank_accuracy}%
                          </span>
                        </div>
                        <span className="text-[9px] font-mono font-bold text-indigo-700 bg-indigo-50 px-1.5 rounded">{"Target >= 80%"}</span>
                      </div>
                      
                      {/* Segmented Control for accuracy selections */}
                      <div className="bg-bg/85 border border-border p-1 rounded-xl flex items-center gap-1">
                        {[0, 50, 80, 95].map((scoreVal) => (
                          <button
                            key={scoreVal}
                            onClick={(e) => {
                              e.stopPropagation();
                              handleUpdateAccuracy(item.subKey, item.chapter, scoreVal);
                            }}
                            className={cn(
                              "flex-1 py-1 text-center font-mono font-bold text-[10px] rounded-lg transition-all cursor-pointer",
                              mastery.state.qbank_accuracy === scoreVal 
                                ? "bg-orange hover:bg-orange-dark text-white shadow-3xs" 
                                : "bg-surface hover:bg-bg text-ink2 border border-border/30"
                            )}
                          >
                            {scoreVal}%
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Item 5: Quiz accuracy >= 80% */}
                    <div className="p-2 hover:bg-surface border border-transparent hover:border-border rounded-xl transition-all flex items-center justify-between gap-4">
                      <div className="flex items-center gap-2 font-bold">
                        {mastery.quiz_accuracy >= 80 ? (
                          <CheckSquare className="w-4.5 h-4.5 text-orange shrink-0" />
                        ) : (
                          <Square className="w-4.5 h-4.5 text-ink3 shrink-0" />
                        )}
                        <span className={cn(mastery.quiz_accuracy >= 80 && "line-through text-ink3 font-medium")}>
                          Step 5: Assessment: {mastery.quiz_accuracy}% accuracy
                        </span>
                      </div>
                      <div className="text-right shrink-0">
                        {mastery.quiz_accuracy < 80 ? (
                          <button
                            onClick={() => {
                              const chIdx = SUBJECTS[item.subKey]?.chapters.findIndex(c => c.name === item.chapter) ?? -1;
                              navigateTo('quiz', item.subKey, chIdx === -1 ? null : chIdx);
                            }}
                            className="bg-orange text-white text-[9px] font-black uppercase px-2.5 py-1.5 rounded-lg hover:scale-105 active:scale-95 transition-all shadow-3xs cursor-pointer"
                          >
                            Take Quiz
                          </button>
                        ) : (
                          <span className="text-[9px] font-black uppercase text-emerald-650 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100">Passed ✓</span>
                        )}
                      </div>
                    </div>

                    {/* Item 6: Mistake Reviews complete */}
                    <div className="p-2 hover:bg-surface border border-transparent hover:border-border rounded-xl transition-all flex items-center justify-between gap-4">
                      <div className="flex items-center gap-2 font-bold">
                        {mastery.unfixedCount === 0 ? (
                          <CheckSquare className="w-4.5 h-4.5 text-orange shrink-0" />
                        ) : (
                          <Square className="w-4.5 h-4.5 text-ink3 shrink-0" />
                        )}
                        <span className={cn(mastery.unfixedCount === 0 && "line-through text-ink3 font-medium")}>
                          Step 6: Mistakes resolved in Mistake Book
                        </span>
                      </div>
                      <div className="text-right shrink-0 font-sans">
                        {mastery.unfixedCount > 0 ? (
                          <button
                            onClick={() => navigateTo('mistake-book')}
                            className="bg-indigo-50 border border-indigo-200 text-indigo-700 text-[95px] font-bold uppercase px-2.5 py-1 rounded-lg hover:bg-indigo-100 cursor-pointer"
                          >
                            Solve {mastery.unfixedCount} errors
                          </button>
                        ) : (
                          <span className="text-[9px] font-black uppercase text-emerald-655 bg-emerald-50 px-2.5 py-0.5 rounded border border-emerald-100">Clean ✓</span>
                        )}
                      </div>
                    </div>

                    {/* Item 7: Revision Completed */}
                    <div className="p-2 hover:bg-surface border border-transparent hover:border-border rounded-xl transition-all flex items-center justify-between gap-4">
                      <div className="flex items-center gap-2 font-bold">
                        {mastery.state.revisions_count >= 1 ? (
                          <CheckSquare className="w-4.5 h-4.5 text-orange shrink-0" />
                        ) : (
                          <Square className="w-4.5 h-4.5 text-ink3 shrink-0" />
                        )}
                        <span className={cn(mastery.state.revisions_count >= 1 && "line-through text-ink3 font-medium")}>
                          Step 7: Revisions count: {mastery.state.revisions_count}/4 Reviewed
                        </span>
                      </div>
                      <div className="text-right shrink-0">
                        {mastery.state.revisions_count < 4 && calculateChapterMastery(item.subKey, item.chapter).isCompleted && (
                          <button
                            onClick={() => handleFulfillRevisionInline(item.subKey, item.chapter, mastery.state.revisions_count)}
                            className="bg-slate-800 text-white text-[9px] font-black uppercase px-2 py-1 rounded-lg hover:bg-slate-700 cursor-pointer"
                          >
                            Mark Rev {mastery.state.revisions_count + 1} Done
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Notes OPTIONAL checkbox */}
                    <button
                      onClick={() => handleUpdateNotesOptional(item.subKey, item.chapter, notesDone)}
                      className="w-full text-left font-bold flex items-center gap-2 p-2 hover:bg-surface rounded-xl transition-all border border-dashed border-border bg-surface2/40 mt-1"
                    >
                      {notesDone ? (
                        <CheckSquare className="w-4.5 h-4.5 text-amber-500 shrink-0" />
                      ) : (
                        <Square className="w-4.5 h-4.5 text-ink3 shrink-0" />
                      )}
                      <div className="flex-1 text-[11px]">
                        <span className={cn(notesDone && "text-ink3 font-medium", "block text-[11px] leading-snug")}>
                          Revision Notebook written up
                        </span>
                        <span className="text-[8px] uppercase tracking-wider text-amber-600 font-extrabold block">★ Recommended but Optional (does not block progress)</span>
                      </div>
                    </button>

                  </div>
                </div>

                {/* Completion Flag and Skipping/Restart Controls */}
                <div className="pt-3 border-t border-dashed border-border/80 flex justify-between items-center bg-transparent mt-3">
                  <span className="text-[9px] font-mono font-bold uppercase text-ink3">Chapter Finalization:</span>
                  {completedChapters[item.chapter] ? (
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <div className="flex items-center gap-1 bg-green-50 px-2.5 py-1 rounded-full border border-green-200 text-slate-800">
                        <Star className="w-3 h-3 text-green-600 fill-green-600 animate-spin-slow" />
                        <span className="text-[9px] font-bold text-green-700 uppercase tracking-wider">Completed (Day {completedChapters[item.chapter]})</span>
                      </div>
                      <button
                        onClick={() => handleRestartToMistake(item.subKey, item.chapter)}
                        className="flex items-center gap-1 bg-indigo-50 border border-indigo-250 text-indigo-700 hover:bg-indigo-100 text-[9px] font-extrabold uppercase px-2.5 py-1 rounded-full cursor-pointer transition-colors"
                        title="Restart study cycle starting back at Step 6: Mistake Book review"
                      >
                        <RefreshCw className="w-2.5 h-2.5 text-indigo-600" />
                        <span>Restart</span>
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-center gap-1.5 justify-between w-full">
                      <div className="flex items-center gap-1 text-[9px] font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200 animate-pulse">
                        <AlertTriangle className="w-3 h-3 text-amber-600" />
                        Checkpoints Pending
                      </div>
                      <button
                        onClick={() => handleRestartToMistake(item.subKey, item.chapter)}
                        className="flex items-center gap-1 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 text-indigo-600 text-[9px] font-extrabold uppercase px-2.5 py-1 rounded-lg cursor-pointer transition-all"
                        title="Force promote and set up learning flow directly from Step 6: Mistake Review"
                      >
                        <RefreshCw className="w-2.5 h-2.5" />
                        <span>Skip to Mistake</span>
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}

          {activeTimelineList.length === 0 && (
            <div className="md:col-span-2 text-center py-8 bg-bg/20 rounded-2xl border border-dashed border-border text-ink3 italic">
              Please activate chapter modules under "Manage Syllabus Chapters" configurations above to evaluate and check off live progress requirements.
            </div>
          )}
        </div>
      </div>

      {/* Setup Reset */}
      <div className="flex justify-center pt-8 border-t border-border border-dashed">
        <button
          onClick={handleReset}
          className="px-4 py-2 bg-surface hover:bg-rose-50 hover:text-rose-600 rounded-xl text-[10px] text-ink3 font-black uppercase tracking-widest border border-border border-dashed transition-all cursor-pointer"
        >
          Reset All Planner Configs & Mastery State
        </button>
      </div>
    </div>
  );
}
