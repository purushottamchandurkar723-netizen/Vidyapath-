import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageSquare, X, Send, Bot, Sparkles, AlertCircle, RefreshCw } from 'lucide-react';
import { adjustStudyPlan } from '../services/geminiService';
import { cn } from '../lib/utils';

interface Message {
  role: 'user' | 'ai';
  text: string;
}

interface PlannerChatProps {
  currentPlan: any;
  onPlanUpdate: (newPlan: any) => void;
  subjectsList: string[];
}

export default function PlannerChat({ currentPlan, onPlanUpdate, subjectsList }: PlannerChatProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { role: 'ai', text: 'Hi! I can help you reschedule or adjust your study plan. Just tell me what you need—like "I\'m busy today, move maths to tomorrow" or "Reschedule my uncompleted tasks."' }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    const userMsg = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setLoading(true);

    try {
      const updatedPlan = await adjustStudyPlan(currentPlan, userMsg, subjectsList);
      onPlanUpdate(updatedPlan);
      setMessages(prev => [...prev, { 
        role: 'ai', 
        text: 'I\'ve updated your plan based on your request! You can see the changes in your dashboard now.' 
      }]);
    } catch (error) {
      console.error('Adjustment failed:', error);
      setMessages(prev => [...prev, { 
        role: 'ai', 
        text: 'Sorry, I couldn\'t update your plan right now. Please try rephrasing your request.' 
      }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      {/* Trigger Button */}
      <motion.button
        onClick={() => setIsOpen(true)}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        className="fixed bottom-24 right-6 w-14 h-14 bg-ink text-white rounded-full shadow-2xl flex items-center justify-center z-40 border border-white/10"
      >
        <Sparkles className="w-6 h-6 text-orange animate-pulse" />
      </motion.button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.9 }}
            className="fixed bottom-24 right-6 w-[350px] max-w-[90vw] h-[500px] bg-surface border border-border rounded-[32px] shadow-2xl z-50 flex flex-col overflow-hidden"
          >
            {/* Header */}
            <div className="p-4 bg-ink text-white flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-orange/20 flex items-center justify-center">
                  <Bot className="w-5 h-5 text-orange" />
                </div>
                <div>
                  <h4 className="text-sm font-black uppercase tracking-widest">Plan Assistant</h4>
                  <p className="text-[10px] text-white/50">AI Powered Rescheduling</p>
                </div>
              </div>
              <button onClick={() => setIsOpen(false)} className="p-2 hover:bg-white/10 rounded-full transition-colors">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Messages */}
            <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4 bg-surface2/30">
              {messages.map((m, i) => (
                <div key={i} className={cn(
                  "flex",
                  m.role === 'user' ? "justify-end" : "justify-start"
                )}>
                  <div className={cn(
                    "max-w-[85%] p-3 rounded-2xl text-xs leading-relaxed",
                    m.role === 'user' 
                      ? "bg-orange text-white rounded-tr-none shadow-md" 
                      : "bg-white border border-border text-ink2 rounded-tl-none shadow-sm"
                  )}>
                    {m.text}
                  </div>
                </div>
              ))}
              {loading && (
                <div className="flex justify-start">
                  <div className="bg-white border border-border text-ink2 p-3 rounded-2xl rounded-tl-none shadow-sm flex items-center gap-2">
                    <RefreshCw className="w-3 h-3 animate-spin text-orange" />
                    <span className="text-[10px] font-bold uppercase tracking-widest">Adjusting Plan...</span>
                  </div>
                </div>
              )}
            </div>

            {/* Input */}
            <div className="p-4 bg-white border-t border-border">
              <div className="relative">
                <input 
                  type="text" 
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                  placeholder="Ask for changes..."
                  className="w-full bg-surface2 border border-border rounded-full py-3 px-5 pr-12 text-xs font-medium focus:outline-none focus:border-orange transition-all"
                />
                <button 
                  onClick={handleSend}
                  disabled={!input.trim() || loading}
                  className="absolute right-2 top-1.5 w-8 h-8 bg-orange text-white rounded-full flex items-center justify-center hover:bg-orange-mid transition-all disabled:opacity-50"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
              <p className="text-[8px] text-center text-ink3 mt-2 font-bold uppercase tracking-widest">
                I can modify your roadmap in real-time
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
