/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Screen } from '../App';
import { SUBJECTS } from '../constants';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowLeft, BookOpen, Zap, HelpCircle, GraduationCap, Video, Play, ChevronRight, CheckCircle, Brain, Eye, EyeOff, RefreshCw, ListFilter, Target, Presentation, Upload, Image as ImageIcon, Camera, Info, Save, Award, Plus, Trash2, Calendar, ArrowUpRight, Sparkles, Check, X, Calculator, FileSpreadsheet, Compass, Paintbrush, Palette } from 'lucide-react';
import Markdown from 'react-markdown';
import { cn, loadItem, saveItem } from '../lib/utils';
import { getAIResponse, fetchTopicsForChapter, fetchDiagramQuestions, evaluateDiagramImage, fetchInteractiveDiagrams, fetchQBankHint, evaluateQBankAnswer, evaluateQBankAnswerWithImage, fetchQBankSimilarQuestion, fetchFormulasForChapter, fetchStudyGuideForChapter } from '../services/geminiService';
import { getChapterPYQs, addRealPYQ, deleteRealPYQ, RealPYQ } from '../services/pyqService';
import { getYouTubeRecommendation, getPreferredTeacher, setPreferredTeacher, POPULAR_TEACHERS, getChapterVideos, getSavedVideoNotes, saveSavedVideoNotes, YouTubeVideoItem } from '../lib/videoUtils';
import { compressImage } from '../utils/imageCompressor';
import { recordEvent } from '../services/analytics';

interface ChapterHubProps {
  subjectKey: string;
  chapterIndex?: number | null;
  initialTab?: string | null;
  initialTopic?: string | null;
  navigateTo: (s: Screen, subKey?: string | null, chIdx?: number | null, topic?: string | null, tab?: string | null) => void;
  showToast: (msg: string) => void;
}

type Tab = 'ainotes' | 'tricks' | 'questions' | 'video' | 'diagrams' | 'pyqs' | 'formulas' | 'studyguide';
type DiagramMode = 'interactive' | 'practice';
type DetailLevel = 'concise' | 'balanced' | 'detailed';
type Difficulty = 'basic' | 'standard' | 'advanced';
type BookStyle = 'ncert' | 'exemplar' | 'rd' | 'cbse';

function DiagramVectorRenderer({ baseIcon, title }: { baseIcon: string; title: string }) {
  const normIcon = baseIcon ? baseIcon.toLowerCase().trim() : '';
  const normTitle = title ? title.toLowerCase().trim() : '';

  // Determine if we should render physical, biological, or chemical SVG schematic
  if (normIcon === 'eye' || normTitle.includes('eye') || normTitle.includes('lens') || normTitle.includes('retina') || normTitle.includes('defect')) {
    return (
      <svg viewBox="0 0 400 250" className="w-full h-full text-indigo-600 fill-none" stroke="currentColor" strokeWidth="2.5">
        {/* Eyeball Outer Sclera */}
        <path d="M 120 125 C 120 50, 280 50, 280 125 C 280 200, 120 200, 120 125 Z" stroke="currentColor" strokeWidth="2.5" className="fill-indigo-500/5" />
        {/* Cornea bulge */}
        <path d="M 120 95 C 100 95, 100 155, 120 155 Z" stroke="currentColor" strokeWidth="2.5" className="fill-sky-400/10" />
        {/* Lens */}
        <path d="M 150 100 C 138 100, 138 150, 150 150 C 162 150, 162 100, 150 100 Z" stroke="currentColor" strokeWidth="2.5" className="fill-indigo-500/20" />
        {/* Iris and pupil */}
        <line x1="135" y1="95" x2="135" y2="112" stroke="currentColor" strokeWidth="4" />
        <line x1="135" y1="138" x2="135" y2="155" stroke="currentColor" strokeWidth="4" />
        {/* Retina back line */}
        <path d="M 230 65 C 275 90, 275 160, 230 185" stroke="#f97316" strokeWidth="3" />
        {/* Optic Nerve */}
        <path d="M 270 115 L 320 105 M 270 135 L 320 145" stroke="currentColor" strokeWidth="2.5" />
        <path d="M 320 105 L 320 145" stroke="currentColor" strokeWidth="2.5" />
        {/* Light Rays focusing */}
        <path d="M 40 105 L 145 105 L 150 125 L 253 125" stroke="#eab308" strokeWidth="1.5" strokeDasharray="4 3" />
        <path d="M 40 145 L 145 145 L 150 125 L 253 125" stroke="#eab308" strokeWidth="1.5" strokeDasharray="4 3" />
        <circle cx="253" cy="125" r="4" fill="#ef4444" stroke="none" />
      </svg>
    );
  }

  if (normIcon === 'heart' || normTitle.includes('heart') || normTitle.includes('blood') || normTitle.includes('circulation')) {
    return (
      <svg viewBox="0 0 400 250" className="w-full h-full text-red-500 fill-none" stroke="currentColor" strokeWidth="2.5">
        {/* Right Ventricle / Left Ventricle backgrounds */}
        <path d="M 200 60 C 150 10, 100 60, 120 130 C 140 200, 200 230, 200 230 C 200 230, 260 200, 280 130 C 300 60, 250 10, 200 60 Z" stroke="currentColor" className="fill-red-500/10" strokeWidth="3" />
        {/* Septum dividing wall */}
        <path d="M 200 90 L 195 220" stroke="#ef4444" strokeWidth="6" />
        {/* Atriums (Left & Right) */}
        <ellipse cx="160" cy="100" rx="25" ry="20" stroke="#3b82f6" className="fill-blue-100/50" />
        <ellipse cx="240" cy="100" rx="25" ry="20" stroke="#ef4444" className="fill-red-100/50" />
        {/* Vena Cava and Aorta loops */}
        <path d="M 230 70 C 230 40, 260 30, 260 10" stroke="#ef4444" strokeWidth="4" />
        <path d="M 170 70 C 170 40, 140 30, 140 10" stroke="#3b82f6" strokeWidth="4" />
        {/* Blood Flow Arrows */}
        <path d="M 140 20 L 140 40 L 155 45" stroke="#3b82f6" strokeWidth="2" />
        <path d="M 260 20 L 260 40 L 245 45" stroke="#ef4444" strokeWidth="2" />
      </svg>
    );
  }

  if (normIcon === 'brain' || normTitle.includes('brain') || normTitle.includes('nervous') || normTitle.includes('reflex')) {
    return (
      <svg viewBox="0 0 400 250" className="w-full h-full text-pink-500 fill-none" stroke="currentColor" strokeWidth="2.5">
        {/* Cerebrum lobes outline */}
        <path d="M 120 150 C 100 130, 90 90, 130 60 C 170 30, 250 30, 280 70 C 310 100, 300 140, 280 160 C 260 180, 230 180, 220 170 C 200 180, 150 180, 120 150 Z" stroke="currentColor" className="fill-pink-500/10" strokeWidth="3" />
        {/* Internal folded paths of brain lobes */}
        <path d="M 150 70 C 160 90, 180 80, 190 100 C 200 120, 220 110, 240 130" stroke="#f472b6" strokeWidth="2" />
        <path d="M 180 50 C 200 70, 210 60, 230 80 C 250 100, 270 90, 280 110" stroke="#f472b6" strokeWidth="2" />
        <path d="M 130 110 C 150 130, 170 120, 190 140" stroke="#f472b6" strokeWidth="2" />
        {/* Cerebellum */}
        <path d="M 220 170 C 240 170, 270 170, 275 195 C 265 215, 230 215, 220 185 Z" stroke="#6366f1" className="fill-indigo-500/20" strokeWidth="2" />
        {/* Brain stem */}
        <path d="M 195 180 L 195 230 L 210 230 L 210 180" stroke="#64748b" className="fill-slate-100" strokeWidth="2" />
      </svg>
    );
  }

  if (normIcon === 'leaf' || normTitle.includes('leaf') || normTitle.includes('photosynthesis') || normTitle.includes('plant') || normTitle.includes('stoma') || normTitle.includes('chloroplast')) {
    return (
      <svg viewBox="0 0 400 250" className="w-full h-full text-emerald-500 fill-none" stroke="currentColor" strokeWidth="2.5">
        {/* Cutaway leaf sheet */}
        <path d="M 60 40 L 340 40 C 360 120, 360 160, 340 210 L 60 210 C 40 160, 40 120, 60 40 Z" stroke="currentColor" className="fill-emerald-500/10" strokeWidth="2.5" />
        {/* Epidermis upper layer */}
        <rect x="80" y="60" width="240" height="25" rx="4" stroke="#059669" className="fill-emerald-50/50" />
        {/* Palisade cells (vertical pillars) */}
        <g stroke="#10b981" className="fill-emerald-100/40">
          <rect x="90" y="95" width="20" height="50" rx="3" />
          <rect x="120" y="95" width="20" height="50" rx="3" />
          <rect x="150" y="95" width="20" height="50" rx="3" />
          <rect x="180" y="95" width="20" height="50" rx="3" />
          <rect x="210" y="95" width="20" height="50" rx="3" />
          <rect x="240" y="95" width="20" height="50" rx="3" />
          <rect x="270" y="95" width="20" height="50" rx="3" />
        </g>
        {/* Tiny chloroplast dots inside palisade cells */}
        <g fill="#047857">
          <circle cx="100" cy="110" r="2" /><circle cx="100" cy="130" r="2" />
          <circle cx="130" cy="110" r="2" /><circle cx="130" cy="130" r="2" />
          <circle cx="160" cy="110" r="2" /><circle cx="160" cy="130" r="2" />
          <circle cx="190" cy="110" r="2" /><circle cx="190" cy="130" r="2" />
          <circle cx="220" cy="110" r="2" /><circle cx="220" cy="130" r="2" />
          <circle cx="250" cy="110" r="2" /><circle cx="250" cy="130" r="2" />
          <circle cx="280" cy="110" r="2" /><circle cx="280" cy="130" r="2" />
        </g>
        {/* Lower Epidermis & guard cells / stoma */}
        <rect x="80" y="165" width="240" height="25" rx="4" stroke="#059669" className="fill-emerald-50/50" />
        {/* Stomatal opening */}
        <path d="M 190 165 C 195 155, 205 155, 210 165 C 205 175, 195 175, 190 165 Z" stroke="#059668" className="fill-emerald-400" />
      </svg>
    );
  }

  if (normIcon === 'circuit' || normTitle.includes('circuit') || normTitle.includes('electric') || normTitle.includes('motor') || normTitle.includes('resistor') || normTitle.includes('ohm')) {
    return (
      <svg viewBox="0 0 400 250" className="w-full h-full fill-none" strokeWidth="2.5">
        {/* Main loop wire */}
        <path d="M 80 125 L 80 50 L 320 50 L 320 200 L 80 200 L 80 125" stroke="#64748b" />
        {/* Resistor (Jagged line) on TOP wire */}
        <path d="M 170 50 L 178 40 L 186 60 L 194 40 L 202 60 L 210 40 L 218 60 L 226 40 L 234 50" stroke="#3b82f6" strokeWidth="3" />
        <text x="180" y="30" fill="#3b82f6" className="text-[10px] font-black font-mono">R (Load)</text>
        {/* Battery on BOTTOM wire */}
        <g stroke="#ef4444" strokeWidth="3">
          <line x1="185" y1="185" x2="185" y2="215" />
          <line x1="195" y1="192" x2="195" y2="208" strokeWidth="5" />
          <line x1="205" y1="185" x2="205" y2="215" />
          <line x1="215" y1="192" x2="215" y2="208" strokeWidth="5" />
        </g>
        <text x="160" y="222" fill="#ef4444" className="text-[10px] font-black font-mono">+</text>
        <text x="225" y="222" fill="#ef4444" className="text-[10px] font-black font-mono">-</text>
        <text x="187" y="175" fill="#ef4444" className="text-[9px] font-black font-mono">V (Cell)</text>
        {/* Ammeter "A" Circle on RIGHT wire */}
        <circle cx="320" cy="125" r="15" fill="#ffffff" stroke="#f97316" strokeWidth="2" />
        <text x="315" y="129" fill="#f97316" className="text-[10px] font-black font-mono">A</text>
        {/* Switch Key on LEFT wire */}
        <circle cx="80" cy="115" r="3" fill="#334155" />
        <line x1="80" y1="115" x2="90" y2="95" stroke="#334155" />
        <circle cx="80" cy="135" r="3" fill="#334155" />
        {/* Glowing arrows for current (I) */}
        <g stroke="#f59e0b">
          <path d="M 120 50 L 130 45 L 120 50 L 130 55" />
          <text x="115" y="38" fill="#f59e0b" className="text-[9px] font-bold">I</text>
        </g>
      </svg>
    );
  }

  if (normTitle.includes('prism') || normTitle.includes('glass') || normTitle.includes('dispersion') || normTitle.includes('ray') || normTitle.includes('optics') || normTitle.includes('mirror') || normTitle.includes('refract') || normTitle.includes('reflect')) {
    return (
      <svg viewBox="0 0 400 250" className="w-full h-full fill-none" strokeWidth="2.5">
        {/* Prism Triangle */}
        <polygon points="200,45 100,205 300,205" stroke="#38bdf8" className="fill-sky-500/10" />
        <text x="175" y="145" fill="#0284c7" className="text-[9px] font-black font-mono uppercase tracking-widest opacity-80">Glass Medium</text>
        {/* Incident White Light Ray */}
        <line x1="30" y1="145" x2="150" y2="125" stroke="#94a3b8" strokeWidth="2.5" />
        <text x="35" y="135" fill="#64748b" className="text-[9px] font-black uppercase">Incident Ray</text>
        {/* Refracted Ray inside */}
        <line x1="150" y1="125" x2="250" y2="145" stroke="#38bdf8" strokeWidth="2.5" />
        {/* Dispersed Rainbow Spectrum emergence */}
        <g strokeWidth="2">
          <line x1="250" y1="145" x2="360" y2="105" stroke="#ef4444" />
          <line x1="250" y1="145" x2="360" y2="115" stroke="#f97316" />
          <line x1="250" y1="145" x2="360" y2="125" stroke="#eab308" />
          <line x1="250" y1="145" x2="360" y2="135" stroke="#10b981" />
          <line x1="250" y1="145" x2="360" y2="145" stroke="#06b6d4" />
          <line x1="250" y1="145" x2="360" y2="155" stroke="#3b82f6" />
          <line x1="250" y1="145" x2="360" y2="165" stroke="#a855f7" />
        </g>
        <text x="325" y="85" fill="#a855f7" className="text-[8px] font-black uppercase tracking-wider">Refracted spectrum</text>
      </svg>
    );
  }

  // Fallback blueprint/schematic style
  return (
    <svg viewBox="0 0 400 250" className="w-full h-full fill-none" strokeWidth="1.5">
      {/* Blueprint Gridlines */}
      <g stroke="currentColor" className="text-slate-200/40 dark:text-slate-700/30">
        <line x1="0" y1="50" x2="400" y2="50" />
        <line x1="0" y1="100" x2="400" y2="100" />
        <line x1="0" y1="150" x2="400" y2="150" />
        <line x1="0" y1="200" x2="400" y2="200" />
        <line x1="50" y1="0" x2="50" y2="250" />
        <line x1="100" y1="0" x2="100" y2="250" />
        <line x1="150" y1="0" x2="150" y2="250" />
        <line x1="200" y1="0" x2="200" y2="250" />
        <line x1="250" y1="0" x2="250" y2="250" />
        <line x1="300" y1="0" x2="300" y2="250" />
        <line x1="350" y1="0" x2="350" y2="250" />
      </g>
      {/* Technical Concentric Target rings in middle */}
      <circle cx="200" cy="125" r="75" stroke="#3b82f6" strokeDasharray="5 5" className="opacity-30" />
      <circle cx="200" cy="125" r="45" stroke="#3b82f6" className="opacity-20" />
      <circle cx="200" cy="125" r="15" stroke="#3b82f6" className="fill-blue-55/10 opacity-45" />
      {/* Wavegraph tracking line */}
      <path d="M 30 125 C 80 75, 120 175, 170 125 C 220 75, 260 175, 310 125 L 370 125" stroke="#3b82f6" strokeWidth="2" strokeDasharray="3 3 M 310 125 L 350 125" className="opacity-50" />
      {/* Central emoji watermark overlay */}
      <g className="opacity-80">
        <text x="180" y="132" className="text-3xl fill-sky-600/30 font-sans" fontSize="36">📐</text>
      </g>
    </svg>
  );
}

interface QBankQuestionCardProps {
  id: string;
  type: string;
  q: any;
  index: number;
  subjectLabel: string;
  chapterName: string;
  subjectKey: string;
  isCompanion?: boolean;
  showToast: (msg: string) => void;
}

function QBankQuestionCard({
  id,
  type,
  q,
  index,
  subjectLabel,
  chapterName,
  subjectKey,
  isCompanion = false,
  showToast,
}: QBankQuestionCardProps) {
  const [hint, setHint] = useState<string>('');
  const [loadingHint, setLoadingHint] = useState<boolean>(false);
  
  const [userTxtAnswer, setUserTxtAnswer] = useState<string>('');
  const [evaluation, setEvaluation] = useState<any>(null);
  const [loadingEvaluation, setLoadingEvaluation] = useState<boolean>(false);
  
  const [selectedMcq, setSelectedMcq] = useState<string>('');
  const [mcqChecked, setMcqChecked] = useState<boolean>(false);
  const [mcqIsCorrect, setMcqIsCorrect] = useState<boolean>(false);
  
  const [arSelected, setArSelected] = useState<string>('');
  const [arChecked, setArChecked] = useState<boolean>(false);
  
  const [revealed, setRevealed] = useState<boolean>(false);
  
  const [similarQ, setSimilarQ] = useState<any>(null);
  const [loadingSimilar, setLoadingSimilar] = useState<boolean>(false);
  const [showSimilar, setShowSimilar] = useState<boolean>(false);
  const [isImp, setIsImp] = useState<boolean>(true);

  const [uploadedImage, setUploadedImage] = useState<string | null>(null);

  const handleImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      showToast('Please select a valid image file (PNG/JPEG/WEBP).');
      return;
    }

    try {
      showToast('Processing and compressing image...');
      const compressedBase64 = await compressImage(file, 1000, 1000, 0.75);
      setUploadedImage(compressedBase64);
      showToast('Answer sheet image compressed and uploaded successfully! Ready for AI self-check.');
    } catch (err) {
      console.error('Error compressing image, falling back to raw:', err);
      showToast('Failed to compress. Loading raw image...');
      
      const reader = new FileReader();
      reader.onloadend = () => {
        setUploadedImage(reader.result as string);
        showToast('Image uploaded (raw fallback). Ready for AI self-check.');
      };
      reader.onerror = () => {
        showToast('Failed to read image file.');
      };
      reader.readAsDataURL(file);
    }
  };

  const removeUploadedImage = () => {
    setUploadedImage(null);
    showToast('Uploaded image removed.');
  };

  const handleAddQuestionToNotebook = () => {
    try {
      const existing = loadItem<any[]>('vidypath_notebook_sources', []) || [];
      
      const questionText = q.question || q.assertion || q.source || "Dynamic Question";
      const answerText = q.answer || "";
      const isMcq = type === 'mcq';
      const mcqOpts = isMcq && q.options ? `\nOptions:\n${q.options.map((o: string, idx: number) => ` - ${['A','B','C','D'][idx]}: ${o}`).join('\n')}` : '';
      const assReas = type === 'assertion_reason' ? `\nAssertion (A): ${q.assertion}\nReason (R): ${q.reason}` : '';
      
      const content = `SUBJECT: ${subjectLabel}\nCHAPTER: ${chapterName}\nQUESTION TYPE: ${type.toUpperCase()}\n\nQUESTION:\n${questionText}${mcqOpts}${assReas}\n\nCORRECT ANSWER / MODEL SOLUTION:\n${answerText}`;
      
      const title = `Q: ${questionText.substring(0, 45)}...`;
      
      // Check if duplicate
      const alreadyExists = existing.find(s => s.content === content || (s.title === title && s.type === 'question'));
      if (alreadyExists) {
        showToast('This question is already in your Notebook.');
        return;
      }
      
      const newSource = {
        id: `q-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        title: title,
        content: content,
        type: 'question',
        subject: subjectLabel
      };
      
      saveItem('vidypath_notebook_sources', [...existing, newSource]);
      showToast('Added to Study Notebook!');
    } catch (e) {
      console.error(e);
      showToast('Could not save to Notebook.');
    }
  };

  const handleGetHint = async () => {
    if (hint) return;
    setLoadingHint(true);
    try {
      const questionText = q.question || q.assertion || "Match column pairs";
      const res = await fetchQBankHint(subjectLabel, chapterName, questionText);
      setHint(res);
    } catch (e) {
      setHint("Recall the central formula, theory or context governing this topic.");
    } finally {
      setLoadingHint(false);
    }
  };

  const handleGradeAnswer = async () => {
    if (!userTxtAnswer.trim() && !uploadedImage) {
      showToast('Please type your draft answer or upload an image of your handwritten answersheet first!');
      return;
    }
    setLoadingEvaluation(true);
    try {
      const questionText = q.question || q.assertion || "Answer question";
      const modelAnswer = q.answer || "";
      const res = await evaluateQBankAnswerWithImage(
        subjectLabel,
        chapterName,
        questionText,
        modelAnswer,
        userTxtAnswer,
        uploadedImage
      );
      setEvaluation(res);
      // Log Question Bank attempt
      recordEvent('qbank_attempt', 'Question Bank Practice', subjectKey, chapterName);
    } catch (error) {
      console.error(error);
      showToast('Evaluation failed. Please try again.');
    } finally {
      setLoadingEvaluation(false);
    }
  };

  const checkMcqAnswer = () => {
    if (!selectedMcq) return;
    setMcqChecked(true);
    
    // Log MCQ practice attempt
    recordEvent('qbank_attempt', 'Question Bank MCQ', subjectKey, chapterName);

    const cleanCorrect = q.answer?.trim() || "";
    const cleanSelected = selectedMcq.trim();
    
    if (cleanCorrect.toLowerCase() === cleanSelected.toLowerCase()) {
      setMcqIsCorrect(true);
      return;
    }

    const letterToIdx = (l: string) => ['A','B','C','D'].indexOf(l.toUpperCase());
    const correctIdx = letterToIdx(cleanCorrect);
    const selectedIdx = letterToIdx(cleanSelected);

    if (correctIdx !== -1 && correctIdx === selectedIdx) {
      setMcqIsCorrect(true);
      return;
    }

    if (q.options && correctIdx !== -1 && q.options[correctIdx]?.toLowerCase() === cleanSelected.toLowerCase()) {
      setMcqIsCorrect(true);
      return;
    }
    
    if (q.options && selectedIdx !== -1 && q.options[selectedIdx]?.toLowerCase() === cleanCorrect.toLowerCase()) {
      setMcqIsCorrect(true);
      return;
    }

    setMcqIsCorrect(false);
  };

  const checkArAnswer = () => {
    if (!arSelected) return;
    setArChecked(true);
  };

  const handlePracticeSimilar = async () => {
    if (similarQ) {
      setShowSimilar(!showSimilar);
      return;
    }
    setLoadingSimilar(true);
    setShowSimilar(true);
    try {
      const questionText = q.question || q.assertion || "Practice dynamic question";
      const res = await fetchQBankSimilarQuestion(subjectLabel, chapterName, type, questionText);
      setSimilarQ(res);
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingSimilar(false);
    }
  };

  const getTypeBadgeColor = () => {
    switch (type) {
      case 'mcq': return 'bg-blue-100 text-blue-600 border-blue-200';
      case 'assertion_reason': return 'bg-red-100 text-red-600 border-red-200';
      case 'match_following': return 'bg-orange-100 text-orange-600 border-orange-200';
      case 'hots': return 'bg-purple-100 text-purple-600 border-purple-200';
      case 'numerical': return 'bg-indigo-100 text-indigo-600 border-indigo-200';
      default: return 'bg-neutral-100 text-neutral-600 border-neutral-200';
    }
  };

  const isSubjective = type !== 'mcq' && 
                       type !== 'assertion_reason' && 
                       type !== 'match_following' && 
                       type !== 'fill_in_blank' && 
                       !q.question?.toLowerCase().includes('fill in the blank') &&
                       !q.question?.toLowerCase().includes('fill in the blanks');

  return (
    <div className={cn("p-5 border rounded-3xl space-y-4 shadow-3xs relative overflow-hidden transition-all text-left", 
      isCompanion ? "border-amber-300 bg-amber-50/10 dark:bg-amber-950/15" : "bg-surface border-border hover:border-blue-250"
    )}>
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className={cn("px-2.5 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider border", getTypeBadgeColor())}>
            {isCompanion ? "✨ Practice Companion" : `${type.replace('_', ' ')}`}
          </span>
          <button
            type="button"
            onClick={() => {
              setIsImp(!isImp);
              showToast(!isImp ? 'Marked as Important Question!' : 'Removed Important flag from question.');
            }}
            className={cn(
              "inline-flex items-center gap-0.5 text-[9px] font-black px-2 py-0.5 rounded-full leading-none shrink-0 border transition-all cursor-pointer active:scale-95 shadow-3xs",
              isImp 
                ? "bg-rose-50 dark:bg-rose-950/30 text-rose-600 dark:text-rose-450 border-rose-200/40 dark:border-rose-900 hover:bg-rose-100 dark:hover:bg-rose-950/50" 
                : "bg-surface text-ink3 border-border hover:bg-surface2 hover:text-ink2"
            )}
            title={isImp ? "Mark as Not Important" : "Mark as Important (IMP)"}
          >
            {isImp ? "🔥 IMP" : "☆ Normal"}
          </button>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleAddQuestionToNotebook}
            className="inline-flex items-center gap-1 px-2.5 py-1 hover:bg-orange hover:text-white border border-border hover:border-orange bg-surface rounded-xl text-[9px] font-black uppercase tracking-wider text-ink2 transition-all active:scale-95 shadow-3xs shrink-0"
            title="Add to Notebook"
          >
            <Plus className="w-3 h-3 text-orange-500" />
            Add to Notebook
          </button>
          <span className="text-[10px] font-mono text-ink3 font-bold shrink-0">Q.{index}</span>
        </div>
      </div>

      <div className="space-y-3">
        {type === 'assertion_reason' ? (
          <div className="space-y-2 text-ink">
            <p className="text-sm font-semibold leading-relaxed">
              <span className="font-extrabold text-red-650 dark:text-red-400">Assertion (A):</span> {q.assertion}
            </p>
            <p className="text-sm font-semibold leading-relaxed">
              <span className="font-extrabold text-red-650 dark:text-red-400">Reason (R):</span> {q.reason}
            </p>
          </div>
        ) : type === 'source_based' ? (
          <div className="space-y-3">
            <div className="p-3.5 bg-amber-50/10 dark:bg-amber-950/25 border border-amber-100 dark:border-amber-900/40 rounded-xl leading-relaxed text-xs font-semibold italic text-amber-900 dark:text-amber-200">
              <span className="block text-[8px] font-black uppercase tracking-widest text-amber-700 dark:text-amber-400 not-italic mb-1">Source Passage</span>
              {q.source}
            </div>
            <p className="text-sm font-extrabold text-ink leading-relaxed">{q.question}</p>
          </div>
        ) : type === 'match_following' ? (
          <div className="space-y-4">
            <p className="text-sm font-extrabold text-ink">Match the columns correctly:</p>
            <div className="grid grid-cols-2 gap-4 text-left">
              <div className="space-y-2">
                <div className="text-[10px] font-black text-orange-600 dark:text-orange-400 uppercase tracking-widest">Column I</div>
                {q.pairs?.map((p: any, idx: number) => (
                  <div key={idx} className="p-2 bg-surface2 border border-border rounded-lg text-xs font-semibold text-ink">
                    <span className="font-mono text-[10px] mr-1">{idx+1})</span> {p.left}
                  </div>
                ))}
              </div>
              <div className="space-y-2">
                <div className="text-[10px] font-black text-orange-600 dark:text-orange-400 uppercase tracking-widest">Column II</div>
                {q.pairs?.map((p: any, idx: number) => (
                  <div key={idx} className="p-2 bg-surface2 border border-border rounded-lg text-xs font-semibold text-ink">
                    <span className="font-mono text-[10px] mr-1">{String.fromCharCode(97 + idx)})</span> {p.right}
                  </div>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <p className="text-sm font-extrabold text-ink leading-relaxed whitespace-pre-wrap">{q.question}</p>
        )}
      </div>

      <div className="pt-2 border-t border-dashed border-border space-y-3">
        {type === 'mcq' && q.options && (
          <div className="space-y-2 text-left">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {q.options.map((opt: string, idx: number) => {
                const choiceLetter = ['A', 'B', 'C', 'D'][idx];
                const isSelected = selectedMcq === choiceLetter || selectedMcq === opt;
                
                let btnStyle = "bg-surface border-border hover:bg-surface2 text-ink";
                if (isSelected) {
                  btnStyle = "bg-blue-50 dark:bg-blue-950/40 border-blue-400 dark:border-blue-500 font-extrabold ring-1 ring-blue-450 dark:ring-blue-900 text-blue-900 dark:text-blue-200";
                }
                if (mcqChecked) {
                  const cleanAns = q.answer?.trim() || "";
                  const isThisCorrect = choiceLetter === cleanAns.toUpperCase() || opt.toLowerCase() === cleanAns.toLowerCase() || cleanAns.toUpperCase() === ['A','B','C','D'][idx];
                  if (isThisCorrect) {
                    btnStyle = "bg-green-50 dark:bg-green-950/45 border-green-500 dark:border-green-400 ring-2 ring-green-150 dark:ring-green-900 text-green-900 dark:text-green-200 font-extrabold";
                  } else if (isSelected) {
                    btnStyle = "bg-red-50 dark:bg-red-950/45 border-red-400 dark:border-red-500 ring-2 ring-red-150 dark:ring-red-900 text-red-900 dark:text-red-200 font-extrabold";
                  }
                }

                return (
                  <button
                    key={idx}
                    type="button"
                    disabled={mcqChecked}
                    onClick={() => setSelectedMcq(choiceLetter)}
                    className={cn("p-3 rounded-2xl border text-left text-xs transition-all flex items-center justify-between gap-2 shadow-3xs", btnStyle)}
                  >
                    <span className="flex items-center gap-2">
                      <span className="font-bold text-ink3 text-[10px] uppercase">{choiceLetter}.</span>
                      <span>{opt}</span>
                    </span>
                    {mcqChecked && (choiceLetter === q.answer?.trim().toUpperCase() || opt.toLowerCase() === q.answer?.trim().toLowerCase()) && (
                      <Check className="w-4 h-4 text-green-600 flex-shrink-0" />
                    )}
                    {mcqChecked && isSelected && !(choiceLetter === q.answer?.trim().toUpperCase() || opt.toLowerCase() === q.answer?.trim().toLowerCase()) && (
                      <X className="w-4 h-4 text-red-650 flex-shrink-0" />
                    )}
                  </button>
                );
              })}
            </div>
            
            {!mcqChecked ? (
              <button
                type="button"
                disabled={!selectedMcq}
                onClick={checkMcqAnswer}
                className="w-full py-2.5 bg-blue-650 hover:bg-blue-700 disabled:opacity-50 text-white rounded-xl text-[10px] font-black uppercase tracking-wider transition-all shadow-sm"
              >
                Check MCQ Option
              </button>
            ) : (
              <div className="p-3.5 bg-green-50/20 border border-green-500/15 rounded-2xl flex items-center gap-3 animate-fadeUp">
                <div className={cn("w-8 h-8 rounded-full flex items-center justify-center text-white flex-shrink-0", mcqIsCorrect ? "bg-green-550" : "bg-red-400")}>
                  {mcqIsCorrect ? <Check className="w-4 h-4" /> : <X className="w-4 h-4" />}
                </div>
                <div>
                  <div className="text-xs font-black text-ink">{mcqIsCorrect ? "Yes! That is absolutely correct." : "Incorrect option selected."}</div>
                  <div className="text-[10px] font-semibold text-ink2">Target Key Answer is: <b className="text-green-650 uppercase font-bold">{q.answer}</b></div>
                </div>
              </div>
            )}
          </div>
        )}

        {type === 'assertion_reason' && (
          <div className="space-y-3 text-left">
            <div className="text-[9px] font-black tracking-wider uppercase text-ink3 mb-1">Standard Board Answer Options:</div>
            <div className="grid grid-cols-1 gap-2">
              {[
                { key: 'A', text: "Both Assertion & Reason are true, and Reason is correct explanation." },
                { key: 'B', text: "Both Assertion & Reason are true, but Reason is not correct explanation." },
                { key: 'C', text: "Assertion is true, but Reason is false." },
                { key: 'D', text: "Assertion is false, but Reason is true." }
              ].map((opt) => {
                const isSelected = arSelected === opt.key;
                let btnStyle = "bg-surface border-border text-ink hover:bg-surface2";
                if (isSelected) btnStyle = "bg-red-50 dark:bg-red-950/40 border-red-300 dark:border-red-500/60 text-red-955 dark:text-red-200 font-semibold ring-1 ring-red-300 dark:ring-red-900";
                if (arChecked) {
                  const isThisCorrect = q.answer?.toUpperCase().includes(`OPTION ${opt.key}`) || q.answer?.toUpperCase().startsWith(opt.key) || q.answer?.toUpperCase().startsWith(`(A)`) || false;
                  if (isSelected) {
                    btnStyle = isThisCorrect ? "bg-green-50 dark:bg-green-950/45 border-green-400 dark:border-green-500 text-green-950 dark:text-green-200 ring-2 ring-green-150 dark:ring-green-900" : "bg-red-50 dark:bg-red-950/45 border-red-400 dark:border-red-500 text-red-955 dark:text-red-200 ring-2 ring-red-150 dark:ring-red-900";
                  } else if (isThisCorrect) {
                    btnStyle = "bg-green-50/50 dark:bg-green-950/20 border-green-300 dark:border-green-800 text-green-905 dark:text-green-300 font-medium";
                  }
                }
                return (
                  <button
                    key={opt.key}
                    type="button"
                    disabled={arChecked}
                    onClick={() => setArSelected(opt.key)}
                    className={cn("p-2.5 px-3 border rounded-xl text-left text-xs transition-all flex items-start gap-2 shadow-3xs", btnStyle)}
                  >
                    <span className="font-bold text-ink3 shrink-0">{opt.key}.</span>
                    <span className="leading-tight text-[11px]">{opt.text}</span>
                  </button>
                );
              })}
            </div>

            {!arChecked ? (
              <button
                type="button"
                disabled={!arSelected}
                onClick={checkArAnswer}
                className="w-full py-2.5 bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white rounded-xl text-[10px] font-black uppercase tracking-wider transition-all"
              >
                Validate Reason Link
              </button>
            ) : (
              <div className="p-4 bg-red-50/15 border border-red-500/10 rounded-2xl space-y-2 text-left animate-fadeUp">
                <span className="text-[9px] font-black uppercase text-red-600 tracking-wider">CBSE Explanation Sheet</span>
                <div className="text-xs font-bold leading-relaxed text-ink markdown-body font-sans">
                  <Markdown>{q.answer}</Markdown>
                </div>
              </div>
            )}
          </div>
        )}

        {isSubjective && (
          <div className="space-y-3 text-left">
            <div className="space-y-1">
              <label className="text-[9px] font-black text-ink3 uppercase ml-1">Write your answer draft here:</label>
              <textarea
                placeholder="Type your answer, core formula or definition and check matches..."
                value={userTxtAnswer}
                onChange={(e) => setUserTxtAnswer(e.target.value)}
                rows={3}
                className="w-full p-3 bg-surface2/60 border border-border text-xs rounded-xl focus:border-blue-500 focus:outline-none transition-all placeholder:text-ink3 text-ink font-semibold"
              ></textarea>
            </div>

            {/* Image Upload Option */}
            <div className="space-y-1">
              <span className="text-[9px] font-black text-ink3 uppercase ml-1 block">Or upload answersheet image:</span>
              {!uploadedImage ? (
                <label 
                  htmlFor={`image-upload-${id}`}
                  className="flex items-center justify-center gap-2 p-3 bg-surface/40 hover:bg-surface2 border border-dashed border-border rounded-xl cursor-crosshair transition-all group hover:border-blue-500/80 hover:bg-blue-50/5"
                >
                  <Upload className="w-3.5 h-3.5 text-ink3 group-hover:text-blue-500 group-hover:scale-110 transition-all" />
                  <span className="text-[11px] font-semibold text-ink2 group-hover:text-ink">Upload Handwritten Photo / Sheet Scan</span>
                  <input 
                    type="file" 
                    id={`image-upload-${id}`} 
                    accept="image/*" 
                    onChange={handleImageChange} 
                    className="hidden" 
                  />
                </label>
              ) : (
                <div className="flex items-center justify-between p-2 bg-surface2 border border-border rounded-xl gap-2 animate-fadeIn">
                  <div className="flex items-center gap-2 overflow-hidden">
                    <div className="w-9 h-9 rounded-lg border border-border bg-neutral-100 dark:bg-neutral-850 overflow-hidden shrink-0 flex items-center justify-center">
                      <img 
                        src={uploadedImage} 
                        alt="Uploaded Written Answer Sheet" 
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    <div className="min-w-0 text-left">
                      <p className="text-[10px] font-black text-ink leading-tight truncate">Written Answer Sheet</p>
                      <span className="text-[9px] font-bold text-green-500">Image Loaded & Ready</span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={removeUploadedImage}
                    className="p-1.5 hover:bg-red-50 dark:hover:bg-red-950/20 text-red-500 rounded-lg shrink-0 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>

            <div className="flex gap-2">
              <button
                type="button"
                disabled={(!userTxtAnswer.trim() && !uploadedImage) || loadingEvaluation}
                onClick={handleGradeAnswer}
                className="flex-1 py-2.5 bg-blue-650 hover:bg-blue-700 text-white font-black text-[10px] uppercase tracking-wider rounded-xl transition-all disabled:opacity-50 flex items-center justify-center gap-1.5 shadow-sm"
              >
                {loadingEvaluation ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <CheckCircle className="w-3.5 h-3.5" />}
                AI Self-Check Answer
              </button>

              <button
                type="button"
                onClick={() => setRevealed(!revealed)}
                className="px-4 py-2.5 border border-border hover:bg-surface2 text-ink2 hover:text-ink font-bold text-[10px] uppercase tracking-wider rounded-xl transition-all"
              >
                {revealed ? "Hide Answer" : "View Answersheet"}
              </button>
            </div>

            {evaluation && (
              <div className="bg-surface2 border border-border rounded-2xl p-4.5 space-y-3 animate-fadeUp text-left shadow-2xs">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5">
                    <span className="flex h-1.5 w-1.5 relative">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-blue-500"></span>
                    </span>
                    <span className="text-[9px] font-black uppercase text-blue-600 tracking-wider">Mock Examiner Feedback</span>
                  </div>
                  <span className={cn("text-[9px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider",
                    evaluation.score >= 80 ? 'bg-green-105 text-green-700' :
                    evaluation.score >= 55 ? 'bg-orange-105 text-orange-700' : 'bg-red-105 text-red-700'
                  )}>
                    Accuracy: {evaluation.score}%
                  </span>
                </div>

                <div className="w-full bg-slate-200 dark:bg-neutral-800 h-1.5 rounded-full overflow-hidden">
                  <div 
                    className={cn("h-full transition-all duration-500", 
                      evaluation.score >= 80 ? 'bg-green-500' :
                      evaluation.score >= 55 ? 'bg-orange-550' : 'bg-red-500'
                    )}
                    style={{ width: `${evaluation.score}%` }}
                  ></div>
                </div>

                <div className="text-xs leading-relaxed font-bold text-ink markdown-body font-sans">
                  <Markdown>{evaluation.feedback}</Markdown>
                </div>

                <div className="pt-2 border-t border-border/50">
                  <span className="text-[9px] font-black text-ink3 uppercase">Standard Model Answer:</span>
                  <div className="text-xs leading-relaxed text-ink2 mt-0.5 markdown-body font-sans">
                    <Markdown>{q.answer}</Markdown>
                  </div>
                </div>
              </div>
            )}

            {revealed && !evaluation && (
              <div className="p-4 bg-surface2 border border-border/85 text-[11px] font-bold text-ink rounded-xl leading-relaxed text-left animate-fadeUp">
                <span className="block text-[8px] font-black uppercase text-ink3 tracking-widest mb-1.5">Answer Key / Rubric:</span>
                <div className="markdown-body font-sans mt-0.5">
                  <Markdown>{q.answer}</Markdown>
                </div>
              </div>
            )}
          </div>
        )}

        {type === 'match_following' && (
          <div className="space-y-2 text-left">
            <button
              type="button"
              onClick={() => setRevealed(!revealed)}
              className="w-full py-2 border border-orange-200 dark:border-orange-900/40 bg-orange-50/5 text-orange-700 dark:text-orange-400 font-extrabold text-[10px] uppercase rounded-xl hover:bg-orange-100/10 transition-all"
            >
              {revealed ? "Hide Mapping Key" : "Reveal Correct Matches"}
            </button>
            {revealed && (
              <div className="p-4 bg-orange-50/10 dark:bg-orange-950/10 border border-orange-200 dark:border-orange-900/30 rounded-2xl text-xs font-bold text-orange-950 dark:text-orange-200 leading-relaxed text-left animate-fadeUp markdown-body font-sans">
                <Markdown>{q.answer}</Markdown>
              </div>
            )}
          </div>
        )}
      </div>

      <div className="pt-2 border-t border-border flex flex-wrap items-center justify-between gap-3 text-left">
        <div className="flex items-center gap-2 max-w-full">
          <button
            type="button"
            disabled={loadingHint}
            onClick={handleGetHint}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-border hover:border-yellow-300 hover:bg-yellow-50/40 text-xs font-bold text-ink2 hover:text-yellow-800 transition-all text-[10px] uppercase tracking-wider shrink-0"
          >
            {loadingHint ? <RefreshCw className="w-3 h-3 animate-spin text-yellow-500" /> : <HelpCircle className="w-3 h-3 text-yellow-500" />}
            Hint
          </button>
          
          {hint && (
            <div className="text-[11px] font-semibold text-ink pl-2 italic text-left border-l-2 border-yellow-200 py-0.5 animate-fadeUp">
              {hint}
            </div>
          )}
        </div>

        {!isCompanion && (
          <button
            type="button"
            disabled={loadingSimilar}
            onClick={handlePracticeSimilar}
            className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-orange-50 hover:bg-orange-100/50 border border-orange-500/10 text-[10px] font-black uppercase text-orange-700 transition-all tracking-wider shrink-0"
          >
            {loadingSimilar ? <RefreshCw className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />}
            {showSimilar ? "Hide Companion" : "Practice Similar"}
          </button>
        )}
      </div>

      {showSimilar && (
        <div className="mt-4 pt-4 border-t border-dashed border-border text-left space-y-3 animate-fadeUp">
          <div className="flex items-center gap-1.5 text-[10px] font-black uppercase text-orange-650 tracking-wider">
            <Sparkles className="w-3.5 h-3.5 text-orange-500 animate-pulse" />
            Similar concept practice (AI Generated)
          </div>

          {loadingSimilar ? (
            <div className="p-6 text-center space-y-2 bg-neutral-50 rounded-2xl border border-border">
              <RefreshCw className="w-5 h-5 animate-spin mx-auto text-orange-500" />
              <div className="text-[10px] font-black uppercase tracking-wider text-ink3 text-center">Analyzing original question & generating similar task...</div>
            </div>
          ) : similarQ ? (
            <QBankQuestionCard
              id={`${id}-similar`}
              type={type}
              q={similarQ}
              index={index}
              subjectLabel={subjectLabel}
              chapterName={chapterName}
              subjectKey={subjectKey}
              isCompanion={true}
              showToast={showToast}
            />
          ) : (
            <div className="text-xs text-ink3 text-center py-2">Couldn't generate similar question. Please try again!</div>
          )}
        </div>
      )}
    </div>
  );
}

interface FormulaCardProps {
  formula: {
    name: string;
    expression: string;
    symbols: { symbol: string; meaning: string; unit?: string }[];
    description: string;
    application: string;
  };
  index: number;
}

function FormulaCard({ formula, index }: FormulaCardProps) {
  const [testMode, setTestMode] = useState(false);
  const [draft, setDraft] = useState('');
  const [checked, setChecked] = useState(false);

  const cleanString = (str: string) => str.replace(/[\s\(\)\*\\\^\{\}\[\]\-\+\=\/]/g, '').toLowerCase();

  const handleCheck = () => {
    setChecked(true);
  };

  const isMatched = cleanString(draft) !== '' && (
    cleanString(draft) === cleanString(formula.expression) ||
    formula.expression.toLowerCase().includes(draft.toLowerCase().trim())
  );

  return (
    <div className="p-5 border border-border rounded-3xl bg-white hover:border-orange/30 transition-all shadow-3xs flex flex-col justify-between space-y-4">
      <div className="space-y-2">
        <div className="flex items-start justify-between gap-3">
          <div className="space-y-0.5">
            <span className="text-[8px] font-black uppercase text-orange bg-orange-lt px-1.5 py-0.5 rounded tracking-wider">Formula #{index}</span>
            <h5 className="font-bold text-sm text-ink text-left">{formula.name}</h5>
          </div>
          <button 
            type="button"
            onClick={() => {
              setTestMode(!testMode);
              setDraft('');
              setChecked(false);
            }}
            className={cn("px-2.5 py-1 text-[9px] font-black uppercase rounded-lg tracking-wider border transition-all",
              testMode ? "bg-orange text-white border-orange-200" : "bg-neutral-50 border-border text-ink2 hover:text-orange hover:border-orange/20"
            )}
          >
            {testMode ? "👁️ Show" : "🙈 Quiz"}
          </button>
        </div>

        {testMode ? (
          <div className="bg-orange-50/10 border border-dashed border-orange-200 rounded-2xl p-4 text-center space-y-3">
            <div className="text-[10px] font-black text-orange-600 uppercase tracking-widest">Active Recall Mode</div>
            <p className="text-xs font-semibold text-ink3 leading-snug">Write the formula/principle representation:</p>
            <input
              type="text"
              placeholder="e.g. 1/f = 1/v - 1/u"
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              disabled={checked}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && draft.trim()) {
                  handleCheck();
                }
              }}
              className="w-full text-center p-2 border border-border focus:border-orange focus:outline-none bg-white rounded-xl font-mono text-sm font-semibold shadow-3xs placeholder:text-ink3"
            />
            {!checked ? (
              <button
                type="button"
                disabled={!draft.trim()}
                onClick={handleCheck}
                className="w-full py-1.5 bg-orange hover:bg-orange/90 text-white font-black text-[9px] uppercase tracking-wider rounded-lg transition-all disabled:opacity-50"
              >
                Evaluate Formula
              </button>
            ) : (
              <div className="space-y-2.5 pt-1.5 animate-fadeUp">
                <div className="flex items-center justify-center gap-1.5">
                  <span className={cn("w-2 h-2 rounded-full", isMatched ? "bg-green-500 animate-ping" : "bg-orange animate-pulse")}></span>
                  <span className="text-[10px] font-black uppercase">
                    {isMatched ? "Excellent Match!" : "Compare to key below"}
                  </span>
                </div>
                <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono text-xs font-black text-slate-800 break-all select-all">
                  {formula.expression}
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setChecked(false);
                    setDraft('');
                  }}
                  className="text-[9px] font-black text-orange-650 uppercase hover:underline"
                >
                  Retry Recall
                </button>
              </div>
            )}
          </div>
        ) : (
          <div className="bg-slate-50 border border-slate-100 rounded-2xl p-4.5 text-center flex items-center justify-center min-h-[5rem] overflow-x-auto shadow-inner">
            <div className="font-mono text-base font-black text-neutral-800 tracking-wide select-all whitespace-pre-wrap">
              {formula.expression}
            </div>
          </div>
        )}

        <p className="text-xs leading-relaxed text-ink2 text-left font-medium">{formula.description}</p>
      </div>

      <div className="space-y-3 pt-3 border-t border-dashed border-border text-left">
        {formula.symbols && formula.symbols.length > 0 && (
          <div className="space-y-1.5">
            <div className="text-[9px] font-black text-ink3 uppercase tracking-wider">Symbols Breakdown:</div>
            <div className="flex flex-wrap gap-1.5">
              {formula.symbols.map((sym: any, sIdx: number) => (
                <span 
                  key={sIdx} 
                  className="inline-flex items-center gap-1 px-2.5 py-1 bg-slate-50 border border-slate-150 rounded-xl text-[10px] font-bold text-ink"
                >
                  <code className="font-mono bg-white px-1 border border-slate-200 rounded text-neutral-850 font-extrabold">{sym.symbol}</code>
                  <span className="text-neutral-400 font-medium font-sans">:</span>
                  <span className="font-semibold text-ink2">{sym.meaning || sym.symbol}</span>
                  {sym.unit && (
                    <span className="text-[9px] font-mono font-medium text-slate-500">({sym.unit})</span>
                  )}
                </span>
              ))}
            </div>
          </div>
        )}

        {formula.application && (
          <div className="p-3 bg-indigo-50/20 border border-indigo-500/10 rounded-2xl text-left space-y-1">
            <span className="text-[9px] font-black uppercase text-indigo-700 tracking-widest flex items-center gap-1">
              <Compass className="w-3.5 h-3.5 text-indigo-500" /> Syllabus Application
            </span>
            <p className="text-[11px] leading-relaxed font-bold text-ink italic">{formula.application}</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default function ChapterHub({ subjectKey, chapterIndex, initialTab, initialTopic, navigateTo, showToast }: ChapterHubProps) {
  const sub = SUBJECTS[subjectKey];
  const [selectedCh, setSelectedCh] = useState<string>(() => {
    if (chapterIndex !== undefined && chapterIndex !== null && sub && sub.chapters[chapterIndex]) {
      return sub.chapters[chapterIndex].name;
    }
    return '';
  });

  // Preferred Teachers reactive state
  const [preferredTeachers, setPreferredTeachersState] = useState<Record<string, string>>(() => ({
    maths: getPreferredTeacher('maths'),
    science: getPreferredTeacher('science'),
    sst: getPreferredTeacher('sst'),
    english: getPreferredTeacher('english')
  }));

  const handleTeacherChange = (subjKey: string, newValue: string) => {
    setPreferredTeacher(subjKey, newValue);
    setPreferredTeachersState(prev => ({
      ...prev,
      [subjKey]: newValue
    }));
    showToast(`🎯 Educator for ${subjKey.toUpperCase()} updated to ${newValue}`);
  };
  const [activeTab, setActiveTab] = useState<Tab>(() => {
    if (initialTab && ['ainotes', 'tricks', 'questions', 'video', 'diagrams', 'pyqs', 'formulas', 'studyguide'].includes(initialTab)) {
      return initialTab as Tab;
    }
    return 'ainotes';
  });

  useEffect(() => {
    if (chapterIndex !== undefined && chapterIndex !== null && sub && sub.chapters[chapterIndex]) {
      setSelectedCh(sub.chapters[chapterIndex].name);
    }
  }, [chapterIndex, sub]);

  useEffect(() => {
    if (initialTab && ['ainotes', 'tricks', 'questions', 'video', 'diagrams', 'pyqs', 'formulas', 'studyguide'].includes(initialTab)) {
      setActiveTab(initialTab as Tab);
    }
  }, [initialTab]);

  useEffect(() => {
    if (initialTopic) {
      setSelectedTopicForQBank(initialTopic);
    }
  }, [initialTopic]);

  const [diagramMode, setDiagramMode] = useState<DiagramMode>('interactive');
  const [loading, setLoading] = useState(false);
  const [aiNotes, setAiNotes] = useState<any>(null);
  const [tricks, setTricks] = useState<string[]>([]);
  const [memoryHacks, setMemoryHacks] = useState<string[]>([]);
  const [diagramQuestions, setDiagramQuestions] = useState<any[]>([]);
  const [interactiveDiagrams, setInteractiveDiagrams] = useState<any[]>([]);
  const [activeHotspot, setActiveHotspot] = useState<{diagIdx: number, partIdx: number} | null>(null);
  const [evaluatingDiagram, setEvaluatingDiagram] = useState<number | null>(null);
  const [diagramFeedback, setDiagramFeedback] = useState<Record<number, string>>({});
  const [difficulty, setDifficulty] = useState<Difficulty>('standard');
  const [bookStyle, setBookStyle] = useState<BookStyle>('ncert');
  const [qBank, setQBank] = useState<any>(null);
  const [selectedTopicForQBank, setSelectedTopicForQBank] = useState<string | null>(null);
  const [revealedQ, setRevealedQ] = useState<Record<string, boolean>>({});
  const [topics, setTopics] = useState<string[]>([]);
  const [topicsLoading, setTopicsLoading] = useState(false);
  const [showAnswerIdx, setShowAnswerIdx] = useState<number | null>(null);
  const [detailLevel, setDetailLevel] = useState<DetailLevel>('balanced');
  const [noteSystem, setNoteSystem] = useState<'v1' | 'v2'>('v2');
  const [notes2Type, setNotes2Type] = useState<'quick' | 'lesson'>('quick');
  const [aiNotes2Quick, setAiNotes2Quick] = useState<any>(null);
  const [aiNotes2Lesson, setAiNotes2Lesson] = useState<any>(null);
  const [tricksMode, setTricksMode] = useState<'shortcuts' | 'mnemonics'>('shortcuts');

  const [formulas, setFormulas] = useState<any[]>([]);
  const [formulasLoading, setFormulasLoading] = useState(false);
  const [formulaSearchQuery, setFormulaSearchQuery] = useState('');

  const [studyGuide, setStudyGuide] = useState<any>(null);
  const [studyGuideLoading, setStudyGuideLoading] = useState(false);

  const filteredFormulas = formulas.filter(f => {
    const query = formulaSearchQuery.toLowerCase().trim();
    if (!query) return true;
    return (
      (f.name?.toLowerCase().includes(query)) ||
      (f.expression?.toLowerCase().includes(query)) ||
      (f.description?.toLowerCase().includes(query)) ||
      (f.application?.toLowerCase().includes(query)) ||
      (f.symbols?.some((s: any) => s.meaning?.toLowerCase().includes(query) || s.symbol?.toLowerCase().includes(query)))
    );
  });

  // PYQ management states
  const [pyqs, setPyqs] = useState<RealPYQ[]>([]);
  const [pyqsLoading, setPyqsLoading] = useState(false);
  const [newPyqQuestion, setNewPyqQuestion] = useState('');
  const [newPyqAnswer, setNewPyqAnswer] = useState('');
  const [newPyqYear, setNewPyqYear] = useState<number>(2024);
  const [newPyqMarks, setNewPyqMarks] = useState<number>(3);
  const [newPyqType, setNewPyqType] = useState<'MCQ' | 'Short Answer' | 'Long Answer' | 'Competency'>('Short Answer');
  const [newPyqSource, setNewPyqSource] = useState('');
  const [showAddPyqForm, setShowAddPyqForm] = useState(false);
  const [revealedPyq, setRevealedPyq] = useState<Record<string, boolean>>({});

  // YouTube Study Desk state definitions
  const [chapterVideos, setChapterVideos] = useState<YouTubeVideoItem[]>([]);
  const [selectedVideo, setSelectedVideo] = useState<YouTubeVideoItem | null>(null);
  const [videoNotes, setVideoNotes] = useState<string>('');
  const [customVideoUrl, setCustomVideoUrl] = useState<string>('');
  const [videoSearchTerm, setVideoSearchTerm] = useState<string>('');
  const [isSearchingVideos, setIsSearchingVideos] = useState<boolean>(false);
  const [searchVideoResults, setSearchVideoResults] = useState<YouTubeVideoItem[]>([]);
  const [activeVideoStart, setActiveVideoStart] = useState<number>(0);
  const [videoPlayerKey, setVideoPlayerKey] = useState<number>(0); // To force re-render iframe on start jump

  // Analytics for video watched
  useEffect(() => {
    if (selectedVideo && selectedCh) {
      recordEvent('video_watched', 'YouTube Study Desk', subjectKey, selectedCh, { videoTitle: selectedVideo.title, videoId: selectedVideo.id });
    }
  }, [selectedVideo?.id, selectedCh]);

  // Load chapter videos & saved notes when chapter or educator shifts
  useEffect(() => {
    if (!selectedCh) return;
    const list = getChapterVideos(selectedCh, subjectKey);
    setChapterVideos(list);
    if (list.length > 0) {
      setSelectedVideo(list[0]);
    } else {
      setSelectedVideo(null);
    }
    const savedNotes = getSavedVideoNotes(subjectKey, selectedCh);
    setVideoNotes(savedNotes);
    setCustomVideoUrl('');
    setVideoSearchTerm('');
    setSearchVideoResults([]);
    setActiveVideoStart(0);
    setVideoPlayerKey(0);
  }, [selectedCh, subjectKey, preferredTeachers[subjectKey]]);

  // Persistence Key
  const cacheKey = `hub_cache_${subjectKey}_${selectedCh}`;

  // Load from cache on chapter change
  useEffect(() => {
    if (!selectedCh) return;
    const cache = loadItem<any>(cacheKey, null);
    if (cache) {
      setAiNotes(cache.aiNotes || null);
      setNoteSystem(cache.noteSystem || 'v2');
      setNotes2Type(cache.notes2Type || 'quick');
      setAiNotes2Quick(cache.aiNotes2Quick || null);
      setAiNotes2Lesson(cache.aiNotes2Lesson || null);
      setTopics(cache.topics || []);
      setTricks(cache.tricks || []);
      setMemoryHacks(cache.memoryHacks || []);
      setQBank(cache.qBank || null);
      setDiagramQuestions(cache.diagramQuestions || []);
      setInteractiveDiagrams(cache.interactiveDiagrams || []);
      setFormulas(cache.formulas || []);
      setStudyGuide(cache.studyGuide || null);
    } else {
      // Clear states if no cache
      setAiNotes(null);
      setNoteSystem('v2');
      setNotes2Type('quick');
      setAiNotes2Quick(null);
      setAiNotes2Lesson(null);
      setTopics([]);
      setTricks([]);
      setMemoryHacks([]);
      setQBank(null);
      setDiagramQuestions([]);
      setInteractiveDiagrams([]);
      setFormulas([]);
      setStudyGuide(null);
    }
    setSelectedTopicForQBank(null);
    setActiveHotspot(null);
    setDiagramFeedback({});
  }, [selectedCh, subjectKey]);

  // Save to cache when states update
  useEffect(() => {
    if (!selectedCh) return;
    const cache = {
      aiNotes,
      noteSystem,
      notes2Type,
      aiNotes2Quick,
      aiNotes2Lesson,
      topics,
      tricks,
      memoryHacks,
      qBank,
      diagramQuestions,
      interactiveDiagrams,
      formulas,
      studyGuide
    };
    saveItem(cacheKey, cache);
  }, [aiNotes, noteSystem, notes2Type, aiNotes2Quick, aiNotes2Lesson, topics, tricks, memoryHacks, qBank, diagramQuestions, interactiveDiagrams, formulas, studyGuide, cacheKey]);
  const chapters = sub.chapters;

  const handleSearchVideos = async () => {
    if (!videoSearchTerm.trim()) {
      showToast("⚠️ Enter search keywords first!");
      return;
    }
    setIsSearchingVideos(true);
    try {
      const prompt = `You are an expert CBSE Class 10 education AI curator. We are looking for high quality YouTube learning videos about "${videoSearchTerm}" for the subject "${sub.label}" (chapter: "${selectedCh}").
Return a JSON array of exactly 3 educational video objects with these keys:
- "id": A valid or highly matching real YouTube video ID (e.g. from Physics Wallah, Dear Sir, or standard CBSE lectures. E.g. "gaX_uY9oV7E", "b2-v_N21L5c", "Z_EIsP4P06Q", or other real learning stream IDs).
- "title": Beautiful, high-density educational video title.
- "channel": Verified channel name (e.g. Dear Sir, Physics Wallah, Digraj Singh Rajput, Class 10 Prashant Kirad, etc.)
- "duration": Approx duration (e.g., "45m", "1h 12m")
- "views": Elegant short view-count (e.g., "1.2M views", "450K views")
- "type": One of: "one_shot", "pyqs", "revision"
- "timestamps": An array of 3 milestone timestamps inside the video (each having "label" e.g. 'Intro' or 'Specific Trick', "time" in integer seconds e.g. 1500, and "stampStr" e.g. '25:00').

Respond ONLY with the raw JSON array of objects without markdown headers except raw code block.`;
      
      const res = await getAIResponse(prompt);
      const cleaned = res.replace(/```json/g, '').replace(/```/g, '').trim();
      const list = JSON.parse(cleaned);
      if (Array.isArray(list) && list.length > 0) {
        setSearchVideoResults(list);
        showToast(`🔍 Curated ${list.length} premium lectures for "${videoSearchTerm}"`);
      } else {
        throw new Error("Invalid response format");
      }
    } catch (e) {
      console.error(e);
      // Fallback
      setSearchVideoResults([
        {
          id: "3-E_aR7K9sc",
          title: `Recommended: ${videoSearchTerm} Concept One-Shot`,
          channel: "Dear Sir CBSE Class 10",
          duration: "45m",
          views: "1.4M views",
          type: "one_shot",
          timestamps: [
            { label: "1. Basic Definition & Fundamentals", time: 0, stampStr: "00:00" },
            { label: "2. Key Questions from High Yield Topics", time: 900, stampStr: "15:00" }
          ]
        },
        {
          id: "Z_EIsP4P06Q",
          title: `${videoSearchTerm} High-scoring PYQs & Practice`,
          channel: "Physics Wallah Foundation",
          duration: "30m",
          views: "890K views",
          type: "pyqs",
          timestamps: [
            { label: "1. Formulas Walkthrough", time: 0, stampStr: "00:00" },
            { label: "2. Detailed Sample Questions Session", time: 600, stampStr: "10:00" }
          ]
        }
      ]);
      showToast("⚠️ Generated recommended stream options from local memory pool.");
    } finally {
      setIsSearchingVideos(false);
    }
  };

  const handleLoadCustomUrl = () => {
    if (!customVideoUrl.trim()) {
      showToast("⚠️ Paste a YouTube Link first!");
      return;
    }
    let vidId = "";
    const rawVal = customVideoUrl.trim();
    
    if (rawVal.includes("youtube.com/watch?v=")) {
      vidId = rawVal.split("v=")[1]?.split("&")[0] || "";
    } else if (rawVal.includes("youtu.be/")) {
      vidId = rawVal.split("youtu.be/")[1]?.split("?")[0] || "";
    } else if (rawVal.includes("youtube.com/embed/")) {
      vidId = rawVal.split("youtube.com/embed/")[1]?.split("?")[0] || "";
    } else if (rawVal.length === 11) {
      vidId = rawVal;
    }

    if (vidId && vidId.length === 11) {
      const customItem: YouTubeVideoItem = {
        id: vidId,
        title: "Pasted Custom Stream Lecture",
        channel: "User Study Stream",
        duration: "Variable",
        views: "Personal Library",
        type: "one_shot",
        timestamps: [
          { label: "1. Beginning", time: 0, stampStr: "00:00" },
          { label: "2. Mid-Session Checkpoint", time: 1800, stampStr: "30:00" },
          { label: "3. Quick Formulas & Summary Recall", time: 3600, stampStr: "1:00:00" }
        ]
      };
      setSelectedVideo(customItem);
      if (!chapterVideos.some(v => v.id === vidId)) {
        setChapterVideos(prev => [customItem, ...prev]);
      }
      showToast("🚀 Successfully embedded custom stream lecture!");
      setCustomVideoUrl('');
    } else {
      showToast("❌ Could not extract valid YouTube video ID. Check the URL!");
    }
  };

  const handleChChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedCh(e.target.value);
  };

  const loadPYQs = async () => {
    if (!selectedCh) return;
    setPyqsLoading(true);
    try {
      const list = await getChapterPYQs(subjectKey, selectedCh);
      setPyqs(list);
    } catch (e) {
      console.error("Failed to load real PYQs:", e);
    } finally {
      setPyqsLoading(false);
    }
  };

  useEffect(() => {
    if (selectedCh) {
      loadTopics();
      loadPYQs();
    }
  }, [selectedCh, subjectKey]);

  const loadTopics = async () => {
    setTopicsLoading(true);
    try {
      const data = await fetchTopicsForChapter(sub.label, selectedCh);
      setTopics(data);
    } catch (e) {
      setTopics(["Main Concepts", "Important Theorems", "Practical Applications", "Revision Mix"]);
    } finally {
      setTopicsLoading(false);
    }
  };

  const generateQBank = async (force = false, topic: string | null = null) => {
    if (!selectedCh) return;
    const tVal = topic || selectedTopicForQBank;
    const cacheKey = tVal
      ? `qbank_${sub.label}_${selectedCh}_topic_${tVal.replace(/\s+/g, '_')}_${difficulty}`
      : `qbank_${sub.label}_${selectedCh}_${difficulty}`;
    const cached = force ? null : loadItem(cacheKey, null);
    if (cached) {
      setQBank(cached);
      setSelectedTopicForQBank(tVal);
      return;
    }

    setLoading(true);
    setRevealedQ({});
    setSelectedTopicForQBank(tVal);

    const langInstr = sub.label.toLowerCase().includes('hindi') 
      ? "\nIMPORTANT: The subject is Hindi. Please generate all content strictly in HINDI language (Devanagari script)." 
      : sub.label.toLowerCase().includes('marathi') 
      ? "\nIMPORTANT: The subject is Marathi. Please generate all content strictly in MARATHI language (Devanagari script)." 
      : "";

    const seedInstr = force 
      ? `\nRandomizer reference key: ${Date.now() % 100000}. Provide a brand new, highly randomized set of questions. Do NOT duplicate or repeat questions from previous runs. Keep the questions fresh, unique, and dynamic!`
      : "";

    const topicInstr = tVal
      ? `\nCRITICAL CONSTRAINTS FOR TOPIC-WISE FOCUS:\nAll questions, contexts, sources, case studies, assertion-reason statements, fill-in-the-blanks, numericals, short answers, and long answers must be STRICTLY and deeply focused on the following specific topic/sub-concept: "${tVal}". Do not include generic questions from outside this narrow topic.`
      : "";

    const prompt = `Upgrade question bank to a modern CBSE Class 10 Question Bank (Academic Session 2026-27).

Subject: ${sub.label}
Chapter: ${selectedCh}
${tVal ? `Focused Topic / Concept: ${tVal}` : ""}
Difficulty: ${difficulty}
${langInstr}
${seedInstr}
${topicInstr}

---

Follow latest CBSE pattern.

Include these question types where relevant:

1. MCQ: {"question": "...", "options": ["A","B","C","D"], "answer": "A"}
2. Fill in the blanks: {"question": "...", "answer": "..."}
3. Short Answer: {"question": "...", "answer": "..."}
4. Long Answer: {"question": "...", "answer": "..."}
5. HOTS Questions: {"question": "...", "answer": "..."}
6. Competency-Based Questions: {"question": "...", "answer": "..."}
7. Case Study Questions: {"passage": "...", "questions": [{"question": "...", "answer": "..."}]}
8. Assertion-Reason Questions: {"assertion": "...", "reason": "...", "answer": "Option A/B/C/D with explanation"}
9. Diagram-Based Questions: {"question": "...", "answer": "..."}
10. Source-Based Questions: {"source": "...", "question": "...", "answer": "..."}
11. Numerical / Problem Solving: {"question": "...", "answer": "..."}
12. Creative / Value-Based Questions: {"question": "...", "answer": "..."}

---

Subject-specific focus:

Maths:
- Numerical
- HOTS
- Competency

Science:
- Diagram
- Assertion-Reason
- HOTS
- Case-based

SST:
- Source-based
- Case-study
- Assertion-Reason

English:
- Source-based
- Creative writing
- Literature analysis

Hindi:
- Comprehension
- व्याकरण
- Creative/value-based

---

Rules:

- Questions must strictly follow CBSE style
- Focus on understanding and application
- Avoid repetition
- Keep language student-friendly
- Include real-life application where possible

---

Return STRICT JSON only:

{
"mcq": [],
"fill_blanks": [],
"short_answer": [],
"long_answer": [],
"hots": [],
"competency": [],
"case_study": [],
"assertion_reason": [],
"diagram_based": [],
"source_based": [],
"numerical": [],
"creative": []
}`;
    try {
      const raw = await getAIResponse(prompt);
      const jt = raw.replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/\s*```\s*$/i, '').trim();
      const data = JSON.parse(jt);
      setQBank(data);
      saveItem(cacheKey, data);
    } catch (error) {
      showToast('Error generating Question Bank. Please retry.');
    } finally {
      setLoading(false);
    }
  };

  const generateDiagramQuestions = async () => {
    if (!selectedCh) return;
    setLoading(true);
    try {
      const qs = await fetchDiagramQuestions(sub.label, selectedCh);
      setDiagramQuestions(qs);
    } catch (error) {
      showToast('Error generating diagram questions.');
    } finally {
      setLoading(false);
    }
  };

  const loadInteractiveDiagrams = async () => {
    if (!selectedCh) return;
    setLoading(true);
    try {
      const data = await fetchInteractiveDiagrams(sub.label, selectedCh);
      setInteractiveDiagrams(data);
    } catch (error) {
      showToast('Error loading interactive diagrams.');
    } finally {
      setLoading(false);
    }
  };

  const handleDiagramUpload = async (e: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setEvaluatingDiagram(index);
    try {
      showToast('Processing and compressing hand-drawn diagram...');
      const base64 = await compressImage(file, 1000, 1000, 0.75);
      const q = diagramQuestions[index];
      const feedback = await evaluateDiagramImage(base64, q.question, q.answer);
      setDiagramFeedback(prev => ({ ...prev, [index]: feedback }));
    } catch (error) {
      console.error('Diagram evaluation/compression failed:', error);
      showToast("AI Evaluation failed. Please ensure the image is a valid PNG/JPEG layout.");
    } finally {
      setEvaluatingDiagram(null);
    }
  };

  const generateTricks = async (force = false) => {
    if (!selectedCh) return;
    const cacheKey = `tricks_${sub.label}_${selectedCh}`;
    const cached = force ? null : loadItem(cacheKey, null);
    if (cached) {
      setTricks(cached);
      return;
    }

    setLoading(true);
    const langInstr = sub.label.toLowerCase().includes('hindi') 
      ? "\nIMPORTANT: Generate all tricks and explanations strictly in HINDI (Devanagari)." 
      : sub.label.toLowerCase().includes('marathi') 
      ? "\nIMPORTANT: Generate all tricks and explanations strictly in MARATHI (Devanagari)." 
      : "";

    const prompt = `Generate CBSE Class 10 exam tricks and shortcuts for ${sub.label}, chapter: ${selectedCh}.
Rules:
- Give 6–8 tricks only.
- Keep each trick extremely short (1–2 lines).
- Focus on exam shortcuts, memory tips (mnemonics), and important formulas.
- Include common mistakes to avoid.
- Use simple student-friendly language.
${langInstr}

Return ONLY a JSON array of strings:
["1. Title - Explanation", "2. Title - Explanation", ...]`;

    try {
      const raw = await getAIResponse(prompt);
      const jt = raw.replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/\s*```\s*$/i, '').trim();
      const data = JSON.parse(jt);
      setTricks(data);
      saveItem(cacheKey, data);
    } catch (error) {
      showToast('Error generating tricks. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const generateMemoryHacks = async (force = false) => {
    if (!selectedCh) return;
    const cacheKey = `mhacks_${sub.label}_${selectedCh}`;
    const cached = force ? null : loadItem(cacheKey, null);
    if (cached) {
      setMemoryHacks(cached);
      return;
    }

    setLoading(true);
    const langInstr = sub.label.toLowerCase().includes('hindi') 
      ? "\nIMPORTANT: Generate all memory hacks strictly in HINDI (Devanagari)." 
      : sub.label.toLowerCase().includes('marathi') 
      ? "\nIMPORTANT: Generate all memory hacks strictly in MARATHI (Devanagari)." 
      : "";

    const prompt = `Generate memory hacks (mnemonics) for CBSE Class 10 ${sub.label}, chapter: ${selectedCh}.
Rules:
- Give 5–6 memory tricks only.
- Use mnemonics (short words to remember lists).
- Make it fun and easy.
- Keep each hack 1–2 lines.
- Focus on important concepts.
${langInstr}

Return ONLY a JSON array of strings in this format:
["- Concept: Hack", "- Concept: Hack", ...]`;

    try {
      const raw = await getAIResponse(prompt);
      const jt = raw.replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/\s*```\s*$/i, '').trim();
      const data = JSON.parse(jt);
      setMemoryHacks(data);
      saveItem(cacheKey, data);
    } catch (error) {
      showToast('Error generating memory hacks.');
    } finally {
      setLoading(false);
    }
  };

  const generateFormulas = async (force = false) => {
    if (!selectedCh) return;
    setFormulasLoading(true);
    try {
      const cacheKey = `formulas_${sub.label}_${selectedCh}`;
      const cached = force ? null : loadItem<any[]>(cacheKey, null);
      if (cached) {
        setFormulas(cached);
        return;
      }
      const data = await fetchFormulasForChapter(sub.label, selectedCh);
      setFormulas(data);
      saveItem(cacheKey, data);
    } catch (error) {
      showToast('Error generating formula sheet.');
    } finally {
      setFormulasLoading(false);
    }
  };

  useEffect(() => {
    if (activeTab === 'formulas' && selectedCh && formulas.length === 0 && !formulasLoading) {
      generateFormulas();
    }
  }, [activeTab, selectedCh, formulas.length, formulasLoading]);

  const generateStudyGuide = async (force = false) => {
    if (!selectedCh) return;
    setStudyGuideLoading(true);
    try {
      const cacheKey = `studyguide_${sub.label}_${selectedCh}`;
      const cached = force ? null : loadItem<any>(cacheKey, null);
      if (cached) {
        setStudyGuide(cached);
        return;
      }
      const data = await fetchStudyGuideForChapter(sub.label, selectedCh);
      setStudyGuide(data);
      saveItem(cacheKey, data);
    } catch (error) {
      showToast('Error generating study guide.');
    } finally {
      setStudyGuideLoading(false);
    }
  };

  useEffect(() => {
    if (activeTab === 'studyguide' && selectedCh && !studyGuide && !studyGuideLoading) {
      generateStudyGuide();
    }
  }, [activeTab, selectedCh, studyGuide, studyGuideLoading]);

  const generateNotes = async (force = false) => {
    if (!selectedCh) return;
    setLoading(true);
    const cacheKey = `ainotes_${selectedCh}_${detailLevel}`;
    const cached = force ? null : loadItem(cacheKey, null);
    
    if (cached) {
      setAiNotes(cached);
      setLoading(false);
      return;
    }

    const detailGuides = {
      concise: "Keep it extremely brief. Maximum 3-4 key points. One summary sentence.",
      balanced: "Standard revision notes. 5-7 key points, essential formulas and terms.",
      detailed: "Extensive notes. Deep dive into concepts, multiple examples, and comprehensive coverage."
    };

    const langInstr = sub.label.toLowerCase().includes('hindi') 
      ? "\nIMPORTANT: The subject is Hindi. Generate all notes, summaries, and definitions strictly in HINDI (Devanagari)." 
      : sub.label.toLowerCase().includes('marathi') 
      ? "\nIMPORTANT: The subject is Marathi. Generate all notes, summaries, and definitions strictly in MARATHI (Devanagari)." 
      : "";

    const prompt = `You are a CBSE Class 10 teacher creating ${detailLevel.toUpperCase()} revision notes for ${sub.label}, chapter: ${selectedCh}.
${detailGuides[detailLevel]}
${langInstr}
Keep everything bullet-style and scannable. Return ONLY valid JSON (no markdown, no extra text):
{
  "summary": "Chapter summary adapted to detail level",
  "keyPoints": ["point 1", "point 2", ...],
  "formulas": ["formula 1", ...],
  "definitions": ["Term: definition"],
  "importantQuestions": [{"q": "question", "a": "answer", "marks": 2}]
}`;

    try {
      const raw = await getAIResponse(prompt);
      const jt = raw.replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/\s*```\s*$/i, '').trim();
      const data = JSON.parse(jt);
      setAiNotes(data);
      if (!force) saveItem(cacheKey, data);
    } catch (error) {
      showToast('Offline mode: Using cached or built-in content.');
    } finally {
      setLoading(false);
    }
  };

  const saveToNotebook = () => {
    if (!aiNotes || !selectedCh) return;
    
    const existing = loadItem<any[]>('vidypath_notebook_sources', []);
    const alreadyExists = existing.find(s => s.title === `${sub.label}: ${selectedCh}`);
    
    if (alreadyExists) {
      showToast('This chapter is already in your notebook.');
      return;
    }

    const content = `SUMMARY:\n${aiNotes.summary}\n\nKEY POINTS:\n${aiNotes.keyPoints.join('\n')}\n\nDEFINITIONS:\n${aiNotes.definitions.join('\n')}`;
    
    const newSource = {
      id: Date.now().toString(),
      title: `${sub.label}: ${selectedCh}`,
      content: content,
      type: 'chapter',
      subject: subjectKey
    };

    saveItem('vidypath_notebook_sources', [...existing, newSource]);
    showToast('Saved to Study Notebook!');
  };

  const generateNotes2 = async (type: 'quick' | 'lesson', force = false) => {
    if (!selectedCh) return;
    setLoading(true);
    
    const cacheKey = `ainotes_v2_${type}_${selectedCh}`;
    const cached = force ? null : loadItem(cacheKey, null);
    
    if (cached) {
      if (type === 'quick') {
        setAiNotes2Quick(cached);
      } else {
        setAiNotes2Lesson(cached);
      }
      setLoading(false);
      return;
    }

    const langInstr = sub.label.toLowerCase().includes('hindi') 
      ? "\nIMPORTANT: The subject is Hindi. Please write all generated notes, explanations, summaries, and definitions strictly in HINDI (using Devanagari script)." 
      : sub.label.toLowerCase().includes('marathi') 
      ? "\nIMPORTANT: The subject is Marathi. Please write all generated notes, explanations, summaries, and definitions strictly in MARATHI (using Devanagari script)." 
      : "";

    let prompt = "";
    if (type === 'quick') {
      prompt = `You are an expert CBSE Class 10 teacher creating comprehensive Notes 2.0: "Quick Notes" for ${sub.label}, chapter: ${selectedCh}.
The purpose of Quick Notes is to enable a 1-2 minute high-impact revision right before the test.
${langInstr}

Please create highly structured, highly readable brief notes containing:
1. Revision Summary (Max 5 sentences, high-impact overview)
2. Core Keywords (Key glossary terms with super-short, punchy definitions, 4-8 items)
3. Essential Formulas & Equations (If mathematics/science) or Crucial Theories/Themes (If history, geography, languages)
4. Important Facts & Milestones (Crucial numbers, dates, values, or historical/scientific data points, 4-8 items)
5. Crucial Exam Points (Common board topics, examiner highlights, 4-6 items)

Keep language student-friendly, encouraging, and clear.
Return ONLY valid JSON (no markdown, no extra text):
{
  "summary": "1-2 min concise revision summary",
  "keywords": ["Concept A: definition", "Concept B: definition", ...],
  "formulas": ["Equation A: detail", ...],
  "importantFacts": ["Fact 1", "Fact 2", ...],
  "examPoints": ["Hot point 1", "Hot point 2", ...]
}`;
    } else {
      prompt = `You are an elite CBSE Class 10 educator crafting comprehensive Notes 2.0: "Lesson Notes" for ${sub.label}, chapter: ${selectedCh}.
The Lesson Notes MUST be deep, complete, and highly thorough—sufficient for a student to fully understand and learn the entire chapter in depth from scratch without needing to watch any supplementary videos.

${langInstr}

Please write complete explanations for all major concepts, step-by-step, leaving no important detail or derivation/reasoning behind. Ensure the language is simple, clear, Class 10 friendly, engaging and helpful.

Structure your response strictly following these 9 parts:
1. Introduction: Detailed explanation of what the chapter is about and its real-world importance/context.
2. Key Concepts: Major learning concepts broken down cleanly.
3. Important Definitions: Highlighted absolute must-know key terms with formal scientific/board-level definitions.
4. Detailed Explanation: In-depth step-by-step academic explanation of all subtopics, major processes, proofs, or logical sequences under those concepts. Do not skip any critical subtopics or concepts.
5. Solved Examples: Concrete solved numerical problems, textual analysis examples, or application scenario cases with clear steps and justifications.
6. Common Mistakes: Frequent conceptual traps or calculation errors that students make in CBSE Board exams and how to prevent them.
7. Exam Tips: High-frequency exam topics, writing tips, CBSE sample paper focus areas, and marks-multiplier advice.
8. Diagrams & Visual Aids: Verbal walk-throughs, step-by-step sketching guides, or labeling details of the critical diagrams associated with this chapter (or system pathways/flowcharts for non-diagram subjects).
9. Summary: A highly structured, end-of-lesson concise bulleted recovery points list for final checklist verification.

Return ONLY valid JSON (no markdown, no extra text):
{
  "introduction": {
    "about": "Detailed about text",
    "importance": "Why it is important details"
  },
  "keyConcepts": [
    {
      "name": "Concept name 1",
      "explanation": "Thorough concept explanation"
    },
    ...
  ],
  "definitions": [
    {
      "term": "Term/Law/Rule 1",
      "definition": "Formal board-approved definition"
    },
    ...
  ],
  "detailedExplanation": [
    {
      "subheading": "Subtopic heading",
      "content": "Deep step-by-step scientific/social/academic details. Cover equations, characteristics, types, or sequences completely. Do not summarize or keep it short."
    },
    ...
  ],
  "solvedExamples": [
    {
      "problem": "Problem statement or question detail",
      "solution": "Detailed step-by-step complete solution and explanation"
    },
    ...
  ],
  "commonMistakes": [
    {
      "mistake": "The misconception or incorrect calculation text",
      "correction": "The correct scientific, mathematical or grammatical process with explanations"
    },
    ...
  ],
  "examTips": [
    "Tip 1 or high-yield CBSE focus point",
    ...
  ],
  "diagrams": [
    {
      "name": "Diagram/Flowchart name",
      "walkthrough": "Visual walkthrough, parts labeling guide, and steps to draw in CBSE exam paper correctly"
    },
    ...
  ],
  "summaryPoints": [
    "Bullet point 1",
    "Bullet point 2",
    ...
  ]
}`;
    }

    try {
      const raw = await getAIResponse(prompt);
      const jt = raw.replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/\s*```\s*$/i, '').trim();
      const data = JSON.parse(jt);
      if (type === 'quick') {
        setAiNotes2Quick(data);
      } else {
        setAiNotes2Lesson(data);
      }
      if (!force) saveItem(cacheKey, data);
    } catch (error) {
      showToast('Error generating Notes 2.0. Please check your connection.');
    } finally {
      setLoading(false);
    }
  };

  const saveNotes2ToNotebook = (type: 'quick' | 'lesson') => {
    const data = type === 'quick' ? aiNotes2Quick : aiNotes2Lesson;
    if (!data || !selectedCh) return;
    
    const existing = loadItem<any[]>('vidypath_notebook_sources', []);
    const titleVal = `${sub.label}: ${selectedCh} (${type === 'quick' ? 'Quick Notes 2.0' : 'Lesson Notes 2.0'})`;
    const alreadyExists = existing.find(s => s.title === titleVal);
    
    if (alreadyExists) {
      showToast('This notes version is already in your notebook.');
      return;
    }

    let content = "";
    if (type === 'quick') {
      content = `QUICK NOTES SUMMARY 2.0:\n${data.summary}\n\nKEYWORDS:\n${data.keywords?.join('\n') || ''}\n\nFORMULAS:\n${data.formulas?.join('\n') || ''}\n\nIMPORTANT FACTS:\n${data.importantFacts?.join('\n') || ''}\n\nEXAM POINTS:\n${data.examPoints?.join('\n') || ''}`;
    } else {
      const intro = `INTRODUCTION:\n${data.introduction?.about || ''}\nImportance: ${data.introduction?.importance || ''}`;
      const concepts = `KEY CONCEPTS:\n${data.keyConcepts?.map((kc: any) => `${kc.name}: ${kc.explanation}`).join('\n') || ''}`;
      const definitions = `IMPORTANT DEFINITIONS:\n${data.definitions?.map((d: any) => `${d.term}: ${d.definition}`).join('\n') || ''}`;
      const detailed = `DETAILED EXPLANATION:\n${data.detailedExplanation?.map((de: any) => `## ${de.subheading}\n${de.content}`).join('\n') || ''}`;
      const examples = `SOLVED EXAMPLES:\n${data.solvedExamples?.map((ex: any) => `Q: ${ex.problem}\nA: ${ex.solution}`).join('\n\n') || ''}`;
      const mistakes = `COMMON MISTAKES:\n${data.commonMistakes?.map((cm: any) => `Mistake: ${cm.mistake}\nCorrection: ${cm.correction}`).join('\n\n') || ''}`;
      const tips = `EXAM TIPS:\n${data.examTips?.join('\n') || ''}`;
      const diagrams = `DIAGRAMS & FLOWCHARTS:\n${data.diagrams?.map((diag: any) => `Diagram Name: ${diag.name}\nWalkthrough: ${diag.walkthrough}`).join('\n\n') || ''}`;
      const summary = `SUMMARY:\n${data.summaryPoints?.join('\n') || ''}`;
      
      content = `${intro}\n\n${concepts}\n\n${definitions}\n\n${detailed}\n\n${examples}\n\n${mistakes}\n\n${tips}\n\n${diagrams}\n\n${summary}`;
    }
    
    const newSource = {
      id: Date.now().toString(),
      title: titleVal,
      content: content,
      type: 'chapter',
      subject: subjectKey
    };

    saveItem('vidypath_notebook_sources', [...existing, newSource]);
    showToast('Saved Notes 2.0 to Study Notebook!');
  };

  return (
    <div className="max-w-[780px] mx-auto px-4 py-8 pb-24">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <button 
          onClick={() => {
            if (selectedCh) setSelectedCh('');
            else navigateTo('home');
          }}
          className="inline-flex items-center gap-2 px-4 py-2 bg-surface border border-border rounded-xl text-sm font-semibold text-ink2 hover:bg-orange-lt hover:text-orange hover:border-orange-mid transition-all shadow-sm shrink-0"
        >
          <ArrowLeft className="w-4 h-4" />
          {selectedCh ? 'All Chapters' : 'Back Home'}
        </button>

        {selectedCh && (
          <div className="flex items-center gap-2 flex-grow max-w-xs">
            <div className="text-[10px] font-black uppercase tracking-widest text-ink3 hidden md:block whitespace-nowrap">Switch:</div>
            <select 
              value={selectedCh} 
              onChange={handleChChange}
              className="w-full p-2 bg-surface border border-border rounded-xl text-[11px] font-bold text-ink outline-none focus:border-orange focus:ring-4 focus:ring-orange/10 transition-all cursor-pointer"
            >
              {chapters.map((ch, i) => (
                <option key={`ch-opt-${i}`} value={ch.name}>{i+1}. {ch.name}</option>
              ))}
            </select>
          </div>
        )}
      </div>

      <div className="space-y-6">
        {!selectedCh ? (
          <div className="space-y-8 animate-fadeUp">
            <div className="space-y-2">
              <div className="text-[10px] font-black uppercase tracking-[0.2em] text-orange">{sub.label}</div>
              <h2 className="text-4xl font-display leading-tight">Syllabus Index</h2>
              <p className="text-sm text-ink3 font-medium">Select a chapter to explore notes, tricks, and question banks.</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {chapters.map((ch, i) => {
                const progress = loadItem<Record<string, any>>('vidypath_progress_v4', {});
                const record = progress[`${subjectKey}__${ch.name}`];
                const pct = record ? Math.round((record.bestScore / record.totalOut) * 100) : 0;
                
                return (
                  <button
                    key={i}
                    onClick={() => setSelectedCh(ch.name)}
                    className="group relative bg-surface border border-border p-6 rounded-[32px] text-left hover:border-orange hover:shadow-xl hover:shadow-orange/5 transition-all duration-300 overflow-hidden active:scale-[0.98]"
                  >
                    <div className="relative z-10 space-y-4">
                      <div className="flex items-center justify-between">
                        <div className="w-10 h-10 bg-white border border-border rounded-2xl flex items-center justify-center font-display text-lg text-ink3 group-hover:bg-orange group-hover:text-white group-hover:border-orange transition-all duration-300">
                          {i + 1}
                        </div>
                        {record && (
                           <div className={cn(
                            "px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-widest text-white",
                            pct >= 80 ? "bg-green-500" : pct >= 50 ? "bg-orange" : "bg-red-500"
                          )}>
                            {pct}% Mastered
                          </div>
                        )}
                      </div>
                      <div>
                        <h4 className="text-lg font-display leading-tight group-hover:text-ink">{ch.name}</h4>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-[9px] font-black uppercase text-ink3 tracking-widest">Board Exam Chapter</span>
                          {record && <div className="w-1 h-1 bg-border rounded-full" />}
                          {record && <span className="text-[9px] font-black uppercase text-green-600 tracking-widest">Active Progress</span>}
                        </div>
                      </div>
                      
                      {/* Mini Progress Bar */}
                      {record && (
                        <div className="w-full h-1 bg-surface2 rounded-full overflow-hidden mt-4">
                          <motion.div 
                            initial={{ width: 0 }}
                            animate={{ width: `${pct}%` }}
                            className={cn("h-full", pct >= 80 ? "bg-green-500" : pct >= 50 ? "bg-orange" : "bg-red-500")}
                          />
                        </div>
                      )}
                    </div>

                    {/* Subtle BG Graphic */}
                    <div className="absolute top-0 right-0 p-4 opacity-[0.03] group-hover:opacity-[0.07] transition-opacity">
                       <BookOpen className="w-24 h-24 rotate-12" />
                    </div>
                    
                    <div className="absolute bottom-6 right-6 opacity-0 group-hover:opacity-100 transition-all translate-x-2 group-hover:translate-x-0">
                      <ChevronRight className="w-5 h-5 text-orange" />
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        ) : (
          <>
            <div className="border-b border-border pb-6 flex items-start justify-between gap-4">
              <div>
                <div className="text-[10px] font-bold uppercase tracking-[0.15em] text-ink3 mb-2">{sub.label}</div>
                <h2 className="text-3xl font-display leading-tight">{selectedCh}</h2>
              </div>
              {(() => {
                const progress = loadItem<Record<string, any>>('vidypath_progress_v4', {});
                const record = progress[`${subjectKey}__${selectedCh}`];
                if (!record) return null;
                const pct = Math.round((record.bestScore / record.totalOut) * 100);
                return (
                  <div className="flex flex-col items-end gap-1">
                    <div className={cn(
                      "px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest text-white shadow-md",
                      pct >= 80 ? "bg-green-500 shadow-green-200" : pct >= 50 ? "bg-orange shadow-orange-100" : "bg-red-500 shadow-red-100"
                    )}>
                      {pct >= 80 ? 'Mastered' : pct >= 50 ? 'Proficient' : 'Learning'}
                    </div>
                    <div className="text-[10px] font-bold text-ink3">Best Score: {record.bestScore}/{record.totalOut}</div>
                  </div>
                );
              })()}
            </div>

            <div className="space-y-6 animate-fadeUp">
            {/* Tabs */}
            <div className="flex gap-2 p-1.5 bg-surface2 border border-border rounded-[24px] overflow-x-auto no-scrollbar shadow-inner">
              {[
                { id: 'ainotes', label: 'AI Notes', icon: Brain },
                { id: 'studyguide', label: 'Study Guide', icon: Compass },
                { id: 'formulas', label: 'Formula Sheet', icon: Calculator },
                { id: 'tricks', label: 'Tricks', icon: Zap },
                { id: 'pyqs', label: 'Real PYQs', icon: Award },
                { id: 'questions', label: 'Questions', icon: HelpCircle },
                { id: 'diagrams', label: 'Diagrams', icon: Presentation, show: ['Science', 'Mathematics', 'Social Studies'].includes(sub.label) },
                { id: 'video', label: 'Video', icon: Video },
              ].filter(t => t.show === undefined || t.show).map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as Tab)}
                  className={cn(
                    "flex-1 flex items-center justify-center gap-2 px-5 py-3 text-[11px] font-black uppercase tracking-tight rounded-[18px] whitespace-nowrap transition-all duration-300",
                    activeTab === tab.id 
                      ? "bg-orange text-white shadow-lg shadow-orange/25 scale-[1.02]" 
                      : "text-ink3 hover:text-ink hover:bg-surface"
                  )}
                >
                  <tab.icon className={cn("w-4 h-4", activeTab === tab.id ? "stroke-[2.5px]" : "stroke-[2px]")} />
                  {tab.label}
                </button>
              ))}
              <button
                onClick={() => navigateTo('quiz', subjectKey, chapters.findIndex(c => c.name === selectedCh))}
                className="flex items-center justify-center gap-2 px-6 py-3 text-[11px] font-black uppercase tracking-tight rounded-[18px] whitespace-nowrap bg-ink text-white hover:bg-orange hover:shadow-lg hover:shadow-orange/20 transition-all ml-1 active:scale-95"
              >
                Start Quiz →
              </button>
            </div>

            {/* Panels */}
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.15 }}
                className="space-y-4"
              >
                {activeTab === 'studyguide' && (
                  <div className="space-y-6 animate-fadeUp text-left">
                    {/* Header */}
                    <div className="bg-gradient-to-r from-indigo-50 to-purple-50 border border-indigo-100 rounded-3xl p-6 relative overflow-hidden flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                      <div className="space-y-2 relative z-10 max-w-xl">
                        <div className="flex items-center gap-1.5 text-indigo-700">
                          <Compass className="w-5 h-5 text-indigo-600 animate-spin-slow" />
                          <span className="text-[10px] font-black uppercase tracking-widest">Ultimate revision resource</span>
                        </div>
                        <h3 className="font-extrabold text-xl tracking-tight text-slate-800">Comprehensive Board Study Guide</h3>
                        <p className="text-[12px] text-slate-600 leading-relaxed">
                          Your active companion for high-yield recall. Synthesizing chapter-critical definitions, conceptual structures, board-specific mnemonics, and essential exam warnings dynamically.
                        </p>
                      </div>
                      <button
                        onClick={() => generateStudyGuide(true)}
                        disabled={studyGuideLoading}
                        className="px-4 py-2 border border-indigo-200 hover:border-indigo-300 rounded-xl text-[10px] uppercase font-black tracking-widest text-indigo-700 hover:bg-white bg-white/50 transition-all flex items-center justify-center gap-1.5 shrink-0 self-start md:self-center cursor-pointer"
                      >
                        <RefreshCw className={cn("w-3.5 h-3.5", studyGuideLoading && "animate-spin")} />
                        Re-Synthesize Guide
                      </button>
                    </div>

                    {studyGuideLoading ? (
                      <div className="p-12 text-center bg-slate-50 border border-border rounded-3xl space-y-4">
                        <div className="relative w-14 h-14 mx-auto flex items-center justify-center">
                          <RefreshCw className="w-8 h-8 animate-spin text-indigo-500 absolute" />
                          <Sparkles className="w-4 h-4 text-amber-500 animate-pulse" />
                        </div>
                        <div className="space-y-1.5">
                          <h5 className="font-extrabold text-sm text-indigo-900 mb-1">Retrieving Core Chapter Intelligence</h5>
                          <p className="text-[11px] text-ink3 leading-relaxed max-w-xs mx-auto">Structuring key concepts, mnemonics, and common student pitfalls specifically for class 10 standard board templates...</p>
                        </div>
                      </div>
                    ) : studyGuide ? (
                      <div className="space-y-6">
                        {/* Chapter Overview Section */}
                        <div className="bg-white border border-border rounded-3xl p-6 shadow-sm space-y-4">
                          <h4 className="font-extrabold text-sm text-indigo-900 flex items-center gap-2 border-b border-border pb-3.5">
                            <span className="w-2.5 h-5 bg-indigo-500 rounded-md"></span>
                            Chapter Executive Summary
                          </h4>
                          <div className="markdown-body font-sans text-xs text-ink leading-relaxed space-y-2">
                            <Markdown>{studyGuide.overview}</Markdown>
                          </div>
                        </div>

                        {/* Key Concepts Grid Section */}
                        <div className="space-y-3">
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] font-black uppercase text-ink3 tracking-widest">Section 1: Micro-Concept Drilldown</span>
                          </div>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {studyGuide.keyConcepts?.map((kc: any, idx: number) => (
                              <div key={idx} className="bg-white border border-border hover:border-slate-350 hover:shadow-md rounded-3xl p-5 transition-all flex flex-col justify-between">
                                <div className="space-y-3.5">
                                  <div className="flex items-center justify-between gap-3">
                                    <h5 className="font-black text-sm text-indigo-900">{kc.conceptName}</h5>
                                    <span className={cn(
                                      "px-2 py-0.5 rounded-[6px] text-[8px] font-black uppercase tracking-wider",
                                      kc.importance?.toLowerCase().includes('critical') 
                                        ? "bg-rose-50 text-rose-600 border border-rose-100" 
                                        : "bg-indigo-50 text-indigo-600 border border-indigo-100"
                                    )}>
                                      {kc.importance || 'High Yield'}
                                    </span>
                                  </div>
                                  <div className="markdown-body font-sans text-[11px] text-slate-700 leading-relaxed">
                                    <Markdown>{kc.explanation}</Markdown>
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Mnemonics & Tricks Deck Section */}
                        <div className="space-y-3">
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] font-black uppercase text-ink3 tracking-widest">Section 2: Memory Bridges & Mnemonics</span>
                          </div>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {studyGuide.mnemonics?.map((m: any, idx: number) => (
                              <div key={idx} className="bg-gradient-to-br from-amber-50/40 via-white to-amber-50/10 border-2 border-dashed border-amber-200 rounded-3xl p-5 shadow-sm space-y-3.5">
                                <div className="flex items-center gap-2 text-amber-700">
                                  <Zap className="w-4 h-4 text-amber-500 fill-amber-500" />
                                  <h6 className="font-extrabold text-[12px] uppercase tracking-wide">{m.title}</h6>
                                </div>
                                <div className="p-3 bg-amber-50/60 border border-amber-150 rounded-2xl text-center">
                                  <span className="font-semibold text-[13px] tracking-wide text-amber-900 font-mono italic">
                                    "{m.phrase}"
                                  </span>
                                </div>
                                <div className="markdown-body font-sans text-[11px] text-zinc-700 leading-relaxed space-y-1">
                                  <Markdown>{m.breakdown}</Markdown>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Syllabi Tips Section */}
                        <div className="bg-white border border-border rounded-3xl p-6 shadow-sm space-y-4">
                          <h4 className="font-extrabold text-sm text-rose-700 flex items-center gap-2 border-b border-rose-100 pb-3.5">
                            <span className="w-2.5 h-5 bg-rose-500 rounded-md"></span>
                            Proactive Syllabus Warnings & Score Enhancers
                          </h4>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4.5">
                            {studyGuide.syllabiTips?.map((tip: string, idx: number) => (
                              <div key={idx} className="flex gap-3 items-start p-4 bg-rose-50/20 border border-rose-100 rounded-2xl">
                                <CheckCircle className="w-4 h-4 text-green-600 mt-1 shrink-0" />
                                <div className="text-[11.5px] leading-relaxed text-slate-700 font-semibold font-sans markdown-body">
                                  <Markdown>{tip}</Markdown>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="p-12 text-center bg-slate-50 border border-border rounded-3xl space-y-4">
                        <div className="w-16 h-16 bg-indigo-50 text-indigo-600 rounded-full flex items-center justify-center mx-auto text-2xl">
                          <Compass className="w-7 h-7" />
                        </div>
                        <h4 className="font-extrabold text-sm text-slate-800">Comprehensive Study Guide Not Generated Yet</h4>
                        <p className="text-[11px] text-slate-600 leading-relaxed max-w-xs mx-auto">
                          Automatically integrate chapter overview text, cognitive mnemonics for hard topics, and critical board scoring methods in one dashboard.
                        </p>
                        <button 
                          onClick={() => generateStudyGuide()}
                          className="bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-3 rounded-xl text-xs font-black tracking-widest uppercase shadow-md shadow-indigo-100 flex items-center gap-2 mx-auto active:scale-95 transition-all cursor-pointer"
                        >
                          <Sparkles className="w-4 h-4" />
                          Generate Custom Study Guide
                        </button>
                      </div>
                    )}
                  </div>
                )}

                {activeTab === 'ainotes' && (
                  <div className="space-y-4">
                    <div className="bg-surface p-5 rounded-2xl border border-border shadow-sm space-y-5">
                      
                      {/* Note System Switcher */}
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-border/50">
                        <div>
                          <h3 className="text-base font-bold text-ink">Smart Learning Notes</h3>
                          <p className="text-[11px] text-ink2">Read comprehensive explanations or quick summary points for the chapter.</p>
                        </div>
                        <div className="flex bg-surface2 p-0.5 rounded-xl border border-border shrink-0 self-start sm:self-center">
                          <button
                            onClick={() => setNoteSystem('v2')}
                            className={cn(
                              "px-3 py-1.5 text-[10px] font-bold rounded-lg transition-all flex items-center gap-1.5",
                              noteSystem === 'v2' 
                                ? "bg-orange text-white shadow-sm" 
                                : "text-ink3 hover:text-ink2"
                            )}
                          >
                            <Sparkles className="w-3.5 h-3.5" />
                            Notes 2.0 (Ultimate)
                          </button>
                          <button
                            onClick={() => setNoteSystem('v1')}
                            className={cn(
                              "px-3 py-1.5 text-[10px] font-bold rounded-lg transition-all flex items-center gap-1.5",
                              noteSystem === 'v1' 
                                ? "bg-orange text-white shadow-sm" 
                                : "text-ink3 hover:text-ink2"
                            )}
                          >
                            <BookOpen className="w-3.5 h-3.5" />
                            Legacy Notes (1.0)
                          </button>
                        </div>
                      </div>

                      {/* Notes 2.0 (Ultimate Learning Flow) */}
                      {noteSystem === 'v2' && (
                        <div className="space-y-4">
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                            <div className="flex items-center gap-2">
                              <GraduationCap className="w-4 h-4 text-orange" />
                              <span className="text-[10px] font-bold text-ink3 uppercase tracking-widest">Notes 2.0 Category</span>
                            </div>
                            <div className="flex gap-1 p-1 bg-surface2 rounded-xl border border-border shrink-0">
                              <button
                                onClick={() => setNotes2Type('quick')}
                                className={cn(
                                  "px-3 py-1.5 text-[9px] font-black uppercase tracking-tight rounded-lg transition-all flex items-center gap-1.5",
                                  notes2Type === 'quick' ? "bg-white text-orange shadow-sm border border-orange/10" : "text-ink3 hover:text-ink2"
                                )}
                              >
                                ⚡ Quick Notes (1-2 Min Revision)
                              </button>
                              <button
                                onClick={() => setNotes2Type('lesson')}
                                className={cn(
                                  "px-3 py-1.5 text-[9px] font-black uppercase tracking-tight rounded-lg transition-all flex items-center gap-1.5",
                                  notes2Type === 'lesson' ? "bg-white text-orange shadow-sm border border-orange/10" : "text-ink3 hover:text-ink2"
                                )}
                              >
                                📚 Lesson Notes (Complete Learning)
                              </button>
                            </div>
                          </div>

                          {/* Quick Notes 2.0 Layout */}
                          {notes2Type === 'quick' && (
                            !aiNotes2Quick ? (
                              <div className="pt-6 text-center space-y-4">
                                <div className="w-16 h-16 bg-orange-lt rounded-full flex items-center justify-center mx-auto text-3xl">⚡</div>
                                <h4 className="font-display text-lg">Quick Notes 2.0</h4>
                                <p className="text-[11px] text-ink2 leading-relaxed max-w-sm mx-auto">
                                  Generate 1-2 minute revision notes containing keywords, essential formulas, important facts, and hot exam points.
                                </p>
                                <button 
                                  onClick={() => generateNotes2('quick')}
                                  disabled={loading}
                                  className="bg-orange text-white px-8 py-3 rounded-xl text-sm font-bold shadow-lg shadow-orange/30 disabled:opacity-50 flex items-center gap-2 mx-auto transition-all active:scale-95"
                                >
                                  {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Brain className="w-4 h-4" />}
                                  Generate 2.0 Quick Notes
                                </button>
                              </div>
                            ) : (
                              <div className="space-y-6 pt-4 border-t border-border border-dashed">
                                {/* Summary banner */}
                                <div className="bg-orange-lt border border-orange/20 p-5 rounded-2xl shadow-sm space-y-2">
                                  <div className="flex items-center justify-between">
                                    <div className="flex items-center gap-2 text-orange font-bold text-xs uppercase tracking-wider">
                                      <Zap className="w-3.5 h-3.5" />
                                      1-2 Minute Revision Summary
                                    </div>
                                    <button 
                                      onClick={() => saveNotes2ToNotebook('quick')}
                                      className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-border rounded-lg text-[10px] font-black uppercase text-orange hover:bg-orange hover:text-white transition-all shadow-sm active:scale-95"
                                    >
                                      <Save className="w-3 h-3" />
                                      Add to Notebook
                                    </button>
                                  </div>
                                  <p className="text-sm text-ink leading-relaxed font-semibold">{aiNotes2Quick.summary}</p>
                                </div>

                                {/* Keywords Grid */}
                                {aiNotes2Quick.keywords?.length > 0 && (
                                  <div className="space-y-3">
                                    <h4 className="text-[10px] font-bold text-sky-500 uppercase tracking-widest flex items-center gap-2">
                                      🔑 Core Keywords & Definitions
                                    </h4>
                                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                      {aiNotes2Quick.keywords.map((kw: string, idx: number) => {
                                        const parts = kw.split(':');
                                        const name = parts[0];
                                        const desc = parts.slice(1).join(':');
                                        return (
                                          <div key={idx} className="bg-surface2 p-4 rounded-xl border border-border shadow-xs">
                                            <div className="font-semibold text-ink text-sm mb-1">{name}</div>
                                            <div className="text-[11px] text-ink2 leading-normal">{desc || 'Critical concept definition'}</div>
                                          </div>
                                        );
                                      })}
                                    </div>
                                  </div>
                                )}

                                {/* Formulas */}
                                {aiNotes2Quick.formulas?.length > 0 && (
                                  <div className="space-y-3">
                                    <h4 className="text-[10px] font-bold text-purple-500 uppercase tracking-widest flex items-center gap-2">
                                      📐 Essential Formulas & Principles
                                    </h4>
                                    <div className="flex flex-wrap gap-2 p-4 bg-purple-50/30 border border-purple-200/50 rounded-2xl">
                                      {aiNotes2Quick.formulas.map((f: string, idx: number) => (
                                        <div key={idx} className="px-4 py-2 bg-white border border-purple-100 rounded-lg text-xs text-purple-700 font-display italic shadow-xs">
                                          {f}
                                        </div>
                                      ))}
                                    </div>
                                  </div>
                                )}

                                {/* Important Facts */}
                                {aiNotes2Quick.importantFacts?.length > 0 && (
                                  <div className="space-y-3">
                                    <h4 className="text-[10px] font-bold text-blue-500 uppercase tracking-widest flex items-center gap-2">
                                      📌 Important Facts & Values
                                    </h4>
                                    <ul className="space-y-2 bg-slate-50/50 p-5 rounded-2xl border border-slate-200/50">
                                      {aiNotes2Quick.importantFacts.map((fact: string, idx: number) => (
                                        <li key={idx} className="flex gap-2 text-xs font-semibold text-slate-700">
                                          <span className="text-sky-500 font-bold">•</span>
                                          <span>{fact}</span>
                                        </li>
                                      ))}
                                    </ul>
                                  </div>
                                )}

                                {/* Exam Points */}
                                {aiNotes2Quick.examPoints?.length > 0 && (
                                  <div className="space-y-3">
                                    <h4 className="text-[10px] font-bold text-emerald-500 uppercase tracking-widest flex items-center gap-2">
                                      🎯 Crucial Exam Practice Points
                                    </h4>
                                    <ul className="space-y-3 bg-emerald-50/30 p-5 rounded-2xl border border-emerald-200/50">
                                      {aiNotes2Quick.examPoints.map((pt: string, idx: number) => (
                                        <li key={idx} className="flex gap-3 text-xs text-emerald-900 font-semibold">
                                          <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                                          <span>{pt}</span>
                                        </li>
                                      ))}
                                    </ul>
                                  </div>
                                )}

                                <div className="text-center pt-6 border-t border-border border-dashed">
                                  <button 
                                    onClick={() => generateNotes2('quick', true)}
                                    disabled={loading}
                                    className="inline-flex items-center gap-2 text-[10px] font-bold text-ink3 uppercase tracking-widest hover:text-orange transition-all disabled:opacity-50"
                                  >
                                    {loading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <RefreshCw className="w-3.5 h-3.5" />}
                                    Not satisfied? Regenerate Quick Notes 2.0
                                  </button>
                                </div>
                              </div>
                            )
                          )}

                          {/* Lesson Notes 2.0 Layout */}
                          {notes2Type === 'lesson' && (
                            !aiNotes2Lesson ? (
                              <div className="pt-6 text-center space-y-4">
                                <div className="w-16 h-16 bg-blue-50 text-blue-600 border border-blue-100 rounded-full flex items-center justify-center mx-auto text-3xl">📚</div>
                                <h4 className="font-display text-lg">Lesson Notes 2.0</h4>
                                <p className="text-[11px] text-ink2 leading-relaxed max-w-sm mx-auto">
                                  Generate exhaustive step-by-step Class 10 textbook content. Comprehensive enough that you can learn the entire chapter even without videos!
                                </p>
                                <button 
                                  onClick={() => generateNotes2('lesson')}
                                  disabled={loading}
                                  className="bg-orange text-white px-8 py-3 rounded-xl text-sm font-bold shadow-lg shadow-orange/30 disabled:opacity-50 flex items-center gap-2 mx-auto transition-all active:scale-95"
                                >
                                  {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Brain className="w-4 h-4" />}
                                  Generate 2.0 Lesson Notes
                                </button>
                              </div>
                            ) : (
                              <div className="space-y-8 pt-4 border-t border-border border-dashed animate-fadeIn">
                                {/* Save to Notebook Action */}
                                <div className="flex justify-end">
                                  <button 
                                    onClick={() => saveNotes2ToNotebook('lesson')}
                                    className="flex items-center gap-1.5 px-4 py-2 bg-orange text-white rounded-xl text-xs font-bold hover:bg-orange-mid transition-all shadow-md active:scale-95"
                                  >
                                    <Save className="w-3.5 h-3.5" />
                                    Add Lesson Notes to Notebook
                                  </button>
                                </div>

                                {/* Section 1: Introduction */}
                                {aiNotes2Lesson.introduction && (
                                  <section className="space-y-3 bg-gradient-to-br from-indigo-50/40 to-sky-50/40 p-6 rounded-2xl border border-indigo-100">
                                    <h3 className="text-xs font-black text-indigo-800 uppercase tracking-wider flex items-center gap-2">
                                      🏁 1. Introduction & Importance
                                    </h3>
                                    <div className="space-y-3">
                                      <div>
                                        <h4 className="text-xs font-bold text-indigo-950 mb-1">About this chapter:</h4>
                                        <p className="text-xs text-slate-800 leading-relaxed font-semibold">{aiNotes2Lesson.introduction.about || aiNotes2Lesson.introduction}</p>
                                      </div>
                                      {aiNotes2Lesson.introduction.importance && (
                                        <div>
                                          <h4 className="text-xs font-bold text-indigo-950 mb-1">Why it is crucial:</h4>
                                          <p className="text-xs text-slate-800 leading-relaxed font-semibold">{aiNotes2Lesson.introduction.importance}</p>
                                        </div>
                                      )}
                                    </div>
                                  </section>
                                )}

                                {/* Section 2: Key Concepts */}
                                {aiNotes2Lesson.keyConcepts?.length > 0 && (
                                  <section className="space-y-4">
                                    <h3 className="text-xs font-black text-sky-600 uppercase tracking-widest flex items-center gap-2">
                                      💡 2. Key Concepts (Class 10 Easy-to-Understand)
                                    </h3>
                                    <div className="space-y-3">
                                      {aiNotes2Lesson.keyConcepts.map((kc: any, idx: number) => (
                                        <div key={idx} className="bg-surface2 p-5 rounded-xl border border-border space-y-1.5">
                                          <h4 className="text-xs font-black text-ink flex items-center gap-2 uppercase tracking-wide">
                                            <span className="text-sky-500">✦</span> {kc.name || kc.conceptName}
                                          </h4>
                                          <p className="text-xs text-ink2 leading-relaxed font-semibold">{kc.explanation}</p>
                                        </div>
                                      ))}
                                    </div>
                                  </section>
                                )}

                                {/* Section 3: Important Definitions */}
                                {aiNotes2Lesson.definitions?.length > 0 && (
                                  <section className="space-y-4">
                                    <h3 className="text-xs font-black text-teal-600 uppercase tracking-widest flex items-center gap-2">
                                      📖 3. Important Definitions & Rules
                                    </h3>
                                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                      {aiNotes2Lesson.definitions.map((def: any, idx: number) => (
                                        <div key={idx} className="p-4 bg-teal-50/20 border border-teal-100 rounded-xl relative overflow-hidden">
                                          <div className="absolute top-0 right-0 w-8 h-8 opacity-10 bg-teal-500 rounded-bl-full flex items-center justify-center font-serif text-teal-900 text-lg">“</div>
                                          <h4 className="text-xs font-bold text-teal-800 mb-1">{def.term || def.word}</h4>
                                          <p className="text-[11px] text-teal-950 font-semibold leading-relaxed italic">{def.definition}</p>
                                        </div>
                                      ))}
                                    </div>
                                  </section>
                                )}

                                {/* Section 4: Detailed Step-by-Step Explanation */}
                                {aiNotes2Lesson.detailedExplanation?.length > 0 && (
                                  <section className="space-y-4">
                                    <h3 className="text-xs font-black text-purple-600 uppercase tracking-widest flex items-center gap-2">
                                      🎓 4. Detailed Academic Explanation (No Skipping!)
                                    </h3>
                                    <div className="space-y-5 bg-surface p-6 rounded-2xl border border-border">
                                      {aiNotes2Lesson.detailedExplanation.map((de: any, idx: number) => (
                                        <div key={idx} className="space-y-2 border-b border-border/20 pb-4 last:border-0 last:pb-0">
                                          <h4 className="text-xs font-bold text-purple-800 flex items-center gap-1.5 uppercase">
                                            <ChevronRight className="w-4 h-4 shrink-0" />
                                            {de.subheading || de.title}
                                          </h4>
                                          <div className="text-xs text-ink font-semibold leading-relaxed bg-surface2/30 p-4 rounded-lg border border-border/20">
                                            {de.content || de.p?.join('\n')}
                                          </div>
                                        </div>
                                      ))}
                                    </div>
                                  </section>
                                )}

                                {/* Section 5: Solved Examples */}
                                {aiNotes2Lesson.solvedExamples?.length > 0 && (
                                  <section className="space-y-4">
                                    <h3 className="text-xs font-black text-orange-600 uppercase tracking-widest flex items-center gap-2">
                                      📐 5. Solved Examples & Case Studies
                                    </h3>
                                    <div className="space-y-4">
                                      {aiNotes2Lesson.solvedExamples.map((ex: any, idx: number) => (
                                        <div key={idx} className="border border-orange/15 bg-orange-lt/5 rounded-2xl overflow-hidden shadow-2xs">
                                          <div className="bg-orange-mid/10 px-4 py-2 border-b border-orange/10 text-[10px] font-black uppercase text-orange-700 tracking-wider flex justify-between">
                                            <span>Solved Case {idx + 1}</span>
                                            <span>CBSE Guide</span>
                                          </div>
                                          <div className="p-5 space-y-3">
                                            <div>
                                              <div className="text-[11px] font-bold uppercase text-ink3 mb-1">Problem:</div>
                                              <p className="text-xs text-ink leading-relaxed font-semibold">{ex.problem || ex.question}</p>
                                            </div>
                                            <div className="pt-3 border-t border-orange/10 border-dashed">
                                              <div className="text-[11px] font-bold uppercase text-green-700 mb-1">Step-by-Step Solution:</div>
                                              <p className="text-xs text-green-950 font-semibold leading-relaxed bg-green-50/50 p-3 rounded-xl border border-green-100 italic">{ex.solution}</p>
                                            </div>
                                          </div>
                                        </div>
                                      ))}
                                    </div>
                                  </section>
                                )}

                                {/* Section 6: Common Mistakes */}
                                {aiNotes2Lesson.commonMistakes?.length > 0 && (
                                  <section className="space-y-4">
                                    <h3 className="text-xs font-black text-rose-600 uppercase tracking-widest flex items-center gap-2">
                                      ⚠️ 6. Common Exam Pitfalls & Mistakes
                                    </h3>
                                    <div className="space-y-3">
                                      {aiNotes2Lesson.commonMistakes.map((cm: any, idx: number) => (
                                        <div key={idx} className="grid grid-cols-1 md:grid-cols-2 gap-2 border border-rose-100 rounded-xl overflow-hidden shadow-xs">
                                          <div className="bg-rose-50/30 p-4 border-b md:border-b-0 md:border-r border-rose-100 space-y-1">
                                            <div className="text-[10px] font-bold uppercase text-rose-600 flex items-center gap-1">❌ Incorrect Habit</div>
                                            <p className="text-xs text-slate-800 font-semibold leading-relaxed">{cm.mistake}</p>
                                          </div>
                                          <div className="bg-emerald-50/30 p-4 space-y-1">
                                            <div className="text-[10px] font-bold uppercase text-emerald-600 flex items-center gap-1">✅ Ideal Answer Formulation</div>
                                            <p className="text-xs text-slate-900 font-semibold leading-relaxed italic">{cm.correction}</p>
                                          </div>
                                        </div>
                                      ))}
                                    </div>
                                  </section>
                                )}

                                {/* Section 7: Exam Tips */}
                                {aiNotes2Lesson.examTips?.length > 0 && (
                                  <section className="space-y-3">
                                    <h3 className="text-xs font-black text-amber-600 uppercase tracking-widest flex items-center gap-2">
                                      🎯 7. CBSE Exam Tips & Crucial Concepts
                                    </h3>
                                    <div className="bg-amber-50/10 border border-amber-200/50 p-5 rounded-2xl">
                                      <ul className="space-y-2.5">
                                        {aiNotes2Lesson.examTips.map((tip: string, idx: number) => (
                                          <li key={idx} className="flex gap-3 text-xs text-amber-950 font-semibold leading-relaxed">
                                            <Award className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                                            <span>{tip}</span>
                                          </li>
                                        ))}
                                      </ul>
                                    </div>
                                  </section>
                                )}

                                {/* Section 8: Diagrams */}
                                {aiNotes2Lesson.diagrams?.length > 0 && (
                                  <section className="space-y-4">
                                    <h3 className="text-xs font-black text-blue-600 uppercase tracking-widest flex items-center gap-2">
                                      🎨 8. Essential Schematic Diagram Explanations
                                    </h3>
                                    <div className="space-y-3">
                                      {aiNotes2Lesson.diagrams.map((diag: any, idx: number) => (
                                        <div key={idx} className="bg-surface2 p-5 rounded-xl border border-border shadow-2xs space-y-2">
                                          <h4 className="text-xs font-bold text-ink flex items-center gap-1.5 uppercase tracking-wide">
                                            <ImageIcon className="w-3.5 h-3.5 text-blue-500" />
                                            {diag.name}
                                          </h4>
                                          <p className="text-xs text-ink2 leading-relaxed font-semibold">{diag.walkthrough || diag.description}</p>
                                        </div>
                                      ))}
                                    </div>
                                  </section>
                                )}

                                {/* Section 9: Summary */}
                                {aiNotes2Lesson.summaryPoints?.length > 0 && (
                                  <section className="space-y-3 bg-gradient-to-br from-slate-50 to-neutral-50 p-6 rounded-2xl border border-gray-200">
                                    <h3 className="text-xs font-black text-slate-800 uppercase tracking-wider flex items-center gap-2">
                                      📋 9. End-of-Lesson Summary Checklist
                                    </h3>
                                    <ul className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                                      {aiNotes2Lesson.summaryPoints.map((pt: string, idx: number) => (
                                        <li key={idx} className="flex gap-2 text-xs font-semibold text-slate-700 bg-white p-3 rounded-xl border border-gray-100 shadow-3xs">
                                          <span className="text-emerald-500 font-black">✔</span>
                                          <span>{pt}</span>
                                        </li>
                                      ))}
                                    </ul>
                                  </section>
                                )}

                                <div className="text-center pt-6 border-t border-border border-dashed">
                                  <button 
                                    onClick={() => generateNotes2('lesson', true)}
                                    disabled={loading}
                                    className="inline-flex items-center gap-2 text-[10px] font-bold text-ink3 uppercase tracking-widest hover:text-orange transition-all disabled:opacity-50"
                                  >
                                    {loading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <RefreshCw className="w-3.5 h-3.5" />}
                                    Not satisfied? Regenerate Lesson Notes 2.0
                                  </button>
                                </div>
                              </div>
                            )
                          )}

                        </div>
                      )}

                      {/* Notes 1.0 (Standard Legacy Revision Notes) */}
                      {noteSystem === 'v1' && (
                        <div className="space-y-4">
                          <div className="flex items-center justify-between gap-4">
                            <div className="flex items-center gap-2">
                              <ListFilter className="w-4 h-4 text-orange" />
                              <span className="text-[10px] font-bold text-ink3 uppercase tracking-widest">Detail Level</span>
                            </div>
                            <div className="flex gap-1 p-1 bg-surface2 rounded-xl border border-border shrink-0">
                              {(['concise', 'balanced', 'detailed'] as DetailLevel[]).map(level => (
                                <button
                                  key={level}
                                  onClick={() => setDetailLevel(level)}
                                  className={cn(
                                    "px-3 py-1.5 text-[9px] font-black uppercase tracking-tight rounded-lg transition-all",
                                    detailLevel === level ? "bg-white text-orange shadow-sm border border-orange/10" : "text-ink3 hover:text-ink2"
                                  )}
                                >
                                  {level}
                                </button>
                              ))}
                            </div>
                          </div>

                          {!aiNotes ? (
                            <div className="pt-4 border-t border-border border-dashed text-center space-y-4">
                              <div className="w-16 h-16 bg-orange-lt rounded-full flex items-center justify-center mx-auto text-3xl">🤖</div>
                              <h4 className="font-display text-lg">Smart Revision Notes</h4>
                              <p className="text-[11px] text-ink2 leading-relaxed max-w-xs mx-auto">Get scannable, point-wise notes tailored to this chapter. Powered by AI.</p>
                              <button 
                                onClick={() => generateNotes()}
                                disabled={loading}
                                className="bg-orange text-white px-8 py-3 rounded-xl text-sm font-bold shadow-lg shadow-orange/30 disabled:opacity-50 flex items-center gap-2 mx-auto transition-transform active:scale-95"
                              >
                                {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Brain className="w-4 h-4" />}
                                Generate {detailLevel} Notes
                              </button>
                            </div>
                          ) : (
                            <div className="space-y-4 pt-4 border-t border-border border-dashed">
                              {/* Notes Content */}
                              <div className="bg-blue-lt border border-blue-200 p-5 rounded-2xl shadow-sm space-y-4">
                                <div className="flex items-center justify-between">
                                  <div className="flex items-center gap-2 text-blue-600 font-bold text-xs uppercase tracking-wider">
                                    <BookOpen className="w-3.5 h-3.5" />
                                    Summary ({detailLevel})
                                  </div>
                                  <button 
                                    onClick={saveToNotebook}
                                    className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-blue-200 rounded-lg text-[10px] font-black uppercase text-blue-600 hover:bg-blue-600 hover:text-white transition-all shadow-sm active:scale-95"
                                  >
                                    <Save className="w-3 h-3" />
                                    Add to Notebook
                                  </button>
                                </div>
                                <p className="text-sm text-blue-900 leading-relaxed font-bold">{aiNotes.summary}</p>
                              </div>

                              <div className="space-y-4">
                                <h4 className="text-[10px] font-bold text-blue-500 uppercase tracking-widest flex items-center gap-2">
                                   📌 Key Points
                                </h4>
                                <ul className="space-y-3 bg-surface2 p-5 rounded-2xl border border-border">
                                  {aiNotes.keyPoints.map((p: string, i: number) => (
                                    <li key={`kp-${i}`} className="flex gap-3 text-sm text-ink group">
                                      <span className="text-orange font-black flex-shrink-0">•</span>
                                      <span className="leading-relaxed font-medium pb-2 border-b border-border/20 w-full group-last:border-0">{p}</span>
                                    </li>
                                  ))}
                                </ul>
                              </div>

                              {aiNotes.formulas?.length > 0 && (
                                <div className="space-y-4">
                                  <h4 className="text-[10px] font-bold text-purple-500 uppercase tracking-widest flex items-center gap-2">
                                    📐 Formulas
                                  </h4>
                                  <div className="flex flex-wrap gap-2 p-4 bg-purple-50/50 border border-purple-200 rounded-2xl">
                                    {aiNotes.formulas.map((f: string, i: number) => (
                                      <div key={`formula-${i}`} className="px-4 py-2 bg-white border border-purple-200 rounded-lg text-sm font-display text-purple-700 italic shadow-sm">
                                        {f}
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              )}

                              <div className="space-y-4">
                                <h4 className="text-[10px] font-bold text-orange-500 uppercase tracking-widest flex items-center gap-2">
                                  ❓ Potential Questions
                                </h4>
                                <div className="space-y-3">
                                  {aiNotes.importantQuestions.map((iq: any, i: number) => (
                                    <div key={`iq-${i}`} className="bg-surface2 p-5 rounded-2xl border border-border space-y-4">
                                      <div className="flex justify-between items-start">
                                        <div className="text-[10px] font-bold text-orange uppercase bg-orange-lt px-1.5 py-0.5 rounded">Q{i + 1}</div>
                                        <div className="text-[10px] font-bold text-ink3">{iq.marks} Marks</div>
                                      </div>
                                      <p className="text-sm font-bold text-ink leading-tight">{iq.q}</p>
                                      {showAnswerIdx === i ? (
                                        <div className="text-xs text-green-700 font-medium bg-green-50 p-4 rounded-xl border border-green-100 leading-normal animate-fadeUp">
                                          <div className="font-bold mb-2 flex items-center gap-1.5 opacity-70">
                                            <CheckCircle className="w-3 h-3" />
                                            Expected Answer:
                                          </div>
                                          {iq.a}
                                        </div>
                                      ) : (
                                        <button 
                                          onClick={() => setShowAnswerIdx(i)}
                                          className="text-[10px] font-bold text-ink3 uppercase hover:text-orange transition-colors flex items-center gap-1.5 px-3 py-1.5 bg-surface rounded-lg border border-border"
                                        >
                                          <Eye className="w-3 h-3" />
                                          Reveal Answer
                                        </button>
                                      )}
                                    </div>
                                  ))}
                                </div>
                              </div>

                              <div className="text-center pt-6 border-t border-border border-dashed">
                                <button 
                                  onClick={() => generateNotes(true)}
                                  disabled={loading}
                                  className="inline-flex items-center gap-2 text-[10px] font-bold text-ink3 uppercase tracking-widest hover:text-orange transition-all disabled:opacity-50"
                                >
                                  {loading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <RefreshCw className="w-3.5 h-3.5" />}
                                  Not satisfied? Regenerate {detailLevel} Notes
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      )}

                    </div>
                  </div>
                )}

                {activeTab === 'formulas' && (
                  <div className="space-y-4">
                    <div className="bg-surface p-5 rounded-2xl border border-border shadow-sm space-y-6">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-amber-100 rounded-xl flex items-center justify-center text-amber-600">
                            <Calculator className="w-5 h-5" />
                          </div>
                          <div className="text-left">
                            <span className="text-[10px] uppercase font-black tracking-widest text-amber-600">Active High-Yield Tool</span>
                            <h4 className="font-display font-black text-lg select-none">Formula Sheet & Principles</h4>
                          </div>
                        </div>

                        {formulas.length > 0 && (
                          <div className="relative max-w-xs w-full">
                            <input
                              type="text"
                              placeholder="Search formulas or terms..."
                              value={formulaSearchQuery}
                              onChange={(e) => setFormulaSearchQuery(e.target.value)}
                              className="w-full pl-9 pr-3 py-1.5 bg-white border border-border text-xs rounded-xl focus:border-orange focus:outline-none focus:ring-1 focus:ring-orange/20 font-semibold"
                            />
                            <ListFilter className="absolute left-3 top-2.5 w-3.5 h-3.5 text-ink3" />
                          </div>
                        )}
                      </div>

                      {formulasLoading ? (
                        <div className="py-12 text-center space-y-4">
                          <RefreshCw className="w-8 h-8 animate-spin mx-auto text-orange" />
                          <div className="text-xs font-black uppercase tracking-wider text-ink3">VidyPath is compiling formula sheet...</div>
                          <p className="text-[11px] text-ink2 max-w-xs mx-auto">Retrieving equations, balanced chemical equations, or core grammatical rules customized for <b>{selectedCh}</b>.</p>
                        </div>
                      ) : formulas.length === 0 ? (
                        <div className="pt-4 border-t border-border border-dashed text-center space-y-4">
                          <div className="w-16 h-16 bg-amber-50 rounded-full flex items-center justify-center mx-auto text-3xl">📐</div>
                          <h4 className="font-display text-lg">No Formulas Cached for {selectedCh}</h4>
                          <p className="text-[11px] text-ink2 leading-relaxed max-w-sm mx-auto">
                            Instantly generate a compiled formula sheet of equations, symbol definitions, unit lists, and board examiner guidance for this chapter.
                          </p>
                          <button 
                            onClick={() => generateFormulas()}
                            disabled={formulasLoading}
                            className="bg-orange text-white px-8 py-3 rounded-xl text-sm font-bold shadow-lg shadow-orange/30 disabled:opacity-50 flex items-center gap-2 mx-auto transition-transform active:scale-95"
                          >
                            <Calculator className="w-4 h-4" />
                            Build Formula Sheet
                          </button>
                        </div>
                      ) : (
                        <div className="space-y-6 pt-4 border-t border-border border-dashed">
                          {filteredFormulas.length === 0 ? (
                            <div className="text-center py-10 bg-neutral-50/50 rounded-2xl border border-dashed border-border">
                              <span className="text-2xl block mb-2">🔍</span>
                              <div className="text-xs text-ink2 font-extrabold">No formulas matching "{formulaSearchQuery}"</div>
                              <p className="text-[10px] text-ink3 mt-1">Try searching for other keywords, variables or application terms.</p>
                            </div>
                          ) : (
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-5 text-left">
                              {filteredFormulas.map((f: any, idx: number) => (
                                <FormulaCard key={idx} formula={f} index={idx + 1} />
                              ))}
                            </div>
                          )}

                          <div className="text-center pt-6 border-t border-border border-dashed">
                            <button 
                              onClick={() => generateFormulas(true)}
                              disabled={formulasLoading}
                              className="inline-flex items-center gap-2 text-[10px] font-bold text-ink3 uppercase tracking-widest hover:text-orange transition-all disabled:opacity-50"
                            >
                              <RefreshCw className="w-3.5 h-3.5" />
                              Regenerate Formula Sheet
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {activeTab === 'questions' && (
                  <div className="space-y-6">
                    <div className="bg-surface p-6 rounded-3xl border border-border shadow-sm space-y-6">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center text-blue-600">
                           <Target className="w-5 h-5" />
                        </div>
                        <div>
                          <h4 className="font-bold text-lg">Question Bank Generator</h4>
                          <p className="text-[10px] uppercase font-black tracking-widest text-ink3">CBSE Board Pattern</p>
                        </div>
                      </div>

                      {selectedTopicForQBank && (
                        <div className="flex items-center justify-between p-3.5 bg-blue-50/70 border border-blue-200/60 rounded-2xl animate-fadeUp">
                          <div className="flex items-center gap-2 text-left">
                            <Sparkles className="w-4 h-4 text-blue-500 animate-pulse shrink-0" />
                            <div>
                              <p className="text-[10px] font-black text-blue-600 uppercase tracking-wider leading-none">Topic-wise Filter Active</p>
                              <p className="text-xs font-bold text-slate-800 dark:text-slate-200 mt-1 leading-relaxed">{selectedTopicForQBank}</p>
                            </div>
                          </div>
                          <button
                            type="button"
                            onClick={() => {
                              setSelectedTopicForQBank(null);
                              generateQBank(true, null);
                            }}
                            className="px-3 py-1.5 bg-white border border-blue-200 hover:bg-slate-50 text-blue-700 text-[10px] font-black uppercase tracking-wider rounded-xl transition-all shadow-3xs hover:border-blue-300"
                          >
                            Reset to Chapter-wide
                          </button>
                        </div>
                      )}

                      <div className="grid grid-cols-1 gap-4 bg-surface2 p-4 rounded-2xl border border-border">
                        <div className="space-y-2">
                           <label className="text-[10px] font-black uppercase text-ink3 ml-1">Practice Difficulty</label>
                           <select 
                            value={difficulty}
                            onChange={(e) => setDifficulty(e.target.value as Difficulty)}
                            className="w-full p-2.5 bg-white border border-border rounded-xl text-xs font-bold focus:border-orange focus:ring-0 transition-all shadow-sm"
                           >
                             <option value="basic">Basic (Concept Check)</option>
                             <option value="standard">Standard (Board Level)</option>
                             <option value="advanced">Advanced (Exemplar/HOTS)</option>
                           </select>
                        </div>
                      </div>

                      <button 
                        onClick={() => generateQBank()}
                        disabled={loading}
                        className="w-full py-4 bg-blue-600 text-white rounded-2xl font-bold flex items-center justify-center gap-2 shadow-lg shadow-blue-200 hover:bg-blue-700 active:scale-95 transition-all disabled:opacity-50"
                      >
                        {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Brain className="w-4 h-4" />}
                        {selectedTopicForQBank ? `Generate Q-Bank for: ${selectedTopicForQBank}` : "Generate Chapter Question Bank"}
                      </button>

                      {qBank && (
                        <div className="space-y-8 pt-4 animate-fadeUp">
                          {/* MCQs */}
                          {qBank.mcq?.length > 0 && (
                            <div className="space-y-4">
                              <h5 className="text-[11px] font-black uppercase text-ink3 tracking-widest flex items-center gap-2">
                                <span className="w-1.5 h-1.5 bg-blue-500 rounded-full"></span>
                                Section A: Multiple Choice Questions
                              </h5>
                              <div className="space-y-3">
                                {qBank.mcq.map((q: any, i: number) => (
                                  <QBankQuestionCard
                                    key={`mcq-${i}`}
                                    id={`mcq-${i}`}
                                    type="mcq"
                                    q={q}
                                    index={i+1}
                                    subjectLabel={sub.label}
                                    chapterName={selectedCh || "Physics"}
                                    subjectKey={subjectKey}
                                    showToast={showToast}
                                  />
                                ))}
                              </div>
                            </div>
                          )}

                          {/* Assertion Reason */}
                          {qBank.assertion_reason?.length > 0 && (
                            <div className="space-y-4">
                              <h5 className="text-[11px] font-black uppercase text-ink3 tracking-widest flex items-center gap-2">
                                <span className="w-1.5 h-1.5 bg-red-500 rounded-full"></span>
                                Section B: Assertion & Reason
                              </h5>
                              <div className="space-y-3">
                                {qBank.assertion_reason.map((q: any, i: number) => (
                                  <QBankQuestionCard
                                    key={`ar-${i}`}
                                    id={`ar-${i}`}
                                    type="assertion_reason"
                                    q={q}
                                    index={i+1}
                                    subjectLabel={sub.label}
                                    chapterName={selectedCh || "Physics"}
                                    subjectKey={subjectKey}
                                    showToast={showToast}
                                  />
                                ))}
                              </div>
                            </div>
                          )}

                          {/* Standard Sections mapping */}
                          {[
                            { key: 'fill_blanks', label: 'Section D1: Fill in the blanks', color: 'blue' },
                            { key: 'short_answer', label: 'Section D2: Short Answer Questions', color: 'blue' },
                            { key: 'long_answer', label: 'Section D3: Long Answer Questions', color: 'orange' },
                            { key: 'hots', label: 'Section D4: HOTS (High Order Thinking)', color: 'red' },
                            { key: 'competency', label: 'Section D5: Competency Based Problems', color: 'purple' },
                            { key: 'diagram_based', label: 'Section D6: Diagram Based Questions', color: 'cyan' },
                            { key: 'numerical', label: 'Section D7: Numerical / Problem' + ' Solving', color: 'indigo' },
                            { key: 'creative', label: 'Section D8: Creative / Value Based', color: 'pink' }
                          ].map((section) => (
                            qBank[section.key]?.length > 0 && (
                              <div key={section.key} className="space-y-4">
                                <h5 className="text-[11px] font-black uppercase text-ink3 tracking-widest flex items-center gap-2">
                                  <span className={cn("w-1.5 h-1.5 rounded-full", {
                                    'bg-blue-500': section.color === 'blue',
                                    'bg-orange-500': section.color === 'orange',
                                    'bg-red-500': section.color === 'red',
                                    'bg-purple-500': section.color === 'purple',
                                    'bg-cyan-500': section.color === 'cyan',
                                    'bg-indigo-500': section.color === 'indigo',
                                    'bg-pink-500': section.color === 'pink'
                                  })}></span>
                                  {section.label}
                                </h5>
                                <div className="space-y-3">
                                  {qBank[section.key].map((q: any, i: number) => (
                                    <QBankQuestionCard
                                      key={`${section.key}-${i}`}
                                      id={`${section.key}-${i}`}
                                      type={section.key}
                                      q={q}
                                      index={i+1}
                                      subjectLabel={sub.label}
                                      chapterName={selectedCh || "Physics"}
                                      subjectKey={subjectKey}
                                      showToast={showToast}
                                    />
                                  ))}
                                </div>
                              </div>
                            )
                          ))}

                          {/* Source Based */}
                          {qBank.source_based?.length > 0 && (
                            <div className="space-y-4">
                              <h5 className="text-[11px] font-black uppercase text-ink3 tracking-widest flex items-center gap-2">
                                <span className="w-1.5 h-1.5 bg-amber-500 rounded-full"></span>
                                Section D: Source Based Questions
                              </h5>
                              <div className="space-y-3">
                                {qBank.source_based.map((sb: any, iIdx: number) => (
                                  <QBankQuestionCard
                                    key={`sb-${iIdx}`}
                                    id={`sb-${iIdx}`}
                                    type="source_based"
                                    q={sb}
                                    index={iIdx+1}
                                    subjectLabel={sub.label}
                                    chapterName={selectedCh || "Physics"}
                                    subjectKey={subjectKey}
                                    showToast={showToast}
                                  />
                                ))}
                              </div>
                            </div>
                          )}

                          {/* Case Based / Case Study */}
                          {(qBank.case_study || qBank.case_based)?.length > 0 && (qBank.case_study || qBank.case_based).map((cb: any, cbIdx: number) => (
                            <div key={`cb-container-${cbIdx}`} className="space-y-4">
                              <h5 className="text-[11px] font-black uppercase text-ink3 tracking-widest flex items-center gap-2">
                                <span className="w-1.5 h-1.5 bg-purple-500 rounded-full"></span>
                                Section E: Case-Based Study ({cbIdx + 1})
                              </h5>
                              <div className="p-6 bg-purple-50/20 border border-purple-100 rounded-[32px] space-y-6">
                                <div className="space-y-2 text-left">
                                  <div className="text-[10px] font-bold text-purple-600 uppercase">Context / Passage</div>
                                  <p className="text-xs leading-relaxed font-semibold italic text-purple-900 border-l-2 border-purple-200 pl-4">{cb.passage}</p>
                                </div>
                                <div className="space-y-4">
                                  {cb.questions.map((q: any, i: number) => (
                                    <QBankQuestionCard
                                      key={`case-${cbIdx}-${i}`}
                                      id={`case-${cbIdx}-${i}`}
                                      type="case_study"
                                      q={q}
                                      index={i+1}
                                      subjectLabel={sub.label}
                                      chapterName={selectedCh || "Physics"}
                                      subjectKey={subjectKey}
                                      showToast={showToast}
                                    />
                                  ))}
                                </div>
                              </div>
                            </div>
                          ))}
                          
                          {/* Dynamic Practice More Button Block */}
                          <div className="pt-8 border-t border-dashed border-border/80 flex flex-col items-center justify-center text-center space-y-4">
                            <div className="bg-yellow-50/40 p-4 border border-yellow-250/30 rounded-2xl max-w-md">
                              <p className="text-xs font-bold text-yellow-905 flex items-center justify-center gap-1.5">
                                <Sparkles className="w-4 h-4 text-orange animate-pulse shrink-0" />
                                Finished this batch of practice?
                              </p>
                              <p className="text-[10px] text-ink3 font-medium mt-1">Generate a fresh set of fully randomized, CBSE-aligned questions to keep drilling your skills!</p>
                            </div>
                            <button
                              type="button"
                              onClick={() => generateQBank(true)}
                              disabled={loading}
                              className="px-8 py-3.5 bg-orange text-white rounded-2xl font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2 shadow-lg shadow-orange-100 hover:bg-orange-mid active:scale-95 transition-all disabled:opacity-50"
                            >
                              {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Brain className="w-4 h-4" />}
                              Practice More (Generate New Questions)
                            </button>
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="bg-surface p-6 rounded-3xl border border-border shadow-sm space-y-4">
                      <div className="flex items-center gap-3 mb-2">
                        <div className="w-10 h-10 bg-indigo-100 rounded-xl flex items-center justify-center text-indigo-600">
                           <ListFilter className="w-5 h-5" />
                        </div>
                        <div>
                          <h4 className="font-bold text-lg">Topic-wise Drills</h4>
                          <p className="text-[10px] uppercase font-black tracking-widest text-ink3">Generate Q-Bank For Specific Topic</p>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 gap-3 pt-2">
                        {topics.map((topic, i) => {
                          const isCurrentTopic = selectedTopicForQBank === topic;
                          return (
                            <button
                              key={`topic-${i}`}
                              onClick={() => {
                                generateQBank(true, topic);
                                window.scrollTo({ top: 220, behavior: 'smooth' });
                              }}
                              disabled={loading}
                              className={cn(
                                "flex items-center justify-between p-4 border rounded-2xl transition-all text-left",
                                isCurrentTopic 
                                  ? "bg-blue-50/40 dark:bg-blue-950/20 border-blue-400 font-semibold shadow-xs" 
                                  : "bg-surface2 border-border hover:border-blue-400 hover:bg-blue-50/10 group cursor-pointer"
                              )}
                            >
                              <div className="flex items-center gap-3 min-w-0">
                                <div className={cn(
                                  "w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs shadow-sm transition-all border shrink-0",
                                  isCurrentTopic
                                    ? "bg-blue-600 text-white border-blue-650"
                                    : "bg-surface border-border text-ink3 group-hover:bg-blue-500 group-hover:text-white"
                                )}>
                                  {isCurrentTopic && loading ? (
                                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                                  ) : (
                                    i + 1
                                  )}
                                </div>
                                <div className="min-w-0">
                                  <span className={cn(
                                    "text-sm font-bold block truncate",
                                    isCurrentTopic ? "text-blue-950 dark:text-blue-200" : "text-ink group-hover:text-blue-900"
                                  )}>
                                    {topic}
                                  </span>
                                  {isCurrentTopic && (
                                    <span className="text-[9px] font-black uppercase text-blue-500 tracking-wider block mt-0.5 animate-pulse">
                                      {loading ? "Generating focused q-bank... please wait" : "Entire Q-Bank Focused On This"}
                                    </span>
                                  )}
                                </div>
                              </div>
                              <div className="flex items-center gap-1 shrink-0">
                                {isCurrentTopic ? (
                                  <Check className="w-4 h-4 text-blue-600 animate-fadeIn" />
                                ) : (
                                  <ChevronRight className="w-4 h-4 text-ink3 group-hover:translate-x-1" />
                                )}
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === 'tricks' && (
                  <div className="space-y-6">
                    <div className="bg-surface p-6 rounded-3xl border border-border shadow-sm space-y-6">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-yellow-100 rounded-xl flex items-center justify-center text-yellow-600">
                            <Zap className="w-5 h-5" />
                          </div>
                          <div>
                            <h4 className="font-bold text-lg">Hacks & Shortcuts</h4>
                            <p className="text-[10px] uppercase font-black tracking-widest text-ink3">Learn Smarter</p>
                          </div>
                        </div>
                        
                        <div className="flex p-1 bg-surface2 rounded-xl border border-border self-start">
                          <button 
                            onClick={() => setTricksMode('shortcuts')}
                            className={cn(
                              "px-4 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all",
                              tricksMode === 'shortcuts' ? "bg-white text-yellow-600 shadow-sm" : "text-ink3"
                            )}
                          >
                            Shortcuts
                          </button>
                          <button 
                            onClick={() => setTricksMode('mnemonics')}
                            className={cn(
                              "px-4 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all",
                              tricksMode === 'mnemonics' ? "bg-white text-yellow-600 shadow-sm" : "text-ink3"
                            )}
                          >
                            Mnemonics
                          </button>
                        </div>
                      </div>

                      {tricksMode === 'shortcuts' ? (
                        <>
                          {!tricks.length ? (
                            <div className="pt-4 border-t border-border border-dashed text-center space-y-4">
                              <div className="w-16 h-16 bg-yellow-50 rounded-full flex items-center justify-center mx-auto text-3xl">🪄</div>
                              <p className="text-sm text-ink2 leading-relaxed max-w-xs mx-auto">Instant shortcuts, calculation tips, and common exam mistakes to avoid.</p>
                              <button 
                                onClick={() => generateTricks()}
                                disabled={loading}
                                className="bg-yellow-500 text-white px-8 py-3 rounded-xl text-sm font-bold shadow-lg shadow-yellow-200 disabled:opacity-50 flex items-center gap-2 mx-auto transition-transform active:scale-95"
                              >
                                {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
                                Reveal Exam Tricks
                              </button>
                            </div>
                          ) : (
                            <div className="space-y-4 pt-4 border-t border-border border-dashed">
                              <div className="grid grid-cols-1 gap-3">
                                {tricks.map((trick, i) => {
                                  const [title, ...descParts] = trick.split(' - ');
                                  const desc = descParts.join(' - ');
                                  return (
                                    <div key={`trick-${i}`} className="p-5 bg-yellow-50/50 border border-yellow-100 rounded-2xl space-y-2 shadow-sm">
                                      <div className="text-sm font-black text-yellow-900">{title}</div>
                                      <p className="text-xs text-yellow-800 leading-relaxed font-medium">{desc}</p>
                                    </div>
                                  );
                                })}
                              </div>
                              <div className="text-center pt-6">
                                <button onClick={() => generateTricks()} disabled={loading} className="text-[10px] font-black text-ink3 uppercase tracking-widest flex items-center gap-2 mx-auto hover:text-yellow-600 transition-colors">
                                  <RefreshCw className={cn("w-3.5 h-3.5", loading && "animate-spin")} />
                                  Refresh Shortcuts
                                </button>
                              </div>
                            </div>
                          )}
                        </>
                      ) : (
                        <>
                          {!memoryHacks.length ? (
                            <div className="pt-4 border-t border-border border-dashed text-center space-y-4">
                              <div className="w-16 h-16 bg-purple-50 rounded-full flex items-center justify-center mx-auto text-3xl">🧠</div>
                              <p className="text-sm text-ink2 leading-relaxed max-w-xs mx-auto">Fun memory mnemonics to remember long lists, cycles, and complex definitions easily.</p>
                              <button 
                                onClick={() => generateMemoryHacks()}
                                disabled={loading}
                                className="bg-purple-500 text-white px-8 py-3 rounded-xl text-sm font-bold shadow-lg shadow-purple-200 disabled:opacity-50 flex items-center gap-2 mx-auto transition-transform active:scale-95"
                              >
                                {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Brain className="w-4 h-4" />}
                                Generate Memory Hacks
                              </button>
                            </div>
                          ) : (
                            <div className="space-y-4 pt-4 border-t border-border border-dashed">
                              <div className="grid grid-cols-1 gap-3">
                                {memoryHacks.map((hack, i) => {
                                  const [concept, ...hackParts] = hack.replace(/^- /, '').split(': ');
                                  const trick = hackParts.join(': ');
                                  return (
                                    <div key={`hack-${i}`} className="p-5 bg-purple-50/50 border border-purple-100 rounded-2xl space-y-2 shadow-sm">
                                      <div className="text-sm font-black text-purple-900">{concept}</div>
                                      <p className="text-xs text-purple-800 leading-relaxed font-medium">{trick}</p>
                                    </div>
                                  );
                                })}
                              </div>
                              <div className="text-center pt-6">
                                <button onClick={() => generateMemoryHacks()} disabled={loading} className="text-[10px] font-black text-ink3 uppercase tracking-widest flex items-center gap-2 mx-auto hover:text-purple-600 transition-colors">
                                  <RefreshCw className={cn("w-3.5 h-3.5", loading && "animate-spin")} />
                                  Refresh Mnemonics
                                </button>
                              </div>
                            </div>
                          )}
                        </>
                      )}
                    </div>
                  </div>
                )}

                {activeTab === 'diagrams' && (
                  <div className="space-y-6">
                    <div className="bg-surface p-6 rounded-3xl border border-border shadow-sm space-y-6">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center text-blue-600">
                            <Presentation className="w-5 h-5" />
                          </div>
                          <div>
                            <h4 className="font-bold text-lg">Visual Learning</h4>
                            <p className="text-[10px] uppercase font-black tracking-widest text-ink3">Diagrams, Maps & Logic</p>
                          </div>
                        </div>

                        <div className="flex p-1 bg-surface2 rounded-xl border border-border self-start">
                          <button 
                            onClick={() => setDiagramMode('interactive')}
                            className={cn(
                              "px-4 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all",
                              diagramMode === 'interactive' ? "bg-white text-blue-600 shadow-sm" : "text-ink3"
                            )}
                          >
                            Explore
                          </button>
                          <button 
                            onClick={() => setDiagramMode('practice')}
                            className={cn(
                              "px-4 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all",
                              diagramMode === 'practice' ? "bg-white text-blue-600 shadow-sm" : "text-ink3"
                            )}
                          >
                            Practice
                          </button>
                        </div>
                      </div>

                      {diagramMode === 'interactive' ? (
                        <div className="space-y-8">
                          {!interactiveDiagrams.length ? (
                            <div className="pt-4 border-t border-border border-dashed text-center space-y-4">
                              <div className="w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center mx-auto text-3xl">🧩</div>
                              <h4 className="font-display text-lg">Interactive Model Explorer</h4>
                              <p className="text-sm text-ink2 leading-relaxed max-w-xs mx-auto">Explore board-important diagrams with clickable hotspots and detailed technical explanations.</p>
                              <button 
                                onClick={loadInteractiveDiagrams}
                                disabled={loading}
                                className="bg-blue-600 text-white px-8 py-3 rounded-xl text-sm font-bold shadow-lg shadow-blue-200 disabled:opacity-50 flex items-center gap-2 mx-auto transition-transform active:scale-95"
                              >
                                {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Eye className="w-4 h-4" />}
                                Generate Interactive Models
                              </button>
                            </div>
                          ) : (
                            <div className="space-y-10 animate-fadeUp">
                              {interactiveDiagrams.map((diag, dIdx) => (
                                <div key={`int-diag-${dIdx}`} className="space-y-6">
                                  <div className="space-y-2">
                                    <h5 className="text-lg font-display flex items-center gap-2">
                                      <span className="w-2 h-2 bg-blue-500 rounded-full" />
                                      {diag.title}
                                    </h5>
                                    <p className="text-xs text-ink2 font-medium leading-relaxed">{diag.overview}</p>
                                  </div>

                                  <div className="relative aspect-video bg-surface2 border border-border rounded-[32px] overflow-hidden group shadow-inner">
                                    {/* Visual Representation (Rich Vector Illustrative Diagrams) */}
                                    <div className="absolute inset-0 flex items-center justify-center p-6 select-none animate-fadeIn">
                                      <DiagramVectorRenderer baseIcon={diag.baseIcon || ''} title={diag.title || ''} />
                                    </div>

                                    {/* Hotspots */}
                                    {diag.parts.map((p: any, pIdx: number) => (
                                      <button 
                                        key={`hotspot-${dIdx}-${pIdx}`}
                                        className={cn(
                                          "absolute w-6 h-6 -ml-3 -mt-3 flex items-center justify-center transition-all duration-300 z-10",
                                          activeHotspot?.diagIdx === dIdx && activeHotspot?.partIdx === pIdx ? "scale-125" : "hover:scale-110"
                                        )}
                                        style={{ left: `${p.x}%`, top: `${p.y}%` }}
                                        onClick={() => setActiveHotspot({ diagIdx: dIdx, partIdx: pIdx })}
                                      >
                                        <div className={cn(
                                          "w-full h-full rounded-full flex items-center justify-center text-[10px] font-black shadow-lg",
                                          activeHotspot?.diagIdx === dIdx && activeHotspot?.partIdx === pIdx 
                                            ? "bg-orange text-white ring-4 ring-orange-lt" 
                                            : "bg-white text-blue-600 border border-blue-200"
                                        )}>
                                          {pIdx + 1}
                                        </div>
                                      </button>
                                    ))}

                                    {/* Tooltip Overlay */}
                                    <AnimatePresence>
                                      {activeHotspot?.diagIdx === dIdx && (
                                        <motion.div 
                                          initial={{ opacity: 0, y: 20 }}
                                          animate={{ opacity: 1, y: 0 }}
                                          exit={{ opacity: 0, y: 20 }}
                                          className="absolute bottom-4 left-4 right-4 bg-white/90 backdrop-blur-md border border-border p-4 rounded-2xl shadow-xl z-20"
                                        >
                                          <div className="flex justify-between items-start gap-4">
                                            <div className="space-y-1">
                                              <div className="text-[10px] font-black uppercase text-orange tracking-widest">
                                                Part {activeHotspot.partIdx + 1}: {diag.parts[activeHotspot.partIdx].label}
                                              </div>
                                              <p className="text-xs text-ink leading-relaxed font-bold">
                                                {diag.parts[activeHotspot.partIdx].description}
                                              </p>
                                            </div>
                                            <button 
                                              onClick={() => setActiveHotspot(null)}
                                              className="p-1 hover:bg-surface rounded-lg transition-colors"
                                            >
                                              <ArrowLeft className="w-4 h-4 text-ink3 rotate-90" />
                                            </button>
                                          </div>
                                        </motion.div>
                                      )}
                                    </AnimatePresence>
                                  </div>
                                </div>
                              ))}
                              
                              <div className="text-center pt-4">
                                <button onClick={loadInteractiveDiagrams} disabled={loading} className="text-[10px] font-black text-ink3 uppercase underline tracking-widest hover:text-blue-600 transition-colors">
                                  {loading ? "Regenerating..." : "Regenerate Interactive Models"}
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      ) : (
                        <div className="space-y-6">
                          {!diagramQuestions.length ? (
                            <div className="pt-4 border-t border-border border-dashed text-center space-y-4">
                              <div className="w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center mx-auto text-3xl">📐</div>
                              <p className="text-sm text-ink2 leading-relaxed max-w-xs mx-auto">Master the most important diagrams from this chapter. View board-level questions and get AI feedback on your work.</p>
                              <button 
                                onClick={() => generateDiagramQuestions()}
                                disabled={loading}
                                className="bg-blue-600 text-white px-8 py-3 rounded-xl text-sm font-bold shadow-lg shadow-blue-200 disabled:opacity-50 flex items-center gap-2 mx-auto transition-transform active:scale-95"
                              >
                                {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Presentation className="w-4 h-4" />}
                                Generate Diagram Set
                              </button>
                            </div>
                          ) : (
                            <div className="space-y-6 pt-4 border-t border-border border-dashed">
                              {diagramQuestions.map((dq, i) => (
                                <div key={`dq-${i}`} className="p-6 bg-surface2 border border-border rounded-2xl space-y-4 shadow-sm relative overflow-hidden">
                                  <div className="flex justify-between items-start">
                                    <span className={cn(
                                      "px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-widest",
                                      dq.type === 'draw' ? "bg-green-100 text-green-700" :
                                      dq.type === 'label' ? "bg-orange-100 text-orange-700" :
                                      dq.type === 'explain' ? "bg-blue-100 text-blue-700" :
                                      dq.type === 'application' ? "bg-purple-100 text-purple-700" :
                                      "bg-red-100 text-red-700"
                                    )}>
                                      {dq.type}
                                    </span>
                                    <div className="text-[10px] font-bold text-ink3">Question {i + 1}</div>
                                  </div>
                                  
                                  <p className="text-sm font-bold text-ink leading-relaxed">{dq.question}</p>
                                  
                                  <div className="pt-4 flex flex-col gap-3 border-t border-border border-dashed">
                                    {diagramFeedback[i] ? (
                                      <div className="p-4 bg-green-50 border border-green-100 rounded-xl space-y-2 animate-fadeUp text-left">
                                        <div className="text-[10px] font-black uppercase text-green-700">AI Evaluation Result</div>
                                        <div className="text-xs text-green-900 leading-relaxed font-semibold markdown-body font-sans">
                                          <Markdown>{diagramFeedback[i]}</Markdown>
                                        </div>
                                        <button 
                                          onClick={() => setDiagramFeedback(prev => {
                                            const n = {...prev};
                                            delete n[i];
                                            return n;
                                          })}
                                          className="text-[10px] font-bold text-green-600 underline"
                                        >
                                          Try Again
                                        </button>
                                      </div>
                                    ) : (
                                      <div className="flex flex-wrap gap-2.5">
                                        <label className="flex-1 min-w-[200px]">
                                          <div className={cn(
                                            "flex items-center justify-center gap-2 px-4 py-3 bg-white border-2 border-dashed border-border rounded-xl cursor-pointer hover:border-blue-400 hover:bg-blue-50 transition-all",
                                            evaluatingDiagram === i && "opacity-50 pointer-events-none"
                                          )}>
                                            {evaluatingDiagram === i ? (
                                              <RefreshCw className="w-4 h-4 animate-spin text-blue-600" />
                                            ) : (
                                              <Upload className="w-4 h-4 text-blue-600" />
                                            )}
                                            <div className="text-xs font-bold text-ink2">
                                              {evaluatingDiagram === i ? "Evaluating..." : "Upload your work for AI Review"}
                                            </div>
                                            <input 
                                              type="file" 
                                              accept="image/*" 
                                              className="hidden" 
                                              onChange={(e) => handleDiagramUpload(e, i)}
                                              disabled={evaluatingDiagram !== null}
                                            />
                                          </div>
                                        </label>
                                        
                                        {revealedQ[`diagram-${i}`] ? (
                                          <div className="w-full p-4 bg-blue-50 border border-blue-100 rounded-xl text-[12px] font-medium text-blue-900 animate-fadeUp text-left markdown-body font-sans">
                                            <div className="text-[10px] font-black uppercase text-blue-700 mb-1">Standard Answer/Guide</div>
                                            <Markdown>{dq.answer}</Markdown>
                                          </div>
                                        ) : (
                                          <button 
                                            onClick={() => setRevealedQ(prev => ({...prev, [`diagram-${i}`]: true}))}
                                            className="px-4 py-3 bg-white border border-border rounded-xl text-[10px] font-black uppercase tracking-widest text-ink hover:bg-surface transition-all flex items-center justify-center gap-2"
                                          >
                                            <Info className="w-3.5 h-3.5 text-blue-500" />
                                            View Hint/Answer
                                          </button>
                                        )}
                                      </div>
                                    )}
                                  </div>
                                </div>
                              ))}

                              <div className="text-center pt-6">
                                <button 
                                  onClick={() => generateDiagramQuestions()} 
                                  disabled={loading} 
                                  className="text-[10px] font-black text-ink3 uppercase underline tracking-widest hover:text-blue-600 transition-colors"
                                >
                                  Refresh Concepts
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {activeTab === 'pyqs' && (
                  <div className="space-y-6">
                    {/* PYQs Header & Summary */}
                    <div className="bg-surface p-6 rounded-[32px] border border-border shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="w-2.5 h-2.5 bg-emerald-500 rounded-full border-2 border-surface shadow-md animate-pulse" />
                          <h3 className="text-sm font-black uppercase tracking-widest text-emerald-600">Verified Board PYQs</h3>
                        </div>
                        <p className="text-xs text-ink2 max-w-md">
                          Authentic, hand-verified CBSE previous year board exam questions. No AI placeholders or generic questions.
                        </p>
                      </div>

                      <button
                        onClick={() => setShowAddPyqForm(!showAddPyqForm)}
                        className="px-5 py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-black uppercase tracking-widest flex items-center justify-center gap-2 transition-all shadow-lg shadow-emerald-100 dark:shadow-none self-start md:self-auto"
                      >
                        <Plus className="w-4 h-4 stroke-[3px]" />
                        {showAddPyqForm ? "Close Form" : "Add Real PYQ"}
                      </button>
                    </div>

                    {/* Add PYQ Form */}
                    <AnimatePresence>
                      {showAddPyqForm && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          exit={{ opacity: 0, height: 0 }}
                          className="overflow-hidden"
                        >
                          <form
                            onSubmit={async (e) => {
                              e.preventDefault();
                              if (!newPyqQuestion.trim()) {
                                showToast("Please enter the board question.");
                                return;
                              }
                              if (!newPyqAnswer.trim()) {
                                showToast("Please enter the official answer / marking scheme.");
                                return;
                              }
                              try {
                                const added = await addRealPYQ({
                                  subjectKey,
                                  chapterName: selectedCh,
                                  question: newPyqQuestion,
                                  answer: newPyqAnswer,
                                  year: newPyqYear,
                                  marks: newPyqMarks,
                                  type: newPyqType,
                                  source: newPyqSource || 'CBSE Board'
                                });
                                setPyqs(prev => [added, ...prev]);
                                showToast("Real board question added successfully!");
                                // Reset
                                setNewPyqQuestion('');
                                setNewPyqAnswer('');
                                setNewPyqSource('');
                                setShowAddPyqForm(false);
                              } catch (err) {
                                showToast("Failed to add question.");
                              }
                            }}
                            className="bg-surface p-6 rounded-[32px] border flex flex-col gap-4 border-emerald-500/20 shadow-sm"
                          >
                            <h4 className="text-xs font-black uppercase tracking-widest text-ink font-sans">Contribute Authentic Board Question</h4>
                            
                            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                              <div className="space-y-1">
                                <label className="text-[10px] font-black text-ink3 uppercase">Exam Year</label>
                                <input
                                  type="number"
                                  min={2000}
                                  max={2030}
                                  value={newPyqYear}
                                  onChange={(e) => setNewPyqYear(Number(e.target.value))}
                                  className="w-full px-4 py-2.5 bg-surface2 border border-border rounded-xl text-xs font-bold text-ink focus:outline-none focus:border-orange"
                                  required
                                />
                              </div>

                              <div className="space-y-1">
                                <label className="text-[10px] font-black text-ink3 uppercase">Question Marks</label>
                                <select
                                  value={newPyqMarks}
                                  onChange={(e) => setNewPyqMarks(Number(e.target.value))}
                                  className="w-full px-4 py-2.5 bg-surface2 border border-border rounded-xl text-xs font-bold text-ink focus:outline-none focus:border-orange cursor-pointer"
                                >
                                  {[1, 2, 3, 4, 5].map(m => (
                                    <option key={`m-${m}`} value={m}>{m} Mark{m > 1 ? 's' : ''}</option>
                                  ))}
                                </select>
                              </div>

                              <div className="space-y-1">
                                <label className="text-[10px] font-black text-ink3 uppercase">Question Type</label>
                                <select
                                  value={newPyqType}
                                  onChange={(e) => setNewPyqType(e.target.value as any)}
                                  className="w-full px-4 py-2.5 bg-surface2 border border-border rounded-xl text-xs font-bold text-ink focus:outline-none focus:border-orange cursor-pointer"
                                >
                                  <option value="Short Answer">Short Answer</option>
                                  <option value="Long Answer">Long Answer</option>
                                  <option value="MCQ">MCQ</option>
                                  <option value="Competency">Competency</option>
                                </select>
                              </div>

                              <div className="space-y-1">
                                <label className="text-[10px] font-black text-ink3 uppercase">Source Paper / Set (Optional)</label>
                                <input
                                  type="text"
                                  placeholder="e.g. CBSE Delhi Set-3"
                                  value={newPyqSource}
                                  onChange={(e) => setNewPyqSource(e.target.value)}
                                  className="w-full px-4 py-2.5 bg-surface2 border border-border rounded-xl text-xs font-bold text-ink focus:outline-none focus:border-orange"
                                />
                              </div>
                            </div>

                            <div className="space-y-1">
                              <label className="text-[10px] font-black text-ink3 uppercase">Exact Question TEXT</label>
                              <textarea
                                placeholder="Type the official question as it came in the board exam..."
                                rows={3}
                                value={newPyqQuestion}
                                onChange={(e) => setNewPyqQuestion(e.target.value)}
                                className="w-full p-4 bg-surface2 border border-border rounded-2xl text-xs font-medium text-ink focus:outline-none focus:border-orange"
                                required
                              />
                            </div>

                            <div className="space-y-1">
                              <label className="text-[10px] font-black text-ink3 uppercase">Official Solution / Marking Scheme Steps</label>
                              <textarea
                                placeholder="Provide the step-by-step verified solution keys..."
                                rows={4}
                                value={newPyqAnswer}
                                onChange={(e) => setNewPyqAnswer(e.target.value)}
                                className="w-full p-4 bg-surface2 border border-border rounded-2xl text-xs font-medium text-ink focus:outline-none focus:border-orange"
                                required
                              />
                            </div>

                            <div className="flex gap-2 justify-end pt-2">
                              <button
                                type="button"
                                onClick={() => setShowAddPyqForm(false)}
                                className="px-4 py-2.5 rounded-xl border border-border hover:bg-surface2 text-[10px] font-black uppercase tracking-widest text-ink3"
                              >
                                Cancel
                              </button>
                              <button
                                type="submit"
                                className="px-6 py-2.5 rounded-xl bg-orange hover:bg-orange-dark text-white text-[10px] font-black uppercase tracking-widest flex items-center gap-1.5 shadow-md shadow-orange/10 animate-fadeUp"
                              >
                                <Plus className="w-3.5 h-3.5 stroke-[3px]" /> Save to Board Database
                              </button>
                            </div>
                          </form>
                        </motion.div>
                      )}
                    </AnimatePresence>

                    {/* PYQ List */}
                    {pyqsLoading ? (
                      <div className="py-20 flex flex-col items-center justify-center gap-3 text-ink3">
                        <RefreshCw className="w-6 h-6 animate-spin text-emerald-600" />
                        <span className="text-[10px] font-black uppercase tracking-[0.2em]">Synchronizing authentic questions...</span>
                      </div>
                    ) : pyqs.length > 0 ? (
                      <div className="grid grid-cols-1 gap-4">
                        {pyqs.map((pyq, idx) => {
                          const isRevealed = !!revealedPyq[pyq.id];
                          return (
                            <div
                              key={pyq.id}
                              className={cn(
                                "bg-surface p-6 rounded-[32px] border shadow-sm transition-all relative overflow-hidden group",
                                pyq.addedByUser ? "border-emerald-500/20 bg-gradient-to-br from-surface to-emerald-50/10" : "border-border hover:border-gray-300"
                              )}
                            >
                              <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
                                <div className="flex flex-wrap items-center gap-2">
                                  <span className="px-3 py-1 bg-emerald-100 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400 text-[9px] font-black tracking-widest rounded-full uppercase flex items-center gap-1">
                                    <Calendar className="w-3 h-3" /> CBSE {pyq.year}
                                  </span>
                                  <span className="px-3 py-1 bg-surface2 border border-border text-ink2 text-[9px] font-black tracking-widest rounded-full uppercase">
                                    {pyq.marks} Mark{pyq.marks > 1 ? 's' : ''}
                                  </span>
                                  <span className="px-3 py-1 bg-surface2 border border-border text-ink2 text-[9px] font-black tracking-widest rounded-full uppercase">
                                    {pyq.type}
                                  </span>
                                  {pyq.addedByUser && (
                                    <span className="px-3 py-1 bg-blue-550 text-blue-700 border border-blue-100 text-[8px] font-black tracking-widest rounded-full uppercase dark:bg-sky-950 dark:text-sky-300">
                                      Contributed
                                    </span>
                                  )}
                                </div>

                                <div className="flex items-center gap-1.5">
                                  <span className="text-[9px] font-mono text-ink3 font-bold uppercase select-none">{pyq.source || "CBSE Paper"}</span>
                                  {pyq.addedByUser && (
                                    <button
                                      type="button"
                                      onClick={async () => {
                                        await deleteRealPYQ(pyq.id, subjectKey, selectedCh);
                                        setPyqs(prev => prev.filter(p => p.id !== pyq.id));
                                        showToast("Question deleted from board database.");
                                      }}
                                      className="p-1 rounded-md text-red-500 hover:bg-red-50 hover:text-red-600 transition-all opacity-0 group-hover:opacity-100"
                                      title="Delete custom question"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                  )}
                                </div>
                              </div>

                              <div className="space-y-4">
                                <div className="flex items-start gap-3">
                                  <span className="text-xl font-display font-bold text-emerald-600 shrink-0 select-none">Q.</span>
                                  <h4 className="text-sm font-semibold text-ink leading-relaxed select-text pt-0.5">{pyq.question}</h4>
                                </div>

                                <div className="flex justify-end border-t border-border/60 pt-3.5 mt-3.5">
                                  <button
                                    onClick={() => setRevealedPyq(prev => ({ ...prev, [pyq.id]: !isRevealed }))}
                                    className={cn(
                                      "px-4.5 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest border transition-all flex items-center gap-2",
                                      isRevealed
                                        ? "bg-surface text-ink3 border-border hover:bg-surface2"
                                        : "bg-emerald-600 hover:bg-emerald-700 text-white border-transparent shadow shadow-emerald-200 dark:shadow-none"
                                    )}
                                  >
                                    {isRevealed ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                                    {isRevealed ? "Hide Solution" : "Reveal Answer & Steps"}
                                  </button>
                                </div>

                                {/* Answer Reveal Panel */}
                                <AnimatePresence>
                                  {isRevealed && (
                                    <motion.div
                                      initial={{ opacity: 0, y: -10, height: 0 }}
                                      animate={{ opacity: 1, y: 0, height: 'auto' }}
                                      exit={{ opacity: 0, y: -10, height: 0 }}
                                      className="overflow-hidden border-t border-emerald-500/10 mt-2 bg-emerald-50/15 dark:bg-emerald-950/5 p-4 rounded-2xl"
                                    >
                                      <div className="flex items-start gap-3 pt-2">
                                        <span className="text-[10px] font-black uppercase tracking-widest text-emerald-600 mt-1 shrink-0">Solution:</span>
                                        <div className="text-xs font-medium text-ink2 leading-relaxed whitespace-pre-line flex-1 select-text">
                                          {pyq.answer}
                                        </div>
                                      </div>
                                    </motion.div>
                                  )}
                                </AnimatePresence>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    ) : (
                      <div className="bg-surface border border-border p-12 rounded-[32px] text-center space-y-4 shadow-sm">
                        <div className="w-16 h-16 bg-emerald-50 dark:bg-emerald-950/20 rounded-full flex items-center justify-center mx-auto text-3xl">
                          🏛️
                        </div>
                        <div className="space-y-1">
                          <h4 className="font-display text-lg text-ink">No hand-verified PYQs yet</h4>
                          <p className="text-xs text-ink3 max-w-sm mx-auto leading-relaxed">
                            Be the first to insert an authentic, real board exam question and marking solution for this chapter!
                          </p>
                        </div>
                        <button
                          onClick={() => setShowAddPyqForm(true)}
                          className="px-5 py-2.5 rounded-xl bg-ink text-white hover:bg-emerald-600 text-[10px] font-black uppercase tracking-widest transition-all inline-flex items-center gap-1.5"
                        >
                          <Plus className="w-3.5 h-3.5" /> Contribute Real PYQ
                        </button>
                      </div>
                    )}
                  </div>
                )}

                {activeTab === 'video' && (
                  <div className="space-y-6 text-left">
                    {/* Header */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-surface p-6 rounded-[28px] border border-border shadow-3xs">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 bg-red-500/10 rounded-2xl flex items-center justify-center text-red-600">
                          <Video className="w-6 h-6 animate-pulse" />
                        </div>
                        <div>
                          <span className="text-[10px] font-black uppercase text-red-600 tracking-wider">CBSE SMART CLASS</span>
                          <h3 className="font-display text-xl font-bold text-ink">YouTube Study Desk</h3>
                        </div>
                      </div>

                      {/* Top Action Area: Teacher Preference & Load Custom */}
                      {(() => {
                        const currentTeacher = preferredTeachers[subjectKey] || getPreferredTeacher(subjectKey);
                        const popularList = POPULAR_TEACHERS[subjectKey] || [];

                        return (
                          <div className="flex flex-wrap items-center gap-2">
                            <div className="flex items-center gap-1.5 bg-surface2 px-3 py-1.5 rounded-xl border border-border text-xs font-bold text-ink2">
                              <span>Educator:</span>
                              <select
                                value={popularList.includes(currentTeacher) ? currentTeacher : "custom"}
                                onChange={(e) => {
                                  const val = e.target.value;
                                  if (val === "custom") {
                                    const promptVal = prompt(`Enter custom teacher/educator name on YouTube:`);
                                    if (promptVal && promptVal.trim()) {
                                      handleTeacherChange(subjectKey, promptVal.trim());
                                    }
                                  } else {
                                    handleTeacherChange(subjectKey, val);
                                  }
                                }}
                                className="bg-transparent font-black text-red-600 cursor-pointer outline-none border-none py-px focus:ring-0"
                              >
                                {popularList.map(t => (
                                  <option key={t} value={t}>{t}</option>
                                ))}
                                <option value="custom">✏️ Custom Educator...</option>
                              </select>
                            </div>
                          </div>
                        );
                      })()}
                    </div>

                    {/* Main Workspace Layout */}
                    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                      {/* Left Pane: Active Player, Presets & Timeline Bookmarks (7 Cols) */}
                      <div className="lg:col-span-7 space-y-6">
                        {/* Interactive Screen Player Card */}
                        <div className="bg-surface rounded-[28px] border border-border overflow-hidden shadow-sm">
                          <div className="p-5 border-b border-border bg-gradient-to-r from-red-50 to-orange-50/50 dark:from-red-950/20 dark:to-orange-950/5 flex items-center justify-between">
                            <div className="space-y-1">
                              <div className="flex items-center gap-2">
                                <span className="inline-block w-2.5 h-2.5 bg-red-600 rounded-full animate-ping" />
                                <span className="text-[10px] font-black uppercase text-red-600 tracking-widest font-mono">
                                  {selectedVideo?.type === 'one_shot' ? '🔥 FULL ONE-SHOT' : selectedVideo?.type === 'pyqs' ? '📝 PYQ PRACTICE' : '⚡ KEY REVISION'}
                                </span>
                              </div>
                              <h4 className="font-display font-medium text-ink text-sm max-w-md line-clamp-1">
                                {selectedVideo ? selectedVideo.title : 'Loading CBSE Board Lecture...'}
                              </h4>
                            </div>
                            <span className="text-[10px] bg-red-100 text-red-700 px-2 py-0.5 rounded-md font-extrabold font-mono shrink-0">
                              {selectedVideo ? selectedVideo.channel : ''}
                            </span>
                          </div>

                          {/* Render Player Screen */}
                          <div className="bg-black aspect-video relative">
                            {selectedVideo ? (
                              <iframe
                                key={selectedVideo.id + "_" + activeVideoStart + "_" + videoPlayerKey}
                                src={`https://www.youtube.com/embed/${selectedVideo.id}?start=${activeVideoStart}&autoplay=${activeVideoStart > 0 ? 1 : 0}&rel=0`}
                                className="absolute inset-0 w-full h-full"
                                title={selectedVideo.title}
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                allowFullScreen
                                referrerPolicy="no-referrer"
                              ></iframe>
                            ) : (
                              <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-6 bg-slate-900 border border-border text-white">
                                <Video className="w-12 h-12 text-slate-600 mb-3 animate-bounce" />
                                <p className="text-xs font-semibold text-slate-400">Select a study lecture from the playlist or paste a custom stream address below.</p>
                              </div>
                            )}
                          </div>

                          {/* Jump Preset Timeline Targets */}
                          {selectedVideo && selectedVideo.timestamps && selectedVideo.timestamps.length > 0 && (
                            <div className="p-5 border-t border-border bg-surface2">
                              <span className="text-[10px] font-black uppercase text-ink3 tracking-widest block mb-3 font-mono">
                                ⏱️ CHRONOLOGICAL BOARD OBJECTIVES
                              </span>
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                                {selectedVideo.timestamps.map((ts, index) => (
                                  <button
                                    key={index}
                                    onClick={() => {
                                      setActiveVideoStart(ts.time);
                                      setVideoPlayerKey(prev => prev + 1);
                                      showToast(`⏱️ Stream seeking to timestamp [${ts.stampStr}]`);
                                    }}
                                    className="p-2.5 rounded-xl border border-border text-left hover:border-red-500 hover:bg-white text-xs font-semibold text-ink2 hover:text-red-650 transition-all flex items-center gap-2 group cursor-pointer shadow-3xs"
                                  >
                                    <span className="w-5 h-5 rounded-md bg-red-100 text-red-700 font-extrabold flex items-center justify-center text-[10px] font-mono shrink-0 tracking-tighter group-hover:bg-red-600 group-hover:text-white transition-colors">
                                      {ts.stampStr}
                                    </span>
                                    <span className="line-clamp-1 text-[11px] group-hover:translate-x-0.5 transition-transform">
                                      {ts.label}
                                    </span>
                                  </button>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>

                        {/* Paste Custom Embed Input */}
                        <div className="bg-surface p-5 rounded-[28px] border border-border space-y-4 shadow-3xs">
                          <h4 className="font-display text-sm select-none flex items-center gap-1.5 text-ink">
                            <span>🚀 Load Custom Stream URL</span>
                            <span className="text-[9px] font-black uppercase bg-slate-100 text-slate-600 py-0.5 px-1.5 rounded tracking-wide font-mono">BYPass</span>
                          </h4>
                          <p className="text-xs text-ink3 leading-relaxed">
                            Pasted direct links from other creators (e.g. <i>Next Toppers, Shubham Pathak, Ashu Sir</i>) will render immediately inside our classroom workspace.
                          </p>
                          <div className="flex items-center gap-2">
                            <input
                              type="text"
                              value={customVideoUrl}
                              onChange={(e) => setCustomVideoUrl(e.target.value)}
                              placeholder="Paste share link, search watch link, or 11-char Video ID (e.g. k6K-oXezU70)..."
                              className="flex-1 p-3 bg-surface2 border border-border rounded-xl text-xs font-semibold placeholder:text-ink3 text-ink outline-none focus:border-red-500"
                            />
                            <button
                              onClick={handleLoadCustomUrl}
                              className="px-4 py-3 bg-ink hover:bg-red-600 text-white rounded-xl text-xs font-black uppercase tracking-widest transition-colors cursor-pointer"
                            >
                              Load
                            </button>
                          </div>
                        </div>
                      </div>

                      {/* Right Pane: Playlist Selection, Notes Workspace & AI search (5 Cols) */}
                      <div className="lg:col-span-5 space-y-6">
                        {/* Curated Educator Course Playlists */}
                        <div className="bg-surface p-5 rounded-[28px] border border-border shadow-3xs space-y-4">
                          <div className="flex items-center justify-between">
                            <h4 className="font-display font-medium text-sm text-ink flex items-center gap-2 select-none">
                              <span className="w-2.5 h-2.5 bg-red-600 rounded-full" />
                              Educator Playlist Recommendations
                            </h4>
                            <span className="text-[9px] bg-red-50 text-red-600 px-2 py-0.5 rounded font-black tracking-widest font-mono shrink-0">
                              {chapterVideos.length} STREAM(S)
                            </span>
                          </div>

                          <div className="space-y-2.5">
                            {chapterVideos.map((vc) => {
                              const isActive = selectedVideo?.id === vc.id;
                              return (
                                <button
                                  key={vc.id}
                                  onClick={() => {
                                    setSelectedVideo(vc);
                                    setActiveVideoStart(0);
                                    setVideoPlayerKey(0);
                                    showToast(`🍿 Switched stream: ${vc.title}`);
                                  }}
                                  className={cn(
                                    "w-full p-3.5 rounded-2xl border text-left flex gap-3 transition-all cursor-pointer relative overflow-hidden group shadow-3xs",
                                    isActive
                                      ? "bg-gradient-to-r from-red-500/5 to-orange-500/0 border-red-500/30"
                                      : "bg-surface2 hover:bg-white border-border border-dashed hover:border-slate-400"
                                  )}
                                >
                                  {/* Dummy Play cover */}
                                  <div className="w-16 h-10 bg-black/90 rounded-lg shrink-0 flex items-center justify-center relative overflow-hidden text-white/50 border border-white/10">
                                    <div className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-40 group-hover:scale-110 transition-transform" style={{ backgroundImage: `url(https://img.youtube.com/vi/${vc.id}/hqdefault.jpg)` }} />
                                    <Play className={cn("w-4 h-4 relative drop-shadow-sm transition-colors", isActive ? "text-red-500" : "text-white group-hover:text-red-500")} />
                                  </div>

                                  <div className="space-y-1 flex-1 min-w-0">
                                    <h5 className={cn("text-xs font-extrabold line-clamp-1", isActive ? "text-red-600" : "text-ink")}>
                                      {vc.title}
                                    </h5>
                                    <div className="flex items-center justify-between text-[10px] font-semibold text-ink2">
                                      <span>{vc.channel}</span>
                                      <div className="flex items-center gap-1.5">
                                        <span className="text-[9px] font-black uppercase text-red-500 tracking-tighter bg-red-105 px-1 py-0.25 rounded">
                                          {vc.type.toUpperCase()}
                                        </span>
                                        <span>•</span>
                                        <span className="font-mono">{vc.duration}</span>
                                      </div>
                                    </div>
                                  </div>
                                </button>
                              );
                            })}
                          </div>
                        </div>

                        {/* Interactive Lecture Classroom Notes */}
                        <div className="bg-surface p-5 rounded-[28px] border border-border shadow-3xs space-y-3.5">
                          <div className="flex items-center justify-between">
                            <h4 className="font-display font-medium text-sm text-ink flex items-center gap-1.5 select-none">
                              <Save className="w-4 h-4 text-emerald-600" />
                              Interactive Classroom Notes
                            </h4>
                            <span className="text-[9px] text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded font-bold font-mono uppercase tracking-wider">
                              Autosaved locally
                            </span>
                          </div>
                          
                          <p className="text-xs text-ink3 leading-relaxed">
                            Jot down core formulas and bullet tricks as you listen. It automatically backs up to your local profile.
                          </p>

                          <textarea
                            value={videoNotes}
                            onChange={(e) => {
                              const val = e.target.value;
                              setVideoNotes(val);
                              saveSavedVideoNotes(subjectKey, selectedCh, val);
                            }}
                            rows={4}
                            placeholder="Type equations, crucial dates, definition briefs, and notes here..."
                            className="w-full p-4 bg-surface2 border border-border rounded-xl text-xs font-semibold placeholder:text-ink3 text-ink outline-none focus:border-red-500 leading-relaxed font-mono resize-none shadow-3xs focus:bg-white transition-colors"
                          />
                        </div>

                        {/* Smart AI Topic Crawler search */}
                        <div className="bg-surface p-5 rounded-[28px] border border-border shadow-3xs space-y-4">
                          <h4 className="font-display font-medium text-sm text-ink flex items-center gap-2 select-none">
                            <Sparkles className="w-4 h-4 text-purple-600 animate-pulse" />
                            Dynamic Video Query Finder
                          </h4>
                          <p className="text-xs text-ink3 leading-relaxed">
                            Instantly query the Gemini Search Core to fetch and curate highly verified CBSE learning clips on ANY sub-topics.
                          </p>

                          <div className="flex items-center gap-2">
                            <input
                              type="text"
                              value={videoSearchTerm}
                              onChange={(e) => setVideoSearchTerm(e.target.value)}
                              placeholder="e.g. Balancing redox rxn tricks..."
                              className="flex-1 p-3 bg-surface2 border border-border rounded-xl text-xs font-semibold placeholder:text-ink3 text-ink outline-none focus:border-red-500"
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') handleSearchVideos();
                              }}
                            />
                            <button
                              onClick={handleSearchVideos}
                              disabled={isSearchingVideos}
                              className="px-4 py-3 bg-purple-650 hover:bg-purple-700 disabled:bg-purple-400 text-white rounded-xl text-xs font-black uppercase tracking-widest transition-colors cursor-pointer flex items-center gap-1.5"
                            >
                              {isSearchingVideos ? (
                                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                              ) : 'Fetch'}
                            </button>
                          </div>

                          {/* AI Search Video Results */}
                          {searchVideoResults && searchVideoResults.length > 0 && (
                            <div className="space-y-2 border-t border-border pt-4">
                              <span className="text-[10px] font-black uppercase text-purple-600 tracking-wider block mb-1">
                                🛸 FEtch Results: Click to Load Video
                              </span>
                              {searchVideoResults.map((v) => {
                                const isActive = selectedVideo?.id === v.id;
                                return (
                                  <button
                                    key={v.id}
                                    onClick={() => {
                                      setSelectedVideo(v);
                                      setActiveVideoStart(0);
                                      setVideoPlayerKey(0);
                                      showToast(`🎯 Embedded session: ${v.title}`);
                                    }}
                                    className={cn(
                                      "w-full text-left p-2.5 rounded-xl border flex items-center gap-2 text-xs font-semibold cursor-pointer text-ink hover:bg-purple-100/10 transition-all",
                                      isActive ? "border-purple-600 bg-purple-100/5" : "border-border"
                                    )}
                                  >
                                    <div className="w-8 h-8 rounded bg-purple-100 text-purple-700 flex items-center justify-center shrink-0">
                                      <Play className="w-3 h-3 text-purple-700" />
                                    </div>
                                    <div className="flex-1 min-w-0">
                                      <div className="font-extrabold truncate text-[11px] text-ink">{v.title}</div>
                                      <div className="text-[9px] text-ink2 truncate font-bold">{v.channel} • {v.duration} • {v.views}</div>
                                    </div>
                                  </button>
                                );
                              })}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </motion.div>
            </AnimatePresence>
          </div>
          </>
        )}
      </div>
    </div>
  );
}
