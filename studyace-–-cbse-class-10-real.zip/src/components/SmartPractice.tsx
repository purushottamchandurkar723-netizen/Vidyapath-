/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Screen } from '../App';
import { SUBJECTS } from '../constants';
import { getAIResponse } from '../services/geminiService';
import { ArrowLeft, Zap, RefreshCw, CheckCircle, XCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn, isAnswerCorrect, loadItem } from '../lib/utils';

interface PracticeProps {
  navigateTo: (s: Screen, subKey?: string | null, chIdx?: number | null) => void;
  showToast: (msg: string) => void;
}

export default function SmartPractice({ navigateTo, showToast }: PracticeProps) {
  const [loading, setLoading] = useState(true);
  const [sections, setSections] = useState<any[]>([]);
  const [score, setScore] = useState({ correct: 0, total: 0 });

  useEffect(() => {
    loadPractice();
  }, []);

  const loadPractice = async () => {
    setLoading(true);
    
    // Identify weak topics from mistake book
    const mistakes = loadItem<any[]>('vidypath_mistakes_v1', []);
    const weakMap: Record<string, number> = {};
    mistakes.forEach(m => {
      const k = `${m.subject} – ${m.chapterName}`;
      weakMap[k] = (weakMap[k] || 0) + 1;
    });
    const weakTopics = Object.entries(weakMap)
      .sort((a,b) => b[1] - a[1])
      .slice(0, 2)
      .map(entry => entry[0]);

    try {
      const prompts = [
        {
          id: 'weak',
          title: weakTopics.length > 0 ? '⚠️ Weak Topics' : '📚 General Revision',
          prompt: `Generate 3 MCQ questions for revision on: ${weakTopics.length > 0 ? weakTopics.join(' and ') : 'general CBSE Class 10 science and maths'}. Return ONLY valid JSON: [{"question":"...","options":["A","B","C","D"],"answer":"exact option"}]`
        },
        {
          id: 'maths',
          title: '📐 Maths Numericals',
          prompt: `Generate 2 numerical MCQ questions from Class 10 Mathematics. Return ONLY valid JSON: [{"question":"...","options":["A","B","C","D"],"answer":"exact option"}]`
        },
        {
          id: 'physics',
          title: '⚡ Physics Numericals',
          prompt: `Generate 2 numerical MCQ questions from Class 10 Physics with units. Return ONLY valid JSON: [{"question":"...","options":["A","B","C","D"],"answer":"exact option"}]`
        }
      ];

      const results = await Promise.all(prompts.map(async p => {
        const langInstr = p.prompt.toLowerCase().includes('hindi') 
          ? "\nIMPORTANT: Generate Hindi content strictly in HINDI (Devanagari)." 
          : p.prompt.toLowerCase().includes('marathi') 
          ? "\nIMPORTANT: Generate Marathi content strictly in MARATHI (Devanagari)." 
          : "";
        
        const raw = await getAIResponse(p.prompt + langInstr);
        const jt = raw.replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/\s*```\s*$/i, '').trim();
        const qs = JSON.parse(jt.slice(jt.indexOf('['), jt.lastIndexOf(']') + 1));
        return { ...p, questions: qs.map((q: any) => ({ ...q, answered: false, selected: null, isCorrect: false })) };
      }));

      setSections(results);
      setScore({ correct: 0, total: results.reduce((acc, s) => acc + s.questions.length, 0) });
    } catch (e) {
      showToast('Offline fallback: Loading practice set from local storage.');
      // Handle fallback...
    } finally {
      setLoading(false);
    }
  };

  const handleSelect = (sIdx: number, qIdx: number, option: string) => {
    const s = [...sections];
    const q = s[sIdx].questions[qIdx];
    if (q.answered) return;

    const isCorrect = isAnswerCorrect(option, q.answer);
    q.answered = true;
    q.selected = option;
    q.isCorrect = isCorrect;
    
    if (isCorrect) setScore(prev => ({ ...prev, correct: prev.correct + 1 }));
    setSections(s);
  };

  const today = new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' });

  if (loading) return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] text-center p-6 space-y-4">
      <div className="w-12 h-12 border-4 border-border border-t-orange rounded-full animate-spin" />
      <div className="space-y-1">
        <h3 className="font-bold text-lg">Building Practice Session...</h3>
        <p className="text-xs text-ink3">AI is picking weak topics and generating numericals</p>
      </div>
    </div>
  );

  return (
    <div className="max-w-[700px] mx-auto px-4 py-8 pb-32 space-y-8">
      <button 
        onClick={() => navigateTo('home')}
        className="inline-flex items-center gap-2 px-4 py-2 bg-surface border border-border rounded-xl text-sm font-semibold text-ink2 hover:bg-orange-lt hover:text-orange hover:border-orange-mid transition-all shadow-sm"
      >
        <ArrowLeft className="w-4 h-4" />
        Home
      </button>

      <div className="space-y-1">
        <div className="inline-flex px-3 py-1 bg-orange-lt text-orange border border-orange-mid rounded-full text-[10px] font-black uppercase tracking-widest mb-1">
          ⚡ Today's Smart Practice
        </div>
        <h2 className="text-3xl font-display leading-tight">{today}</h2>
        <p className="text-sm text-ink2">Personalised revision based on your weak areas and board numericals.</p>
      </div>

      <div className="space-y-10">
        {sections.map((sec, sIdx) => (
          <div key={`sec-${sIdx}`} className="space-y-4">
            <div className="flex items-center gap-3">
              <h3 className="text-xs font-black uppercase tracking-widest text-ink2">{sec.title}</h3>
              <div className="h-px flex-1 bg-border/60" />
            </div>
            
            <div className="space-y-4">
              {sec.questions.map((q: any, qIdx: number) => (
                <div key={`q-${sIdx}-${qIdx}`} className="bg-surface p-5 rounded-[28px] border border-border shadow-sm space-y-4">
                  <div className="text-[10px] font-bold text-ink3">Q{qIdx+1}</div>
                  <p className="text-sm font-bold leading-relaxed">{q.question}</p>
                  
                  <div className="grid grid-cols-1 gap-1.5">
                    {q.options.map((opt: string, i: number) => {
                      const letters = ['A','B','C','D'];
                      const isCorrect = opt === q.answer;
                      const isSelected = q.selected === opt;
                      
                      let btn = "bg-surface2 border-border/50 text-ink hover:border-orange/30";
                      let letter = "bg-border text-ink2";

                      if (q.answered) {
                        if (isCorrect) { btn = "bg-green-50 border-green-500 text-green-900"; letter = "bg-green-500 text-white"; }
                        else if (isSelected) { btn = "bg-red-50 border-red-500 text-red-900"; letter = "bg-red-500 text-white"; }
                        else { btn = "bg-surface border-border opacity-50"; letter = "bg-surface2 text-ink3"; }
                      }

                      return (
                        <button
                          key={`opt-${sIdx}-${qIdx}-${i}`}
                          disabled={q.answered}
                          onClick={() => handleSelect(sIdx, qIdx, opt)}
                          className={cn("flex items-start text-left gap-3 p-3 border-2 rounded-xl text-xs font-semibold transition-all", btn)}
                        >
                          <div className={cn("w-6 h-6 flex-shrink-0 flex items-center justify-center rounded-lg font-bold text-[10px]", letter)}>
                             {letters[i]}
                          </div>
                          <span className="pt-0.5">{opt}</span>
                        </button>
                      );
                    })}
                  </div>

                  {q.answered && (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className={cn(
                      "px-3 py-2 rounded-xl text-[10px] font-bold flex items-center gap-2",
                      q.isCorrect ? "bg-green-50 text-green-700" : "bg-red-50 text-red-700"
                    )}>
                      {q.isCorrect ? <CheckCircle className="w-3.5 h-3.5" /> : <XCircle className="w-3.5 h-3.5" />}
                      {q.isCorrect ? "Correct answer!" : `Incorrect. Answer is: ${q.answer}`}
                    </motion.div>
                  )}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      <div className="sticky bottom-6 left-0 w-full z-40">
        <div className="bg-surface/90 backdrop-blur-md border border-border p-5 rounded-3xl shadow-xl flex items-center justify-between gap-4">
          <div>
            <div className="text-[10px] font-bold text-ink3 uppercase">Session Score</div>
            <div className="text-2xl font-display text-orange">{score.correct} <span className="text-sm opacity-40">/ {score.total}</span></div>
          </div>
          <button 
            onClick={() => navigateTo('home')}
            className="bg-orange text-white px-8 py-3 rounded-2xl font-bold text-sm shadow-lg shadow-orange/30 active:scale-95 transition-all"
          >
            Finish Practice
          </button>
        </div>
      </div>
    </div>
  );
}
