/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Book, Plus, Trash2, MessageSquare, Sparkles, Wand2, FileText, ChevronRight, X, Send, BookOpen, Quote } from 'lucide-react';
import { cn, loadItem, saveItem } from '../lib/utils';
import { getAIResponse } from '../services/geminiService';
import { SUBJECTS } from '../constants';

interface Source {
  id: string;
  title: string;
  content: string;
  type: 'chapter' | 'manual';
  subject?: string;
}

interface NotebookBuddyProps {
  showToast: (msg: string) => void;
}

export default function NotebookBuddy({ showToast }: NotebookBuddyProps) {
  const [sources, setSources] = useState<Source[]>(() => loadItem('vidypath_notebook_sources', []));
  const [activeTab, setActiveTab] = useState<'chat' | 'sources'>('sources');
  const [chat, setChat] = useState<{role: 'user' | 'assistant', content: string}[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isAddingSource, setIsAddingSource] = useState(false);
  const [newSource, setNewSource] = useState({ title: '', content: '', type: 'manual' as const });
  
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    saveItem('vidypath_notebook_sources', sources);
  }, [sources]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chat, isTyping]);

  const addManualSource = () => {
    if (!newSource.title || !newSource.content) {
      showToast('Please fill both title and content.');
      return;
    }
    const source: Source = {
      id: Date.now().toString(),
      ...newSource
    };
    setSources(prev => [...prev, source]);
    setNewSource({ title: '', content: '', type: 'manual' });
    setIsAddingSource(false);
    showToast('Source added to notebook!');
  };

  const deleteSource = (id: string) => {
    setSources(prev => prev.filter(s => s.id !== id));
    showToast('Source removed.');
  };

  const generateGroundedResponse = async () => {
    if (!input.trim() || isTyping) return;
    if (sources.length === 0) {
      showToast('Add some sources first to ground the AI!');
      return;
    }

    const userMsg = { role: 'user' as const, content: input };
    setChat(prev => [...prev, userMsg]);
    const currentInput = input;
    setInput('');
    setIsTyping(true);

    try {
      const context = sources.map(s => `[SOURCE: ${s.title}]\n${s.content}`).join('\n\n---\n\n');
      const prompt = `You are a specialized Study Assistant (like NotebookLM). 
I will provide you with sources from my notebook. You MUST answer the user's question ONLY using the information contained in these sources.
If the answer is NOT in the sources, clearly state that you cannot find this information in the current notebook sources.

[SOURCES]
${context}

[USER QUESTION]
${currentInput}

[INSTRUCTIONS]
- Be concise and grounded.
- If you quote or reference a source, mention its title (e.g., "According to [Chapter Name]...").
- Do not use outside knowledge.`;

      const response = await getAIResponse(prompt);
      setChat(prev => [...prev, { role: 'assistant', content: response }]);
    } catch (error) {
      showToast('Failed to get response.');
      setChat(prev => [...prev, { role: 'assistant', content: '⚠️ AI grounding failed. Please check your internet or retry.' }]);
    } finally {
      setIsTyping(false);
    }
  };

  const synthesize = async (mode: 'summary' | 'qa' | 'guide') => {
    if (sources.length === 0) {
      showToast('No sources to synthesize.');
      return;
    }
    setIsTyping(true);
    setActiveTab('chat');
    
    const context = sources.map(s => `[SOURCE: ${s.title}]\n${s.content}`).join('\n\n---\n\n');
    let prompt = '';
    if (mode === 'summary') {
      prompt = `Create a consolidated executive summary for all the sources in my study notebook. Focus on the most important themes and definitions.\n\n[SOURCES]\n${context}`;
    } else if (mode === 'qa') {
      prompt = `Generate a set of 5 FAQ style questions and answers strictly based on the provided notebook sources. These should be common doubts a student might have.\n\n[SOURCES]\n${context}`;
    } else {
      prompt = `Create a comprehensive Study Guide from these sources. Use bullet points, bold key terms, and structure it logically for board exam revision.\n\n[SOURCES]\n${context}`;
    }

    try {
      const response = await getAIResponse(prompt);
      setChat(prev => [...prev, { role: 'assistant', content: response }]);
    } catch (error) {
       showToast('Synthesis failed.');
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Info */}
      <div className="bg-ink p-6 rounded-[32px] text-white flex items-center justify-between shadow-xl shadow-ink/20">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-orange font-bold text-[10px] uppercase tracking-[0.2em]">
            <Sparkles className="w-3.5 h-3.5" />
            Notebook Intelligence
          </div>
          <h3 className="text-xl font-display">Study Notebook</h3>
          <p className="text-[10px] text-white/60 font-medium tracking-wide">
            Ground your AI in your own notes and chapters. 
          </p>
        </div>
        <div className="hidden sm:flex gap-4">
          <div className="text-center">
            <div className="text-xl font-display">{sources.length}</div>
            <div className="text-[8px] font-black uppercase opacity-50">Sources</div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 p-1 bg-surface2 border border-border rounded-2xl">
        <button 
          onClick={() => setActiveTab('sources')}
          className={cn(
            "flex-1 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all",
            activeTab === 'sources' ? "bg-white text-ink shadow-sm" : "text-ink3 hover:text-ink"
          )}
        >
          Sources
        </button>
        <button 
          onClick={() => setActiveTab('chat')}
          className={cn(
            "flex-1 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all",
            activeTab === 'chat' ? "bg-white text-ink shadow-sm" : "text-ink3 hover:text-ink"
          )}
        >
          Notebook Chat
        </button>
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'sources' ? (
          <motion.div 
            key="sources"
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.98 }}
            className="space-y-4"
          >
            {/* Action Bar */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <button 
                onClick={() => setIsAddingSource(true)}
                className="flex flex-col items-center justify-center gap-2 p-4 bg-orange text-white rounded-[24px] shadow-lg shadow-orange/20 hover:-translate-y-1 transition-all active:scale-95"
              >
                <Plus className="w-5 h-5 border-2 border-white rounded-md" />
                <span className="text-[9px] font-black uppercase tracking-widest">Add Source</span>
              </button>
              <button 
                onClick={() => synthesize('summary')}
                className="flex flex-col items-center justify-center gap-2 p-4 bg-surface border border-border rounded-[24px] shadow-sm hover:border-orange transition-all active:scale-95 text-ink group"
              >
                <FileText className="w-5 h-5 group-hover:text-orange" />
                <span className="text-[9px] font-black uppercase tracking-widest">Summary</span>
              </button>
              <button 
                onClick={() => synthesize('qa')}
                className="flex flex-col items-center justify-center gap-2 p-4 bg-surface border border-border rounded-[24px] shadow-sm hover:border-orange transition-all active:scale-95 text-ink group"
              >
                <Quote className="w-5 h-5 group-hover:text-orange" />
                <span className="text-[9px] font-black uppercase tracking-widest">Notebook FAQ</span>
              </button>
              <button 
                onClick={() => synthesize('guide')}
                className="flex flex-col items-center justify-center gap-2 p-4 bg-surface border border-border rounded-[24px] shadow-sm hover:border-orange transition-all active:scale-95 text-ink group"
              >
                <Wand2 className="w-5 h-5 group-hover:text-orange" />
                <span className="text-[9px] font-black uppercase tracking-widest">Study Guide</span>
              </button>
            </div>

            {/* List */}
            {sources.length === 0 ? (
              <div className="py-16 text-center space-y-4 bg-surface rounded-[40px] border-2 border-dashed border-border opacity-50">
                <Book className="w-12 h-12 mx-auto" />
                <div className="space-y-1">
                  <h4 className="font-bold">Your Notebook is Empty</h4>
                  <p className="text-[10px] uppercase font-black tracking-widest">Ground your AI by adding sources</p>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {sources.map(s => (
                  <div key={s.id} className="bg-surface border border-border p-5 rounded-[32px] shadow-sm group hover:border-orange transition-all">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 bg-orange-lt text-orange rounded-xl flex items-center justify-center">
                          <BookOpen className="w-4 h-4" />
                        </div>
                        <div>
                          <h4 className="text-sm font-bold line-clamp-1">{s.title}</h4>
                          <span className="text-[8px] font-black uppercase text-ink3 tracking-widest">{s.type === 'chapter' ? 'Imported' : 'Manual Entry'}</span>
                        </div>
                      </div>
                      <button 
                        onClick={() => deleteSource(s.id)}
                        className="p-2 text-ink3 hover:text-red-500 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                    <p className="text-[10px] text-ink2 line-clamp-3 leading-relaxed mb-4">{s.content}</p>
                    <button 
                      onClick={() => { setActiveTab('chat'); setInput(`Summarize ${s.title}`); }}
                      className="text-[9px] font-black uppercase tracking-widest text-orange flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-all transform translate-x-1 group-hover:translate-x-0"
                    >
                      Reflect Content <Plus className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </motion.div>
        ) : (
          <motion.div 
            key="chat"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="flex flex-col h-[560px] bg-surface rounded-[40px] border border-border overflow-hidden"
          >
            <div className="flex-1 overflow-y-auto p-6 space-y-4 no-scrollbar">
              {chat.length === 0 && (
                <div className="h-full flex flex-col items-center justify-center text-center p-8 opacity-40 space-y-4">
                  <MessageSquare className="w-12 h-12" />
                  <div className="space-y-1">
                    <h4 className="font-bold">Grounded Interaction</h4>
                    <p className="text-[10px] uppercase font-black tracking-widest">The AI will only use your notebook sources</p>
                  </div>
                </div>
              )}
              {chat.map((m, i) => (
                <div key={i} className={cn("flex gap-3 max-w-[85%]", m.role === 'user' ? "ml-auto flex-row-reverse" : "")}>
                  <div className={cn(
                    "w-7 h-7 rounded-full flex items-center justify-center text-xs flex-shrink-0 mt-1 shadow-sm",
                    m.role === 'user' ? "bg-ink text-white" : "bg-orange text-white"
                  )}>
                    {m.role === 'user' ? '👤' : '🤖'}
                  </div>
                  <div className={cn(
                    "px-4 py-3 rounded-2xl text-xs leading-relaxed whitespace-pre-wrap",
                    m.role === 'user' ? "bg-surface2 border border-border text-ink rounded-tr-none" : "bg-orange-lt border border-orange/10 text-ink rounded-tl-none"
                  )}>
                    {m.content}
                  </div>
                </div>
              ))}
              {isTyping && (
                <div className="flex gap-3 max-w-[85%]">
                  <div className="w-7 h-7 bg-orange text-white rounded-full flex items-center justify-center text-xs flex-shrink-0 mt-1 shadow-sm">🤖</div>
                  <div className="bg-orange-lt border border-orange/10 px-4 py-3 rounded-2xl rounded-tl-none flex gap-1 items-center">
                    <span className="w-1 h-1 bg-orange rounded-full animate-bounce" />
                    <span className="w-1 h-1 bg-orange rounded-full animate-bounce [animation-delay:0.2s]" />
                    <span className="w-1 h-1 bg-orange rounded-full animate-bounce [animation-delay:0.4s]" />
                  </div>
                </div>
              )}
              <div ref={chatEndRef} />
            </div>

            <div className="p-4 bg-surface border-t border-border flex gap-2">
              <input 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && generateGroundedResponse()}
                placeholder={sources.length === 0 ? "Add sources to start chatting..." : "Ask your notebook..."}
                disabled={sources.length === 0}
                className="flex-1 bg-surface2 border-1.5 border-border rounded-2xl px-4 py-3 text-[11px] outline-none focus:border-orange transition-all font-bold placeholder:opacity-50"
              />
              <button 
                onClick={generateGroundedResponse}
                disabled={!input.trim() || isTyping || sources.length === 0}
                className="w-12 h-12 bg-orange text-white rounded-2xl shadow-lg shadow-orange/20 flex items-center justify-center disabled:opacity-50 transition-all active:scale-95"
              >
                <Send className="w-5 h-5 fill-current" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Add Source Modal */}
      <AnimatePresence>
        {isAddingSource && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsAddingSource(false)}
              className="absolute inset-0 bg-ink/60 backdrop-blur-sm" 
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-[480px] bg-surface rounded-[40px] shadow-2xl border border-border p-8 space-y-6"
            >
              <div className="flex justify-between items-center">
                <div className="space-y-1">
                  <h3 className="text-xl font-display">Add Knowledge Source</h3>
                  <p className="text-[10px] text-ink3 uppercase font-black tracking-widest">Manual Entry</p>
                </div>
                <button 
                  onClick={() => setIsAddingSource(false)}
                  className="p-2 hover:bg-surface2 rounded-full transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-ink3">Title / Topic Name</label>
                  <input 
                    value={newSource.title}
                    onChange={(e) => setNewSource({...newSource, title: e.target.value})}
                    placeholder="e.g. Fundamental Rights - My Class Notes"
                    className="w-full p-4 bg-surface2 border-1.5 border-border rounded-2xl text-sm outline-none focus:border-orange transition-all font-bold"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-ink3">Content / Notes</label>
                  <textarea 
                    value={newSource.content}
                    onChange={(e) => setNewSource({...newSource, content: e.target.value})}
                    placeholder="Paste your notes or some paragraphs here..."
                    className="w-full p-4 bg-surface2 border-1.5 border-border rounded-2xl text-sm outline-none focus:border-orange transition-all h-48 resize-none font-medium leading-relaxed"
                  />
                </div>
              </div>

              <button 
                onClick={addManualSource}
                className="w-full py-4 bg-orange text-white rounded-2xl font-bold text-sm shadow-xl shadow-orange/20 hover:-translate-y-1 transition-all active:scale-[0.98]"
              >
                Save to Notebook
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
