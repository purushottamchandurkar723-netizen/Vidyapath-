/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Screen } from '../App';
import { SUBJECTS } from '../constants';
import { ArrowLeft, ChevronRight, CheckCircle2 } from 'lucide-react';
import { cn, loadItem } from '../lib/utils';
import { ProgressRecord } from '../types';

interface ChaptersProps {
  subjectKey: string;
  navigateTo: (s: Screen, subKey?: string | null, chIdx?: number | null) => void;
}

export default function Chapters({ subjectKey, navigateTo }: ChaptersProps) {
  const sub = SUBJECTS[subjectKey];
  const allProg = loadItem<Record<string, ProgressRecord>>('vidypath_progress_v4', {});

  return (
    <div className="max-w-[780px] mx-auto px-4 py-8 pb-32">
      <button 
        onClick={() => navigateTo('home')}
        className="inline-flex items-center gap-2 mb-8 text-ink3 font-bold text-xs uppercase tracking-widest hover:text-orange transition-colors"
      >
        <ArrowLeft className="w-3.5 h-3.5" />
        Back
      </button>

      <header className="mb-10">
        <div 
          className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest mb-4"
          style={{ backgroundColor: sub.light, color: sub.color }}
        >
          {sub.icon} {sub.label}
        </div>
        <h2 className="text-3xl font-display tracking-tight text-ink">Choose a chapter</h2>
        <p className="text-sm text-ink2 mt-1">Study notes and quizzes are generated for each chapter.</p>
      </header>

      <div className="grid grid-cols-1 gap-2.5">
        {sub.chapters.map((ch, i) => {
          const rec = allProg[`${subjectKey}__${ch.name}`];
          const pct = rec ? Math.round((rec.bestScore / rec.totalOut) * 100) : 0;
          
          return (
            <button
              key={i}
              onClick={() => navigateTo('chapter-hub', subjectKey, i)}
              className="flex items-center gap-4 p-5 bg-surface border border-border rounded-[24px] hover:border-orange/20 hover:bg-orange-lt/30 transition-all text-left group shadow-sm"
            >
              <div className="w-10 h-10 rounded-xl bg-surface2 border border-border flex items-center justify-center font-display font-black text-sm text-ink3 group-hover:bg-orange group-hover:text-white transition-colors">
                {String(i + 1).padStart(2, '0')}
              </div>
              
              <div className="flex-1 min-w-0">
                <div className="text-sm font-bold text-ink truncate group-hover:text-orange transition-colors">{ch.name}</div>
                {rec && (
                  <div className="flex items-center gap-2 mt-0.5">
                    <div className={cn(
                      "px-1.5 py-0.5 rounded text-[8px] font-black uppercase tracking-widest",
                      pct >= 80 ? "bg-green-100 text-green-700" : pct >= 50 ? "bg-orange-lt text-orange" : "bg-red-50 text-red-600"
                    )}>
                      Best: {rec.bestScore}/{rec.totalOut}
                    </div>
                  </div>
                )}
              </div>

              {rec?.bestScore === rec?.totalOut ? (
                <CheckCircle2 className="w-5 h-5 text-green-500" />
              ) : (
                <ChevronRight className="w-4 h-4 text-ink3 group-hover:translate-x-1 transition-transform" />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}
