/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { Screen } from '../App';
import { SUBJECTS } from '../constants';
import { loadItem, saveItem, cn } from '../lib/utils';
import { getSyllabusAggregateStats, getAutomatedTodaysTasks, calculateChapterMastery } from '../utils/masteryHelper';
import { motion, AnimatePresence } from 'motion/react';
import { ProgressRecord } from '../types';
import { useAuth } from '../context/AuthContext';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';
import { 
  Bell, 
  Zap, 
  FlaskConical, 
  PenTool, 
  LayoutGrid, 
  Calendar, 
  FileText, 
  Skull, 
  ClipboardList, 
  ChevronRight,
  TrendingUp,
  Flame,
  Target,
  RefreshCw,
  Clock,
  UserPlus,
  Book,
  Check,
  MessageSquare,
  Sparkles,
  Trophy,
  X
} from 'lucide-react';
import DoubtSolverChat from './DoubtSolverChat';
import { fetchLiveCBSEUpdates, CBSEUpdate } from '../services/newsService';
import { getBadgeStatuses } from '../utils/badgeHelper';

interface HomeProps {
  navigateTo: (s: Screen, subKey?: string | null, chIdx?: number | null, topic?: string | null, tab?: string | null) => void;
  showToast: (msg: string) => void;
}

export default function Home({ navigateTo, showToast }: HomeProps) {
  const { user, profile, setAuthModalOpen } = useAuth();
  const [progStats, setProgStats] = useState({ avgPct: 0, count: 0, weakChapter: '' });
  const [streak, setStreak] = useState({ count: 0 });
  const [showCelebration, setShowCelebration] = useState(false);
  const [celebratedStreak, setCelebratedStreak] = useState(0);
  const [updates, setUpdates] = useState<CBSEUpdate[]>(() => loadItem('vidypath_cached_updates', []));
  const [showUpdates, setShowUpdates] = useState(false);
  const [loadingUpdates, setLoadingUpdates] = useState(false);
  const [activeLanguage, setActiveLanguage] = useState<string>(() => loadItem('vidypath_active_language', 'hindi'));
  const [syncing, setSyncing] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [adaptivePlan, setAdaptivePlan] = useState<any>(() => loadItem('vidypath_adaptive_plan', null));
  const [completedTasks, setCompletedTasks] = useState<string[]>(() => {
    const lastReset = loadItem('vidypath_tasks_reset_date', '');
    const today = new Date().toDateString();
    if (lastReset !== today) {
      saveItem('vidypath_tasks_reset_date', today);
      saveItem('vidypath_completed_tasks_today', []);
      return [];
    }
    return loadItem('vidypath_completed_tasks_today', []);
  });

  const [revDueCount, setRevDueCount] = useState(0);

  useEffect(() => {
    try {
      const compChaps = loadItem<Record<string, number>>('vidypath_ft_completed_chapters_val', {});
      const ftDay = loadItem<number>('vidypath_ft_day_val', 1);
      const intervals = [3, 7, 15, 30];
      let dueCount = 0;
      const autoReschedule = loadItem<boolean>('vidypath_rev_auto_reschedule', true);

      Object.entries(compChaps).forEach(([chapName, completionDay]) => {
        let subKey = 'maths';
        Object.entries(SUBJECTS).forEach(([key, sub]) => {
          if (sub.chapters.some(c => c.name === chapName)) {
            subKey = key;
          }
        });

        const mastery = calculateChapterMastery(subKey, chapName);
        const revsCount = mastery.state.revisions_count || 0;

        if (revsCount < 4) {
          const originalDueDay = completionDay + intervals[revsCount];
          let dueDay = originalDueDay;
          if (dueDay < ftDay && autoReschedule) {
            dueDay = ftDay;
          }
          if (dueDay === ftDay) {
            dueCount++;
          }
        }
      });
      setRevDueCount(dueCount);
    } catch (e) {
      console.error('Error calculating home due revisions:', e);
    }
  }, []);

  // Sync Language and Streak from Cloud
  useEffect(() => {
    if (!user) return;
    const fetchPref = async () => {
      setSyncing(true);
      try {
        const snap = await getDoc(doc(db, 'users', user.uid));
        if (snap.exists()) {
          const data = snap.data();
          if (data.secondLanguage) {
            setActiveLanguage(data.secondLanguage);
            saveItem('vidypath_active_language', data.secondLanguage);
          }
          if (data.streak) {
            const cloudStreak = data.streak;
            const localStreak = loadItem<any>('vidypath_streak_v1', null);
            
            if (localStreak) {
              const cloudVal = cloudStreak.count || 0;
              const localVal = localStreak.count || 0;
              
              if (cloudVal > localVal) {
                saveItem('vidypath_streak_v1', cloudStreak);
                setStreak(cloudStreak);
                setCelebratedStreak(cloudVal);
                setShowCelebration(true);
              } else if (localVal > cloudVal) {
                setDoc(doc(db, 'users', user.uid), {
                  streak: localStreak
                }, { merge: true }).catch(err => handleFirestoreError(err, OperationType.WRITE, `users/${user.uid}`));
              }
            } else {
              saveItem('vidypath_streak_v1', cloudStreak);
              setStreak(cloudStreak);
              const cloudVal = cloudStreak.count || 0;
              if (cloudVal > 0) {
                setCelebratedStreak(cloudVal);
                setShowCelebration(true);
              }
            }
          }
        }
        
        // Also sync plan if not in local
        const planSnap = await getDoc(doc(db, 'users', user.uid, 'plans', 'current'));
        if (planSnap.exists()) {
          setAdaptivePlan(planSnap.data());
          saveItem('vidypath_adaptive_plan', planSnap.data());
        }
      } catch (e) {
        console.error('Cloud pref fetch failed:', e);
      } finally {
        setSyncing(false);
      }
    };
    fetchPref();
  }, [user]);

  useEffect(() => {
    const allProg = loadItem<Record<string, ProgressRecord>>('vidypath_progress_v4', {});
    const records = Object.values(allProg);
    
    if (records.length > 0) {
      const avg = Math.round(records.reduce((s: number, r: ProgressRecord) => s + (r.bestScore / r.totalOut) * 100, 0) / records.length);
      const weak = records.find((r: ProgressRecord) => (r.bestScore / r.totalOut) * 100 < 50);
      setProgStats({
        avgPct: avg,
        count: records.length,
        weakChapter: weak ? weak.chapterName : ''
      });
    }

    const todayStr = new Date().toDateString();
    const saved = loadItem<any>('vidypath_streak_v1', null);
    
    // Check badge status on the current records before streak adjusts
    const prevStreakCount = saved?.count || 0;
    const currentProgressRecords = Object.values(loadItem<Record<string, any>>('vidypath_progress_v4', {}));
    const badgesBefore = getBadgeStatuses(prevStreakCount, currentProgressRecords as any);
    
    let newCount = 1;
    let notify = false;
    let notifyMsg = '';

    if (!saved) {
      newCount = 1;
      notify = true;
      notifyMsg = "🔥 Your study streak of 1 day has started! Keep learning daily for Board 2027!";
    } else {
      const lastActiveStr = saved.lastActiveDate;
      const count = saved.count ?? 1;

      if (!lastActiveStr) {
        newCount = count || 1;
      } else {
        const lastActive = new Date(lastActiveStr);
        const today = new Date(todayStr);

        lastActive.setHours(0, 0, 0, 0);
        today.setHours(0, 0, 0, 0);

        const diffTime = today.getTime() - lastActive.getTime();
        const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24));

        if (diffDays === 1) {
          newCount = count + 1;
          notify = true;
          notifyMsg = `🔥 Awesome work! You've extended your study streak to ${newCount} days!`;
          setCelebratedStreak(newCount);
          setShowCelebration(true);
        } else if (diffDays > 1) {
          newCount = 1;
          notify = true;
          notifyMsg = "🎒 Your study streak reset to 1 day. Let's build a new streak starting today!";
        } else {
          newCount = count;
        }
      }
    }

    const updatedStreak = {
      count: newCount,
      lastActiveDate: todayStr
    };

    saveItem('vidypath_streak_v1', updatedStreak);

    // Calculate badge status after streak updates
    const badgesAfter = getBadgeStatuses(newCount, currentProgressRecords as any);
    badgesAfter.forEach(afterStatus => {
      const beforeStatus = badgesBefore.find(b => b.badge.id === afterStatus.badge.id);
      if (afterStatus.unlocked && (!beforeStatus || !beforeStatus.unlocked)) {
        setTimeout(() => {
          showToast(`🏆 NEW ACHIEVEMENT UNLOCKED: "${afterStatus.badge.title}" Badge! Inspect this reward on your Profile page.`);
        }, 3000);
      }
    });
    setStreak(updatedStreak);

    if (notify) {
      setTimeout(() => {
        showToast(notifyMsg);
      }, 1000);
    }

    if (user) {
      setDoc(doc(db, 'users', user.uid), {
        streak: updatedStreak
      }, { merge: true }).catch(err => handleFirestoreError(err, OperationType.WRITE, `users/${user.uid}`));
    }

    // Live CBSE Updates with caching
    const loadUpdates = async () => {
      const lastFetch = loadItem('vidypath_last_update_fetch', 0);
      const now = Date.now();
      const CACHE_TIME = 12 * 60 * 60 * 1000; // 12 hours

      if (updates.length > 0 && (now - lastFetch < CACHE_TIME)) {
        return;
      }

      setLoadingUpdates(true);
      try {
        const liveUpdates = await fetchLiveCBSEUpdates();
        setUpdates(liveUpdates);
        saveItem('vidypath_cached_updates', liveUpdates);
        saveItem('vidypath_last_update_fetch', now);
      } catch (err) {
        console.error('Update fetch failed:', err);
      } finally {
        setLoadingUpdates(false);
      }
    };
    loadUpdates();
  }, [updates.length]);

  const toggleTask = (taskId: string) => {
    const newCompleted = completedTasks.includes(taskId) 
      ? completedTasks.filter(id => id !== taskId)
      : [...completedTasks, taskId];
    setCompletedTasks(newCompleted);
    saveItem('vidypath_completed_tasks_today', newCompleted);
  };

  const scrollToSubjects = () => {
    document.getElementById('subjects')?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleTaskRedirect = (task: any) => {
    let chapterIndex: number | null = null;
    const sub = SUBJECTS[task.subjectKey];
    if (sub && task.chapter) {
      chapterIndex = sub.chapters.findIndex(c => c.name === task.chapter);
      if (chapterIndex === -1) chapterIndex = null;
    }

    const lowercaseTopic = (task.topic || '').toLowerCase();
    const lowercaseAction = (task.actionLabel || '').toLowerCase();
    const idValue = (task.id || '').toLowerCase();

    if (task.type === 'mistake' || idValue.includes('mistake')) {
      navigateTo('mistake-book');
      showToast(`🧙‍♂️ Opened Mistake Book to resolve errors!`);
      return;
    }

    if (idValue.startsWith('quiz-')) {
      if (task.subjectKey && chapterIndex !== null) {
        navigateTo('quiz', task.subjectKey, chapterIndex);
        showToast(`🧩 Opening simulated Board Test quiz for ${task.chapter}!`);
      } else {
        navigateTo('quiz');
      }
      return;
    }

    let targetTab: string = 'ainotes';
    let explanation = 'Revision Notes';

    if (idValue.startsWith('lecture-') || lowercaseTopic.includes('lecture') || lowercaseAction.includes('lecture') || lowercaseAction.includes('video')) {
      targetTab = 'video';
      explanation = 'Video Lectures & tutorials';
    } else if (idValue.startsWith('qbank-') || lowercaseTopic.includes('question bank') || lowercaseTopic.includes('solve') || lowercaseTopic.includes('practice')) {
      targetTab = 'questions';
      explanation = 'Interactive Question Bank';
    } else if (idValue.startsWith('tricks-') || lowercaseTopic.includes('tricks') || lowercaseTopic.includes('shortcut') || lowercaseTopic.includes('mnemonic') || lowercaseTopic.includes('memory hack')) {
      targetTab = 'tricks';
      explanation = 'Memory Hacks & Tricks';
    } else if (lowercaseTopic.includes('formulas') || lowercaseTopic.includes('equations')) {
      targetTab = 'formulas';
      explanation = 'Formulas & Equations';
    } else if (lowercaseTopic.includes('revision') || task.type === 'revision' || idValue.startsWith('rev-')) {
      targetTab = 'ainotes';
      explanation = 'Smart Revision Sheet';
    }

    if (task.subjectKey && chapterIndex !== null) {
      navigateTo('chapter-hub', task.subjectKey, chapterIndex, null, targetTab);
      showToast(`🎯 Directed to ${explanation} for ${task.chapter}!`);
    } else {
      navigateTo('chapter-hub', task.subjectKey || 'maths');
    }
  };

  const getTodayTasks = () => {
    try {
      return getAutomatedTodaysTasks();
    } catch (e) {
      return [
        { id: 'fallback-1', subjectKey: 'maths', chapter: 'Polynomials', topic: 'Initialize your Study Plan', type: 'progress', durationMins: 20, priorityLabel: 'High', actionLabel: 'Select a subject and start quiz' },
        { id: 'fallback-2', subjectKey: 'science', chapter: 'Chemical Reactions and Equations', topic: 'Try Answer Checker in AI Tools', type: 'progress', durationMins: 15, priorityLabel: 'Normal', actionLabel: 'Try Answer Checker' },
      ];
    }
  };

  const todayTasks = getTodayTasks();
  const sysStats = getSyllabusAggregateStats();

  return (
    <div className="max-w-[840px] mx-auto px-4 py-6 pb-24 space-y-6">
      {/* Greeting Banner */}
      <div className="flex items-center justify-between">
        <div className="flex-1">
          <h2 className="text-3xl font-display tracking-tight text-ink">
            Hello, <span className="text-orange">{user?.displayName?.split(' ')[0] || 'Scholar'}</span>
          </h2>
          <p className="text-xs font-semibold text-ink3 uppercase tracking-widest mt-1 opacity-70">Day {streak.count} of your board prep</p>
        </div>

        <div className="flex items-center gap-4 relative">
          {/* Trophy Icon button for friendly competition on top */}
          <button 
            onClick={() => navigateTo('leaderboard')}
            title="Friendly Competition & Leaderboard"
            className="w-12 h-12 rounded-2xl bg-amber-50 border border-amber-200 dark:bg-amber-955/20 dark:border-amber-900/40 flex items-center justify-center hover:bg-amber-100 dark:hover:bg-amber-900/30 transition-colors active:scale-95 group relative shadow-3xs"
          >
            <Trophy className="w-5 h-5 text-amber-500 group-hover:scale-110 transition-transform" />
            <span className="absolute -top-1.5 -right-1.5 bg-amber-500 text-white text-[8px] font-black px-1.5 py-0.5 rounded-full shadow-2xs border border-white dark:border-neutral-900">
              {progStats.count * 100 + streak.count * 25 + Math.round(progStats.avgPct * 2)}
            </span>
          </button>

          <div className="relative">
            <button 
              onClick={() => setShowUpdates(!showUpdates)}
              className="lg:hidden w-12 h-12 rounded-2xl bg-surface border border-border flex items-center justify-center hover:bg-surface2 transition-colors active:scale-95 group"
            >
              <Bell className="w-5 h-5 text-ink3 group-hover:text-blue-500 transition-colors" />
              {updates.some(u => u.isNew) && (
                <span className="absolute top-3 right-3 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-surface animate-bounce" />
              )}
            </button>
            
            {showUpdates && (
              <div className="absolute top-full right-0 mt-3 w-72 bg-surface border border-border rounded-3xl shadow-2xl p-5 z-[100] animate-fadeUp text-left cursor-default" onClick={(e) => e.stopPropagation()}>
                <div className="flex items-center justify-between mb-4">
                  <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-blue-500 flex items-center gap-2">
                    <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-pulse" />
                    CBSE Updates
                  </h4>
                  <span className="text-[9px] font-black uppercase text-ink3 tracking-widest">Session {new Date().getFullYear()}-{new Date().getFullYear() + 1}</span>
                </div>
                <div className="space-y-4">
                  {loadingUpdates && updates.length === 0 ? (
                    <div className="py-8 flex flex-col items-center justify-center gap-3 text-ink3">
                      <RefreshCw className="w-5 h-5 animate-spin" />
                      <span className="text-[10px] font-black uppercase tracking-widest">Syncing with CBSE...</span>
                    </div>
                  ) : updates.length > 0 ? (
                    updates.map((u, i) => (
                      <div key={`update-${i}`} className="flex items-start gap-3 group">
                        <div className="w-1.5 h-1.5 bg-blue-400 rounded-full mt-1.5 shrink-0" />
                        <div className="space-y-1">
                          <p className="text-xs font-bold text-ink leading-tight group-hover:text-blue-600 transition-colors">{u.title}</p>
                          {u.isNew && <span className="inline-block px-1.5 py-0.5 bg-red-500 text-white text-[7px] font-black rounded uppercase">New</span>}
                        </div>
                      </div>
                    ))
                  ) : (
                    <p className="text-xs text-ink3 py-4 text-center">No recent updates available.</p>
                  )}
                  
                  {!loadingUpdates && (
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        saveItem('vidypath_last_update_fetch', 0); // Force refresh
                        window.location.reload(); 
                      }}
                      className="w-full mt-2 py-2 text-[8px] font-black uppercase tracking-[0.2em] text-blue-500 hover:bg-blue-50 transition-colors rounded-lg border border-blue-100 flex items-center justify-center gap-2"
                    >
                      <RefreshCw className="w-3 h-3" /> Refresh Feed
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>

          {user?.photoURL ? (
            <img src={user.photoURL} alt="Profile" className="w-12 h-12 rounded-2xl border-2 border-orange shadow-xl rotate-3 hover:rotate-0 transition-transform" />
          ) : (
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-orange to-[#FF9A3C] flex items-center justify-center text-xl shadow-xl shadow-orange/20 rotate-3 hover:rotate-0 transition-transform">
              🎓
            </div>
          )}
        </div>
      </div>

      {!user && (
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-ink p-7 rounded-[40px] text-white flex flex-col md:flex-row items-center gap-6 relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-48 h-48 bg-orange opacity-20 blur-[100px] -mr-20 -mt-20" />
          <div className="absolute bottom-0 left-0 w-32 h-32 bg-blue-500 opacity-10 blur-[80px] -ml-10 -mb-10" />
          
          <div className="text-center md:text-left relative z-10 flex-1 space-y-2">
            <div className="inline-flex px-2 py-0.5 bg-orange/20 text-orange text-[9px] font-black uppercase tracking-widest rounded">Security First</div>
            <h3 className="text-xl font-display">Sync your prep to the cloud</h3>
            <p className="text-xs text-white/50 leading-relaxed max-w-sm">
              Save your mistake book, progress stats, and custom study plans across all your devices.
            </p>
          </div>
          <button 
            onClick={() => setAuthModalOpen(true)}
            className="w-full md:w-auto px-10 py-4 bg-orange hover:bg-orange-dark text-white rounded-2xl font-black text-[10px] uppercase tracking-[0.2em] shadow-2xl shadow-orange/20 transition-all active:scale-95 flex items-center justify-center gap-3 group cursor-pointer"
          >
            <UserPlus className="w-4 h-4 group-hover:scale-110 transition-transform" />
            Connect Now
          </button>
        </motion.div>
      )}

      {/* Dashboard Feed Column */}
      <div className="space-y-6">
        {/* Hero Banner */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-ink rounded-[40px] p-1 pt-1 overflow-hidden shadow-2xl shadow-ink/10"
        >
          <div className="bg-gradient-to-br from-[#1E1B18] to-[#12100E] rounded-[39px] p-8 text-white relative overflow-hidden">
            <div className="absolute -top-24 -right-24 w-64 h-64 bg-orange opacity-10 blur-[120px]" />
            <div className="absolute -bottom-24 -left-24 w-64 h-64 bg-blue-600 opacity-10 blur-[120px]" />
            
            <div className="relative z-10 space-y-5">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 bg-orange rounded-full animate-pulse" />
                <span className="text-[10px] font-black uppercase tracking-[0.25em] text-orange">Board Exam 2027</span>
              </div>
              
              <h1 className="text-4xl sm:text-5xl font-display leading-[0.95] tracking-tight">
                Master every<br /><span className="text-orange italic">concept.</span>
              </h1>
              
              <p className="text-sm text-white/50 max-w-xs leading-relaxed font-medium">
                Daily adaptive tests, NCERT deep-dives, and AI-powered doubt solving.
              </p>

              <div className="flex flex-wrap gap-3 pt-4">
                <button 
                  onClick={scrollToSubjects}
                  className="bg-orange text-white px-7 py-3.5 rounded-2xl text-[11px] font-black uppercase tracking-widest shadow-xl shadow-orange/20 hover:bg-orange-dark hover:-translate-y-0.5 transition-all active:scale-95"
                >
                  Start Study
                </button>
                <button 
                  onClick={() => navigateTo('ai-tools')}
                  className="bg-white/5 border border-white/10 text-white px-7 py-3.5 rounded-2xl text-[11px] font-black uppercase tracking-widest hover:bg-white/10 hover:-translate-y-0.5 transition-all active:scale-95 flex items-center gap-2"
                >
                  <Zap className="w-4 h-4 text-orange" />
                  AI Tools
                </button>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Streak Bar */}
        {streak.count > 0 && (
          <div className="flex items-center gap-4 bg-gradient-to-r from-orange to-[#FF9A3C] p-4 rounded-3xl text-white shadow-xl shadow-orange/10">
            <div className="text-2xl flex-shrink-0 animate-bounce">🔥</div>
            <div className="flex-1">
              <h4 className="font-extrabold text-sm">Day {streak.count} streak!</h4>
              <p className="text-[10px] opacity-90">Keep it going — study every day.</p>
            </div>
            <div className="flex gap-1.5">
              {[...Array(7)].map((_, i) => (
                <div key={`streak-${i}`} className={`w-2 h-2 rounded-full ${i < streak.count ? 'bg-white' : 'bg-white/30'}`} />
              ))}
            </div>
          </div>
        )}

        {/* Revision Center Alert Banner */}
        {revDueCount > 0 && (
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-[#FFF9E6] border border-[#FFE7A3] p-5 rounded-3xl text-left shadow-sm">
            <div className="flex items-start gap-3">
              <span className="text-2xl pt-0.5">💡</span>
              <div className="space-y-0.5">
                <h4 className="font-extrabold text-xs text-amber-900 uppercase tracking-wide">Spaced Revisions Due!</h4>
                <p className="text-[11px] text-amber-800 leading-relaxed font-semibold">
                  You have <strong className="text-black">{revDueCount} key chapters</strong> due for Day 3, 7, 15, or 30 revisions! Retain mastery now.
                </p>
              </div>
            </div>
            <button
              onClick={() => navigateTo('revision-center')}
              className="w-full sm:w-auto shrink-0 px-4 py-2.5 bg-orange hover:bg-orange/95 text-white rounded-xl font-black text-[9px] uppercase tracking-widest transition-colors shadow-xs active:scale-95"
            >
              Open Revision Center
            </button>
          </div>
        )}

        {/* Quick Actions (Visually Refined Grid) */}
        <div className="bg-surface border border-border p-6 rounded-[32px] shadow-sm space-y-4">
          <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-ink3">Quick Shortcuts</h4>
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-4">
            {[
              { label: 'Readiness', icon: '🎯', screen: 'exam-readiness', bg: 'bg-[#E6F8FF] border-[#BDE9FF] text-sky-750 dark:bg-[#072434] dark:border-[#0F4A6A]', shape: 'rounded-[20px]' },
              { label: 'Mastery', icon: '👑', screen: 'mastery-dashboard', bg: 'bg-[#FFF0F5] border-[#FFD2E2] text-pink-700 dark:bg-[#340816] dark:border-[#68112D]', shape: 'rounded-2xl' },
              { label: 'Practice', icon: '⚡', screen: 'smart-practice', bg: 'bg-[#F4EFFF] border-[#E8DCFF] text-indigo-700 dark:bg-[#1E113E] dark:border-[#3B2967]', shape: 'rounded-full' },
              { label: 'Board', icon: '📝', screen: 'board-test', bg: 'bg-[#EEF2F6] border-[#D0E0EF] text-blue-750 dark:bg-[#101F30] dark:border-[#213F5F]', shape: 'rounded-3xl' },
              { label: 'Revision', icon: '💡', screen: 'revision-center', bg: 'bg-[#FFF9E6] border-[#FFE7A3] text-amber-700 dark:bg-[#3E3205] dark:border-[#674F0D]', shape: 'rounded-[18px]' },
              { label: 'Quiz', icon: '🧩', screen: 'home', bg: 'bg-[#FFF3EC] border-[#FFE1D1] text-orange dark:bg-[#3E1A05] dark:border-[#672E0D]', shape: 'rounded-xl', action: scrollToSubjects },
              { label: 'Papers', icon: '📄', screen: 'sample-papers', bg: 'bg-[#EDFDF3] border-[#D1F9E0] text-emerald-700 dark:bg-[#0C2A1A] dark:border-[#195634]', shape: 'rounded-[16px]' },
              { label: 'Plan', icon: '📅', screen: 'planner', bg: 'bg-[#FFF0F5] border-[#FFD2E2] text-[#DB2777] dark:bg-[#340816] dark:border-[#68112D]', shape: 'rounded-[20px]' },
              { label: 'Date', icon: '📆', screen: 'date-sheet', bg: 'bg-[#F2F1FF] border-[#E2DBFF] text-purple-700 dark:bg-[#1A114E] dark:border-[#35268A]', shape: 'rounded-[24px]' },
              ...(profile?.role === 'owner' ? [
                { label: 'Admin', icon: '📊', screen: 'admin-dashboard', bg: 'bg-[#EDFDF3] border-[#D1F9E0] text-emerald-700 dark:bg-[#0C2A1A] dark:border-[#195634]', shape: 'rounded-xl' }
              ] : [])
            ].map((item, i) => (
              <button 
                key={`action-${i}`} 
                onClick={() => item.action ? item.action() : navigateTo(item.screen as Screen)}
                className="group flex flex-col items-center gap-2 transition-all p-2 rounded-2xl hover:bg-surface2"
              >
                <div className={cn(
                  "w-12 h-12 border flex items-center justify-center text-xl group-hover:-translate-y-1 group-hover:scale-110 transition-all duration-300 shadow-sm",
                  item.shape,
                  item.bg
                )}>
                  {item.icon}
                </div>
                <span className="text-[10px] font-black uppercase text-ink tracking-wider text-center">{item.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Today's Tasks Widget - Daily Checklist */}
        <div className="bg-surface p-6 rounded-[32px] border border-border shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-ink3">📋 Daily Checklist</h4>
              <p className="text-[10px] text-ink3 font-medium">Double-click any task to launch Study Room instantly! Single click marks done.</p>
            </div>
            <ClipboardList className="w-4 h-4 text-orange" />
          </div>
          <div className="space-y-3">
            {todayTasks.map((task, i) => {
              const isCompleted = completedTasks.includes(task.id);
              return (
                <div 
                  key={task.id} 
                  onClick={() => toggleTask(task.id)}
                  onDoubleClick={() => handleTaskRedirect(task)}
                  className={cn(
                    "flex items-center gap-3 p-3 rounded-2xl transition-all cursor-pointer border border-transparent hover:bg-surface2 hover:border-border active:scale-99 select-none",
                    isCompleted && "opacity-50 grayscale"
                  )}
                  title="Double click to navigate, single click to check-off!"
                >
                  <div className={cn(
                    "w-5 h-5 rounded-md border-2 flex items-center justify-center transition-all shrink-0",
                    isCompleted ? "bg-orange border-orange shadow-md shadow-orange/20" : "border-border bg-surface"
                  )}>
                    {isCompleted && <Check className="w-3 h-3 text-white stroke-[4px]" />}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="text-[9px] font-black uppercase tracking-wider text-orange/80">
                        {task.subject}
                      </span>
                      <span className={cn(
                        "text-[8px] font-black px-1.5 py-0.5 rounded uppercase tracking-widest",
                        task.priorityLabel.includes('Urgent') 
                          ? "bg-rose-500 text-white animate-pulse" 
                          : task.priorityLabel === 'High'
                            ? "bg-rose-100 text-rose-700 dark:bg-rose-950/30"
                            : "bg-slate-100 text-slate-700 dark:bg-slate-800"
                      )}>
                        {task.priorityLabel}
                      </span>
                    </div>
                    <p className={cn(
                      "text-xs font-semibold leading-tight mt-0.5",
                      isCompleted ? "text-ink3 line-through font-normal" : "text-ink"
                    )}>
                      {task.topic}
                    </p>
                  </div>

                  <div className="flex flex-col items-end gap-1 shrink-0">
                    <span className="text-[10px] font-mono font-bold text-ink2">{task.durationMins}m</span>
                    <span className="text-[8px] font-black uppercase bg-orange-lt text-orange px-1 rounded">Double-Click 👉</span>
                  </div>
                </div>
              );
            })}
            {todayTasks.length === 0 && (
              <div className="text-center py-6 text-xs text-ink3">
                🏆 No active automated tasks today! Configure your study plan in Syllabus Tracker.
              </div>
            )}
          </div>
        </div>

        {/* Progress Overview Widget (Track Record) */}
        <div className="bg-surface p-6 rounded-[32px] border border-border shadow-sm space-y-4 text-left">
          <div className="flex items-center justify-between">
            <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-ink3">🏆 Chapter Mastery & Syllabus</h4>
            <TrendingUp className="w-4 h-4 text-orange" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <div className="flex items-baseline gap-1">
                <span className="text-3xl font-display text-ink font-black">{sysStats.averageMasteryScore}%</span>
              </div>
              <span className="text-[9px] uppercase tracking-widest font-black text-ink3">Weighted Mastery</span>
            </div>
            <div>
              <div className="flex items-baseline gap-1">
                <span className="text-3xl font-display text-ink font-black">{sysStats.overallCompletionPct}%</span>
              </div>
              <span className="text-[9px] uppercase tracking-widest font-black text-ink3">Syllabus Done</span>
            </div>
          </div>
          
          <div className="space-y-1">
            <div className="flex justify-between text-[9px] font-bold text-ink3 uppercase">
              <span>Syllabus Completion progress</span>
              <span>{sysStats.completedChapters} / {sysStats.totalChapters} Chapters</span>
            </div>
            <div className="h-2 w-full bg-surface2 rounded-full overflow-hidden border border-border/85 shadow-inner">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${sysStats.overallCompletionPct}%` }}
                className="h-full bg-gradient-to-r from-orange to-amber-500 rounded-full"
              />
            </div>
          </div>
          
          {sysStats.needsAttentionCount > 0 ? (
            <div className="flex items-center gap-2 p-2 bg-amber-50 border border-amber-200 rounded-xl text-[10px] font-black uppercase tracking-wider text-amber-700">
              <Skull className="w-3.5 h-3.5 animate-pulse" />
              <span>{sysStats.needsAttentionCount} Chapters Need Attention (Below 50%)</span>
            </div>
          ) : (
            <div className="flex items-center gap-2 p-2 bg-green-50 border border-green-105 rounded-xl text-[10px] font-black uppercase tracking-wider text-green-600">
              <Target className="w-3.5 h-3.5" />
              <span>Syllabus Mastered or Resting Stable!</span>
            </div>
          )}
          
          <div className="flex flex-col gap-2 w-full">
            <button 
              onClick={() => navigateTo('exam-readiness')}
              className="w-full py-2.5 bg-gradient-to-r from-orange to-amber-500 hover:from-orange/90 hover:to-amber-500/90 text-white font-black text-[10px] uppercase tracking-widest rounded-xl text-center shadow-xs cursor-pointer flex items-center justify-center gap-1.5 transition-all active:scale-[0.98]"
            >
              🎯 Open Exam Readiness Dashboard
            </button>
            <div className="grid grid-cols-2 gap-2 w-full">
              <button 
                onClick={() => navigateTo('mastery-dashboard')}
                className="w-full py-2 bg-bg border border-border hover:border-orange hover:bg-orange-lt hover:text-orange transition-all text-[9.5px] font-black uppercase tracking-widest text-ink2 rounded-xl text-center shadow-inner cursor-pointer"
              >
                Mastery Dashboard
              </button>
              <button 
                onClick={() => navigateTo('planner')}
                className="w-full py-2 bg-bg border border-border hover:border-orange hover:bg-orange-lt hover:text-orange transition-all text-[9.5px] font-black uppercase tracking-widest text-ink2 rounded-xl text-center shadow-inner cursor-pointer"
              >
                Open Spaced Planner
              </button>
            </div>
          </div>
        </div>



        {/* Subjects Grid */}
        <section id="subjects" className="pt-4 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <h3 className="text-xs font-bold uppercase tracking-[0.15em] text-ink3">Choose a Subject</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {Object.entries(SUBJECTS)
              .filter(([key]) => {
                const standard = ['maths', 'science', 'sst', 'english'];
                if (standard.includes(key)) return true;
                return key === activeLanguage;
              })
              .map(([key, sub]) => (
              <motion.div
                key={key}
                whileHover={{ y: -4, scale: 1.005 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => navigateTo('chapter-hub', key)}
                className="bg-surface p-6 rounded-[32px] border border-border shadow-sm cursor-pointer group relative overflow-hidden flex flex-col transition-all duration-300"
              >
                <div className="absolute top-0 left-0 w-full h-1" style={{ backgroundColor: sub.color }} />
                <div 
                  className="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl mb-4 transition-colors group-hover:rotate-6 duration-300"
                  style={{ backgroundColor: sub.light }}
                >
                  {sub.icon}
                </div>
                <h4 className="font-display text-xl mb-1 group-hover:text-orange transition-colors duration-300">{sub.label}</h4>
                <p className="text-xs text-ink2 leading-relaxed flex-1 opacity-80 mb-4">
                  {key === 'maths' ? 'Algebra, Geometry, Calculus, Trigonometry & Stats' : 
                   key === 'science' ? 'Physics, Chemistry, Biology & Natural Science' :
                   key === 'sst' ? 'History, Geography, Civics, Economics & Disaster Mgmt' :
                   key === 'english' ? 'First Flight Prose, Footprints Reader & Grammar' :
                   key === 'hindi' ? 'Kshitij, Kritika & Vyakaran Prose & Poetry' : 
                   key === 'hindi_b' ? 'Sparsh, Sanchayan & Vyakaran Syllabus B' : 'Kumarbharati & Grammar Options'}
                </p>
                <div className="flex items-center justify-between mt-auto pt-2 border-t border-border/40">
                  <span className="text-[10px] font-black uppercase text-ink3 tracking-widest bg-surface2 px-2.5 py-1 rounded-lg border border-border/60">{sub.chapters.length} Syllabus Chapters</span>
                  <div className="w-8 h-8 rounded-full bg-orange-lt border border-orange-mid flex items-center justify-center group-hover:bg-orange group-hover:border-orange transition-all duration-300">
                    <ChevronRight className="w-4 h-4 text-orange group-hover:text-white transition-colors" />
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </section>
      </div>

      {/* Floating AI Chatbot */}
      <div className="fixed bottom-24 sm:bottom-6 right-4 z-[100] flex flex-col items-end gap-3 pointer-events-none">
        <motion.div 
          initial={false}
          animate={{ 
            opacity: isChatOpen ? 1 : 0,
            scale: isChatOpen ? 1 : 0.8,
            y: isChatOpen ? 0 : 20
          }}
          className={cn(
            "w-[calc(100vw-32px)] sm:w-[380px] bg-surface border border-border shadow-2xl rounded-[32px] overflow-hidden pointer-events-auto",
            !isChatOpen && "hidden"
          )}
        >
          <div className="bg-ink p-4 flex items-center justify-between text-white">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-orange rounded-xl flex items-center justify-center">
                <MessageSquare className="w-4 h-4 text-white" />
              </div>
              <div>
                <h4 className="text-xs font-bold">Doubt Solver</h4>
                <div className="flex items-center gap-1">
                   <div className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse" />
                   <span className="text-[8px] font-black uppercase tracking-widest text-white/60">Ready to Help</span>
                </div>
              </div>
            </div>
            <button 
              onClick={() => setIsChatOpen(false)}
              className="p-2 hover:bg-white/10 rounded-xl transition-colors"
            >
              <RefreshCw className="w-4 h-4 rotate-45" />
            </button>
          </div>
          <div className="p-2">
            <DoubtSolverChat showToast={showToast} height="400px" />
          </div>
        </motion.div>

        <button 
          onClick={() => setIsChatOpen(!isChatOpen)}
          className={cn(
            "w-14 h-14 rounded-2xl flex items-center justify-center shadow-2xl transition-all active:scale-95 pointer-events-auto",
            isChatOpen ? "bg-ink text-white" : "bg-orange text-white"
          )}
        >
          {isChatOpen ? <RefreshCw className="w-6 h-6 rotate-45" /> : <MessageSquare className="w-6 h-6" />}
          {!isChatOpen && (
            <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 border-2 border-surface rounded-full animate-pulse" />
          )}
        </button>
      </div>

      <footer className="lg:hidden pt-12 pb-4 text-center border-t border-border">
        <p className="text-[10px] font-bold text-ink3 uppercase tracking-widest">
          Made with ❤️ for CBSE Class 10 students · VidyPath v6.0
        </p>
      </footer>

      {/* Celebratory Streak Modal */}
      <AnimatePresence>
        {showCelebration && (
          <div key="celebration-modal-overlay" className="fixed inset-0 z-[200] flex items-center justify-center p-4">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowCelebration(false)}
              className="absolute inset-0 bg-ink/75 backdrop-blur-sm pointer-events-auto"
            />
            
            {/* Modal Container */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 30 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 30 }}
              transition={{ type: "spring", damping: 25, stiffness: 350 }}
              className="bg-surface border border-orange/10 max-w-sm w-full rounded-[40px] p-8 shadow-2xl relative overflow-hidden z-[210] text-center pointer-events-auto"
            >
              {/* Decorative Blur Background Bulbs */}
              <div className="absolute -top-16 -left-16 w-36 h-36 bg-orange/10 rounded-full blur-[40px] pointer-events-none" />
              <div className="absolute -bottom-16 -right-16 w-36 h-36 bg-yellow-400/10 rounded-full blur-[40px] pointer-events-none" />

              {/* Close Button */}
              <button
                onClick={() => setShowCelebration(false)}
                className="absolute top-5 right-5 p-2 rounded-full bg-surface2 border border-border text-ink3 hover:text-ink hover:scale-105 transition-all"
                aria-label="Close dialog"
              >
                <X className="w-4 h-4" />
              </button>

              {/* Big Graphic Hero */}
              <div className="relative inline-flex items-center justify-center mt-2 mb-6">
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ ease: "linear", duration: 15, repeat: Infinity }}
                  className="absolute inset-0 -m-1.5 w-24 h-24 border border-dashed border-orange/30 rounded-full"
                />
                
                <motion.div
                  animate={{ scale: [1, 1.05, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                  className="w-20 h-20 rounded-[28px] bg-gradient-to-tr from-orange to-[#FF9A3C] shadow-lg shadow-orange/30 flex items-center justify-center relative"
                >
                  <Flame className="w-10 h-10 text-white fill-white animate-pulse" />
                </motion.div>
                
                {/* Floating Micro elements */}
                <Sparkles className="absolute -top-1 -right-2 w-5 h-5 text-yellow-500 animate-bounce" style={{ animationDelay: '200ms' }} />
                <Trophy className="absolute -bottom-1 -left-2.5 w-5 h-5 text-orange animate-bounce" style={{ animationDelay: '600ms' }} />
              </div>

              {/* Header Text */}
              <div className="space-y-1.5 mb-5 select-none">
                <div className="flex items-center justify-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-orange animate-pulse" />
                  <span className="text-[9px] font-black uppercase tracking-[0.2em] text-orange">STREAK EXTENDED!</span>
                  <Sparkles className="w-3.5 h-3.5 text-orange animate-pulse" />
                </div>
                <h2 className="text-2xl font-display text-ink leading-tight">
                  You are absolutely<br />
                  <span className="text-orange italic">on fire!</span>
                </h2>
              </div>

              {/* Milestone Display */}
              <div className="bg-surface2 border border-border rounded-[28px] p-5 mb-6 relative">
                <div className="text-4xl font-display font-black text-ink mb-1 flex items-center justify-center gap-1.5">
                  <span>{celebratedStreak || streak.count || 1}</span>
                  <span className="text-xl font-sans font-extrabold text-orange">DAYS</span>
                </div>
                <p className="text-[10px] text-ink2 leading-relaxed max-w-[210px] mx-auto font-medium">
                  Your daily commitment is paying off. Keep up the high score momentum!
                </p>
              </div>

              {/* Action Buttons */}
              <div className="space-y-2">
                <button
                  onClick={() => {
                    setShowCelebration(false);
                    scrollToSubjects();
                  }}
                  className="w-full bg-orange hover:bg-orange-dark text-white py-3.5 rounded-2xl text-[10px] font-black uppercase tracking-[0.25em] shadow-lg shadow-orange/20 transition-all active:scale-95 flex items-center justify-center gap-1.5"
                >
                  <Zap className="w-3.5 h-3.5 fill-white" />
                  Continue Learning
                </button>
                
                <button
                  onClick={() => setShowCelebration(false)}
                  className="w-full bg-surface2 border border-border hover:bg-border/30 text-ink2 hover:text-ink py-3 rounded-2xl text-[9px] font-black uppercase tracking-[0.2em] transition-all"
                >
                  Awesome, Got It!
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
