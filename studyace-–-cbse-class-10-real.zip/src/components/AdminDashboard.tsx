/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Screen } from '../App';
import { motion } from 'motion/react';
import { 
  ArrowLeft, Users, BarChart2, Calendar, ClipboardList, Video, 
  CheckCircle2, AlertTriangle, ShieldCheck, Database, RefreshCw, 
  Flame, BookOpen, Clock, Activity, Settings, TrendingUp, Info,
  Mail, Sparkles, Image as ImageIcon, Eye, X, Plus, Trash, Check, 
  UserCheck, GraduationCap, ShieldAlert, Award
} from 'lucide-react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, PieChart as RechartsPieChart, Pie, Cell, BarChart as RechartsBarChart, Bar, Legend } from 'recharts';
import { getRealAnalytics, getSimulatedAnalytics, isUserAdmin, AnalyticsEvent } from '../services/analytics';
import { useAuth } from '../context/AuthContext';
import { db } from '../lib/firebase';
import { collection, getDocs, doc, setDoc, deleteDoc, query, orderBy } from 'firebase/firestore';
import { SUBJECTS } from '../constants';

interface AdminDashboardProps {
  navigateTo: (s: Screen) => void;
  showToast: (msg: string) => void;
}

export default function AdminDashboard({ navigateTo, showToast }: AdminDashboardProps) {
  const { user, profile } = useAuth();
  const userRole = profile?.role || 'student';

  // Sub-tabs list per role
  const [activeTab, setActiveTab] = useState<string>('');

  // Set default tab based on user's verified role
  useEffect(() => {
    if (userRole === 'owner') {
      setActiveTab('analytics');
    } else if (userRole === 'teacher') {
      setActiveTab('upload-lecture');
    }
  }, [userRole]);

  // Operational states
  const [dataSource, setDataSource] = useState<'real' | 'simulated'>('simulated');
  const [realStats, setRealStats] = useState(getRealAnalytics());
  const [simStats, setSimStats] = useState(getSimulatedAnalytics());
  const [loadingActive, setLoadingActive] = useState(false);

  // User List (Owner panel) & Search
  const [usersList, setUsersList] = useState<any[]>([]);
  const [loadingUsers, setLoadingUsers] = useState<boolean>(false);
  const [searchUserQuery, setSearchUserQuery] = useState<string>('');
  
  // Add Teacher Form states
  const [showAddTeacherModal, setShowAddTeacherModal] = useState<boolean>(false);
  const [newTeacherName, setNewTeacherName] = useState<string>('');
  const [newTeacherEmail, setNewTeacherEmail] = useState<string>('');
  const [newTeacherPassword, setNewTeacherPassword] = useState<string>('');
  const [newTeacherSchool, setNewTeacherSchool] = useState<string>('');
  const [newTeacherClass, setNewTeacherClass] = useState<string>('CBSE Class 10');
  const [registeringTeacher, setRegisteringTeacher] = useState<boolean>(false);

  // Content Moderation (Owner panel)
  const [allLectures, setAllLectures] = useState<any[]>([]);
  const [allTests, setAllTests] = useState<any[]>([]);
  const [loadingContent, setLoadingContent] = useState<boolean>(false);

  // User Feedback states (Analytics tab)
  const [feedbacks, setFeedbacks] = useState<any[]>([]);
  const [fetchingFeedbacks, setFetchingFeedbacks] = useState(false);
  const [selectedScreenshotUrl, setSelectedScreenshotUrl] = useState<string | null>(null);

  // Lecture form states (Teacher Panel)
  const [lectureTitle, setLectureTitle] = useState<string>('');
  const [lectureDesc, setLectureDesc] = useState<string>('');
  const [lectureSubject, setLectureSubject] = useState<string>('science');
  const [lectureChapter, setLectureChapter] = useState<string>('Chemical Reactions and Equations');
  const [lectureVideoUrl, setLectureVideoUrl] = useState<string>('');

  // Quiz test builder states (Teacher Panel)
  const [testTitle, setTestTitle] = useState<string>('');
  const [testSubject, setTestSubject] = useState<string>('science');
  const [testChapter, setTestChapter] = useState<string>('Chemical Reactions and Equations');
  const [questions, setQuestions] = useState<Array<{ q: string; opts: string[]; ansIdx: number }>>([
    { q: '', opts: ['', '', '', ''], ansIdx: 0 }
  ]);

  // Cohort tracker states (Teacher Panel)
  const [selectedCohortStudent, setSelectedCohortStudent] = useState<any | null>(null);
  const [studentProgressList, setStudentProgressList] = useState<any[]>([]);
  const [studentPlans, setStudentPlans] = useState<any | null>(null);
  const [loadingStudentDetail, setLoadingStudentDetail] = useState<boolean>(false);

  const SIMULATED_FEEDBACKS = [
    {
      id: 'fb_1',
      userId: 'st_83941',
      userEmail: 'aarav.sharma@gmail.com',
      category: 'bug',
      message: 'CBSE Class 10 Math, Section 3 Quadratic Equations test had an overlapping label in Question #4 diagram. Screen becomes unresponsive for a second.',
      appVersion: 'v2.4.1',
      timestampStr: new Date(Date.now() - 3600000 * 2).toLocaleString(),
      screenshot: null
    },
    {
      id: 'fb_2',
      userId: 'st_12399',
      userEmail: 'diya.patel@outlook.com',
      category: 'feature',
      message: 'Please add a global Pomodoro study timer widget in the workspace bar. It will encourage students to stick to 25-minute study intervals!',
      appVersion: 'v2.4.1',
      timestampStr: new Date(Date.now() - 3600000 * 8).toLocaleString(),
      screenshot: null
    },
    {
      id: 'fb_3',
      userId: 'st_29481',
      userEmail: 'karan.johri@yahoo.co.in',
      category: 'feedback',
      message: 'The AI Tutor Desk is stunningly fast. It instantly cleared up my doubts on Carbon and its Compounds. Kudos to the creators of VidyPath!',
      appVersion: 'v2.4.1',
      timestampStr: new Date(Date.now() - 3600000 * 24).toLocaleString(),
      screenshot: null
    }
  ];

  // Load Feedbacks dynamically
  const handleFetchFeedbacks = async () => {
    if (dataSource === 'real') {
      setFetchingFeedbacks(true);
      try {
        const qSnap = await getDocs(collection(db, 'feedbacks'));
        const list = qSnap.docs.map(doc => ({
          id: doc.id,
          ...doc.data(),
          timestampStr: doc.data().timestamp?.toDate 
            ? doc.data().timestamp.toDate().toLocaleString() 
            : new Date().toLocaleString()
        }));
        setFeedbacks(list);
      } catch (error) {
        console.error('Failed to load feedbacks:', error);
      } finally {
        setFetchingFeedbacks(false);
      }
    } else {
      setFeedbacks(SIMULATED_FEEDBACKS);
    }
  };

  // Fetch registered user database profiles
  const fetchUsers = async () => {
    setLoadingUsers(true);
    try {
      const snap = await getDocs(collection(db, 'users'));
      const list = snap.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setUsersList(list);
    } catch (err) {
      console.error("Error fetching users list:", err);
      showToast("❌ DB query denied. Verify rules.");
    } finally {
      setLoadingUsers(false);
    }
  };

  // Fetch all custom published contents
  const fetchAllContent = async () => {
    setLoadingContent(true);
    try {
      const lecSnap = await getDocs(collection(db, 'lectures'));
      const listLec = lecSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setAllLectures(listLec);

      const testSnap = await getDocs(collection(db, 'customTests'));
      const listTest = testSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setAllTests(listTest);
    } catch (err) {
      console.error("Failed to load platform content:", err);
    } finally {
      setLoadingContent(false);
    }
  };

  // Promote / Demote user accounts
  const handleUpdateRole = async (targetUid: string, nextRole: 'student' | 'teacher') => {
    try {
      const userRef = doc(db, 'users', targetUid);
      await setDoc(userRef, { role: nextRole, updatedAt: new Date().toISOString() }, { merge: true });
      showToast(`⚡ User role updated to ${nextRole}!`);
      fetchUsers();
    } catch (err) {
      console.error(err);
      showToast("❌ Demote/Promote action failed.");
    }
  };

  // Create and Register a New Teacher
  const handleCreateTeacher = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTeacherName.trim() || !newTeacherEmail.trim() || !newTeacherPassword.trim()) {
      showToast("⚠️ All fields are required.");
      return;
    }
    if (newTeacherPassword.length < 6) {
      showToast("⚠️ Password should be at least 6 characters.");
      return;
    }

    setRegisteringTeacher(true);
    let secondaryApp = null;
    try {
      const { initializeApp } = await import('firebase/app');
      const { getAuth, createUserWithEmailAndPassword, updateProfile, signOut } = await import('firebase/auth');
      const firebaseConfig = await import('../../firebase-applet-config.json');

      const secondaryAppName = `teacher-registration-${Date.now()}`;
      secondaryApp = initializeApp(firebaseConfig.default || firebaseConfig, secondaryAppName);
      const secondaryAuth = getAuth(secondaryApp);

      const credential = await createUserWithEmailAndPassword(secondaryAuth, newTeacherEmail.trim(), newTeacherPassword);
      const uid = credential.user.uid;

      await updateProfile(credential.user, {
        displayName: newTeacherName.trim()
      });

      const teacherProfile = {
        name: newTeacherName.trim(),
        class: newTeacherClass,
        school: newTeacherSchool.trim() || 'Private CBSE Educator',
        photoURL: '',
        level: 'average',
        time: 60,
        secondLanguage: 'hindi',
        streak: { count: 0, lastActiveDate: '' },
        role: 'student', // compliant with default initial create rule
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      const userDocRef = doc(db, 'users', uid);
      await setDoc(userDocRef, teacherProfile);

      await signOut(secondaryAuth);
      await secondaryApp.delete();
      secondaryApp = null;

      // Promote to 'teacher' role using owner authentication
      await setDoc(userDocRef, {
        role: 'teacher',
        updatedAt: new Date().toISOString()
      }, { merge: true });

      showToast(`🎓 Teacher ${newTeacherName} successfully added!`);
      setShowAddTeacherModal(false);
      setNewTeacherName('');
      setNewTeacherEmail('');
      setNewTeacherPassword('');
      setNewTeacherSchool('');
      setNewTeacherClass('CBSE Class 10');
      
      fetchUsers();
    } catch (err: any) {
      console.error("Teacher creation failed:", err);
      showToast(`❌ Registration failed: ${err.message || err}`);
    } finally {
      if (secondaryApp) {
        try {
          await secondaryApp.delete();
        } catch (_) {}
      }
      setRegisteringTeacher(false);
    }
  };

  // Delete user account profile
  const handleDeleteUser = async (targetUid: string) => {
    if (!window.confirm("Are you sure you want to permanently delete this student profile?")) return;
    try {
      await deleteDoc(doc(db, 'users', targetUid));
      showToast("🗑️ Student profile deleted.");
      fetchUsers();
    } catch (err) {
      showToast("❌ Could not delete profile.");
    }
  };

  // Delete lecture
  const handleDeleteLecture = async (id: string) => {
    if (!window.confirm("Remove this lecture link?")) return;
    try {
      await deleteDoc(doc(db, 'lectures', id));
      showToast("🗑️ Lecture removed.");
      fetchAllContent();
    } catch (err) {
      showToast("❌ Failed to remove lecture.");
    }
  };

  // Delete test
  const handleDeleteTest = async (id: string) => {
    if (!window.confirm("Remove this mock evaluation test?")) return;
    try {
      await deleteDoc(doc(db, 'customTests', id));
      showToast("🗑️ Test removed.");
      fetchAllContent();
    } catch (err) {
      showToast("❌ Failed to remove test.");
    }
  };

  // Submit custom lecture
  const handleUploadLecture = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!lectureTitle.trim() || !lectureDesc.trim()) {
      showToast("⚠️ All basic information details are required.");
      return;
    }
    try {
      const lecId = `lec_${Date.now()}`;
      await setDoc(doc(db, 'lectures', lecId), {
        title: lectureTitle,
        description: lectureDesc,
        subject: lectureSubject,
        chapter: lectureChapter,
        videoUrl: lectureVideoUrl || '',
        authorId: user?.uid || 'educator_usr',
        authorName: profile?.name || user?.displayName || 'Instructing Teacher',
        createdAt: new Date().toISOString()
      });
      showToast("🎓 Lecture video published for student hub!");
      setLectureTitle('');
      setLectureDesc('');
      setLectureVideoUrl('');
      fetchAllContent();
    } catch (err) {
      showToast("❌ Error uploading content. Check security rules.");
    }
  };

  // MCQ Test builder helpers
  const addQuestionField = () => {
    if (questions.length >= 5) {
      showToast("⚠️ Standard practice mock test capped at 5 questions.");
      return;
    }
    setQuestions([...questions, { q: '', opts: ['', '', '', ''], ansIdx: 0 }]);
  };

  const removeQuestionField = (idx: number) => {
    if (questions.length <= 1) return;
    setQuestions(questions.filter((_, i) => i !== idx));
  };

  const updateQuestionQuery = (idx: number, qText: string) => {
    const list = [...questions];
    list[idx].q = qText;
    setQuestions(list);
  };

  const updateOptionText = (qIdx: number, oIdx: number, val: string) => {
    const list = [...questions];
    list[qIdx].opts[oIdx] = val;
    setQuestions(list);
  };

  const updateCorrectAnswer = (qIdx: number, ansIdx: number) => {
    const list = [...questions];
    list[qIdx].ansIdx = ansIdx;
    setQuestions(list);
  };

  const handlePublishTest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!testTitle.trim()) {
      showToast("⚠️ Practice test title name cannot be blank.");
      return;
    }
    for (let i = 0; i < questions.length; i++) {
      const item = questions[i];
      if (!item.q.trim()) {
        showToast(`⚠️ Missing question text for Q${i+1}`);
        return;
      }
      for (let o = 0; o < item.opts.length; o++) {
        if (!item.opts[o].trim()) {
          showToast(`⚠️ Missing Option ${o+1} content inside Q${i+1}`);
          return;
        }
      }
    }

    try {
      const testId = `test_${Date.now()}`;
      const finalQuestions = questions.map(q => ({
        question: q.q,
        options: q.opts,
        answer: q.opts[q.ansIdx]
      }));

      await setDoc(doc(db, 'customTests', testId), {
        title: testTitle,
        subject: testSubject,
        chapterName: testChapter,
        questions: finalQuestions,
        authorId: user?.uid || 'educator_usr',
        authorName: profile?.name || user?.displayName || 'Instructing Teacher',
        createdAt: new Date().toISOString()
      });

      showToast("🚀 Real board test published and synchronized!");
      setTestTitle('');
      setQuestions([{ q: '', opts: ['', '', '', ''], ansIdx: 0 }]);
      fetchAllContent();
    } catch (err) {
      showToast("❌ Rules validation denied. Try again.");
    }
  };

  // Student progress deep inspection
  const fetchCohortStudentDetail = async (targetStudent: any) => {
    setLoadingStudentDetail(true);
    setSelectedCohortStudent(targetStudent);
    try {
      const pSnap = await getDocs(collection(db, 'users', targetStudent.id, 'progress'));
      setStudentProgressList(pSnap.docs.map(doc => doc.data()));

      const planSnap = await getDocs(collection(db, 'users', targetStudent.id, 'plans'));
      if (!planSnap.empty) {
        setStudentPlans(planSnap.docs[0].data());
      } else {
        setStudentPlans(null);
      }
    } catch (err) {
      console.error(err);
      showToast("⚠️ Permission denied on sub-collection progress lookup.");
      setStudentProgressList([]);
      setStudentPlans(null);
    } finally {
      setLoadingStudentDetail(false);
    }
  };

  // General control feeds
  const handleRefresh = () => {
    setLoadingActive(true);
    setTimeout(() => {
      setRealStats(getRealAnalytics());
      setSimStats(getSimulatedAnalytics());
      handleFetchFeedbacks();
      if (userRole === 'owner') {
        fetchUsers();
      }
      fetchAllContent();
      setLoadingActive(false);
      showToast('🔄 Dashboards and connected collections reloaded!');
    }, 600);
  };

  useEffect(() => {
    setRealStats(getRealAnalytics());
    handleFetchFeedbacks();
    if (userRole === 'owner') {
      fetchUsers();
    }
    fetchAllContent();
  }, [dataSource, userRole]);

  // Derived Analytics stats mapping
  const isSimulated = dataSource === 'simulated';
  const data = isSimulated 
    ? {
        dau: simStats.summary.activeToday,
        wau: simStats.summary.activeThisWeek,
        mau: simStats.summary.activeThisMonth,
        chapterCompletions: simStats.summary.chapterCompletions,
        videosWatched: simStats.summary.videosWatched,
        quizAttempts: simStats.summary.totalQuizzesAttempted,
        mistakesRecovered: simStats.summary.mistakesResolved,
        mostUsedFeatures: simStats.features,
        registeredCount: simStats.summary.registeredCount,
      }
    : {
        dau: realStats.dau,
        wau: realStats.wau,
        mau: realStats.mau,
        chapterCompletions: realStats.chapterCompletions,
        videosWatched: realStats.videosWatched,
        quizAttempts: realStats.quizAttempts,
        mistakesRecovered: realStats.mistakesRecovered,
        mostUsedFeatures: realStats.mostUsedFeatures.length > 0 
          ? realStats.mostUsedFeatures 
          : [
              { name: 'AI Tutor Desk', count: realStats.eventsCount ? Math.round(realStats.eventsCount * 0.45) : 0, value: 45, color: '#f97316' },
              { name: 'Smart Practice Book', count: realStats.quizAttempts * 2, value: 30, color: '#3b82f6' },
              { name: 'Spaced Revision Center', count: realStats.revisionsCompleted, value: 15, color: '#10b981' }
            ],
        registeredCount: usersList.length > 0 ? usersList.length : (user ? 1 : 0),
      };

  const getRetentionBg = (value: number | string) => {
    if (value === '-') return 'bg-surface2 text-ink3/40';
    const num = Number(value);
    if (num === 100) return 'bg-orange/20 text-orange border border-orange/10 font-bold';
    if (num >= 85) return 'bg-indigo-500/10 text-indigo-500 font-bold dark:text-indigo-400';
    if (num >= 75) return 'bg-sky-500/10 text-sky-500 dark:text-sky-400';
    if (num >= 65) return 'bg-amber-500/10 text-amber-500 dark:text-amber-400';
    return 'bg-pink-500/10 text-pink-500 dark:text-pink-400';
  };

  // Searching filter
  const filteredUsers = usersList.filter(u => {
    const qText = searchUserQuery.toLowerCase().trim();
    if (!qText) return true;
    return (u.name || '').toLowerCase().includes(qText) || 
           (u.school || '').toLowerCase().includes(qText) || 
           (u.class || '').toLowerCase().includes(qText) ||
           u.id.toLowerCase().includes(qText) ||
           (u.role || '').toLowerCase().includes(qText);
  });

  return (
    <div className="max-w-[1240px] mx-auto px-4 py-8 pb-32 animate-fadeIn text-left">
      {/* RETRO GRADE BACK BUTTON & HEADER */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div>
          <button 
            onClick={() => navigateTo('home')}
            className="inline-flex items-center gap-2 mb-3 text-ink3 font-bold text-xs uppercase tracking-widest hover:text-orange transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            Back to Desk
          </button>
          <div className="flex items-center gap-3">
            <span className="p-2.5 rounded-2xl bg-orange-lt text-orange text-lg">🛡️</span>
            <div>
              <h1 className="text-2xl font-display font-black tracking-tight text-ink">
                Admin Hub Control
              </h1>
              <p className="text-ink3 text-xs font-semibold uppercase tracking-wider mt-0.5">
                Authorized Space for Platform Operators & Educators
              </p>
            </div>
          </div>
        </div>

        {/* ROLE INDICATOR BADGE & REFRESH */}
        <div className="flex items-center gap-2.5 flex-wrap">
          {userRole === 'owner' && (
            <div className="bg-orange-lt border border-orange/40 px-3.5 py-1.5 rounded-xl flex items-center gap-2 text-orange text-[10px] font-black uppercase tracking-wider">
              <ShieldCheck className="w-4 h-4" />
              Verified Owner operator
            </div>
          )}
          {userRole === 'teacher' && (
            <div className="bg-teal-50 border border-teal-200 px-3.5 py-1.5 rounded-xl flex items-center gap-2 text-teal-700 text-[10px] font-black uppercase tracking-wider dark:bg-teal-950/20 dark:border-teal-900">
              <GraduationCap className="w-4 h-4" />
              Verified Teacher operator
            </div>
          )}

          <button
            onClick={handleRefresh}
            disabled={loadingActive}
            className="p-2.5 bg-surface hover:bg-surface2 border border-border rounded-xl text-ink2 transition-all cursor-pointer active:scale-95 flex items-center justify-center"
            title="Refresh database records"
          >
            <RefreshCw className={`w-4 h-4 ${loadingActive ? 'animate-spin text-orange' : ''}`} />
          </button>
        </div>
      </div>

      {/* CORE INTEGRAL SUB-NAVIGATION PANEL */}
      <div className="flex border-b border-border mb-8 overflow-x-auto pr-1 gap-1">
        {userRole === 'owner' && (
          <>
            <button
              onClick={() => setActiveTab('analytics')}
              className={`pb-3 px-4 text-xs font-black uppercase tracking-widest border-b-2 transition-all flex items-center gap-2 ${
                activeTab === 'analytics'
                  ? 'border-orange text-orange font-bold'
                  : 'border-transparent text-ink3 hover:text-ink'
              }`}
            >
              <BarChart2 className="w-4 h-4" />
              Platform Analytics
            </button>
            <button
              onClick={() => { setActiveTab('users'); fetchUsers(); }}
              className={`pb-3 px-4 text-xs font-black uppercase tracking-widest border-b-2 transition-all flex items-center gap-2 ${
                activeTab === 'users'
                  ? 'border-orange text-orange font-bold'
                  : 'border-transparent text-ink3 hover:text-ink'
              }`}
            >
              <Users className="w-4 h-4" />
              User Directory & Teachers ({filteredUsers.length})
            </button>
            <button
              onClick={() => { setActiveTab('content'); fetchAllContent(); }}
              className={`pb-3 px-4 text-xs font-black uppercase tracking-widest border-b-2 transition-all flex items-center gap-2 ${
                activeTab === 'content'
                  ? 'border-orange text-orange font-bold'
                  : 'border-transparent text-ink3 hover:text-ink'
              }`}
            >
              <ShieldAlert className="w-4 h-4" />
              Content Moderation
            </button>
          </>
        )}

        {userRole === 'teacher' && (
          <>
            <button
              onClick={() => setActiveTab('upload-lecture')}
              className={`pb-3 px-4 text-xs font-black uppercase tracking-widest border-b-2 transition-all flex items-center gap-2 ${
                activeTab === 'upload-lecture'
                  ? 'border-orange text-orange font-bold'
                  : 'border-transparent text-ink3 hover:text-ink'
              }`}
            >
              <Video className="w-4 h-4" />
              Publish Lecture Video
            </button>
            <button
              onClick={() => setActiveTab('exam-builder')}
              className={`pb-3 px-4 text-xs font-black uppercase tracking-widest border-b-2 transition-all flex items-center gap-2 ${
                activeTab === 'exam-builder'
                  ? 'border-orange text-orange font-bold'
                  : 'border-transparent text-ink3 hover:text-ink'
              }`}
            >
              <ClipboardList className="w-4 h-4" />
              Construct Board Exam
            </button>
            <button
              onClick={() => { setActiveTab('cohort'); fetchUsers(); }}
              className={`pb-3 px-4 text-xs font-black uppercase tracking-widest border-b-2 transition-all flex items-center gap-2 ${
                activeTab === 'cohort'
                  ? 'border-orange text-orange font-bold'
                  : 'border-transparent text-ink3 hover:text-ink'
              }`}
            >
              <GraduationCap className="w-4 h-4" />
              Student Progress logs
            </button>
          </>
        )}
      </div>

      {/* ======================= OWNER: ANALYTICS TAB ======================= */}
      {activeTab === 'analytics' && (
        <div className="space-y-6">
          {/* Performance Warning simulator */}
          {isSimulated && (
            <div className="bg-gradient-to-r from-orange-500/5 to-indigo-500/5 border border-orange-500/10 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs font-semibold text-ink2">
              <div className="flex items-start sm:items-center gap-3">
                <div className="p-2 bg-orange-lt text-orange rounded-lg shrink-0">
                  <TrendingUp className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-orange font-black uppercase text-[10px] tracking-wider block">Cohort Simulation mode active</span>
                  Model displays structured telemetry of <strong className="text-ink">1,250 registered students</strong> of CBSE school candidates. Click Database Feed to view live profiles.
                </div>
              </div>
              <button
                onClick={() => setDataSource('real')}
                className="px-3.5 py-1.5 bg-indigo-500 hover:bg-indigo-600 text-white font-black text-[9px] uppercase tracking-widest rounded-lg transition-colors cursor-pointer shrink-0"
              >
                Go Database Live
              </button>
            </div>
          )}

          {/* CHORT TRAFFIC TOGGLER */}
          <div className="flex justify-end mb-4">
            <div className="flex bg-surface border border-border p-1 rounded-xl shadow-3xs">
              <button
                onClick={() => setDataSource('simulated')}
                className={`px-4 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer ${
                  dataSource === 'simulated' ? 'bg-ink text-white shadow-sm' : 'text-ink3 hover:text-ink hover:bg-surface2'
                }`}
              >
                Simulator Feed
              </button>
              <button
                onClick={() => setDataSource('real')}
                className={`px-4 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer ${
                  dataSource === 'real' ? 'bg-orange text-white shadow-sm' : 'text-ink3 hover:text-ink hover:bg-surface2'
                }`}
              >
                Database Feed
              </button>
            </div>
          </div>

          {/* KPI CARDS */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { label: 'Platform Students', value: isSimulated ? '1,250' : data.registeredCount, desc: 'Registered CBSE database profiles', icon: Users, color: 'text-orange bg-orange-lt border-orange-mid' },
              { label: 'Daily Active (DAU)', value: data.dau, desc: 'Current active candidates', icon: Activity, color: 'text-indigo-500 bg-indigo-500/5 border-indigo-500/10 dark:text-indigo-400' },
              { label: 'Weekly Active (WAU)', value: data.wau, desc: 'Active over 7-day window', icon: Calendar, color: 'text-sky-500 bg-sky-500/5 border-sky-500/10' },
              { label: 'Monthly Active (MAU)', value: data.mau, desc: 'Rolling 30-day retention', icon: TrendingUp, color: 'text-emerald-500 bg-emerald-500/5 border-emerald-500/10' }
            ].map((c, i) => (
              <div key={i} className="bg-surface border border-border p-5 rounded-[24px] shadow-3xs flex items-start gap-4">
                <div className={`p-3 rounded-xl shrink-0 ${c.color.split(' ').slice(1).join(' ')} border`}>
                  <c.icon className={`w-5 h-5 ${c.color.split(' ')[0]}`} />
                </div>
                <div>
                  <div className="text-[10px] font-black uppercase text-ink3 tracking-widest leading-none mb-1">{c.label}</div>
                  <div className="text-2xl font-display font-black text-ink leading-tight tracking-tight">{c.value}</div>
                  <div className="text-[10px] text-ink2 font-medium mt-0.5">{c.desc}</div>
                </div>
              </div>
            ))}
          </div>

          {/* DETAILED STATS COUNTER GRID */}
          <h3 className="text-15px font-display font-bold text-ink pt-4 uppercase tracking-widest border-b border-border pb-2">
            Operational Event Summary
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { label: 'Chapters Ticked Complete', value: data.chapterCompletions, icon: CheckCircle2, color: 'text-green-600 bg-green-500/5' },
              { label: 'Lectures Watched', value: data.videosWatched, icon: Video, color: 'text-red-500 bg-red-500/5' },
              { label: 'Quiz Exercises Taken', value: data.quizAttempts, icon: BookOpen, color: 'text-purple-500 bg-purple-500/5' },
              { label: 'Mistakes Restructured', value: data.mistakesRecovered, icon: Flame, color: 'text-orange bg-orange-lt' }
            ].map((s, i) => (
              <div key={i} className="bg-surface2 border border-border p-4 rounded-2xl flex items-center gap-3">
                <div className={`p-2 rounded-xl shrink-0 ${s.color}`}>
                  <s.icon className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-[10px] text-ink3 font-bold block">{s.label}</span>
                  <strong className="text-base text-ink font-mono">{s.value}</strong>
                </div>
              </div>
            ))}
          </div>

          {/* TWO MAIN CHARTS BLOCK */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 pt-4">
            <div className="bg-surface border border-border p-6 rounded-[28px] shadow-3xs">
              <div className="flex items-center justify-between gap-4 mb-4">
                <div>
                  <h4 className="font-display font-bold text-ink text-base">User Activity & Traffic Velocity</h4>
                  <p className="text-[10px] text-ink3 font-medium">30-day interval of user active records</p>
                </div>
                <div className="flex items-center gap-3 font-mono text-[9px] uppercase font-black text-ink2">
                  <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 bg-orange rounded-full" /> DAU</span>
                  <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 bg-indigo-500 rounded-full" /> WAU</span>
                </div>
              </div>
              <div className="h-64">
                {isSimulated ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={simStats.trend} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                      <defs>
                        <linearGradient id="dauColor" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#f97316" stopOpacity={0.2}/>
                          <stop offset="95%" stopColor="#f97316" stopOpacity={0}/>
                        </linearGradient>
                        <linearGradient id="wauColor" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#6366f1" stopOpacity={0.2}/>
                          <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                      <XAxis dataKey="date" tickLine={false} style={{ fontSize: 9, fill: '#94a3b8' }} />
                      <YAxis tickLine={false} style={{ fontSize: 9, fill: '#94a3b8' }} />
                      <Tooltip contentStyle={{ background: '#0f172a', border: 'none', borderRadius: 12, color: '#fff', fontSize: 10 }} />
                      <Area type="monotone" dataKey="dau" stroke="#f97316" strokeWidth={2.5} fillOpacity={1} fill="url(#dauColor)" />
                      <Area type="monotone" dataKey="wau" stroke="#6366f1" strokeWidth={2.5} fillOpacity={1} fill="url(#wauColor)" />
                    </AreaChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="h-full flex flex-col items-center justify-center p-6 bg-surface2 border border-dashed border-border rounded-2xl text-center">
                    <TrendingUp className="w-8 h-8 text-indigo-500 animate-pulse mb-2" />
                    <h5 className="font-bold text-xs font-display">Real-Time Timeseries Active</h5>
                    <p className="text-[10px] text-ink3 mt-1">Multi-day sequence captures live session ticks securely across days.</p>
                  </div>
                )}
              </div>
            </div>

            <div className="bg-surface border border-border p-6 rounded-[28px] shadow-3xs">
              <h4 className="font-display font-bold text-ink text-base mb-1">Subject Mastery Index</h4>
              <p className="text-[10px] text-ink3 font-medium mb-4 font-display">Class aggregate status on syllabus components</p>
              <div className="h-64">
                {isSimulated ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <RechartsBarChart data={simStats.mastery} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                      <XAxis dataKey="range" tickLine={false} style={{ fontSize: 9, fill: '#94a3b8' }} />
                      <YAxis tickLine={false} style={{ fontSize: 9, fill: '#94a3b8' }} />
                      <Tooltip contentStyle={{ background: '#0f172a', border: 'none', borderRadius: 12, color: '#fff', fontSize: 10 }} />
                      <Legend wrapperStyle={{ fontSize: 9, fontWeight: 'bold' }} />
                      <Bar dataKey="maths" name="Maths" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                      <Bar dataKey="science" name="Science" fill="#10b981" radius={[4, 4, 0, 0]} />
                      <Bar dataKey="sst" name="SST" fill="#f97316" radius={[4, 4, 0, 0]} />
                    </RechartsBarChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="h-full flex flex-col items-center justify-center p-6 bg-surface2 border border-dashed border-border rounded-2xl text-center">
                    <BarChart2 className="w-8 h-8 text-emerald-500 animate-pulse mb-2" />
                    <h5 className="font-bold text-xs font-display">Awaiting comparative mastery distribution</h5>
                    <p className="text-[10px] text-ink3 mt-1">Populates once users start taking mock papers in the database.</p>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* LOGS & RETENTION COHORTS */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 pt-4">
            {/* RETENTION HEATMAP */}
            <div className="lg:col-span-7 bg-surface border border-border p-6 rounded-[28px] shadow-3xs">
              <div className="flex items-center justify-between gap-4 mb-4">
                <div>
                  <h4 className="font-display font-bold text-ink text-base">Syllabus Cohorts Retention Map</h4>
                  <p className="text-[10px] text-ink3 font-medium">Daily learning habits retention matrix of user segments</p>
                </div>
                <span className="text-[9px] font-black uppercase text-indigo-500 tracking-wider">ROLLING 6-WEEK TIMELINE</span>
              </div>
              <div className="overflow-x-auto rounded-xl">
                <table className="w-full text-center border-collapse text-xs font-semibold">
                  <thead>
                    <tr className="border-b border-border text-[9px] font-black uppercase tracking-wider text-ink3 bg-surface2">
                      <th className="py-3 px-3 text-left">Cohort (Weekly)</th>
                      <th className="py-3 px-3">Size</th>
                      <th className="py-3 px-3">W1</th>
                      <th className="py-3 px-3">W2</th>
                      <th className="py-3 px-3">W3</th>
                      <th className="py-3 px-3">W4</th>
                      <th className="py-3 px-3">W5</th>
                      <th className="py-3 px-3">W6</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border text-xs font-semibold">
                    {isSimulated ? (
                      simStats.retention.map((row, idx) => (
                        <tr key={idx} className="hover:bg-surface2/30 transition-colors">
                          <td className="py-3 px-3 text-left font-display text-ink font-bold">{row.cohort}</td>
                          <td className="py-3 px-3 font-mono text-ink2">{row.size}</td>
                          {[row.w1, row.w2, row.w3, row.w4, row.w5, row.w6].map((w, wIdx) => (
                            <td key={wIdx} className="p-1 font-mono">
                              <div className={`py-1.5 rounded-lg border text-[10px] ${getRetentionBg(w)}`}>
                                {typeof w === 'number' ? `${w}%` : w}
                              </div>
                            </td>
                          ))}
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={8} className="py-8 px-4 text-center text-ink3">
                          <div className="flex flex-col items-center gap-1.5 animate-pulse">
                            <Users className="w-6 h-6 text-indigo-500 mb-1" />
                            <span className="font-bold text-xs text-ink">Historical cohort tracking initiated</span>
                            <p className="text-[10px] max-w-sm">Calculates user visitation habits recursively over time.</p>
                          </div>
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* LIVE SYSTEM EVENTS */}
            <div className="lg:col-span-5 bg-surface border border-border p-6 rounded-[28px] shadow-3xs">
              <div className="flex items-center justify-between gap-4 mb-4">
                <div>
                  <h4 className="font-display font-bold text-ink text-base">Live Activity Logger</h4>
                  <p className="text-[10px] text-ink3 font-medium">Session-wide background operational stream</p>
                </div>
                <span className="flex h-2 w-2 relative">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-orange opacity-75 mr-1" />
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-orange mr-1" />
                </span>
              </div>
              <div className="space-y-3 max-h-[300px] overflow-y-auto pr-1">
                {realStats.events.length > 0 ? (
                  realStats.events.map((e, idx) => (
                    <div key={idx} className="p-3 bg-surface2 border border-border rounded-xl text-[11px] font-semibold flex items-start gap-2.5 hover:bg-border/35 transition-colors">
                      <div className={`p-1.5 rounded-lg text-xs leading-none mt-0.5 ${
                        e.type === 'visit' ? 'bg-indigo-500/10 text-indigo-500' :
                        e.type === 'quiz_attempt' ? 'bg-purple-500/10 text-purple-500' :
                        e.type === 'chapter_completed' ? 'bg-green-500/10 text-green-500' :
                        e.type === 'video_watched' ? 'bg-red-500/10 text-red-500' :
                        'bg-orange-lt text-orange'
                      }`}>
                        {e.type === 'visit' ? '👁️' : e.type === 'quiz_attempt' ? '📝' : e.type === 'video_watched' ? '📺' : '⚡'}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-1">
                          <span className="text-ink font-mono uppercase text-[9px] tracking-wider font-bold">
                            {e.type.replace('_', ' ')}
                          </span>
                          <span className="text-[8px] text-ink3 font-mono">
                            {new Date(e.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                          </span>
                        </div>
                        <p className="text-ink2 text-[10px] mt-0.5 truncate leading-tight">
                          <strong>{e.feature}</strong> {e.chapterName ? `(${e.chapterName})` : ''}
                        </p>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="py-12 text-center text-ink3">
                    <Clock className="w-8 h-8 text-orange animate-spin mb-2 mx-auto" />
                    <span className="font-bold text-xs text-ink block">Zero local activities logged yet</span>
                    <p className="text-[10px] max-w-sm mx-auto mt-1">Perform activities across the boards and study cards to trigger logs.</p>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* USER FEEDBACKS PIPELINE */}
          <div className="bg-surface border border-border p-6 rounded-[28px] shadow-3xs space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-border pb-4">
              <div>
                <h4 className="font-display font-bold text-ink text-lg flex items-center gap-2">
                  <span>📬</span> User Submitted Reports
                </h4>
                <p className="text-[10px] text-ink3 font-medium">Reports submitted securely from student profile panels</p>
              </div>
              <span className="text-[10px] font-black uppercase tracking-wider px-3 py-1 bg-surface2 border border-border rounded-lg text-ink3">
                {feedbacks.length} Total Pipeline Records
              </span>
            </div>

            <div className="space-y-3.5">
              {fetchingFeedbacks ? (
                <div className="py-12 text-center text-ink3">
                  <RefreshCw className="w-8 h-8 text-orange animate-spin mb-2 mx-auto" />
                  <span className="font-bold text-xs text-ink block">Connecting Feedbacks Pipeline...</span>
                </div>
              ) : feedbacks.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {feedbacks.map((fb) => (
                    <div key={fb.id} className="p-5 bg-surface2 border border-border rounded-2xl relative group hover:border-orange/20 transition-all flex flex-col justify-between space-y-3">
                      <div className="flex items-start justify-between gap-2.5">
                        <div className="space-y-0.5 text-left">
                          <span className={`px-2.5 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider border ${
                            fb.category === 'bug' ? 'bg-pink-100/10 border-pink-200 text-pink-700' :
                            fb.category === 'feature' ? 'bg-purple-100/10 border-purple-200 text-purple-700' :
                            fb.category === 'support' ? 'bg-emerald-100/10 border-emerald-200 text-emerald-700' :
                            'bg-indigo-100/10 border-indigo-200 text-indigo-700'
                          }`}>
                            {fb.category === 'bug' ? '🐛 Bug' : fb.category === 'feature' ? '💡 Feature' : fb.category === 'support' ? '🤝 Support' : '💬 feedback'}
                          </span>
                          <div className="pt-1.5 text-left text-ink2 text-[10px] font-medium truncate max-w-sm">
                            From: <strong className="text-ink">{fb.userEmail || 'anonymous'}</strong>
                            <p className="text-[8px] font-mono text-ink3 leading-none mt-1">UID: {fb.userId}</p>
                          </div>
                        </div>
                        <span className="text-[9px] text-ink3 font-mono flex items-center gap-1 shrink-0">
                          <Clock className="w-3 h-3" />
                          {fb.timestampStr}
                        </span>
                      </div>

                      <div className="text-xs text-ink/90 leading-relaxed bg-surface p-3.5 border border-border/80 rounded-xl whitespace-pre-wrap flex-1 min-h-[50px] text-left shadow-2xs">
                        {fb.message}
                      </div>

                      {fb.screenshot && (
                        <div className="flex items-center gap-2 border border-border bg-surface p-2 rounded-xl text-left shadow-2xs">
                          <div className="w-16 h-10 border border-border rounded-lg overflow-hidden bg-surface2 shrink-0">
                            <img src={fb.screenshot} alt="Captured report thumbnail" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                          </div>
                          <div className="flex-1 min-w-0 flex items-center justify-between gap-2">
                            <span className="text-[9px] text-ink3 font-black uppercase tracking-wider truncate">Attachment Screenshot</span>
                            <button
                              type="button"
                              onClick={() => setSelectedScreenshotUrl(fb.screenshot)}
                              className="p-1 px-2.5 bg-orange hover:bg-orange/90 text-white text-[9px] font-black uppercase tracking-widest rounded-lg flex items-center gap-1 cursor-pointer transition-colors shadow-sm"
                            >
                              <Eye className="w-3 h-3" /> View
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="py-12 text-center text-ink3 bg-surface2 rounded-2xl border border-dashed border-border">
                  <p className="text-sm">📥</p>
                  <span className="font-bold text-xs text-ink block mt-1.5">No feedbacks in current view</span>
                  <p className="text-[10px] max-w-sm mx-auto">Reports appear immediately once submitted by students.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ======================= OWNER: USER DIRECTORY ======================= */}
      {activeTab === 'users' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-surface border border-border p-5 rounded-3xl shadow-3xs">
            <div className="space-y-0.5">
              <h2 className="text-lg font-display font-black text-ink">Active Candidate Profile Register</h2>
              <p className="text-ink3 text-xs font-semibold uppercase tracking-wider">Inspect and manage live candidate roles instantly</p>
            </div>
            <div className="flex flex-col sm:flex-row gap-2.5 w-full sm:w-auto items-stretch sm:items-center">
              {/* Search Input bar */}
              <div className="relative flex-1 sm:w-64">
                <input
                  type="text"
                  placeholder="Search candidates, schools, roles, emails..."
                  value={searchUserQuery}
                  onChange={(e) => setSearchUserQuery(e.target.value)}
                  className="w-full py-2.5 pl-4 pr-10 text-xs bg-surface2 border border-border rounded-2xl focus:outline-none focus:border-orange text-ink font-semibold"
                />
                <span className="absolute right-3.5 top-3 text-ink3 text-xs">🔍</span>
              </div>
              
              <button
                type="button"
                onClick={() => setShowAddTeacherModal(true)}
                className="px-4 py-2.5 bg-teal-600 hover:bg-teal-700 text-white font-black text-xs uppercase tracking-widest rounded-2xl flex items-center justify-center gap-1.5 cursor-pointer transition-all active:scale-95 shadow-2xs"
              >
                <Plus className="w-3.5 h-3.5" /> Add Teacher
              </button>
            </div>
          </div>

          {/* ADD TEACHER MODAL / FORM SECTION */}
          {showAddTeacherModal && (
            <motion.div 
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-surface border border-border p-6 rounded-3xl shadow-md max-w-lg mx-auto"
            >
              <div className="flex items-center justify-between border-b border-border pb-3 mb-4">
                <div className="flex items-center gap-2">
                  <span className="p-2 rounded-xl bg-teal-50 text-teal-600 border border-teal-200 text-sm">🎓</span>
                  <div>
                    <h3 className="font-display font-black text-ink text-base">Pre-Register New Teacher</h3>
                    <p className="text-ink3 text-[10px] uppercase font-bold tracking-wider">Create credentials and activate teacher role</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setShowAddTeacherModal(false)}
                  className="p-1.5 hover:bg-surface2 text-ink3 hover:text-ink rounded-lg transition-colors cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleCreateTeacher} className="space-y-4 text-left">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] font-black uppercase text-ink3 tracking-widest mb-1.5">Teacher Full Name <span className="text-orange">*</span></label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Mrs. Ananya Sen"
                      value={newTeacherName}
                      onChange={(e) => setNewTeacherName(e.target.value)}
                      className="w-full px-3.5 py-2 text-xs bg-surface2 border border-border focus:border-teal-600 rounded-xl focus:outline-none text-ink font-semibold"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-black uppercase text-ink3 tracking-widest mb-1.5">Class / Curriculum <span className="text-orange">*</span></label>
                    <select
                      value={newTeacherClass}
                      onChange={(e) => setNewTeacherClass(e.target.value)}
                      className="w-full px-3.5 py-2 text-xs bg-surface2 border border-border focus:border-teal-600 rounded-xl focus:outline-none text-ink font-semibold"
                    >
                      <option value="CBSE Class 10">CBSE Class 10</option>
                      <option value="CBSE Class 9">CBSE Class 9</option>
                      <option value="CBSE Class 11">CBSE Class 11</option>
                      <option value="CBSE Class 12">CBSE Class 12</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-black uppercase text-ink3 tracking-widest mb-1.5">School / Institution</label>
                  <input
                    type="text"
                    placeholder="e.g. National Model Public School"
                    value={newTeacherSchool}
                    onChange={(e) => setNewTeacherSchool(e.target.value)}
                    className="w-full px-3.5 py-2 text-xs bg-surface2 border border-border focus:border-teal-600 rounded-xl focus:outline-none text-ink font-semibold"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] font-black uppercase text-ink3 tracking-widest mb-1.5">Email Address <span className="text-orange">*</span></label>
                    <input
                      type="email"
                      required
                      placeholder="teacher@school.com"
                      value={newTeacherEmail}
                      onChange={(e) => setNewTeacherEmail(e.target.value)}
                      className="w-full px-3.5 py-2 text-xs bg-surface2 border border-border focus:border-teal-600 rounded-xl focus:outline-none text-ink font-semibold"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-black uppercase text-ink3 tracking-widest mb-1.5">Initial Password <span className="text-orange">*</span></label>
                    <input
                      type="password"
                      required
                      minLength={6}
                      placeholder="At least 6 chars"
                      value={newTeacherPassword}
                      onChange={(e) => setNewTeacherPassword(e.target.value)}
                      className="w-full px-3.5 py-2 text-xs bg-surface2 border border-border focus:border-teal-600 rounded-xl focus:outline-none text-ink font-semibold"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-end gap-2.5 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowAddTeacherModal(false)}
                    className="px-4 py-2 text-xs font-black uppercase tracking-widest text-ink2 hover:text-ink transition-colors cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={registeringTeacher}
                    className="px-5 py-2 bg-teal-600 hover:bg-teal-700 text-white font-black text-xs uppercase tracking-widest rounded-xl flex items-center gap-1.5 cursor-pointer transition-all active:scale-95 disabled:opacity-50"
                  >
                    {registeringTeacher ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Registering...
                      </>
                    ) : (
                      <>
                        <Check className="w-3.5 h-3.5" /> Save & Activate
                      </>
                    )}
                  </button>
                </div>
              </form>
            </motion.div>
          )}

          <div className="bg-surface border border-border rounded-3xl overflow-hidden shadow-3xs">
            {loadingUsers ? (
              <div className="py-16 text-center text-ink3">
                <RefreshCw className="w-8 h-8 text-orange animate-spin mx-auto mb-2" />
                <span className="font-bold text-xs text-ink block font-display">Querying Cloud Database Directory...</span>
              </div>
            ) : filteredUsers.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-border text-[9px] font-black uppercase tracking-wider text-ink3 bg-surface2">
                      <th className="py-3 px-4">Student Profile Context</th>
                      <th className="py-3 px-4">Contact UID Context</th>
                      <th className="py-3 px-4">Level & Preference</th>
                      <th className="py-3 px-4">Operational Role</th>
                      <th className="py-3 px-4 text-right">Administrative Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border text-xs font-semibold">
                    {filteredUsers.map((usr) => (
                      <tr key={usr.id} className="hover:bg-surface2/40 transition-colors">
                        <td className="py-4 px-4">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full border border-orange bg-orange-lt font-black text-orange flex items-center justify-center font-display text-base">
                              {usr.name ? usr.name.charAt(0).toUpperCase() : 'S'}
                            </div>
                            <div className="text-left">
                              <h5 className="font-bold font-display text-ink text-sm leading-snug">{usr.name || 'Candidate Scholar'}</h5>
                              <p className="text-[10px] text-ink2 leading-tight mt-0.5">{usr.class || 'CBSE Class 10'} • {usr.school || 'Private CBSE Educator'}</p>
                            </div>
                          </div>
                        </td>
                        <td className="py-4 px-4 text-left font-mono text-[10px] text-ink2">
                          <div className="font-bold text-[11px] text-ink">{usr.id}</div>
                          <span className="text-[9px] opacity-60">Verified Document Target</span>
                        </td>
                        <td className="py-4 px-4 text-left">
                          <span className={`px-2 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider ${
                            usr.level === 'strong' ? 'bg-green-50 text-green-600 border border-green-100' :
                            usr.level === 'average' ? 'bg-blue-50 text-blue-600 border border-blue-100' :
                            'bg-yellow-50 text-yellow-600 border border-yellow-105'
                          }`}>
                            {usr.level || 'average'}
                          </span>
                          <div className="text-[9px] text-ink3 font-bold uppercase tracking-wide mt-1.5 font-mono">Daily target: {usr.time || 60}m</div>
                        </td>
                        <td className="py-4 px-4 text-left">
                          <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider border ${
                            usr.role === 'owner' ? 'bg-orange-mid text-orange border-orange/40' :
                            usr.role === 'teacher' ? 'bg-teal-50 text-teal-600 border-teal-200' :
                            'bg-surface2 text-ink3 border-border/80'
                          }`}>
                            {usr.role || 'student'}
                          </span>
                        </td>
                        <td className="py-4 px-4 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            {usr.role === 'student' ? (
                              <button
                                onClick={() => handleUpdateRole(usr.id, 'teacher')}
                                className="px-3 py-1.5 bg-teal-600 hover:bg-teal-700 text-white font-black text-[9px] uppercase tracking-widest rounded-lg flex items-center gap-1 cursor-pointer transition-colors"
                              >
                                <GraduationCap className="w-3 h-3" /> Make Teacher
                              </button>
                            ) : usr.role === 'teacher' ? (
                              <button
                                onClick={() => handleUpdateRole(usr.id, 'student')}
                                className="px-3 py-1.5 bg-surface hover:bg-surface2 text-ink2 border border-border font-black text-[9px] uppercase tracking-widest rounded-lg flex items-center gap-1 cursor-pointer transition-all"
                              >
                                <Users className="w-3 h-3" /> Demote student
                              </button>
                            ) : (
                              <span className="text-[9px] text-orange font-bold uppercase tracking-wide px-3 select-none">System Root</span>
                            )}
                            
                            {usr.role !== 'owner' && (
                              <button
                                onClick={() => handleDeleteUser(usr.id)}
                                className="p-1.5 bg-surface hover:bg-red-50 text-ink3 hover:text-red-500 border border-border rounded-lg cursor-pointer transition-all active:scale-95"
                                title="Delete Candidate profile"
                              >
                                <Trash className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="py-16 text-center text-ink3">
                <Users className="w-8 h-8 text-orange mb-2 mx-auto" />
                <span className="font-bold text-xs text-ink block font-display">No candidates found matching query</span>
                <p className="text-[10px] max-w-xs mx-auto">Try typing another candidate email or name query.</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ======================= OWNER: CONTENT MODERATION ======================= */}
      {activeTab === 'content' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Moderation Lectures list */}
          <div className="bg-surface border border-border p-6 rounded-[28px] shadow-3xs space-y-4">
            <h2 className="text-lg font-display font-black text-ink flex items-center gap-2">
              <Video className="w-5 h-5 text-orange" /> Published Lectures ({allLectures.length})
            </h2>
            <div className="space-y-3.5 max-h-[500px] overflow-y-auto pr-1">
              {allLectures.length > 0 ? (
                allLectures.map((l) => (
                  <div key={l.id} className="p-4 bg-surface2 border border-border rounded-2xl flex items-start justify-between gap-3 text-left">
                    <div className="min-w-0 flex-1">
                      <span className="px-2 py-0.5 bg-orange-lt text-orange border border-orange-mid/20 rounded text-[9px] font-black uppercase tracking-wider">{l.subject}</span>
                      <h4 className="font-bold text-sm text-ink font-display truncate mt-1.5 leading-snug">{l.title}</h4>
                      <p className="text-[10px] text-ink2 mt-1 truncate">{l.description}</p>
                      <div className="flex items-center gap-2 mt-2 flex-wrap">
                        <span className="text-[9px] text-ink3 font-medium">By: <strong>{l.authorName}</strong></span>
                        {l.videoUrl && <span className="text-[9px] font-mono text-indigo-500 leading-none bg-indigo-500/5 px-2 py-0.5 rounded border border-indigo-500/10">Attached Video</span>}
                      </div>
                    </div>
                    <button
                      onClick={() => handleDeleteLecture(l.id)}
                      className="p-1.5 bg-surface hover:bg-red-50 text-ink3 hover:text-red-500 border border-border rounded-lg cursor-pointer transition-all shrink-0 active:scale-95"
                    >
                      <Trash className="w-4 h-4" />
                    </button>
                  </div>
                ))
              ) : (
                <div className="py-16 text-center text-ink3 bg-surface2 rounded-2xl border border-dashed border-border/80">
                  <span className="text-[10px]">No educators lectures active on directory.</span>
                </div>
              )}
            </div>
          </div>

          {/* Moderation Tests list */}
          <div className="bg-surface border border-border p-6 rounded-[28px] shadow-3xs space-y-4">
            <h2 className="text-lg font-display font-black text-ink flex items-center gap-2">
              <ClipboardList className="w-5 h-5 text-indigo-500" /> Published Quizzes ({allTests.length})
            </h2>
            <div className="space-y-3.5 max-h-[500px] overflow-y-auto pr-1">
              {allTests.length > 0 ? (
                allTests.map((t) => (
                  <div key={t.id} className="p-4 bg-surface2 border border-border rounded-2xl flex items-start justify-between gap-3 text-left">
                    <div className="min-w-0 flex-1">
                      <span className="px-2 py-0.5 bg-indigo-500/10 text-indigo-500 border border-indigo-500/20 rounded text-[9px] font-black uppercase tracking-wider">{t.subject}</span>
                      <h4 className="font-bold text-sm text-ink font-display truncate mt-1.5 leading-snug">{t.title}</h4>
                      <p className="text-[10px] text-ink3 font-medium mt-1">Quiz chapter: <strong className="text-ink">{t.chapterName}</strong></p>
                      <div className="flex items-center gap-2 mt-2 flex-wrap text-[9px] text-ink3 font-medium">
                        <span>Items: <strong>{(t.questions || []).length} MCQs</strong></span>
                        <span>• By: <strong>{t.authorName}</strong></span>
                      </div>
                    </div>
                    <button
                      onClick={() => handleDeleteTest(t.id)}
                      className="p-1.5 bg-surface hover:bg-red-50 text-ink3 hover:text-red-500 border border-border rounded-lg cursor-pointer transition-all shrink-0 active:scale-95"
                    >
                      <Trash className="w-4 h-4" />
                    </button>
                  </div>
                ))
              ) : (
                <div className="py-16 text-center text-ink3 bg-surface2 rounded-2xl border border-dashed border-border/80">
                  <span className="text-[10px]">No dynamic tests published on directory.</span>
                </div>
              )}
            </div>
          </div>
        </div>
      )}


      {/* ======================= TEACHER: UPLOAD LECTURES ======================= */}
      {activeTab === 'upload-lecture' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Form component */}
          <div className="lg:col-span-5 bg-surface border border-border p-6 rounded-[28px] shadow-3xs space-y-4">
            <div>
              <h2 className="text-lg font-display font-black text-ink">Publish Lecture Link</h2>
              <p className="text-ink3 text-xs font-semibold uppercase tracking-wider mt-0.5">Configure structured notes to feed course cards</p>
            </div>

            <form onSubmit={handleUploadLecture} className="space-y-4 text-left">
              <div className="space-y-1.5">
                <label className="text-[10px] font-black uppercase tracking-widest text-ink3">CBSE Board Subject</label>
                <select
                  value={lectureSubject}
                  onChange={(e) => setLectureSubject(e.target.value)}
                  className="w-full bg-surface2 border border-border rounded-2xl py-2.5 px-3.5 focus:outline-none focus:border-orange text-xs text-ink font-semibold"
                >
                  {Object.values(SUBJECTS).map(s => (
                    <option key={s.key} value={s.key}>{s.label}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-black uppercase tracking-widest text-ink3">Target Lecture Chapter</label>
                <select
                  value={lectureChapter}
                  onChange={(e) => setLectureChapter(e.target.value)}
                  className="w-full bg-surface2 border border-border rounded-2xl py-2.5 px-3.5 focus:outline-none focus:border-orange text-xs text-ink font-semibold"
                >
                  {SUBJECTS[lectureSubject]?.chapters.map((ch, i) => (
                    <option key={i} value={ch.name}>{ch.name}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-black uppercase tracking-widest text-ink3">Lecture Title</label>
                <input
                  type="text"
                  placeholder="e.g., Balancing Reactions: Easy 5-Step Shortcut"
                  value={lectureTitle}
                  onChange={(e) => setLectureTitle(e.target.value)}
                  className="w-full bg-surface2 border border-border rounded-2xl py-2.5 px-3.5 focus:outline-none focus:border-orange text-xs text-ink font-semibold"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-black uppercase tracking-widest text-ink3">YouTube Lecture URL / ID (Optional)</label>
                <input
                  type="text"
                  placeholder="e.g., https://www.youtube.com/watch?v=gaX_uY9oV7E"
                  value={lectureVideoUrl}
                  onChange={(e) => setLectureVideoUrl(e.target.value)}
                  className="w-full bg-surface2 border border-border rounded-2xl py-2.5 px-3.5 focus:outline-none focus:border-orange text-xs text-ink font-semibold"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-black uppercase tracking-widest text-ink3">Topic Description & Core Takeaways</label>
                <textarea
                  rows={4}
                  placeholder="Type outline key formulae, concepts, and board review notes of this lecture..."
                  value={lectureDesc}
                  onChange={(e) => setLectureDesc(e.target.value)}
                  className="w-full bg-surface2 border border-border rounded-2xl py-2.5 px-3.5 focus:outline-none focus:border-orange text-xs text-ink font-medium leading-relaxed"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-orange hover:bg-orange/95 text-white font-black text-[10px] uppercase tracking-widest rounded-2xl transition-all shadow-md shadow-orange/15 cursor-pointer active:scale-95"
              >
                Publish Class Notes
              </button>
            </form>
          </div>

          {/* List component */}
          <div className="lg:col-span-7 bg-surface border border-border p-6 rounded-[28px] shadow-3xs space-y-4">
            <div>
              <h2 className="text-lg font-display font-black text-ink">My Published Lectures ({allLectures.filter(l => l.authorId === user?.uid).length})</h2>
              <p className="text-ink3 text-xs font-semibold uppercase tracking-wider mt-0.5">Manage notes published under your verified educator profile</p>
            </div>
            <div className="space-y-3 max-h-[550px] overflow-y-auto pr-1">
              {allLectures.some(l => l.authorId === user?.uid) ? (
                allLectures.filter(l => l.authorId === user?.uid).map((l) => (
                  <div key={l.id} className="p-4 bg-surface2 border border-border rounded-2xl flex items-start justify-between gap-3 text-left">
                    <div className="min-w-0 flex-1">
                      <span className="px-2 py-0.5 bg-orange-lt text-orange border border-orange-mid/25 rounded text-[8px] font-black uppercase tracking-widest">{l.subject}</span>
                      <h4 className="font-bold text-sm text-ink mt-2 font-display leading-snug">{l.title}</h4>
                      <p className="text-[10px] text-ink2 font-medium mt-1 leading-relaxed">{l.description}</p>
                      <p className="text-[9px] text-ink3 mt-2.5 font-mono">Chapter: {l.chapter}</p>
                    </div>
                    <button
                      onClick={() => handleDeleteLecture(l.id)}
                      className="p-1.5 bg-surface hover:bg-red-50 text-ink3 hover:text-red-500 border border-border rounded-lg cursor-pointer transition-all shrink-0 active:scale-95"
                    >
                      <Trash className="w-4 h-4" />
                    </button>
                  </div>
                ))
              ) : (
                <div className="py-20 text-center text-ink3 bg-surface2 rounded-2xl border border-dashed border-border">
                  <Video className="w-8 h-8 text-orange/30 mx-auto mb-2 animate-pulse" />
                  <span className="font-bold text-xs text-ink block font-display">No published lectures found</span>
                  <p className="text-[10px] max-w-xs mx-auto">Fill the Publish form to push real-time CBSE class notes.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ======================= TEACHER: CREATE TESTS ======================= */}
      {activeTab === 'exam-builder' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Builder Form */}
          <div className="lg:col-span-7 bg-surface border border-border p-6 rounded-[28px] shadow-3xs space-y-4">
            <div>
              <h2 className="text-lg font-display font-black text-ink">Construct Practice Board Quiz</h2>
              <p className="text-ink3 text-xs font-semibold uppercase tracking-wider mt-0.5">Assemble multiple-choice questions to evaluate student syllabus mastery</p>
            </div>

            <form onSubmit={handlePublishTest} className="space-y-4 text-left">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black uppercase tracking-widest text-ink3">Subject Category</label>
                  <select
                    value={testSubject}
                    onChange={(e) => setTestSubject(e.target.value)}
                    className="w-full bg-surface2 border border-border rounded-2xl py-2.5 px-3.5 focus:outline-none focus:border-orange text-xs text-ink font-semibold"
                  >
                    {Object.values(SUBJECTS).map(s => (
                      <option key={s.key} value={s.key}>{s.label}</option>
                    ))}
                  </select>
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black uppercase tracking-widest text-ink3">Chapter target</label>
                  <select
                    value={testChapter}
                    onChange={(e) => setTestChapter(e.target.value)}
                    className="w-full bg-surface2 border border-border rounded-2xl py-2.5 px-3.5 focus:outline-none focus:border-orange text-xs text-ink font-semibold"
                  >
                    {SUBJECTS[testSubject]?.chapters.map((ch, i) => (
                      <option key={i} value={ch.name}>{ch.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-black uppercase tracking-widest text-ink3">Evaluation Quiz Title</label>
                <input
                  type="text"
                  placeholder="e.g., Chemical reactions chapter mid-term test"
                  value={testTitle}
                  onChange={(e) => setTestTitle(e.target.value)}
                  className="w-full bg-surface2 border border-border rounded-2xl py-2.5 px-3.5 focus:outline-none focus:border-orange text-xs text-ink font-semibold"
                />
              </div>

              {/* Questions Area */}
              <div className="space-y-4 pt-3">
                <div className="flex items-center justify-between border-b border-border pb-1.5">
                  <h4 className="text-13px font-display font-black uppercase tracking-wider text-ink">MCQ Question Sheets</h4>
                  <button
                    type="button"
                    onClick={addQuestionField}
                    className="px-3 py-1 bg-ink text-white hover:bg-orange rounded-xl text-[9px] font-black uppercase tracking-widest flex items-center gap-1 cursor-pointer transition-all active:scale-95"
                  >
                    <Plus className="w-3 h-3" /> Insert Question
                  </button>
                </div>

                {questions.map((q, qIdx) => (
                  <div key={qIdx} className="bg-surface2 border border-border p-4 rounded-2xl space-y-3 relative">
                    <button
                      type="button"
                      disabled={questions.length <= 1}
                      onClick={() => removeQuestionField(qIdx)}
                      className="absolute right-3.5 top-3.5 text-ink3 hover:text-red-500 cursor-pointer disabled:opacity-45"
                    >
                      <Trash className="w-3.5 h-3.5" />
                    </button>

                    <div className="space-y-1.5 text-left">
                      <span className="text-[9px] font-black uppercase tracking-widest text-ink3">Question #{qIdx + 1}</span>
                      <input
                        type="text"
                        placeholder="e.g., Which gas is released on reacting zinc granules with dilute sulphuric acid?"
                        value={q.q}
                        onChange={(e) => updateQuestionQuery(qIdx, e.target.value)}
                        className="w-full bg-surface border border-border rounded-xl py-2 px-3 focus:outline-none focus:border-orange text-xs text-ink font-semibold"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {q.opts.map((opt, oIdx) => (
                        <div key={oIdx} className="space-y-1 flex items-center gap-2">
                          <input
                            type="radio"
                            name={`correct_radio_${qIdx}`}
                            checked={q.ansIdx === oIdx}
                            onChange={() => updateCorrectAnswer(qIdx, oIdx)}
                            className="cursor-pointer accent-orange"
                          />
                          <input
                            type="text"
                            placeholder={`Option ${oIdx + 1}`}
                            value={opt}
                            onChange={(e) => updateOptionText(qIdx, oIdx, e.target.value)}
                            className="w-full bg-surface border border-border rounded-lg py-1.5 px-3.5 text-xs text-ink font-medium"
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-orange hover:bg-orange/95 text-white font-black text-[10px] uppercase tracking-widest rounded-2xl transition-all shadow-md shadow-orange/15 cursor-pointer active:scale-95"
              >
                Publish Board Test
              </button>
            </form>
          </div>

          {/* List component */}
          <div className="lg:col-span-5 bg-surface border border-border p-6 rounded-[28px] shadow-3xs space-y-4">
            <div>
              <h4 className="font-display font-bold text-ink text-lg">My Created Tests ({allTests.filter(t => t.authorId === user?.uid).length})</h4>
              <p className="text-ink3 text-xs font-semibold uppercase tracking-wider mt-0.5">Manage mock assessments published on the candidate feed</p>
            </div>
            <div className="space-y-3 max-h-[550px] overflow-y-auto pr-1">
              {allTests.some(t => t.authorId === user?.uid) ? (
                allTests.filter(t => t.authorId === user?.uid).map((t) => (
                  <div key={t.id} className="p-4 bg-surface2 border border-border rounded-2xl flex items-start justify-between gap-3 text-left">
                    <div className="min-w-0 flex-1">
                      <span className="px-2 py-0.5 bg-indigo-500/10 text-indigo-500 border border-indigo-500/15 rounded text-[8px] font-black uppercase tracking-widest">{t.subject}</span>
                      <h4 className="font-bold text-sm text-ink mt-2 font-display leading-snug">{t.title}</h4>
                      <p className="text-[10px] text-ink3 mt-1">Syllabus target: <strong className="text-ink">{t.chapterName}</strong></p>
                      <p className="text-[10px] text-ink3 mt-1.5 font-mono">Questions depth: <strong>{(t.questions || []).length} MCQs</strong></p>
                    </div>
                    <button
                      onClick={() => handleDeleteTest(t.id)}
                      className="p-1.5 bg-surface hover:bg-red-50 text-ink3 hover:text-red-500 border border-border rounded-lg cursor-pointer transition-all shrink-0 active:scale-95"
                    >
                      <Trash className="w-4 h-4" />
                    </button>
                  </div>
                ))
              ) : (
                <div className="py-20 text-center text-ink3 bg-surface2 rounded-2xl border border-dashed border-border animate-fadeIn">
                  <ClipboardList className="w-8 h-8 text-indigo-400 mx-auto mb-2 animate-pulse" />
                  <span className="font-bold text-xs text-ink block font-display">No examinations constructed</span>
                  <p className="text-[10px] max-w-xs mx-auto">Publish real assess evaluations using the Mock Exam Builder form.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}


      {/* ======================= TEACHER: VIEW COHORT STUDENT PROGRESS ======================= */}
      {activeTab === 'cohort' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Student list column */}
          <div className="lg:col-span-5 bg-surface border border-border p-6 rounded-[28px] shadow-3xs space-y-4">
            <div>
              <h2 className="text-lg font-display font-black text-ink">My Student Cohort</h2>
              <p className="text-ink3 text-xs font-semibold uppercase tracking-wider mt-0.5">Select a CBSE board candidate profile below to query progress metrics</p>
            </div>

            <div className="space-y-2.5 max-h-[500px] overflow-y-auto pr-1">
              {usersList.length > 0 ? (
                /* Only filter students */
                usersList.filter(u => u.role !== 'owner' && u.role !== 'teacher').map((st) => (
                  <div
                    key={st.id}
                    onClick={() => fetchCohortStudentDetail(st)}
                    className={`p-3.5 rounded-2xl cursor-pointer border transition-all flex items-center justify-between text-left ${
                      selectedCohortStudent?.id === st.id
                        ? 'bg-orange-lt border-orange/50 shadow-sm'
                        : 'bg-surface2 hover:bg-surface border-border hover:border-orange/20'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-surface border border-border shadow-3xs text-xs font-display font-black flex items-center justify-center text-ink2">
                        {st.name ? st.name.charAt(0).toUpperCase() : 'S'}
                      </div>
                      <div>
                        <h4 className="font-bold text-xs text-ink font-display leading-tight">{st.name || 'Candidate Scholar'}</h4>
                        <p className="text-[9px] text-ink2 mt-0.5">{st.school || 'Private candidate'}</p>
                      </div>
                    </div>
                    <span className="text-[9px] text-orange font-bold uppercase tracking-widest font-mono">inspect</span>
                  </div>
                ))
              ) : (
                <div className="py-16 text-center text-ink3">
                  <Users className="w-6 h-6 text-orange/30 mx-auto mb-1 animate-pulse" />
                  <span className="font-bold text-xs text-ink">Cohort empty</span>
                </div>
              )}
            </div>
          </div>

          {/* Student details inspect panel */}
          <div className="lg:col-span-7 bg-surface border border-border p-6 rounded-[28px] shadow-3xs">
            {selectedCohortStudent ? (
              <div className="space-y-6">
                {/* core block */}
                <div className="bg-surface2 border border-border p-5 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-left">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-full border-2 border-orange/30 bg-orange-lt font-display font-black text-orange text-lg flex items-center justify-center">
                      {selectedCohortStudent.name ? selectedCohortStudent.name.charAt(0).toUpperCase() : 'S'}
                    </div>
                    <div>
                      <h3 className="font-black text-base text-ink font-display leading-snug">{selectedCohortStudent.name}</h3>
                      <p className="text-[10px] text-ink2 mt-0.5 font-semibold">Class status: <strong className="text-ink font-medium">{selectedCohortStudent.class || 'CBSE Class 10'}</strong></p>
                      <p className="text-[8px] font-mono text-ink3 leading-none mt-1">Scholar UID: {selectedCohortStudent.id}</p>
                    </div>
                  </div>

                  <div className="text-left sm:text-right">
                    <span className="text-[9px] text-ink3 font-black uppercase tracking-widest">Mastery Bracket</span>
                    <div className="text-sm font-display font-black text-ink uppercase tracking-wide">{selectedCohortStudent.level || 'Average candidate'}</div>
                    <p className="text-[10px] font-mono text-ink2 mt-1">Study goal: <strong>{selectedCohortStudent.time || 60}m/day</strong></p>
                  </div>
                </div>

                {loadingStudentDetail ? (
                  <div className="py-16 text-center text-ink3">
                    <RefreshCw className="w-6 h-6 text-orange animate-spin mx-auto mb-2" />
                    <span className="font-bold text-xs text-ink font-display">Parsing Student Academic profile...</span>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Progress details */}
                    <div className="space-y-3.5 text-left">
                      <h4 className="text-[11px] font-black uppercase tracking-widest text-ink3 flex items-center gap-1">
                        <Activity className="w-3.5 h-3.5 text-orange" /> Syllabus Progression Records
                      </h4>
                      <div className="space-y-2.5 max-h-[300px] overflow-y-auto pr-1">
                        {studentProgressList.length > 0 ? (
                          studentProgressList.map((prog, idx) => (
                            <div key={idx} className="p-3 bg-surface2 border border-border rounded-xl space-y-1">
                              <span className="text-[8px] font-mono font-black uppercase tracking-widest text-orange bg-orange-lt px-1.5 py-0.5 rounded border border-orange-mid/10">{prog.subjectKey || 'Subject'}</span>
                              <h5 className="font-bold font-display text-xs text-ink mt-2">{prog.chapterName}</h5>
                              <div className="flex items-center justify-between text-[10px] text-ink2 pt-1 font-mono">
                                <span>Scored best: <strong>{prog.bestScore}/{prog.totalOut}</strong></span>
                                <span>Attempts: <strong>{prog.attempts || 1}</strong></span>
                              </div>
                            </div>
                          ))
                        ) : (
                          <div className="p-6 text-center text-ink3 bg-surface2 border border-dashed border-border rounded-2xl">
                            <CheckCircle2 className="w-6 h-6 text-ink3/45 mx-auto mb-1" />
                            <span className="text-[9px]">No syllabus chapter completions recorded yet.</span>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Adaptive plan summary */}
                    <div className="space-y-3.5 text-left">
                      <h4 className="text-[11px] font-black uppercase tracking-widest text-ink3 flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5 text-indigo-500" /> Current Adaptive Roadmap Tasks
                      </h4>
                      <div className="space-y-2.5 max-h-[300px] overflow-y-auto pr-1">
                        {studentPlans && studentPlans.roadmap && (studentPlans.roadmap || []).length > 0 ? (
                          (studentPlans.roadmap || []).map((t: any, idx: number) => (
                            <div key={idx} className="p-3 bg-indigo-500/5 border border-indigo-500/10 rounded-xl space-y-1">
                              <h5 className="font-bold font-display text-xs text-ink leading-tight">{t.topic || 'Revision task'}</h5>
                              <p className="text-[9px] text-ink2 leading-relaxed">{t.actionLabel || 'Mock checklist'}</p>
                              <div className="flex justify-between items-center text-[8px] font-mono font-bold uppercase text-indigo-500 pt-1.5 border-t border-indigo-500/5">
                                <span>Subject: {t.subject || 'science'}</span>
                                <span className={t.completed ? 'text-green-600' : 'text-indigo-400'}>{t.completed ? 'Completed' : 'Study Desk'}</span>
                              </div>
                            </div>
                          ))
                        ) : (
                          <div className="p-6 text-center text-ink3 bg-teal-500/5 border border-dashed border-border rounded-2xl">
                            <Calendar className="w-6 h-6 text-ink3/45 mx-auto mb-1 animate-pulse" />
                            <span className="text-[9px]">No custom adaptive study planning generated.</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="py-20 text-center text-ink3 bg-surface2 rounded-3xl border border-dashed border-border/70 animate-pulse">
                <Users className="w-10 h-10 text-orange border border-orange bg-orange-lt rounded-full p-2 mx-auto mb-3" />
                <h5 className="font-bold text-xs text-ink font-display leading-snug">No Active Candidate selection</h5>
                <p className="text-[10px] max-w-sm mx-auto mt-0.5 pr-4 pl-4 leading-relaxed">Select a candidate on the left to pull real-time database progress records, syllabus metrics, and study plans.</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* RENDER MODAL VIEW ZOOMED IN FEEDBACK SCREENSHOT */}
      {selectedScreenshotUrl && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs animate-fadeIn">
          <div className="max-w-3xl w-full bg-surface border border-border rounded-3xl p-5 shadow-2xl relative flex flex-col space-y-4 animate-scaleIn">
            <div className="flex items-center justify-between border-b border-border pb-2.5">
              <span className="text-[10px] font-black uppercase tracking-widest text-ink3 flex items-center gap-2">
                <ImageIcon className="w-4 h-4 text-orange" /> Feedback Screenshot Attachment
              </span>
              <button
                type="button"
                onClick={() => setSelectedScreenshotUrl(null)}
                className="p-1 text-ink3 hover:text-ink hover:bg-surface2 rounded-full border border-border transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="w-full overflow-hidden bg-black rounded-2xl flex items-center justify-center max-h-[70vh]">
              <img src={selectedScreenshotUrl} alt="Report full sizes" className="max-w-full max-h-[70vh] object-contain shadow-sm" referrerPolicy="no-referrer" />
            </div>
            <div className="flex justify-end pt-1">
              <button
                type="button"
                onClick={() => setSelectedScreenshotUrl(null)}
                className="px-5 py-2.5 bg-orange text-white text-[10px] font-black uppercase tracking-wider rounded-xl hover:bg-orange/95 cursor-pointer active:scale-95 transition-all"
              >
                Dismiss Proof
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
