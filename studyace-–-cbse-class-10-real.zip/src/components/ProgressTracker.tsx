/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useMemo, useState, useEffect } from 'react';
import { Screen } from '../App';
import { SUBJECTS } from '../constants';
import { loadItem, saveItem } from '../lib/utils';
import { ArrowLeft, Trash2, Award, BookOpen, Target, Clock, ChevronRight, RefreshCw, Cloud, BarChart } from 'lucide-react';
import { cn } from '../lib/utils';
import { ProgressRecord } from '../types';
import { useAuth } from '../context/AuthContext';
import { db } from '../lib/firebase';
import { collection, getDocs, query, writeBatch } from 'firebase/firestore';
import { 
  LineChart, 
  Line, 
  BarChart as ReBarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Cell 
} from 'recharts';

interface TrackerProps {
  navigateTo: (s: Screen, subKey?: string | null, chIdx?: number | null) => void;
  showToast: (msg: string) => void;
}

export default function ProgressTracker({ navigateTo, showToast }: TrackerProps) {
  const { user } = useAuth();
  const [allProg, setAllProg] = useState<Record<string, ProgressRecord>>(() => loadItem<Record<string, ProgressRecord>>('vidypath_progress_v4', {}));
  const [syncing, setSyncing] = useState(false);

  // Sync from Cloud
  useEffect(() => {
    if (!user) return;

    const fetchCloudProgress = async () => {
      setSyncing(true);
      try {
        const q = query(collection(db, 'users', user.uid, 'progress'));
        const querySnapshot = await getDocs(q);
        const cloudData: Record<string, ProgressRecord> = {};
        querySnapshot.forEach((doc) => {
          cloudData[doc.id] = doc.data() as ProgressRecord;
        });
        if (Object.keys(cloudData).length > 0) {
          setAllProg(cloudData);
          saveItem('vidypath_progress_v4', cloudData);
        }
      } catch (err) {
        console.error('Failed to sync progress:', err);
      } finally {
        setSyncing(false);
      }
    };

    fetchCloudProgress();
  }, [user]);

  const records = Object.values(allProg) as ProgressRecord[];

  const stats = useMemo(() => {
    if (records.length === 0) return { tests: 0, chapters: 0, avg: 0, best: 0 };
    const bests = records.map((r: ProgressRecord) => (r.bestScore / r.totalOut) * 100);
    return {
      tests: records.reduce((s: number, r: ProgressRecord) => s + r.attempts, 0),
      chapters: records.length,
      avg: Math.round(bests.reduce((s: number, b: number) => s + b, 0) / bests.length),
      best: Math.round(Math.max(...bests))
    };
  }, [records]);

  const weakChapters = records.filter((r: ProgressRecord) => (r.bestScore / r.totalOut) * 100 < 50);

  const chartData = useMemo(() => {
    // Subject wise average for bar chart
    const subStats: Record<string, { totalPct: number, count: number }> = {};
    records.forEach((r: ProgressRecord) => {
      if (!subStats[r.subjectKey]) subStats[r.subjectKey] = { totalPct: 0, count: 0 };
      subStats[r.subjectKey].totalPct += (r.bestScore / r.totalOut) * 100;
      subStats[r.subjectKey].count += 1;
    });

    const barData = Object.entries(SUBJECTS).map(([key, sub]) => {
      const stat = subStats[key];
      return {
        name: sub.label,
        key: key,
        score: stat ? Math.round(stat.totalPct / stat.count) : 0,
        color: sub.color.replace('bg-', '#').replace('orange', '#ff851b').replace('blue', '#0074d9').replace('green', '#2ecc40').replace('red', '#ff4136').replace('purple', '#b10dc9')
      };
    }).filter(d => d.score > 0);

    // Trend data for line chart (Simplified: sort by date string)
    // 11-May-2026 -> 2026-05-11
    const parseDate = (d: string) => {
      const parts = d.split(' ');
      const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
      const month = monthNames.indexOf(parts[1]);
      return new Date(parseInt(parts[2]), month, parseInt(parts[0])).getTime();
    };

    const trendData = [...records].sort((a, b) => parseDate(a.lastDate) - parseDate(b.lastDate)).map(r => ({
      date: r.lastDate.split(' ').slice(0, 2).join(' '), // 11 May
      score: Math.round((r.bestScore / r.totalOut) * 100)
    }));

    return { barData, trendData };
  }, [records]);

  const clearProgress = async () => {
    if (!confirm('Delete all saved progress? This cannot be undone.')) return;
    
    saveItem('vidypath_progress_v4', {});
    setAllProg({});
    
    if (user) {
      try {
        const batch = writeBatch(db);
        const q = query(collection(db, 'users', user.uid, 'progress'));
        const querySnapshot = await getDocs(q);
        querySnapshot.forEach((doc) => batch.delete(doc.ref));
        await batch.commit();
      } catch (err) {
        console.error('Failed to clear cloud progress:', err);
      }
    }
    showToast('All progress cleared.');
    window.location.reload();
  };

  return (
    <div className="max-w-[780px] mx-auto px-4 py-8 pb-32">
      <header className="mb-10 space-y-4">
        <div className="flex items-center justify-between">
          <button 
            onClick={() => navigateTo('home')}
            className="inline-flex items-center gap-2 text-ink3 font-bold text-xs uppercase tracking-widest hover:text-orange transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            Home
          </button>
          {user && (
            <div className="flex items-center gap-1 text-[9px] font-black uppercase tracking-widest text-green-500 bg-green-50 px-2 py-1 rounded-full border border-green-100">
              <Cloud className={cn("w-2.5 h-2.5", syncing && "animate-pulse")} />
              {syncing ? 'Syncing...' : 'Cloud Active'}
            </div>
          )}
        </div>
        <div className="space-y-1">
          <h2 className="text-3xl font-display tracking-tight">Study Dashboard</h2>
          <p className="text-sm text-ink2">Your learning progress across all CBSE Class 10 subjects.</p>
        </div>
      </header>

      {/* Summary Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-10">
        {[
          { label: 'Tests taken', val: stats.tests, icon: Clock, color: 'text-orange bg-orange-lt' },
          { label: 'Chapters done', val: stats.chapters, icon: BookOpen, color: 'text-blue-600 bg-blue-50' },
          { label: 'Avg score', val: stats.avg + '%', icon: Target, color: 'text-green-600 bg-green-50' },
          { label: 'Best score', val: stats.best + '%', icon: Award, color: 'text-purple-600 bg-purple-50' },
        ].map((s, i) => (
          <div key={i} className="bg-surface p-5 rounded-2xl border border-border flex flex-col items-center text-center space-y-2 shadow-sm">
            <div className={cn("w-8 h-8 rounded-full flex items-center justify-center", s.color)}>
              <s.icon className="w-4 h-4" />
            </div>
            <div className="text-2xl font-display text-ink">{s.val}</div>
            <div className="text-[10px] font-bold uppercase tracking-wider text-ink3">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Analytics Section */}
      {records.length > 0 && (
        <div className="space-y-6 mb-10">
          <div className="flex items-center gap-3 text-xs font-black uppercase tracking-[0.2em] text-ink3 px-2">
            <BarChart className="w-4 h-4" />
            Performance Analytics
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Subject Breakdown Bar Chart */}
            <div className="bg-surface border border-border rounded-[32px] p-6 shadow-sm space-y-4 min-w-0">
              <div className="text-[10px] font-black uppercase tracking-widest text-ink3">Subject Mastery (%)</div>
              <div className="h-[200px] w-full">
                <ResponsiveContainer width="100%" height={200} minWidth={0}>
                  <ReBarChart data={chartData.barData}>
                    <XAxis 
                      dataKey="name" 
                      hide={false} 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{ fontSize: 9, fontWeight: 700, fill: '#6B7280' }}
                    />
                    <Tooltip 
                      cursor={{ fill: 'transparent' }}
                      contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)', fontSize: '10px', fontWeight: 'bold' }}
                    />
                    <Bar dataKey="score" radius={[8, 8, 0, 0]} barSize={24}>
                      {chartData.barData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Bar>
                  </ReBarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Performance Trend Line Chart */}
            <div className="bg-surface border border-border rounded-[32px] p-6 shadow-sm space-y-4 min-w-0">
              <div className="text-[10px] font-black uppercase tracking-widest text-ink3">Chapter Achievement Trend</div>
              <div className="h-[200px] w-full">
                <ResponsiveContainer width="100%" height={200} minWidth={0}>
                  <LineChart data={chartData.trendData}>
                    <XAxis 
                      dataKey="date" 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{ fontSize: 9, fontWeight: 700, fill: '#6B7280' }}
                    />
                    <Tooltip 
                      contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)', fontSize: '10px', fontWeight: 'bold' }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="score" 
                      stroke="#FF851B" 
                      strokeWidth={3} 
                      dot={{ fill: '#FF851B', strokeWidth: 2, r: 4 }}
                      activeDot={{ r: 6, strokeWidth: 0 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Weak Alert */}
      {weakChapters.length > 0 && (
        <div className="bg-red-50 border border-red-100 p-5 rounded-3xl mb-10 space-y-3">
          <div className="flex items-center gap-2 text-red-600 font-bold text-xs uppercase tracking-widest">
            <Award className="w-4 h-4 fill-current rotate-180" />
            Needs Attention ({weakChapters.length})
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {weakChapters.map((r: ProgressRecord, i: number) => (
              <div key={i} className="flex items-center gap-3 p-3 bg-white/60 rounded-xl border border-red-100/50">
                <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-bold text-red-900 truncate">{r.chapterName}</div>
                  <div className="text-[10px] text-red-600 font-semibold">{SUBJECTS[r.subjectKey]?.label} · Best: {r.bestScore}/{r.totalOut}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Subject Breakdown */}
      <div className="space-y-8">
        {Object.entries(SUBJECTS).map(([key, sub]) => {
          const subRecords = records.filter((r: ProgressRecord) => r.subjectKey === key);
          if (subRecords.length === 0) return null;

          return (
            <div key={key} className="space-y-4">
              <h3 className="flex items-center gap-3 text-sm font-bold text-ink uppercase tracking-widest">
                <span className="w-8 h-8 rounded-xl bg-surface2 border border-border flex items-center justify-center shadow-sm">{sub.icon}</span>
                {sub.label}
              </h3>
              <div className="space-y-1">
                {sub.chapters.map((ch, i) => {
                  const rec = allProg[`${key}__${ch.name}`] as ProgressRecord | undefined;
                  const pct = rec ? Math.round((rec.bestScore / rec.totalOut) * 100) : 0;
                  const status = pct >= 80 ? 'great' : pct >= 50 ? 'ok' : pct > 0 ? 'low' : 'none';

                  const colors = {
                    great: 'bg-green-500',
                    ok: 'bg-orange',
                    low: 'bg-red-500',
                    none: 'bg-border'
                  };

                  return (
                    <div key={i} className={cn(
                      "flex items-center gap-4 p-4 bg-surface border border-border rounded-xl transition-all shadow-sm",
                      rec ? "opacity-100" : "opacity-40 grayscale group"
                    )}>
                      <div className="text-[10px] font-black font-display text-ink3 w-4">{String(i+1).padStart(2,'0')}</div>
                      <div className="flex-1">
                        <div className="text-sm font-bold text-ink">{ch.name}</div>
                        {rec && <div className="text-[10px] font-medium text-ink3 uppercase mt-0.5">{rec.lastDate} · {rec.attempts} attempts</div>}
                      </div>

                      {rec ? (
                        <>
                          <div className="hidden sm:block w-20">
                            <div className="h-1 w-full bg-border rounded-full overflow-hidden">
                              <div className={cn("h-full rounded-full transition-all", colors[status as keyof typeof colors])} style={{ width: `${pct}%` }} />
                            </div>
                          </div>
                          <div className={cn(
                            "px-2.5 py-1 rounded-lg text-[10px] font-black uppercase text-white shadow-sm",
                            colors[status as keyof typeof colors]
                          )}>
                            {rec.bestScore}/{rec.totalOut}
                          </div>
                          <button 
                            onClick={() => navigateTo('quiz', key, i)}
                            className="p-1.5 rounded-lg border border-border text-ink3 hover:border-orange hover:text-orange transition-all"
                          >
                            <RefreshCw className="w-3.5 h-3.5" />
                          </button>
                        </>
                      ) : (
                        <button 
                          onClick={() => navigateTo('quiz', key, i)}
                          className="px-4 py-1.5 rounded-lg border border-orange text-orange text-[10px] font-black uppercase tracking-widest hover:bg-orange hover:text-white transition-all ml-auto"
                        >
                          Start
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      {records.length > 0 && (
        <div className="mt-16 pt-8 border-t border-border text-center">
          <button 
            onClick={clearProgress}
            className="inline-flex items-center gap-2 px-6 py-2 border border-border rounded-xl text-xs font-bold text-ink3 hover:text-red-500 hover:border-red-200 transition-all uppercase tracking-widest"
          >
            <Trash2 className="w-3.5 h-3.5" />
            Clear All progress
          </button>
        </div>
      )}
    </div>
  );
}
