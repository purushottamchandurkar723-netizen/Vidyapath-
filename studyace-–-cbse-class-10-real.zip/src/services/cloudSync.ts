/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { doc, setDoc, getDocs, collection, serverTimestamp, writeBatch } from 'firebase/firestore';
import { db, OperationType, handleFirestoreError } from '../lib/firebase';

// Debounce queue setup for cloud synchronization
const pendingSyncs = new Map<string, any>();
const syncTimeouts = new Map<string, NodeJS.Timeout>();

/**
 * Enqueues a debounced cloud sync operation to avoid overloading Firestore.
 */
export function enqueueCloudSync(userId: string, key: string, value: any): void {
  const syncKey = `${userId}_${key}`;
  pendingSyncs.set(syncKey, value);

  // Clear existing debounced timeout for this specific key
  const existingTimeout = syncTimeouts.get(syncKey);
  if (existingTimeout) {
    clearTimeout(existingTimeout);
  }

  // Set new debounced timeout to execute the write (800ms delay)
  const timeoutId = setTimeout(async () => {
    syncTimeouts.delete(syncKey);
    const currentValue = pendingSyncs.get(syncKey);
    if (currentValue === undefined) return;

    try {
      const docRef = doc(db, 'users', userId, 'syncData', key);
      await setDoc(docRef, {
        value: JSON.stringify(currentValue),
        updatedAt: serverTimestamp()
      });
      // Clear value from pending once successfully synced
      pendingSyncs.delete(syncKey);
    } catch (error) {
      console.error(`[CloudSync] Background sync failed for key: ${key}`, error);
      // Let's call the standard firestore error handler internally for diagnosis
      try {
        handleFirestoreError(error, OperationType.WRITE, `users/${userId}/syncData/${key}`);
      } catch (e) {
        // Just catch so we don't crash background thread
      }
    }
  }, 800);

  syncTimeouts.set(syncKey, timeoutId);
}

/**
 * Syncs and pulls down all server states from Firestore, saving them to local user storage namespace.
 * This is executed right at login or session start.
 */
export async function pullCloudSync(userId: string, showToast?: (msg: string) => void): Promise<boolean> {
  try {
    const q = collection(db, 'users', userId, 'syncData');
    const querySnapshot = await getDocs(q);
    
    let updatedCount = 0;
    querySnapshot.forEach((docSnap) => {
      const key = docSnap.id;
      const data = docSnap.data();
      if (data && typeof data.value === 'string') {
        const localKey = `${userId}_${key}`;
        localStorage.setItem(localKey, data.value);
        updatedCount++;
      }
    });

    console.log(`[CloudSync] Pulled ${updatedCount} keys successfully from cloud for user ${userId}`);
    if (updatedCount > 0 && showToast) {
      showToast('All learning data synchronized from Cloud.');
    }
    return true;
  } catch (error) {
    console.error('[CloudSync] Failed to pull data from Cloud:', error);
    try {
      handleFirestoreError(error, OperationType.GET, `users/${userId}/syncData`);
    } catch (e) {
      // Ignored
    }
    return false;
  }
}

/**
 * Pushes any existing guest local keys into the cloud when a student signs up or connects their account.
 */
export async function pushGuestToCloud(userId: string): Promise<void> {
  try {
    // List of known vidypath_ keys we wish to migrate from the guest session
    const syncKeys = [
      'vidypath_chapter_mast_notes',
      'vidypath_ft_time_val',
      'vidypath_ft_day_val',
      'vidypath_ft_active_chapters_val',
      'vidypath_ft_completed_chapters_val',
      'vidypath_chapter_mast_v1',
      'vidypath_rev_auto_reschedule',
      'vidypath_rev_rescheduled_items',
      'vidypath_rev_completed_days',
      'vidypath_mistakes_v1',
      'vidypath_progress_v4',
      'vidypath_custom_pyqs_v1',
      'vidypath_notebook_sources',
      'vidypath_datesheet_v1',
      'vidypath_preferred_teachers_v2',
      'vidypath_completed_tasks_today'
    ];

    const batch = writeBatch(db);
    let count = 0;

    for (const key of syncKeys) {
      const guestKey = `guest_${key}`;
      const guestVal = localStorage.getItem(guestKey);
      if (guestVal) {
        // Prepare target cloud doc
        const docRef = doc(db, 'users', userId, 'syncData', key);
        batch.set(docRef, {
          value: guestVal,
          updatedAt: serverTimestamp()
        });

        // Also copy locally into the scoped user storage namespace
        const userKey = `${userId}_${key}`;
        localStorage.setItem(userKey, guestVal);
        count++;
      }
    }

    if (count > 0) {
      await batch.commit();
      console.log(`[CloudSync] Migrated ${count} keys from guest to user account ${userId}`);
    }
  } catch (error) {
    console.error('[CloudSync] Failed to push guest keys to cloud:', error);
  }
}
