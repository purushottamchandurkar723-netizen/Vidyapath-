/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export async function getAIResponse(prompt: string): Promise<string> {
  const finalPrompt = `${prompt}

---
CRITICAL STYLE & FORMATTING RULES:
1. NEVER use the dollar sign '$' or '$$' (LaTeX delimiters) to wrap math/science symbols, equations, formulas, units, chemical formulas, or standard numbers (e.g., do NOT output concepts like "$30\\text{ cm}$", "$H_2O$", or "$1/f$"). Instead, output standard plain-text expressions or normal unicode representations (e.g., "30 cm", "H₂O", "1/f = 1/v - 1/u").
2. DO NOT wrap JSON option text strings, answers, headings, titles, keywords, or short definitions inside unnecessary markdown bold stars '**' or bullet asterisks. Keep the textual elements clean, standard, and elegant, as the client UI is already responsible for layout decorations.`;

  // Always use our secure backend endpoint
  try {
    const response = await fetch('/api/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ prompt: finalPrompt }),
    });

    if (!response.ok) {
      const data = await response.json().catch(() => ({}));
      throw new Error(data.error || `Server error: ${response.status}`);
    }

    const data = await response.json();
    return data.text || '';
  } catch (error: any) {
    console.error('AI Request failed:', error.message || error);
    throw new Error(error.message || 'AI request failed. Please check your internet connection or API keys.');
  }
}

export async function fetchFlashcardsFromAI(subjectLabel: string, chapterName: string): Promise<any[]> {
  const langInstr = getLanguageInstruction(subjectLabel);
  const prompt = `You are an expert CBSE Class 10 teacher. Generate 10 high-quality flashcards for the following subject and chapter.
Subject: ${subjectLabel}
Chapter: ${chapterName}
${langInstr}

Requirements:
1. Front: A concise question, term, or concept.
2. Back: A clear, accurate, and high-yield explanation or definition.
3. Focus on "must-know" facts, definitions, formulas, and concepts likely to appear in board exams.
4. Keep content punchy and easy to memorize.

Return ONLY a valid JSON array of objects:
[{"front":"...","back":"..."}]`;

  try {
    const raw = await getAIResponse(prompt);
    const jt = raw.replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/\s*```\s*$/i, '').trim();
    const s = jt.indexOf('[');
    const e = jt.lastIndexOf(']');
    if (s === -1 || e === -1) throw new Error('Invalid JSON format from AI');
    return JSON.parse(jt.slice(s, e + 1));
  } catch (error) {
    console.error('Failed to fetch flashcards:', error);
    throw error;
  }
}

function getLanguageInstruction(subjectLabel: string): string {
  const label = subjectLabel.toLowerCase();
  if (label.includes('hindi')) return "\nIMPORTANT: The subject is Hindi. Please generate all content (questions, options, answers, etc.) strictly in Hindi language (Devanagari script).";
  if (label.includes('marathi')) return "\nIMPORTANT: The subject is Marathi. Please generate all content (questions, options, answers, etc.) strictly in Marathi language (Devanagari script).";
  return "";
}

export async function fetchQuestionsFromAI(subjectLabel: string, chapterName: string, topic?: string): Promise<any[]> {
  const topicStr = topic ? `specifically from the sub-topic "${topic}"` : '';
  const langInstr = getLanguageInstruction(subjectLabel);
  const prompt = `You are a CBSE Class 10 teacher. Generate 5 MCQ questions from the given subject, chapter, and topic. Make them board exam level.
Subject: ${subjectLabel}
Chapter: ${chapterName}
${topicStr}
${langInstr}

Return ONLY a valid JSON array with no extra text:
[{"question":"...","options":["A","B","C","D"],"answer":"exact correct option text"}]`;

  try {
    const raw = await getAIResponse(prompt);
    const jt = raw.replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/\s*```\s*$/i, '').trim();
    const s = jt.indexOf('[');
    const e = jt.lastIndexOf(']');
    if (s === -1 || e === -1) throw new Error('Invalid JSON format from AI');
    return JSON.parse(jt.slice(s, e + 1));
  } catch (error) {
    console.error('Failed to fetch questions:', error);
    throw error;
  }
}

export async function fetchTopicsForChapter(subjectLabel: string, chapterName: string): Promise<string[]> {
  const cacheKey = `topics_${subjectLabel}_${chapterName}`.replace(/\s+/g, '_');
  const cached = localStorage.getItem(cacheKey);
  if (cached) return JSON.parse(cached);

  const langInstr = getLanguageInstruction(subjectLabel);
  const prompt = `List the 4-5 main sub-topics for CBSE Class 10 ${subjectLabel} chapter: "${chapterName}". 
Keep names short and specific to the syllabus.
${langInstr}
Return ONLY a valid JSON array of strings: ["Topic 1", "Topic 2", ...]`;

  try {
    const raw = await getAIResponse(prompt);
    const jt = raw.replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/\s*```\s*$/i, '').trim();
    const topics = JSON.parse(jt);
    localStorage.setItem(cacheKey, JSON.stringify(topics));
    return topics;
  } catch (error) {
    console.error('Failed to fetch topics:', error);
    return ["Basic Concepts", "Important Definitions", "Key Laws", "Numerical Practice"];
  }
}

export async function fetchDiagramQuestions(subjectLabel: string, chapterName: string): Promise<any[]> {
  const langInstr = getLanguageInstruction(subjectLabel);
  const prompt = `Generate 5 diagram-based practice questions for CBSE Class 10 ${subjectLabel}, chapter: ${chapterName}.
Rules:
- Focus ONLY on important diagrams/graphs/maps from this chapter.
- Questions must be clear and exam-oriented.
${langInstr}

Include 5 specific types:
1. Draw-based (Instruction on what to draw)
2. Labeling (Describe a diagram and ask to label parts)
3. Explanation (What a specific diagram/graph shows)
4. Application (Real-life use of the diagram's concept)
5. Common mistake (Common errors students make while drawing/interpreting it)

Return STRICT JSON:
{"diagram_questions":[{"type":"draw|label|explain|application|mistake","question":"...","answer":"..."}]}`;

  const raw = await getAIResponse(prompt);
  const jt = raw.replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/\s*```\s*$/i, '').trim();
  const data = JSON.parse(jt);
  return data.diagram_questions || [];
}

export async function evaluateDiagramImage(image: string, question: string, expectedAnswer: string): Promise<string> {
  const prompt = `You are a CBSE board examiner. Evaluate the student's diagram/work relative to this question: "${question}".
Expected criteria/answer: ${expectedAnswer}

Check for:
1. Accuracy of the drawing/labeling.
2. Neatness and technical correctness.
3. Common mistakes.

Provide a short, constructive feedback (3-4 sentences) and give a score out of 5.
Student's work is provided as an image.`;

  return await getAIResponseWithImage(prompt, image);
}

async function getAIResponseWithImage(prompt: string, base64Image: string): Promise<string> {
  try {
    const response = await fetch('/api/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ prompt, image: base64Image }),
    });

    if (!response.ok) {
      const errData = await response.json().catch(() => ({}));
      throw new Error(errData.error || `Server error: ${response.status}`);
    }

    const data = await response.json();
    return data.text || '';
  } catch (error) {
    console.error("AI Image evaluation failed:", error);
    throw error;
  }
}

export async function adjustStudyPlan(currentPlan: any, userRequest: string, subjectsList: string[]): Promise<any> {
  const prompt = `You are a smart Personal Study Assistant. You have full access to modify the student's study plan.
Current Plan: ${JSON.stringify(currentPlan)}
Available Subjects: ${subjectsList.join(', ')}
User's Request: "${userRequest}"

Goal: 
1. Modify the current study plan according to the user's demand.
2. If the user wants to reschedule (e.g., "I'm busy today", "Move Maths to tomorrow"), intelligently shift tasks between 'today_plan' and 'roadmap' without increasing the long-term workload too much.
3. If they want to add/remove focus, update the subjects in the plan using the available subjects.
4. Ensure the modified plan still follows the student's proficiency level constraints.
5. Return the FULL updated plan in the same JSON structure.

Return STRICT JSON:
{
  "roadmap": [...],
  "today_plan": {...}
}`;

  const raw = await getAIResponse(prompt);
  const jt = raw.replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/\s*```\s*$/i, '').trim();
  const s = jt.indexOf('{');
  const e = jt.lastIndexOf('}');
  if (s === -1 || e === -1) throw new Error('Invalid JSON format from AI');
  return JSON.parse(jt.slice(s, e + 1));
}

export async function fetchAdaptiveStudyPlan(timeMinutes: number, level: string, subjectsList: string[]): Promise<any> {
  const prompt = `Generate a smart adaptive study plan for a CBSE Class 10 student.
Available Daily Time: ${timeMinutes} minutes
Performance Level: ${level}
Focus Subjects: ${subjectsList.join(', ')}

Requirements:
1. Merge roadmap and daily planner into ONE system.
2. Break chapters into 5–7 small topics per chapter.
3. Plan learning topic-wise across multiple days.
4. If level is 'weak': Focus on 1-2 subjects, more revision, and mistake tracking.
5. If level is 'average': Balanced learning + practice (2 subjects).
6. If level is 'strong': 2-3 subjects, harder topics + tests.
7. Include a personalized recommended YouTube video watch task for EACH subject's chapter planned today. The video task MUST specify which topic/stamp to watch until so they don't get overwhelmed and understand it first.

Return STRICT JSON:
{
  "roadmap": [
    {
      "subject": "Maths",
      "chapter": "Trigonometry",
      "start_day": 1,
      "end_day": 4,
      "total_topics": 6,
      "completed_topics": 2
    }
  ],
  "today_plan": {
    "mode": "${level}",
    "subjects": [
      {
        "name": "Maths",
        "chapter": "Trigonometry",
        "topics": ["Trigonometric Ratios", "Specific Angles"],
        "tasks": {
          "notes": "Read NCERT Page 170-175 and solve Example 1-4",
          "trick": "Pandit Badri Prasad / Har Har Bole for SOHCAHTOA",
          "practice": { "mcq": 2, "short": 1 },
          "diagram": "yes",
          "revision": "Draw the value table for 0, 30, 45, 60, 90"
        },
        "video": {
          "title": "Trigonometry CBSE Class 10 Full explanation by Dear Sir",
          "search_query": "cbse class 10 trigonometry full concept dear sir or pw",
          "watch_until": "Trigonometric Ratios of Specific Angles (till 42:15 timestamp)"
        }
      }
    ]
  }
}`;

  const raw = await getAIResponse(prompt);
  const jt = raw.replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/\s*```\s*$/i, '').trim();
  return JSON.parse(jt);
}

export async function fetchSmartStudyPlan(subjectLabel: string, chapterName: string, level: string, timeMinutes: number): Promise<any> {
  const langInstr = getLanguageInstruction(subjectLabel);
  const prompt = `Generate a smart daily study plan for a CBSE Class 10 student.
Subject: ${subjectLabel}
Chapter: ${chapterName}
Student Level: ${level}
Available Time: ${timeMinutes} minutes

Goal:
- Do NOT assign full chapter in one day.
- Break chapter into 2-3 small concepts only.
- Give only what can be completed today comfortably.
${langInstr}

Return STRICT JSON:
{
  "topics": ["Topic 1", "Topic 2"],
  "notes_task": "Concise reading task description",
  "tricks": "Key memory trick/shortcut",
  "practice": { "mcq": 3, "short": 2 },
  "diagram": "yes/no",
  "revision": "End of day revision task",
  "mistake_focus": "Specific area to watch out for"
}`;

  const raw = await getAIResponse(prompt);
  const jt = raw.replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/\s*```\s*$/i, '').trim();
  return JSON.parse(jt);
}

export async function fetchBoardQuestions(type: string, subjectLabel: string, weakChapters: string[], count: number, marks: number): Promise<any[]> {
  const weakStr = weakChapters.length > 0 ? `Prioritise these weak topics: ${weakChapters.slice(0, 3).join(', ')}.` : '';
  const langInstr = getLanguageInstruction(subjectLabel);
  
  // Cache check - simple per-day, per-subject, per-type cache
  const today = new Date().toISOString().split('T')[0];
  const cacheKey = `boardqs_${today}_${subjectLabel}_${type}_${count}_${marks}`.replace(/\s+/g, '_');
  const cached = localStorage.getItem(cacheKey);
  if (cached) return JSON.parse(cached);

  let typeInstructions = '';
  if (type === 'mcq') typeInstructions = `Generate ${count} MCQ questions (board exam level). Each must have 4 options and one correct answer.`;
  else if (type === 'short') typeInstructions = `Generate ${count} short answer questions (${marks} marks each). Include at least 1 numerical.`;
  else if (type === 'long') typeInstructions = `Generate ${count} long answer questions (${marks} marks each).`;
  else if (type === 'case') typeInstructions = `Generate ${count} case-based questions with a short passage followed by 3 sub-questions.`;
  else if (type === 'comp') typeInstructions = `Generate ${count} competency-based questions (real-life application). ${marks} marks each.`;

  const prompt = `You are a CBSE Class 10 board exam paper setter for ${subjectLabel}.
${typeInstructions}
${weakStr}
${langInstr}
Be concise. Focus on high-yield questions.
Return ONLY a JSON array. No markdown, no extra text.
For MCQ: [{"q":"question","opts":["A","B","C","D"],"ans":"correct option text","marks":${marks}}]
For short/long/case/comp: [{"q":"question","ans_hint":"model answer hint","marks":${marks}}]`;

  try {
    const raw = await getAIResponse(prompt);
    const jt = raw.replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/\s*```\s*$/i, '').trim();
    const s = jt.indexOf('[');
    const e = jt.lastIndexOf(']');
    if (s === -1 || e === -1) throw new Error('Invalid JSON format from AI');
    const data = JSON.parse(jt.slice(s, e + 1)).slice(0, count);
    localStorage.setItem(cacheKey, JSON.stringify(data));
    return data;
  } catch (error) {
    console.error('Failed to fetch board questions:', error);
    throw error;
  }
}

export async function fetchInteractiveDiagrams(subjectLabel: string, chapterName: string): Promise<any[]> {
  const langInstr = getLanguageInstruction(subjectLabel);
  const prompt = `Generate interactive diagram data for CBSE Class 10 ${subjectLabel}, chapter: ${chapterName}.
Rules:
- Identify 2-3 most important diagrams/concepts that are visual in nature (e.g., Human Eye, Heart, Electric Motor, Periodic Table section, Maps).
- For each diagram, provide a title, a brief overview, and 5-6 interactive "parts" or "hotspots".
- Each "part" must have a precise label and a short scientific/social-study explanation.
- Assign (x, y) coordinates for each part on a 100x100 scale to place pins.
${langInstr}

Return STRICT JSON:
{
  "diagrams": [
    {
      "title": "Diagram Title",
      "overview": "Overview of what this diagram explains",
      "baseIcon": "heart | eye | circuit | leaf | brain | box",
      "parts": [
        { "label": "Part Name", "description": "Interactive explanation", "x": 20, "y": 30 }
      ]
    }
  ]
}`;

  try {
    const raw = await getAIResponse(prompt);
    const jt = raw.replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/\s*```\s*$/i, '').trim();
    const data = JSON.parse(jt);
    return data.diagrams || [];
  } catch (error) {
    console.error('Failed to fetch interactive diagrams:', error);
    return [];
  }
}

export async function fetchQBankHint(subjectLabel: string, chapterName: string, question: string): Promise<string> {
  const langInstr = getLanguageInstruction(subjectLabel);
  const prompt = `You are a friendly CBSE Class 10 tutor. Provide a short, elegant, indirect hint or clue for this question without revealing the actual core answer or formula values directly.
  
  Subject: ${subjectLabel}
  Chapter: ${chapterName}
  Question: "${question}"
  ${langInstr}
  
  Keep the response extremely short (1 sentence), clear, and student-focused. Do NOT include markdown code blocks.`;
  
  try {
    const raw = await getAIResponse(prompt);
    return raw.trim();
  } catch (error) {
    console.error('Failed to fetch hint:', error);
    return "Think about the core formula or mechanism related to this topic!";
  }
}

export async function evaluateQBankAnswer(
  subjectLabel: string,
  chapterName: string,
  question: string,
  modelAnswer: string,
  userAnswer: string
): Promise<{ feedback: string; score: number; isCorrect: boolean }> {
  const langInstr = getLanguageInstruction(subjectLabel);
  const prompt = `You are an expert CBSE Class 10 evaluator grading a student's answer.
  
  Subject: ${subjectLabel}
  Chapter: ${chapterName}
  Question: "${question}"
  Model Answer: "${modelAnswer}"
  Student's Answer: "${userAnswer}"
  ${langInstr}
  
  Grade the student's answer constructively in the same language. Detect key terms and logical match.
  Return a STRICT JSON object ONLY, with NO extra text or markdown formatting of the JSON block itself.
  {
    "feedback": "A warm, 1-2 sentence grading comment explaining what is correct or what was missed to secure full marks.",
    "score": <number from 0 to 100 based on accuracy>,
    "isCorrect": <boolean, true if they got the core concept mostly right (score >= 60)>
  }`;

  try {
    const raw = await getAIResponse(prompt);
    const jt = raw.replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/\s*```\s*$/i, '').trim();
    return JSON.parse(jt);
  } catch (error) {
    console.error('Failed to evaluate answer:', error);
    const uLower = userAnswer.toLowerCase();
    const mLower = modelAnswer.toLowerCase();
    const matchedCount = mLower.split(' ').filter(word => word.length > 3 && uLower.includes(word)).length;
    const score = Math.min(100, Math.round((matchedCount / (mLower.split(' ').length || 1)) * 150));
    return {
      feedback: "Answer recorded! Self-check against the Model Answer.",
      score: score > 0 ? score : 50,
      isCorrect: score >= 40
    };
  }
}

export async function evaluateQBankAnswerWithImage(
  subjectLabel: string,
  chapterName: string,
  question: string,
  modelAnswer: string,
  userAnswer: string,
  base64Image: string | null
): Promise<{ feedback: string; score: number; isCorrect: boolean }> {
  if (!base64Image) {
    return evaluateQBankAnswer(subjectLabel, chapterName, question, modelAnswer, userAnswer);
  }

  try {
    const response = await fetch('/api/check-answer-image', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        question,
        standardAnswer: modelAnswer,
        draftText: userAnswer,
        image: base64Image
      }),
    });

    if (!response.ok) {
      const errData = await response.json().catch(() => ({}));
      throw new Error(errData.error || `Server error: ${response.status}`);
    }

    return await response.json();
  } catch (error: any) {
    console.warn('Failed to evaluate image answer on server:', error.message || error);
    return {
      feedback: `⚠️ AI Image Evaluation Failed: ${error.message || "Ensure your server/API key is configured correctly."}`,
      score: 0,
      isCorrect: false
    };
  }
}

export async function fetchQBankSimilarQuestion(
  subjectLabel: string,
  chapterName: string,
  type: string,
  originalQuestion: string
): Promise<any> {
  const langInstr = getLanguageInstruction(subjectLabel);
  const prompt = `You are a CBSE Class 10 expert teacher. Generate exactly ONE brand-new, similar practice question of type "${type}" checking the identical skill but using different numbers/values or contexts.
  
  Original Question: "${originalQuestion}"
  Subject: ${subjectLabel}
  Chapter: ${chapterName}
  ${langInstr}
  
  Return a STRICT JSON object only. No intro or outro text.
  Expected JSON schemes:
  If type is mcq:
  {"question": "...", "options": ["A","B","C","D"], "answer": "correct_option_letter_like_A_or_B_or_C_or_D"}
  
  If type is assertion_reason:
  {"assertion": "...", "reason": "...", "answer": "Option A/B/C/D with brief why"}
  
  If type is match_following:
  {"pairs": [{"left": "...", "right": "..."}], "answer": "..."}
  
  Any other type (short, long, numerical, case_study / case_based, hots, writing etc):
  {"question": "...", "answer": "..."}`;

  try {
    const raw = await getAIResponse(prompt);
    const jt = raw.replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/\s*```\s*$/i, '').trim();
    return JSON.parse(jt);
  } catch (error) {
    console.error('Failed to fetch similar question:', error);
    return null;
  }
}

export async function fetchFormulasForChapter(subjectLabel: string, chapterName: string): Promise<any[]> {
  const cacheKey = `formulas_${subjectLabel}_${chapterName}`.replace(/\s+/g, '_');
  const cached = localStorage.getItem(cacheKey);
  if (cached) return JSON.parse(cached);

  const langInstr = getLanguageInstruction(subjectLabel);
  const prompt = `You are an expert CBSE Class 10 teacher. Generate a comprehensive "Formula Sheet" or "Key Principles List" for the given subject and chapter.
Subject: ${subjectLabel}
Chapter: ${chapterName}
${langInstr}

Requirements:
1. Identify 5-8 central mathematical formulas, chemical equations, scientific laws, biological structures, or core principles for this chapter.
2. For subjects with math/science (Maths, Physics, Chemistry): Provide actual mathematical formulas (using clean LaTeX-style plain text, e.g., "R = \\rho \\frac{l}{A}") or balanced chemical equations.
3. For other subjects (Biology, Social Science, English, etc.): Provide "Key Principles", "Theorems", "Golden Rules", "Timeline Laws", or "Grammar Rules" in a structurally identical format.
4. Each item must have:
   - "name": The name of the formula or principle (e.g., "Lens Formula", "Ohm's Law", "First Law of Thermodynamics").
   - "expression": The symbolic equation, representation, or main core sentence (e.g., "1/f = 1/v - 1/u" or "V = I * R").
   - "symbols": An array of objects explaining the symbols, terms, or key terms involved. Example: [{"symbol": "f", "meaning": "Focal length", "unit": "meters (m)"}].
   - "description": A concise, clear definition of the formula/principle.
   - "application": A specific practical scenario, trick, or common board exam problem where this is applied.

Return ONLY a valid JSON object of the structure:
{
  "formulas": [
    {
      "name": "Lens Formula",
      "expression": "1/f = 1/v - 1/u",
      "symbols": [
        {"symbol": "f", "meaning": "Focal length", "unit": "meters"},
        {"symbol": "v", "meaning": "Image distance", "unit": "meters"},
        {"symbol": "u", "meaning": "Object distance", "unit": "meters"}
      ],
      "description": "Relates focal length, object distance, and image distance for a spherical lens.",
      "application": "Used to find image position or focal length of a concave/convex lens using Cartesian sign convention."
    }
  ]
}
`;

  try {
    const raw = await getAIResponse(prompt);
    const jt = raw.replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/\s*```\s*$/i, '').trim();
    const s = jt.indexOf('{');
    const e = jt.lastIndexOf('}');
    if (s === -1 || e === -1) throw new Error('Invalid JSON format from AI');
    const parsed = JSON.parse(jt.slice(s, e + 1));
    const formulas = parsed.formulas || [];
    localStorage.setItem(cacheKey, JSON.stringify(formulas));
    return formulas;
  } catch (error) {
    console.error('Failed to fetch formulas:', error);
    return [];
  }
}

export async function fetchStudyGuideForChapter(subjectLabel: string, chapterName: string): Promise<any> {
  const cacheKey = `studyguide_${subjectLabel}_${chapterName}`.replace(/\s+/g, '_');
  const cached = localStorage.getItem(cacheKey);
  if (cached) return JSON.parse(cached);

  const langInstr = getLanguageInstruction(subjectLabel);
  const prompt = `You are an expert CBSE Class 10 teacher. Generate a comprehensive "Study Guide" for the given subject and chapter.
Subject: ${subjectLabel}
Chapter: ${chapterName}
${langInstr}

Requirements:
1. Provide a detailed overview of the chapter with bold headings.
2. Identify 3-4 Key Concepts, each with a name, importance level, and detailed explanation using bold headings, styled bullets, and rich markdown formatting.
3. Provide 2-3 Mnemonics, Memory Hacks, or Tricks specifically crafted to remember key steps, processes, list of order, or values from this chapter. (Include a title, the phrase, and a structured breakdown).
4. Include 2-3 High-Yield Board Syllabus Tips (or high-scoring advice/avoid-common-mistakes guidance).

Return ONLY a valid JSON object of structural schema:
{
  "overview": "**Markdown bold-heading structured overview summary of the chapter.**",
  "keyConcepts": [
    {
      "conceptName": "Concept Name",
      "importance": "High / Critical",
      "explanation": "### Core Heading\\nDetailed explanation with standard markdown syntax. Incorportate bullet points, bold terms, etc."
    }
  ],
  "mnemonics": [
    {
      "title": "Mnemonic Title",
      "phrase": "Dynamic Mnemonic Phrase",
      "breakdown": "* **Letter/Part**: Explanation of what it stands for or maps to"
    }
  ],
  "syllabiTips": [
    "**Tip 1**: Markdown styled high-scoring tip...",
    "**Tip 2**: Another syllabus tip..."
  ]
}
`;

  try {
    const raw = await getAIResponse(prompt);
    const jt = raw.replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/\s*```\s*$/i, '').trim();
    const s = jt.indexOf('{');
    const e = jt.lastIndexOf('}');
    if (s === -1 || e === -1) throw new Error('Invalid JSON format from AI');
    const parsed = JSON.parse(jt.slice(s, e + 1));
    localStorage.setItem(cacheKey, JSON.stringify(parsed));
    return parsed;
  } catch (error) {
    console.error('Failed to fetch study guide:', error);
    return null;
  }
}

