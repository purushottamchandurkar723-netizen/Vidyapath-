export interface CBSEUpdate {
  title: string;
  isNew: boolean;
  date?: string;
  link?: string;
}

export async function fetchLiveCBSEUpdates(): Promise<CBSEUpdate[]> {
  try {
    const response = await fetch('/api/cbse-news');
    if (!response.ok) {
      throw new Error(`Failed to fetch CBSE news from server: ${response.status}`);
    }
    return await response.json();
  } catch (error: any) {
    console.warn("Failed to fetch live CBSE updates (using local/offline default news instead):", error.message || error);
    
    // Static offline CBSE updates as fallback
    const currentMonth = new Date().getMonth();
    const currentYear = new Date().getFullYear();

    if (currentMonth >= 4 && currentMonth <= 5) { // May-June
      return [
        { title: `CBSE Class 10 Results ${currentYear} - Official Announcement`, isNew: true },
        { title: `Marksheet DigiLocker Access for Batch ${currentYear - 1}-27`, isNew: true },
        { title: `Improvement Exam Form Submission Guidelines`, isNew: false }
      ];
    } else if (currentMonth >= 6 && currentMonth <= 8) { // July-Sept
      return [
        { title: `2026-27 Syllabus & Sample Question Papers Out`, isNew: true },
        { title: `CBSE Assessment Framework 2027 Updated`, isNew: true },
        { title: `LOI for Center Superintendent Appointment`, isNew: false }
      ];
    } else if (currentMonth >= 9 && currentMonth <= 11) { // Oct-Dec
      return [
        { title: `CBSE Class 10 Board Exam 2027 Date Sheet Update`, isNew: true },
        { title: `Practical Exam Dates for Regular Students Out`, isNew: true },
        { title: `LOC Data Verification for 2027 Exams`, isNew: false }
      ];
    } else { // Jan-April
      return [
        { title: `CBSE Admit Card Download for Board Exams 2027`, isNew: true },
        { title: `Last Minute Board Prep Tips from Toppers`, isNew: true },
        { title: `Strict Guidelines for Unfair Means (UFM) in 2027`, isNew: false }
      ];
    }
  }
}
