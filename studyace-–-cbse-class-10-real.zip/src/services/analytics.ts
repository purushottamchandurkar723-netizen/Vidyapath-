/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { loadItem, saveItem } from '../lib/utils';
import { auth } from '../lib/firebase';

export interface AnalyticsEvent {
  id: string;
  userId: string;
  type: 'visit' | 'chapter_completed' | 'video_watched' | 'quiz_attempt' | 'qbank_attempt' | 'revision_completed' | 'mistake_recovered';
  feature: string;
  subjectKey?: string;
  chapterName?: string;
  timestamp: string; // ISO String
  payload?: any;
}

/**
 * Record a student learning tracking event asynchronously in the background.
 * Uses localStorage with automatic debounced Firebase Cloud sync for zero performance overhead.
 */
export function recordEvent(
  type: AnalyticsEvent['type'],
  feature: string,
  subjectKey?: string,
  chapterName?: string,
  payload?: any
): void {
  try {
    const list = loadItem<AnalyticsEvent[]>('vidypath_analytics_v1', []);
    const userId = auth?.currentUser?.uid || 'guest';
    const newEvent: AnalyticsEvent = {
      id: `${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      userId,
      type,
      feature,
      subjectKey,
      chapterName,
      timestamp: new Date().toISOString(),
      payload
    };

    // Keep events array within bounds of 500 records to avoid localStorage or state footprint exhaust
    const updated = [newEvent, ...list].slice(0, 500);
    saveItem('vidypath_analytics_v1', updated);
  } catch (error) {
    console.error('[Analytics] Failed to record event:', error);
  }
}

/**
 * Helper to record page views or active session ticks
 */
export function trackVisit(featureName: string): void {
  recordEvent('visit', featureName);
}

/**
 * Returns true if the logged-in student has administrator/moderator email credentials
 */
export function isUserAdmin(): boolean {
  const email = auth?.currentUser?.email;
  return email ? ['purushottamchandurkar723@gmail.com', 'prasadchandurkar5@gmail.com', 'dustf154@gmail.com'].includes(email) : false;
}

/**
 * Parse real metrics recorded in the user's active/offline localStorage scope.
 */
export function getRealAnalytics() {
  const events = loadItem<AnalyticsEvent[]>('vidypath_analytics_v1', []);
  
  // Aggregate stats
  const visits = events.filter(e => e.type === 'visit');
  const chapterCompletions = events.filter(e => e.type === 'chapter_completed');
  const videosWatched = events.filter(e => e.type === 'video_watched');
  const quizAttempts = events.filter(e => e.type === 'quiz_attempt');
  const qbankAttempts = events.filter(e => e.type === 'qbank_attempt');
  const revisionsCompleted = events.filter(e => e.type === 'revision_completed');
  const mistakesRecovered = events.filter(e => e.type === 'mistake_recovered');

  // Count active stats
  const activeDays = new Set(events.map(e => e.timestamp.split('T')[0]));
  
  // Feature usage ranking
  const featureCounts: Record<string, number> = {};
  events.forEach(e => {
    featureCounts[e.feature] = (featureCounts[e.feature] || 0) + 1;
  });
  
  const mostUsedFeatures = Object.entries(featureCounts)
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => b.count - a.count);

  return {
    eventsCount: events.length,
    dau: activeDays.size || 1,
    wau: activeDays.size ? Math.min(7, activeDays.size) : 1,
    mau: activeDays.size ? Math.min(30, activeDays.size) : 1,
    chapterCompletions: chapterCompletions.length,
    videosWatched: videosWatched.length,
    quizAttempts: quizAttempts.length,
    qbankAttempts: qbankAttempts.length,
    revisionsCompleted: revisionsCompleted.length,
    mistakesRecovered: mistakesRecovered.length,
    mostUsedFeatures,
    events
  };
}

/**
 * Seed extremely rich, representative simulated cluster analytics data for the VidyPath platform 
 * representing a cohort of 1,250 registered board candidates to showcase responsive, beautiful dashboards.
 */
export function getSimulatedAnalytics() {
  // 1. DAU Trend (Last 30 Days)
  const dauTrend = [];
  const baseDate = new Date();
  baseDate.setDate(baseDate.getDate() - 30);
  
  for (let i = 0; i <= 30; i++) {
    const d = new Date(baseDate);
    d.setDate(d.getDate() + i);
    const dayOfWeek = d.getDay();
    
    // School students study more on weekdays, key spikes before pre-boards
    const base = dayOfWeek === 0 ? 280 : dayOfWeek === 6 ? 390 : 490;
    const noise = Math.floor(Math.random() * 50) - 25;
    const dau = base + noise + (i * 2); // growth accentuation
    const wau = Math.round(dau * 2.1 + 80);
    const mau = 1250 - Math.floor(Math.random() * 80);

    dauTrend.push({
      date: d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }),
      dau,
      wau,
      mau,
    });
  }

  // 2. Feature Engagement Share
  const featureUsage = [
    { name: 'AI Tutor Desk', count: 1850, value: 45, color: '#f97316' },
    { name: 'Smart Practice Book', count: 1240, value: 30, color: '#3b82f6' },
    { name: 'Spaced Revision Center', count: 820, value: 15, color: '#10b981' },
    { name: 'Adaptive Time-Sheet Planner', count: 410, value: 7, color: '#a855f7' },
    { name: 'Past Board Papers', count: 180, value: 3, color: '#ef4444' },
  ];

  // 3. Weakest Science & Math Topics inside CBSE Class 8/9/10 syllabus
  const weakestChapters = [
    { subject: 'Science', chapter: 'Carbon & its Compounds', avgMastery: 48, studentsStruggling: 640 },
    { subject: 'Mathematics', chapter: 'Quadratic Equations', avgMastery: 52, studentsStruggling: 512 },
    { subject: 'Science', chapter: 'Light Reflection & Refraction', avgMastery: 54, studentsStruggling: 430 },
    { subject: 'Mathematics', chapter: 'Introduction to Trigonometry', avgMastery: 59, studentsStruggling: 388 },
    { subject: 'Social Science', chapter: 'Nationalism in India', avgMastery: 65, studentsStruggling: 245 },
  ];

  // 4. Cohort Retention Heatmap Grid (Weeks Active)
  const retentionCohorts = [
    { cohort: '6 Weeks Ago', size: 180, w1: 100, w2: 88, w3: 81, w4: 76, w5: 69, w6: 64 },
    { cohort: '5 Weeks Ago', size: 210, w1: 100, w2: 91, w3: 84, w4: 79, w5: 72, w6: '-' },
    { cohort: '4 Weeks Ago', size: 195, w1: 100, w2: 89, w3: 82, w4: 77, w5: '-', w6: '-' },
    { cohort: '3 Weeks Ago', size: 220, w1: 100, w2: 92, w3: 85, w4: '-', w5: '-', w6: '-' },
    { cohort: '2 Weeks Ago', size: 240, w1: 100, w2: 90, w3: '-', w4: '-', w5: '-', w6: '-' },
    { cohort: 'Last Week', size: 205, w1: 100, w2: '-', w3: '-', w4: '-', w5: '-', w6: '-' },
  ];

  // 5. Subject Mastery Distribution levels across registered cluster
  const masterySpread = [
    { range: 'Superior (80-100%)', maths: 380, science: 420, sst: 510, english: 640 },
    { range: 'Proficient (60-80%)', maths: 490, science: 480, sst: 420, english: 410 },
    { range: 'Developing (40-60%)', maths: 260, science: 230, sst: 210, english: 150 },
    { range: 'Struggling (0-40%)', maths: 120, science: 120, sst: 110, english: 50 },
  ];

  return {
    trend: dauTrend,
    features: featureUsage,
    weakest: weakestChapters,
    retention: retentionCohorts,
    mastery: masterySpread,
    summary: {
      registeredCount: 1250,
      activeToday: dauTrend[dauTrend.length - 1].dau,
      activeThisWeek: dauTrend[dauTrend.length - 1].wau,
      activeThisMonth: 1142,
      totalQuizzesAttempted: 14850,
      chapterCompletions: 3410,
      videosWatched: 8960,
      mistakesResolved: 4120
    }
  };
}
