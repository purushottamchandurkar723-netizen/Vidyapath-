/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { collection, addDoc, getDocs, deleteDoc, doc, query, where } from 'firebase/firestore';
import { db, auth } from '../lib/firebase';
import { loadItem, saveItem } from '../lib/utils';

export interface RealPYQ {
  id: string;
  subjectKey: string;
  chapterName: string;
  question: string;
  answer: string;
  year: number;
  marks: number;
  type: 'MCQ' | 'Short Answer' | 'Long Answer' | 'Competency';
  source?: string;
  options?: string[];
  addedByUser?: boolean;
}

// Pre-seeded, authentic CBSE Class 10 Board Exam Questions
const PRESEEDED_PYQS: RealPYQ[] = [
  {
    id: 's_chem_1',
    subjectKey: 'science',
    chapterName: 'Chemical Reactions and Equations',
    question: 'Write the balanced chemical equation for the following chemical reaction: Hydrogen sulphide gas burns in air to give water and sulphur dioxide.',
    answer: '2H₂S(g) + 3O₂(g) → 2H₂O(l) + 2SO₂(g)\n\nIn this reaction, Hydrogen sulphide (H₂S) displays oxidation as it gains oxygen to form water and sulphur dioxide, while Oxygen (O₂) acts as the oxidising agent.',
    year: 2020,
    marks: 2,
    type: 'Short Answer',
    source: 'CBSE Delhi Set-1'
  },
  {
    id: 's_chem_2',
    subjectKey: 'science',
    chapterName: 'Chemical Reactions and Equations',
    question: 'Why does the colour of copper sulphate solution change when an iron nail is dipped in it? Write the appropriate chemical equation for the reaction.',
    answer: 'Fe(s) + CuSO₄(aq) [Blue] → FeSO₄(aq) [Light Green] + Cu(s) [Brown]\n\nWhen an iron nail is dipped in copper sulphate solution, iron displaces copper from copper sulphate solution because iron is more reactive than copper (a classic single displacement reaction). The blue colour of copper sulphate fades and turns light green due to the formation of ferrous sulphate (FeSO₄), and red-brown copper metal is deposited on the iron nail.',
    year: 2023,
    marks: 2,
    type: 'Short Answer',
    source: 'CBSE Board Paper'
  },
  {
    id: 's_chem_3',
    subjectKey: 'science',
    chapterName: 'Chemical Reactions and Equations',
    question: 'A metal compound \'A\' reacts with dilute hydrochloric acid to produce effervescence. The gas evolved extinguishes a burning candle. Write a balanced chemical equation for the reaction if one of the compounds formed is calcium chloride.',
    answer: 'The metal compound \'A\' is Calcium Carbonate (CaCO₃).\nThe gas evolved is Carbon Dioxide (CO₂), which extinguishes a burning candle because it does not support combustion.\n\nBalanced Equation:\nCaCO₃(s) + 2HCl(aq) → CaCl₂(aq) [Calcium Chloride] + H₂O(l) + CO₂(g) ↟',
    year: 2024,
    marks: 3,
    type: 'Short Answer',
    source: 'CBSE AI Set-1'
  },
  {
    id: 's_chem_4',
    subjectKey: 'science',
    chapterName: 'Chemical Reactions and Equations',
    question: 'Identify the oxidising agent and reducing agent in the following reaction:\nMnO₂ + 4HCl → MnCl₂ + 2H₂O + Cl₂',
    answer: '1. MnO₂ is reduced to MnCl₂ (loss of oxygen). Therefore, MnO₂ is the Oxidising Agent.\n2. HCl is oxidised to Cl₂ (loss of hydrogen). Therefore, HCl is the Reducing Agent.',
    year: 2022,
    marks: 2,
    type: 'Short Answer',
    source: 'CBSE Term-2'
  },
  {
    id: 'm_real_1',
    subjectKey: 'maths',
    chapterName: 'Real Numbers',
    question: 'Prove that √5 is an irrational number.',
    answer: 'Let us assume √5 is a rational number.\nTherefore, we can write √5 = a/b, where a and b are co-prime integers and b ≠ 0.\n\nSquaring both sides:\n5 = a²/b²  =>  5b² = a²  --- (Eqn 1)\nSince 5 divides a², it must also divide a (by Fundamental Theorem of Arithmetic).\nLet a = 5c for some integer c.\n\nSubstitute a in Eqn 1:\n5b² = (5c)²  =>  5b² = 25c²  =>  b² = 5c²\nSince 5 divides b², it must also divide b.\n\nTherefore, 5 is a common factor of both a and b, which contradicts our initial assumption that a and b are co-prime. Hence, √5 is an irrational number.',
    year: 2023,
    marks: 3,
    type: 'Short Answer',
    source: 'CBSE National'
  },
  {
    id: 'm_real_2',
    subjectKey: 'maths',
    chapterName: 'Real Numbers',
    question: 'Explain why 7 × 11 × 13 + 13 and 7 × 6 × 5 × 4 × 3 × 2 × 1 + 5 are composite numbers.',
    answer: 'A composite number has factors other than 1 and itself.\n\n1. For the first number: 7 × 11 × 13 + 13\n   Take 13 common: 13(7 × 11 + 1) = 13(77 + 1) = 13 × 78\n   Since the number has 13 and 78 as its prime factors, it is a composite number.\n\n2. For the second number: 7 × 6 × 5 × 4 × 3 × 2 × 1 + 5\n   Take 5 common: 5(7 × 6 × 4 × 3 × 2 × 1 + 1) = 5(1008 + 1) = 5 × 1009\n   Since the number has 5 and 1009 as prime factors, it is a composite number.',
    year: 2022,
    marks: 2,
    type: 'Short Answer',
    source: 'CBSE Main'
  },
  {
    id: 'm_real_3',
    subjectKey: 'maths',
    chapterName: 'Real Numbers',
    question: 'Find the LCM and HCF of 404 and 96 by prime factorization and verify that HCF × LCM = Product of the two numbers.',
    answer: '1. Prime Factorization:\n   96 = 2⁵ × 3\n   404 = 2² × 101\n\n2. Calculating HCF and LCM:\n   HCF = 2² = 4\n   LCM = 2⁵ × 3 × 101 = 32 × 3 × 101 = 9696\n\n3. Verification:\n   HCF × LCM = 4 × 9696 = 38784\n   Product of numbers = 96 × 404 = 38784\n   LHS = RHS. Verified.',
    year: 2020,
    marks: 3,
    type: 'Short Answer',
    source: 'CBSE Main'
  },
  {
    id: 's_life_1',
    subjectKey: 'science',
    chapterName: 'Life Processes',
    question: 'How is oxygen and carbon dioxide transported in human beings?',
    answer: '1. Transport of Oxygen:\n   - Oxygen is transported mainly by red blood cells (RBCs).\n   - Hemoglobin, a red iron-containing pigment present in RBCs, has a very high affinity for oxygen. It binds with oxygen to form Oxyhemoglobin and transports it to different body tissues.\n\n2. Transport of Carbon Dioxide:\n   - Carbon dioxide is more soluble in water than oxygen is.\n   - Therefore, it is mostly transported in dissolved form in our blood plasma from tissues back to the lungs, where it diffuses into the alveoli.',
    year: 2024,
    marks: 3,
    type: 'Short Answer',
    source: 'CBSE Outside Delhi Set-3'
  },
  {
    id: 's_life_2',
    subjectKey: 'science',
    chapterName: 'Life Processes',
    question: 'Explain the three pathways of glucose breakdown (respiration) in living organisms.',
    answer: 'First step is Glycolysis, where glucose (6-carbon molecule) is broken down into pyruvate (3-carbon molecule) in the cytoplasm.\n\nThereafter, pyruvate undergoes breakdown through 3 distinct pathways:\n\n1. In Absence of Oxygen (Anaerobic / Yeast):\n   Pyruvate is converted into Ethanol (2-carbon) + Carbon Dioxide (CO₂) + 2 moles of ATP energy.\n\n2. In Lack of Oxygen (Human Muscle Cells during heavy exercise):\n   Pyruvate is converted into Lactic Acid (3-carbon) + 2 moles of ATP energy. Accumulated lactic acid causes muscle cramps.\n\n3. In Presence of Oxygen (Aerobic / Mitochondria):\n   Pyruvate breaks down completely into Carbon Dioxide (CO₂) + Water (H₂O) + abundant energy (~36 or 38 ATP).',
    year: 2023,
    marks: 5,
    type: 'Long Answer',
    source: 'CBSE Delhi'
  },
  {
    id: 's_life_3',
    subjectKey: 'science',
    chapterName: 'Life Processes',
    question: 'State the exact roles of the following in human digestion:\n(a) Gastric Mucus\n(b) Hydrochloric Acid (HCl)\n(c) Pancreatic Trypsin',
    answer: '(a) Gastric Mucus: Protects the inner epithelial lining of the stomach walls from being digested and eroded by the highly corrosive strong hydrochloric acid.\n\n(b) Hydrochloric Acid (HCl): Kills harmful bacteria entering with food and creates an acidic environment (pH ~1.8) necessary for the inactive pepsinogen enzyme to convert into active pepsin.\n\n(c) Trypsin: Produced in an inactive form by the pancreas, active Trypsin acts under an alkaline medium in the small intestine to break down complex proteins and peptides into simplified amino acids.',
    year: 2024,
    marks: 3,
    type: 'Short Answer',
    source: 'CBSE National Set-1'
  },
  {
    id: 'sst_nat_1',
    subjectKey: 'sst',
    chapterName: 'Nationalism in India',
    question: 'Why did Mahatma Gandhi decide to withdraw the Non-Cooperation Movement in February 1922?',
    answer: 'Mahatma Gandhi withdrew the Non-Cooperation Movement in February 1922 due to the following reasons:\n\n1. Chauri Chaura Incident: In February 1922, at Chauri Chaura in Gorakhpur district (Uttar Pradesh), a peaceful protest demonstration turned violent. A clash with the police led an angry crowd to set a nearby police station on fire, burning 22 police constables alive.\n2. Dedication to Non-violence: Gandhi was a staunch supporter of Ahimsa (non-violence). The event deeply shocked him, and he realised the movement was turning violent.\n3. Lack of Training: He felt that the Satyagrahis needed to be properly trained in peaceful demonstrations before they would be ready for mass struggles.',
    year: 2023,
    marks: 3,
    type: 'Short Answer',
    source: 'CBSE Topper Series'
  },
  {
    id: 'sst_nat_2',
    subjectKey: 'sst',
    chapterName: 'Nationalism in India',
    question: 'Explain the effects of the Great Depression on the Indian economy.',
    answer: 'The Great Depression (1929) had a profound impact on British India:\n\n1. Crash in Trade: Indian exports and imports halved between 1928 and 1934.\n2. Agricultural Decline: As international prices crashed, agricultural prices in India fell by 50% between 1928 and 1934.\n3. Indebtedness: While prices plunged, the colonial government refused to reduce revenue demands, forcing peasants to sell gold, jewelry, and land reserves to pay taxes.\n4. Gold Exports: India became an exporter of precious metals (especially gold which Gandhi described as "gold drain") which helped speed up the recovery of the global British sterling currency system but ruined rural peasants.',
    year: 2022,
    marks: 5,
    type: 'Long Answer',
    source: 'CBSE Main Set-2'
  },
  {
    id: 's_elec_1',
    subjectKey: 'science',
    chapterName: 'Electricity',
    question: 'Why are copper and aluminium wires usually employed for electricity transmission? Why are heating elements of electric irons made of alloys (like nichrome) rather than pure metals?',
    answer: '1. Transmission Wires: Copper and Aluminium have extremely low electrical resistivity and are highly ductile. This makes them excellent conductors of electricity, minimizing power loss (I²R heating losses) during transit.\n\n2. Heating Elements: Alloys like Nichrome are preferred for heating appliances because:\n   - They have higher resistivity than pure metals, generating high heat.\n   - They have a high melting point.\n   - They do not oxidise (burn or melt) at high temperatures.',
    year: 2023,
    marks: 3,
    type: 'Short Answer',
    source: 'CBSE National'
  }
];

// Load local custom PYQs from localStorage
const getCustomPYQs = (): RealPYQ[] => {
  return loadItem<RealPYQ[]>('vidypath_custom_pyqs_v1', []);
};

// Save custom PYQs to localStorage
const saveCustomPYQs = (list: RealPYQ[]) => {
  saveItem('vidypath_custom_pyqs_v1', list);
};

// Fetch unified real PYQs for a chapter
export const getChapterPYQs = async (subjectKey: string, chapterName: string): Promise<RealPYQ[]> => {
  const seeds = PRESEEDED_PYQS.filter(
    p => p.subjectKey === subjectKey && p.chapterName.toLowerCase() === chapterName.toLowerCase()
  );

  let local = getCustomPYQs().filter(
    p => p.subjectKey === subjectKey && p.chapterName.toLowerCase() === chapterName.toLowerCase()
  );

  // If user is authenticated, also sync and fetch from Firestore
  if (auth.currentUser) {
    try {
      const qRef = query(
        collection(db, 'users', auth.currentUser.uid, 'custom_pyqs'),
        where('subjectKey', '==', subjectKey),
        where('chapterName', '==', chapterName)
      );
      const snapshot = await getDocs(qRef);
      const dbPyqs = snapshot.docs.map(docSnapshot => ({
        id: docSnapshot.id,
        ...docSnapshot.data()
      })) as RealPYQ[];
      
      // Merge unique ones
      const localIds = new Set(local.map(l => l.id));
      dbPyqs.forEach(dbQ => {
        if (!localIds.has(dbQ.id)) {
          local.push(dbQ);
        }
      });
    } catch (e) {
      console.error("Failed to fetch custom PYQs from Firestore", e);
    }
  }

  return [...seeds, ...local].sort((a, b) => b.year - a.year);
};

// Add a real custom PYQ
export const addRealPYQ = async (
  pyqData: Omit<RealPYQ, 'id' | 'addedByUser'>
): Promise<RealPYQ> => {
  const newId = 'custom_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5);
  const newPyq: RealPYQ = {
    ...pyqData,
    id: newId,
    addedByUser: true
  };

  // 1. Add to local cache
  const localList = getCustomPYQs();
  localList.push(newPyq);
  saveCustomPYQs(localList);

  // 2. Sync to Firestore if authenticated
  if (auth.currentUser) {
    try {
      await addDoc(collection(db, 'users', auth.currentUser.uid, 'custom_pyqs'), {
        ...pyqData,
        id: newId,
        addedByUser: true
      });
    } catch (e) {
      console.error("Firestore sync error during adding custom PYQ", e);
    }
  }

  return newPyq;
};

// Delete a custom PYQ (only allowed for user-added ones)
export const deleteRealPYQ = async (id: string, subjectKey: string, chapterName: string): Promise<boolean> => {
  // 1. Delete from local cache
  const localList = getCustomPYQs();
  const filtered = localList.filter(p => p.id !== id);
  saveCustomPYQs(filtered);

  // 2. Delete from Firestore if authenticated
  if (auth.currentUser) {
    try {
      const qRef = query(
        collection(db, 'users', auth.currentUser.uid, 'custom_pyqs'),
        where('subjectKey', '==', subjectKey),
        where('chapterName', '==', chapterName),
        where('id', '==', id)
      );
      const snapshot = await getDocs(qRef);
      for (const docSnapshot of snapshot.docs) {
        await deleteDoc(doc(db, 'users', auth.currentUser.uid, 'custom_pyqs', docSnapshot.id));
      }
    } catch (e) {
      console.error("Firestore delete error for custom PYQ", e);
    }
  }

  return true;
};
