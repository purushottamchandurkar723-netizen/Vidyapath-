/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Compresses an image file by resizing it and lowering the quality using canvas.
 * This prevents the client from sending giant payloads (e.g. 5MB-20MB camera uploads)
 * which can cause proxy/network disconnections resulting in "Failed to fetch" errors.
 *
 * @param file The uploaded Image File
 * @param maxWidth The maximum width of the output image in pixels
 * @param maxHeight The maximum height of the output image in pixels
 * @param quality The output quality ratio between 0.1 and 1.0 (defaults to 0.75)
 * @returns Promise resolving to a base64-encoded Data URL of the compressed JPEG image
 */
export function compressImage(
  file: File,
  maxWidth = 1000,
  maxHeight = 1000,
  quality = 0.75
): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;

        // Calculate aspect-ratio-friendly scaled dimensions
        if (width > height) {
          if (width > maxWidth) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          }
        } else {
          if (height > maxHeight) {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }

        canvas.width = width;
        canvas.height = height;

        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('Canvas 2D context unavailable'));
          return;
        }

        // Draw and scale down
        ctx.drawImage(img, 0, 0, width, height);

        // Convert to highly optimized JPEG format
        const dataUrl = canvas.toDataURL('image/jpeg', quality);
        resolve(dataUrl);
      };

      img.onerror = (err) => {
        reject(err);
      };

      img.src = event.target?.result as string;
    };

    reader.onerror = (err) => {
      reject(err);
    };

    reader.readAsDataURL(file);
  });
}
