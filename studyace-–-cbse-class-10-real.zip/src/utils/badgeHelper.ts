/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ProgressRecord } from '../types';

export interface Badge {
  id: string;
  title: string;
  description: string;
  iconName: 'Award' | 'Flame' | 'Trophy' | 'Target' | 'Crown' | 'Star' | 'Gem' | 'BookOpen' | 'Compass' | 'Sparkles';
  colorClass: string; // Tailwind bg/border styling for the badge circle
  bgClass: string;
  category: 'streak' | 'perf' | 'volume';
  cbseTip: string; // Constructive motivational board-preparation tip for Class 10
}

export interface BadgeStatus {
  badge: Badge;
  unlocked: boolean;
  progressStr: string;
  current: number;
  target: number;
}

export const ALL_BADGES: Badge[] = [
  {
    id: 'launchpad',
    title: 'Launchpad Scholar',
    description: 'Complete your first ever chapter quiz preparation.',
    iconName: 'BookOpen',
    colorClass: 'text-blue-500 border-blue-250 bg-blue-50/50 dark:bg-blue-950/20',
    bgClass: 'from-blue-500 to-indigo-500',
    category: 'volume',
    cbseTip: 'Starting is the hardest part. Ensure you map out difficult chapters first in social sciences to avoid eleventh-hour cramming.'
  },
  {
    id: 'perfect_master',
    title: 'Perfect Master',
    description: 'Score a perfect 100% on any practice quiz.',
    iconName: 'Trophy',
    colorClass: 'text-yellow-600 border-yellow-250 bg-yellow-50/50 dark:bg-yellow-950/20',
    bgClass: 'from-amber-400 to-yellow-600',
    category: 'perf',
    cbseTip: 'Unbelievable accuracy! CBSE board exam answer sheets are evaluated strictly on key terms. Always underline your final numeric answer in math!'
  },
  {
    id: 'streak_3',
    title: 'Spark Starter',
    description: 'Keep a 3-day active study streak alive.',
    iconName: 'Flame',
    colorClass: 'text-orange border-orange-mid bg-orange-lt/50 dark:bg-orange-950/20',
    bgClass: 'from-orange to-red-500',
    category: 'streak',
    cbseTip: 'Three days of steady momentum! Revising formula concepts for 10 minutes daily is more effective than practicing 10 hours on Sundays.'
  },
  {
    id: 'streak_7',
    title: 'Weekly Warrior',
    description: 'Build a durable 7-day study streak with daily revisions.',
    iconName: 'Crown',
    colorClass: 'text-purple-600 border-purple-200 bg-purple-50/50 dark:bg-purple-950/20',
    bgClass: 'from-purple-500 to-indigo-600',
    category: 'streak',
    cbseTip: 'A full week of loyalty! Use active recall during long commutes: close your eyes and explain the concept of Carbon Compounds to yourself.'
  },
  {
    id: 'streak_14',
    title: 'Limitless Scholar',
    description: 'Maintain a 14-day study streak to foster unbreakable habit loops.',
    iconName: 'Sparkles',
    colorClass: 'text-pink-600 border-pink-200 bg-pink-50/50 dark:bg-pink-950/20',
    bgClass: 'from-pink-500 to-rose-600',
    category: 'streak',
    cbseTip: 'Two weeks of absolute devotion! Board toppers consistently practice back-to-back mock tests from previous years to hone their time management.'
  },
  {
    id: 'super_driller',
    title: 'Board Challenger',
    description: 'Score 80% or high on at least 5 different chapter quizzes.',
    iconName: 'Target',
    colorClass: 'text-red-500 border-red-200 bg-red-50/50 dark:bg-red-950/20',
    bgClass: 'from-rose-500 to-red-650',
    category: 'perf',
    cbseTip: 'Five chapters thoroughly conquered! In Science, diagrams like the human nephron or electric motor are scoring. Always draw them neatly!'
  },
  {
    id: 'subject_conqueror',
    title: 'Syllabus Conqueror',
    description: 'Prepare and pass chapters across Maths, Science, social studies, and English.',
    iconName: 'Compass',
    colorClass: 'text-emerald-600 border-emerald-200 bg-emerald-50/50 dark:bg-emerald-950/20',
    bgClass: 'from-teal-500 to-emerald-600',
    category: 'volume',
    cbseTip: 'Multi-disciplinary prowess! English literature demands proper character references; double-check spelling and character names to keep assessors happy.'
  },
  {
    id: 'knowledge_sage',
    title: 'Knowledge Giant',
    description: 'Acquire a combined total of at least 50 correct answers across your best quiz attempts.',
    iconName: 'Gem',
    colorClass: 'text-cyan-600 border-cyan-200 bg-cyan-50/50 dark:bg-cyan-950/20',
    bgClass: 'from-cyan-400 to-sky-600',
    category: 'volume',
    cbseTip: 'Fifty concepts validated! Remember that keeping standard bullet points in social science answers earns higher marks than generic long paragraphs.'
  },
  {
    id: 'silver_scholar',
    title: 'Elite Academic',
    description: 'Aspirant who has completed at least 10 different chapter quizzes.',
    iconName: 'Star',
    colorClass: 'text-indigo-600 border-indigo-200 bg-indigo-50/50 dark:bg-indigo-950/20',
    bgClass: 'from-indigo-400 to-blue-600',
    category: 'volume',
    cbseTip: 'Phenomenal depth! When attempting CBSE sample papers, always dedicate the first 15 minutes of reading time strictly to planning which questions to skip.'
  }
];

export function getBadgeStatuses(
  streakCount: number,
  records: ProgressRecord[]
): BadgeStatus[] {
  return ALL_BADGES.map((badge) => {
    let unlocked = false;
    let progressStr = '';
    let current = 0;
    let target = 0;

    switch (badge.id) {
      case 'launchpad': {
        target = 1;
        current = records.length;
        unlocked = current >= target;
        progressStr = `${current}/${target} Chapter`;
        break;
      }
      case 'perfect_master': {
        target = 1;
        const exists = records.some((r) => r.bestScore === r.totalOut && r.totalOut > 0);
        current = exists ? 1 : 0;
        unlocked = exists;
        progressStr = unlocked ? 'Complete' : 'No 100% yet';
        break;
      }
      case 'streak_3': {
        target = 3;
        current = streakCount;
        unlocked = current >= target;
        progressStr = `${current}/${target} Days`;
        break;
      }
      case 'streak_7': {
        target = 7;
        current = streakCount;
        unlocked = current >= target;
        progressStr = `${current}/${target} Days`;
        break;
      }
      case 'streak_14': {
        target = 14;
        current = streakCount;
        unlocked = current >= target;
        progressStr = `${current}/${target} Days`;
        break;
      }
      case 'super_driller': {
        target = 5;
        current = records.filter((r) => r.totalOut > 0 && r.bestScore / r.totalOut >= 0.8).length;
        unlocked = current >= target;
        progressStr = `${current}/${target} Chapters`;
        break;
      }
      case 'subject_conqueror': {
        target = 4;
        const seenSubjects = new Set(records.map((r) => r.subjectKey.toLowerCase()));
        
        // Let's gather how many key subjects are covered
        let subCount = 0;
        if (seenSubjects.has('maths')) subCount++;
        if (seenSubjects.has('science')) subCount++;
        // Support either partial names
        if (records.some(r => r.subjectKey?.toLowerCase().includes('sst') || r.subjectKey?.toLowerCase().includes('social') || r.subjectKey?.toLowerCase().includes('history'))) subCount++;
        if (records.some(r => r.subjectKey?.toLowerCase().includes('english') || r.subjectKey?.toLowerCase().includes('lang'))) subCount++;
        
        current = subCount;
        unlocked = current >= target;
        progressStr = `${current}/${target} Subjects`;
        break;
      }
      case 'knowledge_sage': {
        target = 50;
        current = records.reduce((sum, r) => sum + r.bestScore, 0);
        unlocked = current >= target;
        progressStr = `${current}/${target} Answers`;
        break;
      }
      case 'silver_scholar': {
        target = 10;
        current = records.length;
        unlocked = current >= target;
        progressStr = `${current}/${target} Quizzes`;
        break;
      }
      default:
        break;
    }

    return {
      badge,
      unlocked,
      progressStr,
      current,
      target
    };
  });
}
