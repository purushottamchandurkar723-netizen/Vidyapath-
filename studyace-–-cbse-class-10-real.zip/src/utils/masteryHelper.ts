/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { loadItem, saveItem } from '../lib/utils';
import { SUBJECTS } from '../constants';

export interface ChapterMasteryState {
  lecture_completed: boolean;
  notes_completed?: boolean;
  qbank_accuracy: number; // 0 to 100
  tricks_completed: boolean;
  revisions_count: number; // 0 to 4 (corresponds to Day 3, 7, 15, 30)
  startDate?: string; // e.g., "12 June"
  expectedDate?: string; // e.g., "18 June"
}

export interface Mistake {
  id: string | number;
  question: string;
  correctAnswer: string;
  subject: string;
  chapterName: string;
  practiced: boolean;
  date: string;
  questionType?: string;
  originalSolved?: boolean;
  similarSolved: boolean;
  similarQuestion?: string;
  similarAnswer?: string;
  fixed?: boolean;
}

// Default mastery states provider
export function loadAllMasteryStates(): Record<string, ChapterMasteryState> {
  return loadItem<Record<string, ChapterMasteryState>>('vidypath_chapter_mast_v1', {});
}

export function saveAllMasteryStates(states: Record<string, ChapterMasteryState>) {
  saveItem('vidypath_chapter_mast_v1', states);
}

export function getChapterMasteryState(subjectKey: string, chapterName: string): ChapterMasteryState {
  const all = loadAllMasteryStates();
  const k = `${subjectKey}__${chapterName}`;
  
  if (!all[k]) {
    // Determine a default timeline starting today
    const today = new Date();
    const expected = new Date();
    expected.setDate(today.getDate() + 7); // Default expected completion in 7 days
    
    const fmtDate = (d: Date) => {
      return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
    };

    all[k] = {
      lecture_completed: false,
      notes_completed: false,
      qbank_accuracy: 0,
      tricks_completed: false,
      revisions_count: 0,
      startDate: fmtDate(today),
      expectedDate: fmtDate(expected)
    };
    saveAllMasteryStates(all);
  }
  return all[k];
}

export function updateChapterMasteryState(subjectKey: string, chapterName: string, updates: Partial<ChapterMasteryState>) {
  const all = loadAllMasteryStates();
  const k = `${subjectKey}__${chapterName}`;
  const current = getChapterMasteryState(subjectKey, chapterName);
  
  all[k] = {
    ...current,
    ...updates
  };
  saveAllMasteryStates(all);
}

// Re-calculate the mastery percent and details for a chapter
export function calculateChapterMastery(subjectKey: string, chapterName: string) {
  const state = getChapterMasteryState(subjectKey, chapterName);
  
  // 1. Quiz Accuracy from vidypath_progress_v4
  const progressLogs = loadItem<Record<string, any>>('vidypath_progress_v4', {});
  const quizRecord = progressLogs[`${subjectKey}__${chapterName}`];
  const quiz_accuracy = quizRecord && quizRecord.totalOut > 0 
    ? Math.round((quizRecord.bestScore / quizRecord.totalOut) * 100) 
    : 0;
  
  // 2. Mistake Recovery Percent
  const mistakes = loadItem<Mistake[]>('vidypath_mistakes_v1', []);
  // Subject mapping checking
  const sub = SUBJECTS[subjectKey];
  const subjectLabel = sub ? sub.label : '';
  const chapterMistakes = mistakes.filter(m => 
    m.chapterName?.toLowerCase() === chapterName?.toLowerCase() &&
    (m.subject?.toLowerCase() === subjectLabel?.toLowerCase() || m.subject?.toLowerCase() === subjectKey?.toLowerCase())
  );
  
  const totalMistakes = chapterMistakes.length;
  const fixedMistakes = chapterMistakes.filter(m => m.originalSolved && m.similarSolved).length;
  const recovery_pct = totalMistakes === 0 ? 100 : Math.round((fixedMistakes / totalMistakes) * 100);
  
  // Weights mapped exactly to requested Mastery Dashboard requirements:
  // 1. Lecture = 20% (contrib = lectureWeight)
  // 2. Question Bank = 25% (contrib = qbank_accuracy * 0.25)
  // 3. Quiz = 25% (contrib = quiz_accuracy * 0.25)
  // 4. Mistake Recovery = 15% (contrib = recovery_pct * 0.15)
  // 5. Revision = 10% (contrib = Math.min(revisions_count, 4) * 2.5) -> scaled 0 to 10%
  // 6. Tricks = 5% (contrib = tricks_completed ? 5 : 0)
  
  const notes_completed = state.notes_completed ?? false;
  const lectureWeight = state.lecture_completed ? 20 : 0;
  const tricksWeight = state.tricks_completed ? 5 : 0;
  const qbWeight = state.qbank_accuracy * 0.25;
  const quizWeight = quiz_accuracy * 0.25;
  const mistakeWeight = recovery_pct * 0.15;
  const revWeight = Math.min(state.revisions_count, 4) * 2.5; // weight max 10%
  
  const masteryScore = Math.round(lectureWeight + tricksWeight + qbWeight + quizWeight + mistakeWeight + revWeight);
  const clampedMastery = Math.min(100, Math.max(0, masteryScore));
  
  // Status levels:
  // 0-49 = Needs Attention
  // 50-69 = Learning
  // 70-84 = Practicing
  // 85-100 = Mastered
  let status: 'Needs Attention' | 'Learning' | 'Practicing' | 'Mastered' = 'Needs Attention';
  if (clampedMastery >= 85) status = 'Mastered';
  else if (clampedMastery >= 70) status = 'Practicing';
  else if (clampedMastery >= 50) status = 'Learning';
  
  // Remaining Tasks
  const remainingTasks: string[] = [];
  if (!state.lecture_completed) remainingTasks.push('Complete lecture video');
  if (!notes_completed) remainingTasks.push('Read chapter revision notes');
  if (!state.tricks_completed) remainingTasks.push('Complete study of tricks and memory hacks');
  if (state.qbank_accuracy < 80) {
    remainingTasks.push(state.qbank_accuracy === 0 ? 'Practice Question Bank' : `Improve Question Bank accuracy (current: ${state.qbank_accuracy}% - Target >= 80%)`);
  }
  if (quiz_accuracy < 80) {
    remainingTasks.push(quiz_accuracy === 0 ? 'Practice Chapter Quiz' : `Improve Quiz accuracy (current: ${quiz_accuracy}% - Target >= 80%)`);
  }
  
  const unfixedCount = totalMistakes - fixedMistakes;
  if (unfixedCount > 0) remainingTasks.push(`Fix ${unfixedCount} mistake(s) in review`);
  
  if (state.revisions_count < 1) remainingTasks.push('Complete at least 1 Chapter Revision');
  
  // Progress % (Percentage of requirements met for completion - 7 items)
  // ✓ Lecture completed (1)
  // ✓ Notes read (1)
  // ✓ Tricks completed (1)
  // ✓ Question Bank accuracy >= 80% (1)
  // ✓ Quiz accuracy >= 80% (1)
  // ✓ Mistake Review completed (all chapter mistakes must be fixed) (1)
  // ✓ Revision completed (revisions_count >= 1) (1)
  let metCount = 0;
  if (state.lecture_completed) metCount++;
  if (notes_completed) metCount++;
  if (state.tricks_completed) metCount++;
  if (state.qbank_accuracy >= 80) metCount++;
  if (quiz_accuracy >= 80) metCount++;
  if (unfixedCount === 0) metCount++;
  if (state.revisions_count >= 1) metCount++;
  const progressPct = Math.round((metCount / 7) * 100);
  
  const isCompleted = metCount === 7;
  
  return {
    masteryScore: clampedMastery,
    status,
    remainingTasks,
    totalMistakes,
    fixedMistakes,
    unfixedCount,
    recovery_pct,
    progressPct,
    isCompleted,
    quiz_accuracy,
    metCount,
    state
  };
}

// Get aggregate stats across all subjects & chapters
export function getSyllabusAggregateStats() {
  let totalChapters = 0;
  let completedChapters = 0;
  let totalMasterySum = 0;
  let needsAttentionCount = 0;
  
  Object.entries(SUBJECTS).forEach(([subjectKey, sub]) => {
    sub.chapters.forEach(ch => {
      totalChapters++;
      const stats = calculateChapterMastery(subjectKey, ch.name);
      if (stats.isCompleted) {
        completedChapters++;
      }
      if (stats.masteryScore < 50) {
        needsAttentionCount++;
      }
      totalMasterySum += stats.masteryScore;
    });
  });
  
  const overallCompletionPct = totalChapters === 0 ? 0 : Math.round((completedChapters / totalChapters) * 105);
  const clampedCompletionPct = Math.min(overallCompletionPct, 100);
  const averageMasteryScore = totalChapters === 0 ? 0 : Math.round(totalMasterySum / totalChapters);
  
  return {
    totalChapters,
    completedChapters,
    overallCompletionPct: clampedCompletionPct,
    averageMasteryScore,
    needsAttentionCount
  };
}

export interface SharedPlannerTask {
  id: string;
  subject: string;
  subjectKey: string;
  chapter: string;
  topic: string;
  type: 'revision' | 'mistake' | 'progress' | 'future';
  durationMins: number;
  priorityLabel: 'Urgent (Overdue)' | 'High' | 'Normal' | 'Secondary';
  actionLabel: string;
}

export function getAutomatedTodaysTasks(): SharedPlannerTask[] {
  // Load current components from storage
  const activeChapters = loadItem<Record<string, string[]>>('vidypath_ft_active_chapters_val', {
    maths: ["Polynomials"],
    science: ["Chemical Reactions and Equations"],
    sst: ["Power Sharing"],
    english: ["A Letter to God"]
  });

  const completedChapters = loadItem<Record<string, number>>('vidypath_ft_completed_chapters_val', {});
  const currentDay = loadItem<number>('vidypath_ft_current_day_val', 1);

  // AUTOMATE TRANSITIONS: If a chapter in activeChapters is completed, let's ensure it is recorded in completedChapters.
  // And let's automatically select the next uncompleted chapter of that subject if the current active chapter is completed!
  let changed = false;
  const updatedActive = { ...activeChapters };
  const updatedCompleted = { ...completedChapters };

  Object.entries(activeChapters).forEach(([subKey, list]) => {
    let uncompletedList = list.filter(chName => {
      const mastery = calculateChapterMastery(subKey, chName);
      if (mastery.isCompleted) {
        if (!updatedCompleted[chName]) {
          updatedCompleted[chName] = currentDay;
          changed = true;
        }
        return false; // completed, remove from active list or mark completed
      }
      return true;
    });

    // If active list becomes empty because current one is completed, let's automatically schedule the next uncompleted chapter!
    if (uncompletedList.length === 0) {
      const sub = SUBJECTS[subKey];
      if (sub) {
        const nextChapter = sub.chapters.find(c => !updatedCompleted[c.name]);
        if (nextChapter) {
          uncompletedList = [nextChapter.name];
          changed = true;
        }
      }
    }

    if (uncompletedList.length !== list.length || (uncompletedList.length > 0 && uncompletedList[0] !== list[0])) {
      updatedActive[subKey] = uncompletedList;
      changed = true;
    }
  });

  if (changed) {
    saveItem('vidypath_ft_active_chapters_val', updatedActive);
    saveItem('vidypath_ft_completed_chapters_val', updatedCompleted);
  }

  const queue: SharedPlannerTask[] = [];

  // --- PRIORITY 1: DUE SPACED REVISIONS ---
  Object.entries(updatedCompleted).forEach(([chapterName, completionDay]) => {
    let subKey = 'maths';
    let subLabel = 'Mathematics';
    Object.entries(SUBJECTS).forEach(([k, s]) => {
      if (s.chapters.some(c => c.name === chapterName)) {
        subKey = k;
        subLabel = s.label;
      }
    });

    const mastery = calculateChapterMastery(subKey, chapterName);
    const revsCompleted = mastery.state.revisions_count;

    if (revsCompleted < 4) {
      const rules = [3, 7, 15, 30];
      const nextDueInDays = rules[revsCompleted];
      const targetDay = completionDay + nextDueInDays;

      if (currentDay >= targetDay) {
        const isOverdue = currentDay > targetDay;
        queue.push({
          id: `rev-${subKey}-${chapterName}`,
          subject: subLabel,
          subjectKey: subKey,
          chapter: chapterName,
          topic: `Spaced Revision ${revsCompleted + 1} (Day ${targetDay} schedule)`,
          type: 'revision',
          durationMins: 15,
          priorityLabel: isOverdue ? 'Urgent (Overdue)' : 'High',
          actionLabel: `Perform Revision ${revsCompleted + 1}`
        });
      }
    }
  });

  // --- PRIORITY 2: PENDING MISTAKE REVIEWS ---
  const rawMistakes = loadItem<any[]>('vidypath_mistakes_v1', []);
  const pendingMistakes = rawMistakes.filter(m => !m.fixed && !m.practiced);

  pendingMistakes.forEach(m => {
    let subjectK = 'maths';
    let subjectL = 'Mathematics';
    Object.entries(SUBJECTS).forEach(([k, s]) => {
      if (s.label?.toLowerCase() === m.subject?.toLowerCase() || k?.toLowerCase() === m.subject?.toLowerCase()) {
        subjectK = k;
        subjectL = s.label;
      }
    });

    queue.push({
      id: `mistake-${m.id}`,
      subject: subjectL,
      subjectKey: subjectK,
      chapter: m.chapterName,
      topic: `Resolve logged error: "${m.question.substring(0, 40)}..."`,
      type: 'mistake',
      durationMins: 10,
      priorityLabel: 'High',
      actionLabel: 'Solve original & similar questions in Mistake Book'
    });
  });

  // --- PRIORITY 3: CURRENT CHAPTER PROGRESS ---
  Object.entries(SUBJECTS).forEach(([subKey, sub]) => {
    const activeList = updatedActive[subKey] || [];
    activeList.forEach(chName => {
      const isFinished = updatedCompleted[chName];
      if (!isFinished) {
        const mastery = calculateChapterMastery(subKey, chName);
        
        if (!mastery.state.lecture_completed) {
          queue.push({
            id: `lecture-${subKey}-${chName}`,
            subject: sub.label,
            subjectKey: subKey,
            chapter: chName,
            topic: `Watch lecture video: ${chName}`,
            type: 'progress',
            durationMins: 20,
            priorityLabel: 'Normal',
            actionLabel: 'Complete video lecture'
          });
        }
        else if (!(mastery.state.notes_completed ?? false)) {
          queue.push({
            id: `notes-${subKey}-${chName}`,
            subject: sub.label,
            subjectKey: subKey,
            chapter: chName,
            topic: `Read & study Revision Notes: ${chName}`,
            type: 'progress',
            durationMins: 15,
            priorityLabel: 'Normal',
            actionLabel: 'Read chapter notes & concepts'
          });
        }
        else if (!mastery.state.tricks_completed) {
          queue.push({
            id: `tricks-${subKey}-${chName}`,
            subject: sub.label,
            subjectKey: subKey,
            chapter: chName,
            topic: `Master shortcuts & mnemonics: ${chName}`,
            type: 'progress',
            durationMins: 10,
            priorityLabel: 'Secondary',
            actionLabel: 'Complete study of tricks and memory hacks'
          });
        }
        else if (mastery.state.qbank_accuracy < 80) {
          queue.push({
            id: `qbank-${subKey}-${chName}`,
            subject: sub.label,
            subjectKey: subKey,
            chapter: chName,
            topic: `Solve Question Bank: ${chName} (Accuracy: ${mastery.state.qbank_accuracy}%)`,
            type: 'progress',
            durationMins: 15,
            priorityLabel: 'Normal',
            actionLabel: 'Achieve >= 80% Question Bank precision'
          });
        }
        else if (mastery.quiz_accuracy < 80) {
          queue.push({
            id: `quiz-${subKey}-${chName}`,
            subject: sub.label,
            subjectKey: subKey,
            chapter: chName,
            topic: `Take board assessment mockup: ${chName} (Best: ${mastery.quiz_accuracy}%)`,
            type: 'progress',
            durationMins: 15,
            priorityLabel: 'Normal',
            actionLabel: 'Achieve >= 80% Quiz Accuracy'
          });
        }
        else if (mastery.unfixedCount > 0) {
          queue.push({
            id: `mistake-chapter-${subKey}-${chName}`,
            subject: sub.label,
            subjectKey: subKey,
            chapter: chName,
            topic: `Resolve mistakes in Mistake Book: ${chName} (${mastery.unfixedCount} errors)`,
            type: 'mistake',
            durationMins: 10,
            priorityLabel: 'High',
            actionLabel: 'Solve original and similar questions in Mistake Book'
          });
        }
        else if (mastery.state.revisions_count < 1) {
          queue.push({
            id: `rev-${subKey}-${chName}`,
            subject: sub.label,
            subjectKey: subKey,
            chapter: chName,
            topic: `Immediate Session Revision: ${chName}`,
            type: 'revision',
            durationMins: 15,
            priorityLabel: 'High',
            actionLabel: 'Perform Revision 1'
          });
        }
      }
    });
  });

  // --- PRIORITY 4: FUTURE NEW INDEX ---
  Object.entries(SUBJECTS).forEach(([subKey, sub]) => {
    const activeList = updatedActive[subKey] || [];
    const nextFuture = sub.chapters.find(c => !activeList.includes(c.name) && !updatedCompleted[c.name]);
    if (nextFuture) {
      queue.push({
        id: `future-${subKey}-${nextFuture.name}`,
        subject: sub.label,
        subjectKey: subKey,
        chapter: nextFuture.name,
        topic: `Prepare ahead: read textbook for ${nextFuture.name}`,
        type: 'future',
        durationMins: 20,
        priorityLabel: 'Secondary',
        actionLabel: 'Assign and start chapter'
      });
    }
  });

  return queue.slice(0, 4);
}
