/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { SUBJECTS } from './constants';
import { ProgressRecord, Mistake } from './types';
import { loadItem, saveItem } from './lib/utils';

// Components
import Nav from './components/Nav';
import Home from './components/Home';
import Chapters from './components/Chapters';
import Quiz from './components/Quiz';
import Results from './components/Results';
import ProgressTracker from './components/ProgressTracker';
import SmartPractice from './components/SmartPractice';
import StudyPlanner from './components/StudyPlanner';
import BoardTest from './components/BoardTest';
import AITools from './components/AITools';
import MistakeBook from './components/MistakeBook';
import ChapterHub from './components/ChapterHub';
import SamplePapers from './components/SamplePapers';
import DateSheet from './components/DateSheet';
import Toast from './components/Toast';
import BottomNav from './components/BottomNav';
import Profile from './components/Profile';
import Leaderboard from './components/Leaderboard';
import RevisionCenter from './components/RevisionCenter';
import MasteryDashboard from './components/MasteryDashboard';
import ExamReadinessDashboard from './components/ExamReadinessDashboard';
import AuthModal from './components/AuthModal';
import AdminDashboard from './components/AdminDashboard';
import { AuthProvider, useAuth } from './context/AuthContext';
import { trackVisit } from './services/analytics';

export type Screen = 
  | 'home' 
  | 'chapters' 
  | 'quiz' 
  | 'results' 
  | 'tracker' 
  | 'smart-practice' 
  | 'planner' 
  | 'board-test' 
  | 'ai-tools' 
  | 'mistake-book'
  | 'chapter-hub'
  | 'sample-papers'
  | 'date-sheet'
  | 'profile'
  | 'leaderboard'
  | 'revision-center'
  | 'mastery-dashboard'
  | 'exam-readiness'
  | 'admin-dashboard';

function AppInner() {
  const { user, profile, loading, isAuthModalOpen, setAuthModalOpen } = useAuth();
  const [screen, setScreen] = useState<Screen>('home');
  const [currentSubject, setCurrentSubject] = useState<string | null>(null);
  const [selectedChapter, setSelectedChapter] = useState<number | null>(null);
  const [quizResults, setQuizResults] = useState<any>(null);
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const [theme, setTheme] = useState<'light' | 'dark'>(() => loadItem('vidypath_theme', 'light'));

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    saveItem('vidypath_theme', theme);
  }, [theme]);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 2500);
  };

  const [selectedTopic, setSelectedTopic] = useState<string | null>(null);
  const [selectedTab, setSelectedTab] = useState<string | null>(null);

  const navigateTo = (
    s: Screen, 
    subKey: string | null = null, 
    chIdx: number | null = null, 
    topic: string | null = null,
    tab: string | null = null
  ) => {
    if (subKey) setCurrentSubject(subKey);
    if (chIdx !== null) setSelectedChapter(chIdx);
    setSelectedTopic(topic);
    setSelectedTab(tab);
    setScreen(s);
    window.scrollTo(0, 0);

    // Track active student platform interaction
    trackVisit(s);
  };

  const toggleTheme = () => setTheme(prev => prev === 'light' ? 'dark' : 'light');

  if (loading) {
    return (
      <div className="min-h-screen bg-bg text-ink flex flex-col items-center justify-center p-8 font-sans">
        <div className="flex flex-col items-center space-y-5 text-center">
          <img 
            src="/src/assets/images/vidypath_app_icon_1781441846760.jpg" 
            alt="VidyPath Logo" 
            className="w-20 h-20 rounded-[28px] shadow-2xl border-4 border-surface shadow-orange/10 transition-transform duration-500 animate-pulse"
            referrerPolicy="no-referrer"
          />
          <div className="space-y-1.5">
            <h1 className="text-2xl font-display text-ink leading-tight">VidyPath</h1>
            <p className="text-[10px] uppercase tracking-widest font-black text-ink3">Loading student session...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div key={user?.uid || 'guest'} className="min-h-screen bg-bg text-ink flex flex-col font-sans">
      <Nav 
        theme={theme} 
        toggleTheme={toggleTheme} 
        navigateTo={navigateTo} 
      />

      <main className="flex-1 overflow-x-hidden">
        {screen === 'home' && <Home navigateTo={navigateTo} showToast={showToast} />}
        {screen === 'chapters' && currentSubject && (
          <Chapters 
            subjectKey={currentSubject} 
            navigateTo={navigateTo} 
          />
        )}
        {screen === 'chapter-hub' && currentSubject && (
          <ChapterHub 
            subjectKey={currentSubject} 
            chapterIndex={selectedChapter}
            initialTab={selectedTab}
            initialTopic={selectedTopic}
            navigateTo={navigateTo}
            showToast={showToast}
          />
        )}
        {screen === 'quiz' && currentSubject && selectedChapter !== null && (
          <Quiz 
            subjectKey={currentSubject} 
            chapterIndex={selectedChapter} 
            topic={selectedTopic || undefined}
            setResults={setQuizResults}
            navigateTo={navigateTo}
            showToast={showToast}
          />
        )}
        {screen === 'results' && quizResults && (
            <Results 
              results={quizResults} 
              navigateTo={navigateTo} 
            />
        )}
        {screen === 'tracker' && (
          <ProgressTracker navigateTo={navigateTo} showToast={showToast} />
        )}
        {screen === 'smart-practice' && (
          <SmartPractice navigateTo={navigateTo} showToast={showToast} />
        )}
        {screen === 'planner' && (
          <StudyPlanner navigateTo={navigateTo} showToast={showToast} />
        )}
        {screen === 'board-test' && (
          <BoardTest navigateTo={navigateTo} showToast={showToast} />
        )}
        {screen === 'ai-tools' && (
          <AITools navigateTo={navigateTo} showToast={showToast} />
        )}
        {screen === 'mistake-book' && (
          <MistakeBook navigateTo={navigateTo} showToast={showToast} />
        )}
        {screen === 'sample-papers' && (
          <SamplePapers navigateTo={navigateTo} showToast={showToast} />
        )}
        {screen === 'date-sheet' && (
          <DateSheet navigateTo={navigateTo} showToast={showToast} />
        )}
        {screen === 'profile' && (
          <Profile navigateTo={navigateTo} showToast={showToast} />
        )}
        {screen === 'leaderboard' && (
          <Leaderboard navigateTo={navigateTo} showToast={showToast} />
        )}
        {screen === 'revision-center' && (
          <RevisionCenter navigateTo={navigateTo} showToast={showToast} />
        )}
        {screen === 'mastery-dashboard' && (
          <MasteryDashboard navigateTo={navigateTo} showToast={showToast} />
        )}
        {screen === 'exam-readiness' && (
          <ExamReadinessDashboard navigateTo={navigateTo} showToast={showToast} />
        )}
        {screen === 'admin-dashboard' && (profile?.role === 'owner' ? (
          <AdminDashboard navigateTo={navigateTo} showToast={showToast} />
        ) : (
          <div className="min-h-[50vh] flex flex-col items-center justify-center text-center p-8 bg-surface border border-border rounded-[32px] max-w-md mx-auto my-12 shadow-3xs">
            <span className="text-4xl text-orange">🔒</span>
            <h2 className="text-xl font-display font-black text-ink mt-4">Access Denied</h2>
            <p className="text-ink3 text-xs mt-1 leading-relaxed">Students are not permitted in the executive panel. Feel free to continue using student desk operations.</p>
            <button onClick={() => navigateTo('home')} className="mt-6 px-4 py-2 bg-orange hover:bg-orange/95 text-white rounded-xl text-[10px] font-black uppercase tracking-widest cursor-pointer active:scale-95 transition-all shadow-md shadow-orange/15">
              Back to Student Desk
            </button>
          </div>
        ))}
      </main>

      <Toast message={toastMsg} />
      <BottomNav currentScreen={screen} navigateTo={navigateTo} />

      {isAuthModalOpen && (
        <AuthModal onClose={() => setAuthModalOpen(false)} />
      )}
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppInner />
    </AuthProvider>
  );
}
