/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Chapter {
  name: string;
}

export interface Subject {
  key: string;
  label: string;
  icon: string;
  color: string;
  light: string;
  chapters: Chapter[];
}

export interface ProgressRecord {
  subjectKey: string;
  chapterName: string;
  bestScore: number;
  lastScore: number;
  totalOut: number;
  attempts: number;
  lastDate: string;
}

export interface Mistake {
  id: string | number;
  question: string;
  correctAnswer: string;
  subject: string;
  chapterName: string;
  practiced: boolean;
  date: string;
  questionType?: string;
  originalSolved?: boolean;
  similarSolved?: boolean;
  similarQuestion?: string;
  similarAnswer?: string;
  fixed?: boolean;
}

export interface Question {
  question: string;
  options: string[];
  answer: string;
}

export interface BoardQuestion {
  id: string;
  sectionId: string;
  sectionName: string;
  type: string;
  marks: number;
  num: number;
  isWeak: boolean;
  q: string;
  opts?: string[];
  ans?: string;
  ans_hint?: string;
  passage?: string;
}

export interface TestHistoryItem {
  id: number;
  type: string;
  subject: string;
  scored: number;
  total: number;
  pct: number;
  mcqCorrect: number;
  mcqTotal: number;
  date: string;
}

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}
