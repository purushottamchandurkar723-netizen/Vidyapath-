import React, { createContext, useContext, useEffect, useState } from 'react';
import { 
  User, 
  onAuthStateChanged, 
  signInWithPopup, 
  GoogleAuthProvider, 
  signOut,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  updateProfile
} from 'firebase/auth';
import { auth, db } from '../lib/firebase';
import { doc, setDoc, serverTimestamp, onSnapshot } from 'firebase/firestore';

export interface StudentProfile {
  name: string;
  class: string;
  school?: string;
  photoURL?: string;
  level: string;
  time: number;
  secondLanguage: string;
  streak?: { count: number; lastActiveDate: string };
  role?: 'student' | 'teacher' | 'owner';
}

export const OWNER_EMAILS = [
  'purushottamchandurkar723@gmail.com',
  'prasadchandurkar5@gmail.com',
  'dustf154@gmail.com'
];

interface AuthContextType {
  user: User | null;
  profile: StudentProfile | null;
  loading: boolean;
  isAuthModalOpen: boolean;
  setAuthModalOpen: (open: boolean) => void;
  signIn: () => Promise<void>;
  signInWithEmail: (email: string, password: string) => Promise<void>;
  signUpWithEmail: (
    email: string, 
    password: string, 
    name: string, 
    classVal: string, 
    schoolVal?: string, 
    photoURL?: string
  ) => Promise<void>;
  updateProfileCustom: (updates: Partial<StudentProfile>) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<StudentProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [isAuthModalOpen, setAuthModalOpen] = useState(false);

  useEffect(() => {
    let unsubscribeProfile: (() => void) | null = null;

    const unsubscribeAuth = onAuthStateChanged(auth, async (u) => {
      setUser(u);
      
      if (unsubscribeProfile) {
        unsubscribeProfile();
        unsubscribeProfile = null;
      }

      if (u) {
        // Automatically sync all learning progress keys from Cloud back to localStorage
        import('../services/cloudSync')
          .then(({ pullCloudSync }) => pullCloudSync(u.uid))
          .catch(err => console.error('[CloudSync] Auth state pull failed:', err));

        const userRef = doc(db, 'users', u.uid);
        
        // Listen to User Profile changes in real-time
        unsubscribeProfile = onSnapshot(userRef, async (docSnap) => {
          if (docSnap.exists()) {
            const data = docSnap.data() as StudentProfile;
            const isOwnerEmail = u.email && OWNER_EMAILS.includes(u.email.toLowerCase());
            // Auto-upgrade existing owners if missing role or matches list
            if (isOwnerEmail && data.role !== 'owner') {
              try {
                await setDoc(userRef, { 
                  role: 'owner',
                  updatedAt: serverTimestamp()
                }, { merge: true });
                data.role = 'owner';
              } catch (err) {
                console.error("Failed to auto-upgrade existing doc owner role:", err);
              }
            }
            if (!data.role) {
              data.role = 'student';
            }
            setProfile(data);
            setLoading(false);
          } else {
            // Document doesn't exist, register default profile
            const isOwnerEmail = u.email && OWNER_EMAILS.includes(u.email.toLowerCase());
            const defaultProfile: StudentProfile = {
              name: u.displayName || 'Bright Scholar',
              class: 'CBSE Class 10',
              school: '',
              photoURL: u.photoURL || '',
              level: 'average',
              time: 60,
              secondLanguage: 'hindi',
              streak: { count: 0, lastActiveDate: '' },
              role: isOwnerEmail ? 'owner' : 'student'
            };
            try {
              await setDoc(userRef, {
                ...defaultProfile,
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp()
              });
              setProfile(defaultProfile);
            } catch (err) {
              console.error("Error creating default profile document:", err);
            }
            setLoading(false);
          }
        }, (err) => {
          console.error("Profile snapshot listener error:", err);
          setLoading(false);
        });
      } else {
        setProfile(null);
        setLoading(false);
      }
    });

    return () => {
      unsubscribeAuth();
      if (unsubscribeProfile) {
        unsubscribeProfile();
      }
    };
  }, []);

  const signIn = async () => {
    const provider = new GoogleAuthProvider();
    try {
      const credential = await signInWithPopup(auth, provider);
      if (credential.user) {
        const { pushGuestToCloud, pullCloudSync } = await import('../services/cloudSync');
        await pushGuestToCloud(credential.user.uid);
        await pullCloudSync(credential.user.uid);
        window.location.reload();
      }
    } catch (error: any) {
      if (error.code === 'auth/popup-closed-by-user') {
        console.log('User closed the login popup.');
        return;
      }
      throw error;
    }
  };

  const signInWithEmail = async (email: string, password: string) => {
    const credential = await signInWithEmailAndPassword(auth, email, password);
    if (credential.user) {
      const { pushGuestToCloud, pullCloudSync } = await import('../services/cloudSync');
      await pushGuestToCloud(credential.user.uid);
      await pullCloudSync(credential.user.uid);
      window.location.reload();
    }
  };

  const signUpWithEmail = async (
    email: string,
    password: string,
    name: string,
    classVal: string,
    schoolVal?: string,
    photoURL?: string
  ) => {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const u = userCredential.user;

    // Update Auth profile representation
    await updateProfile(u, {
      displayName: name,
      photoURL: photoURL || ''
    });

    // Create user profile document in Firestore
    const userRef = doc(db, 'users', u.uid);
    const isOwnerEmail = email && OWNER_EMAILS.includes(email.toLowerCase());
    const studentProfile: StudentProfile = {
      name,
      class: classVal,
      school: schoolVal || '',
      photoURL: photoURL || '',
      level: 'average',
      time: 60,
      secondLanguage: 'hindi',
      streak: { count: 0, lastActiveDate: '' },
      role: isOwnerEmail ? 'owner' : 'student'
    };

    await setDoc(userRef, {
      ...studentProfile,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });

    // Migrate student workspace progress from legacy guest space
    const { pushGuestToCloud } = await import('../services/cloudSync');
    await pushGuestToCloud(u.uid);
    window.location.reload();
  };

  const updateProfileCustom = async (updates: Partial<StudentProfile>) => {
    if (!auth.currentUser) throw new Error('Not authenticated');
    const userRef = doc(db, 'users', auth.currentUser.uid);
    
    // Sync to auth profile if name or photoURL changes
    if (updates.name || updates.photoURL) {
      await updateProfile(auth.currentUser, {
        displayName: updates.name || auth.currentUser.displayName,
        photoURL: updates.photoURL || auth.currentUser.photoURL
      });
    }

    await setDoc(userRef, {
      ...updates,
      updatedAt: serverTimestamp()
    }, { merge: true });
  };

  const logout = async () => {
    await signOut(auth);
    window.location.reload();
  };

  return (
    <AuthContext.Provider value={{ 
      user, 
      profile, 
      loading, 
      isAuthModalOpen,
      setAuthModalOpen,
      signIn, 
      signInWithEmail, 
      signUpWithEmail, 
      updateProfileCustom, 
      logout 
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
