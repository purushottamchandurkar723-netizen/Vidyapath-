# Security Specification

## 1. Data Invariants
- `users/{userId}`: Must be owned by the user. `level` must be one of `['weak', 'average', 'strong']`. `time` must be 0-1440.
- `users/{userId}/plans/current`: Must be owned by the user.
- `users/{userId}/mistakes/{mistakeId}`: Must be owned by the user. Document IDs must be valid.

## 2. The Dirty Dozen Payloads (Target: DENY)
1. **Identity Spoofing**: Create `/users/victim_uid` as `attacker_uid`.
2. **Invalid Enum**: Set `level` to "expert" in `/users/{userId}`.
3. **Resource Exhaustion**: Send 2MB string for `question` in mistake.
4. **Orphaned Writes**: Create a plan for a `userId` that doesn't exist (handled by path matching).
5. **Unauthorized Read**: List `/users/victim_uid/mistakes` as `attacker_uid`.
6. **Shadow Fields**: Update user with `{ "level": "weak", "isAdmin": true }`.
7. **Invalid ID Poisoning**: Create mistake with ID `../../../../etc/passwd`.
8. **Type Mismatch**: Send `time: "60"` (string) instead of `60` (number).
9. **Bulk Scrape**: Try `allow list` on `/users` without UID filter.
10. **State Shortcut**: update `completed_topics` to exceed `total_topics` (schema check).
11. **PII Leak**: Read another user's email if stored in profile.
12. **Malicious Regex**: Use long recursive strings in ID fields.

## 3. Test Runner (Mock Logic)
All tests verified against `DRAFT_firestore.rules`.
